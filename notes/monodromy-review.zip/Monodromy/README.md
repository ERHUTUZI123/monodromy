# A Monodromy Computer by Path Lifting

Xiaoyang Liu · University of Waterloo · x98liu@uwaterloo.ca  
Draft — 4 November 2026

Start with `Monodromy.pdf`. This directory is the complete Lean project
for the note; its original module names and all mathematical sources are
preserved. Native execution uses fixed geometric words and finite analytic
root selection. The root degree and word table are fixed for each program;
successive covering lifts produce its conditional writes.

## Reproduce

With Lean and Lake installed, run from this directory:

```sh
lake exe cache get
lake build
lake env lean -DautoImplicit=false -DwarningAsError=true src/Audit.lean
```

Lean and external dependency caches are obtained as needed on a fresh
installation. The complete build passes (3071 Lake jobs); the strict audit
checks 1531 Monodromy declarations and their transitive dependencies,
allowing only `propext`, `Classical.choice`, and `Quot.sound`.

The pinned proof tree was checked in a newly extracted directory on macOS
15.4.1 (arm64), with a fresh project build. Only the nine external dependency
checkouts and their build caches were shared through `.lake/packages`;
every revision matched the lockfile. All three commands above were run.

This package refreshes the PDF from the current manuscript. Its 21 Lean
source and build files are byte-identical to that verified proof tree.
The refreshed PDF was rendered and inspected on all seven pages; the ZIP
contents, source fingerprint, and exact PDF bytes were checked again.

## Exact proof version

- Lean: **4.35.0**.
- Mathlib: `56a005855ea17e0b0958f73ec801ae140b0a1679`.
- Git base: `7b057301805f6763c68e33450e1874902dc2fa1d`.
- Source-tree SHA-256: `5cace91af9a10ffd4498248e56d1260892a09d2d01f8d1fcb24c1703f5b34539`.

The source has changes relative to the Git base; the fingerprint identifies
this exact proof tree. To reproduce it, sort the relative paths of all
`src/**/*.lean` files and the three root files `lakefile.lean`,
`lean-toolchain`, and `lake-manifest.json`. For each file form the UTF-8 line
`<lowercase SHA-256>  <relative path>\n` (two spaces, LF newline), concatenate
those lines, and take their SHA-256. There are 21 files in this calculation.

## Proof index

Names below have prefix `Monodromy`; module paths are under `src/Monodromy/`.

| Mathematical statement | File and principal declarations |
| --- | --- |
| Conditional winding and the coupled covering | `Logarithm.lean`: `NestedContinuation.execute_prepare`; `Continuation.lean`: `CoupledPullback.upperCovering`, `lowerCovering` |
| The three-root fiber and actual successive lifts (Definition 3.1) | `Continuation.lean`: `CoupledContinuation.prepare_surjective`, `prepare_injective`, `intermediateCurve_actual_lift`, `restrictedTrajectory_actual_lift` |
| Five operations, example, and finite routing (Proposition 3.2–Definition 4.1) | `Continuation.lean`: `CoupledContinuation.execute_A_left`, `execute_A_right`, `execute_B_left`, `execute_B_right`, `execute_control_prepare`, `example_run`, `routeDriver_eq`, `Program.step_prepare` |
| Counter and tape reductions (Proposition 4.2) | `Counter.lean`: `CounterContinuation.two_returns`, `eval_encode`, `Counter.TuringCompiler.step_firstReturn`, `Counter.Compression.step_firstReturn`; `Tape.lean`: `TapeCode.encode_injective` |
| Native universality and exact first returns (Theorem 5.1) | `FormalCompilation.lean`: `NativeTuring.native_universality`, `macroStep_iota`, `finiteMacro_iota`, `finite_eval_iota`, `result_actual_lifts` |
| Transitive axiom check | `src/Audit.lean`, importing the public facade `src/Monodromy.lean` |

The source machine enters the static compiler and correspondence proofs.
The native executor generates paths from its fixed table and returned roots.
The note identifies an optional returned state with a state or a halt signal;
its macro remains a partial operation outside the encoded configurations.

Generative AI contributed to constructions, proofs, formalization,
implementation, and writing; the human author directed the work and assumes
responsibility. The PDF contains the full disclosure and references.

Repository: https://github.com/ERHUTUZI123/monodromy

## Software notice (verbatim)

This is free and unencumbered software released into the public domain.

Anyone is free to copy, modify, publish, use, compile, sell, or
distribute this software, either in source code form or as a compiled
binary, for any purpose, commercial or non-commercial, and by any
means.

In jurisdictions that recognize copyright laws, the author or authors
of this software dedicate any and all copyright interest in the
software to the public domain. We make this dedication for the benefit
of the public at large and to the detriment of our heirs and
successors. We intend this dedication to be an overt act of
relinquishment in perpetuity of all present and future rights to this
software under copyright law.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

For more information, please refer to <https://unlicense.org>
