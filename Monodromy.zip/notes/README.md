# Mathematical note

[Manuscript](monodromy-note.tex) · [PDF](monodromy-note.pdf)

The note develops conditional winding, the three-root construction, native
operations, finite execution, and Theorem 5.1 on geometric Turing universality.
The two figures are vector diagrams written directly in LaTeX/TikZ.

## Complete review bundle

[monodromy-review.zip](monodromy-review.zip) contains the PDF, standalone
LaTeX, a concise reader guide, and the complete Lean project for this frozen
note under `formalization/`. Its human-readable `PROOFS.md` maps mathematical claims to
Lean declarations. The bundle records the Git base and exact source-snapshot
SHA-256, with pinned Lean and Mathlib dependencies. The exported project was
built in a separate directory with a fresh local build; its axiom audit passed.

## Proof companions

These files are complete, byte-identical copies of the corresponding sources
in the frozen review bundle. They are tied to source snapshot
`527fc5c027c519bdc67929b85573eaeb48fc75258a837278b1ff0df0154f73ee`,
the SHA-256 of the bundle's `formalization/SHA256.json`.

The active research sources in `src/Monodromy/` advance independently of this
note. The companions reproduce the reviewed snapshot rather than the current
research working tree. Their names follow the printed mathematical objects or
supporting section; a source proving several statements is copied once.
Appendix A and the bundle's `formalization/PROOFS.md` give the theorem mapping.

| Manuscript | Companion | Source path in the frozen project |
| --- | --- | --- |
| Section 2; covering transport and pullbacks | [2_covering_transport.lean](2_covering_transport.lean) | `src/Monodromy/Covering.lean` |
| Section 2; the two logarithmic lifts | [2_construction_conditional_winding.lean](2_construction_conditional_winding.lean) | `src/Monodromy/Logarithm.lean` |
| Definition 3.1, Proposition 3.2, Example 3.3, Definition 4.1; actual execution, native gates, routing | [3.1_definition_successive_execution.lean](3.1_definition_successive_execution.lean) | `src/Monodromy/Continuation.lean` |
| Section 4; analytic kernels used in Definition 4.1 | [4_analytic_branch_selection.lean](4_analytic_branch_selection.lean) | `src/Monodromy/Choice.lean` |
| Section 4; finite power-cover observation | [4_finite_root_observation.lean](4_finite_root_observation.lean) | `src/Monodromy/Radix.lean` |
| Proposition 4.2; counter compilation used in Theorem 5.1 | [4.2_proposition_counter_realization.lean](4.2_proposition_counter_realization.lean) | `src/Monodromy/Counter.lean` |
| Theorem 5.1; canonical half-tape coding | [5_tape_encoding.lean](5_tape_encoding.lean) | `src/Monodromy/Tape.lean` |
| Theorem 5.1; finite pointed source types | [5_finite_source_renaming.lean](5_finite_source_renaming.lean) | `src/Monodromy/FiniteSupport.lean` |
| Theorem 5.1; the complete native simulation and first returns | [5.1_theorem_native_geometric_turing_universality.lean](5.1_theorem_native_geometric_turing_universality.lean) | `src/Monodromy/FormalCompilation.lean` |
| Section 6 and Appendix A; transitive axiom audit | [6_verification_axiom_audit.lean](6_verification_axiom_audit.lean) | `src/Audit.lean` |

For reproduction, build the complete frozen project. From this repository's
root, extract it into a separate directory:

```sh
review_dir="$(mktemp -d)"
unzip notes/monodromy-review.zip -d "$review_dir"
cd "$review_dir/monodromy-review/formalization"
lake exe cache get
lake build
lake env lean -DautoImplicit=false -DwarningAsError=true src/Audit.lean
```

`lake exe cache get` obtains the pinned external dependency cache. The review
bundle's README records the toolchain, dependency versions, base Git revision,
and immutable source manifest.

[proofs.json](proofs.json) records each companion's source path and SHA-256
within this reviewed version. Prepare a new note, companions, manifests, and
bundle together when releasing a new reviewed version. The numbered files
serve as source navigation; the active library remains `src/Monodromy/`.

## Editorial revision

The note derives the product coupling before displaying the projection, draws
the actual lifted component curves, and explains each classical reduction by
its role. The simulation macro explicitly begins with a native Monodromy word
return. Analytic routing selects from a finite program table; the conditional
write comes from successive covering lifts. Observation is repeated only at
complete word returns.

The main text has six pages and the mathematical proof index has one page.
The final rendered PDF has been inspected page by page. The complete review
bundle uses the original module names and supplies the entire project; the
numbered companions are navigation copies of that same frozen source.

Separately, from this repository's root, compile the standalone note with:

```sh
cd notes
latexmk -pdf monodromy-note.tex
```

The frozen review project passed its full build (3071 Lake jobs) and strict
1531-declaration transitive axiom audit. The numbered companions were checked
against that project. These results describe the supplied review snapshot;
ongoing mainline research has its own builds and audits. Independent reviews
checked the geometry, first-return simulation, diagrams, source mapping, and
archive consistency.

The final reproduction check used the actual ZIP in a newly extracted
directory on macOS 15.4.1 (arm64), with Lean 4.35.0 and a fresh project build.
The nine external dependency checkouts and their build caches were shared
through `.lake/packages`; every checkout revision matched `lake-manifest.json`.
All three commands above ran successfully. `lake exe cache get` found the
pinned cache already present; the complete project was then rebuilt and
audited. No project build products were copied into the extracted directory.
