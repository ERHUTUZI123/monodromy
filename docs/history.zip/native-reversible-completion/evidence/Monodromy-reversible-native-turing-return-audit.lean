import «Monodromy-reversible-native-turing-return»
import Lean.Util.CollectAxioms
import Lean.Elab.Command

open Monodromy.ReversibleNativeTuring
#check complete_native_universality
#check step_firstReturn
#check FirstReturn.iterates
#check FirstReturn.inverse_iterates
#check step_return_pair
#check macroStep_iota
#print axioms complete_native_universality
#print axioms step_return_pair
#print axioms macroStep_iota
#print axioms FirstReturn.inverse_iterates

open Lean Elab Command in
run_cmd do
  let allowed : Array Name := #[`propext, `Classical.choice, `Quot.sound]
  let mut checked : Nat := 0
  for (name, _) in (← getEnv).constants.toList do
    if (`Monodromy.ReversibleNativeTuring).isPrefixOf name then
      checked := checked + 1
      for dependency in ← collectAxioms name do
        unless allowed.contains dependency do
          throwError "{name} depends on {dependency}"
  logInfo m!"Audited {checked} reversible native Turing declarations: standard axioms only."

open Lean Elab Command in
run_cmd do
  let forbidden : Array Name := #[
    `Turing.TM0.step, `Monodromy.Counter.step, `Monodromy.Counter.Recorded.step,
    `Monodromy.Counter.Reversible.step, `Monodromy.Counter.Reversible.eval,
    `Monodromy.Counter.Reversible.Action.apply, `Monodromy.Counter.Reversible.Action.enabled,
    `Monodromy.ReversibleControl.enabled, `Monodromy.CoupledContinuation.Program.indexInt,
    `Monodromy.CoupledContinuation.Word.evalInt, `Monodromy.CoupledContinuation.Program.nextInt,
    `Monodromy.ReversibleTuring.Compression.boundaryTransition,
    `Monodromy.ReversibleTuring.Compression.macroStep]
  let mut pending := [
    `Monodromy.ReversibleNativeTuring.program,
    `Monodromy.ReversibleNativeTuring.reverseProgram,
    `Monodromy.ReversibleNativeTuring.boundaryProgram,
    `Monodromy.ReversibleNativeTuring.macroStep,
    `Monodromy.ReversibleNativeTuring.reverseMacro,
    `Monodromy.CoupledContinuation.Program.runDriver]
  let environment ← getEnv
  let mut visited : NameSet := {}
  while !pending.isEmpty do
    let name := pending.head!
    pending := pending.tail!
    unless visited.contains name do
      visited := visited.insert name
      if forbidden.contains name || (`Monodromy.AnalyticComparison).isPrefixOf name then
        throwError "Native definition depends on proof-side interpreter {name}"
      if let some declaration := environment.find? name then
        if let some body := declaration.value? then
          pending := body.getUsedConstants.toList ++ pending
  for required in #[`Monodromy.CoupledContinuation.lower,
      `Monodromy.CoupledContinuation.feed, `Monodromy.CoupledContinuation.upper] do
    unless visited.contains required do
      throwError "Actual lift component missing: {required}"
  logInfo m!"Native forward/inverse macro audit: {visited.size} definitions; actual lifts present; all source interpreters absent."
