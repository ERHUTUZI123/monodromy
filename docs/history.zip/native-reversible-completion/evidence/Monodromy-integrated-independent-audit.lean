module

import Monodromy.FormalCompilation
import Lean.Util.CollectAxioms
import Lean.Elab.Command

open Lean Elab Command in
run_cmd do
  let roots : Array Name := #[
    `Monodromy.Counter.Reversible.PrimeCompression.step_firstReturn,
    `Monodromy.Counter.Reversible.PrimeCompression.marked_firstReturn,
    `Monodromy.ReversibleTuring.Compression.step_reaches,
    `Monodromy.ReversibleTuring.Compression.source_no_outgoing_of_halt,
    `Monodromy.ReversibleTuring.Compression.result_iff,
    `Monodromy.ReversibleTuring.Compression.step_retraces,
    `Monodromy.ReversibleNativeTuring.native_universality,
    `Monodromy.ReversibleNativeTuring.step_retraces]
  let allowed := #[`propext, `Classical.choice, `Quot.sound]
  for root in roots do
    unless (← getEnv).contains root do
      throwError "Missing declaration {root}"
    for dependency in ← collectAxioms root do
      unless allowed.contains dependency do
        throwError "Unexpected axiom {dependency} in {root}"
  logInfo m!"Independent theorem audit: {roots.size} complete theorem roots, standard axioms only."

open Lean Elab Command in
run_cmd do
  let roots := [
    `Monodromy.ReversibleTuring.Compression.table,
    `Monodromy.ReversibleNativeTuring.program,
    `Monodromy.ReversibleNativeTuring.reverseProgram,
    `Monodromy.CoupledContinuation.Program.advance,
    `Monodromy.CoupledContinuation.Program.runDriver]
  let forbidden : Array Name := #[
    `Turing.TM0.step, `Turing.TM1.step, `Turing.TM2.step,
    `StateTransition.eval, `Nat.Partrec.Code.eval,
    `Monodromy.Counter.step, `Monodromy.Counter.Recorded.step,
    `Monodromy.Counter.Reversible.step, `Monodromy.Counter.Reversible.eval,
    `Monodromy.Counter.Reversible.Action.apply, `Monodromy.Counter.Reversible.Action.enabled,
    `Monodromy.ReversibleControl.enabled,
    `Monodromy.CoupledContinuation.Program.indexInt,
    `Monodromy.CoupledContinuation.Program.nextInt,
    `Monodromy.CoupledContinuation.Word.evalInt]
  let env ← getEnv
  let mut pending := roots
  let mut visited : NameSet := {}
  while !pending.isEmpty do
    let root := pending.head!
    pending := pending.tail!
    unless visited.contains root do
      visited := visited.insert root
      if forbidden.contains root || (`Monodromy.AnalyticComparison).isPrefixOf root then
        throwError "Execution definition references proof-side interpreter {root}"
      if let some info := env.find? root then
        if let some body := info.value? then
          pending := body.getUsedConstants.toList ++ pending
  let required := #[
    `Monodromy.Counter.Reversible.PrimeCompression.rawTable,
    `Monodromy.Counter.Reversible.PrimeCompression.componentTable,
    `Monodromy.Counter.Reversible.PortNetwork.table,
    `Monodromy.Counter.Reversible.Radix.table,
    `Monodromy.CoupledContinuation.lower,
    `Monodromy.CoupledContinuation.feed,
    `Monodromy.CoupledContinuation.upper]
  for root in required do
    unless visited.contains root do
      throwError "Execution definition is missing expected construction {root}"
  logInfo m!"Independent definition audit: {visited.toList.length} definitions; static radix/port construction and actual successive lifts present; source interpreters absent."
