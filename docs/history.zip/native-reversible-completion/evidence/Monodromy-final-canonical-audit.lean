module

import Monodromy
import Lean.Util.CollectAxioms
import Lean.Elab.Command

open Lean Elab Command in
run_cmd do
  let environment ← getEnv
  let roots : Array Name := #[
    `Monodromy.Counter.Reversible.PrimeCompression.marked_firstReturn,
    `Monodromy.ReversibleCompilation.marked_firstReturn,
    `Monodromy.ReversibleTuring.Compression.step_firstReturn,
    `Monodromy.ReversibleNativeTuring.step_firstReturn,
    `Monodromy.ReversibleNativeTuring.step_return_pair,
    `Monodromy.ReversibleNativeTuring.FirstReturn.iterates,
    `Monodromy.ReversibleNativeTuring.FirstReturn.inverse_iterates,
    `Monodromy.ReversibleNativeTuring.macroStep_iota,
    `Monodromy.ReversibleNativeTuring.finite_run_actual_lifts,
    `Monodromy.ReversibleNativeTuring.native_universality,
    `Monodromy.CoupledContinuation.Program.reverseReturn_of_firstReturn,
    `Monodromy.ReversibleReturn.firstReturn_of_relation,
    `Monodromy.ReversibleReturn.inverse_firstReturn]
  for root in roots do
    unless (environment.find? root).isSome do
      throwError "Missing final theorem root {root}"
  let allowed := #[`propext, `Quot.sound, `Classical.choice]
  let mut checked : Nat := 0
  for (name, _) in environment.constants.toList do
    if (`Monodromy).isPrefixOf name then
      checked := checked + 1
      for dependency in ← collectAxioms name do
        unless allowed.contains dependency do
          throwError "Unexpected axiom {dependency} in {name}"
  logInfo m!"Canonical-only independent axiom audit: {checked} declarations; all {roots.size} final theorem roots present; standard axioms only."

open Lean Elab Command in
run_cmd do
  let forbidden : Array Name := #[
    `Turing.TM0.step, `Turing.TM1.step, `Turing.TM2.step,
    `StateTransition.eval, `Nat.Partrec.Code.eval,
    `Monodromy.Counter.step, `Monodromy.Counter.Recorded.step,
    `Monodromy.Counter.Reversible.step, `Monodromy.Counter.Reversible.eval,
    `Monodromy.Counter.Reversible.Action.apply, `Monodromy.Counter.Reversible.Action.enabled,
    `Monodromy.ReversibleControl.enabled,
    `Monodromy.CoupledContinuation.Program.indexInt,
    `Monodromy.CoupledContinuation.Program.nextInt,
    `Monodromy.CoupledContinuation.Word.evalInt]
  let environment ← getEnv
  let mut pending := [
    `Monodromy.ReversibleTuring.Compression.table,
    `Monodromy.ReversibleTuring.Compression.mark,
    `Monodromy.ReversibleNativeTuring.program,
    `Monodromy.ReversibleNativeTuring.reverseProgram,
    `Monodromy.ReversibleNativeTuring.boundaryProgram,
    `Monodromy.CoupledContinuation.Program.advance,
    `Monodromy.CoupledContinuation.Program.runDriver]
  for root in pending do
    unless (environment.find? root).isSome do
      throwError "Missing static native root {root}"
  let mut visited : NameSet := {}
  while !pending.isEmpty do
    let name := pending.head!
    pending := pending.tail!
    unless visited.contains name do
      visited := visited.insert name
      if forbidden.contains name || (`Monodromy.AnalyticComparison).isPrefixOf name then
        throwError "Static native execution contains an interpreter {name}"
      if let some information := environment.find? name then
        if let some body := information.value? then
          pending := body.getUsedConstants.toList ++ pending
  let required := #[
    `Monodromy.ReversibleTuring.Compression.sourceMark,
    `Monodromy.Counter.Reversible.PrimeCompression.rawTable,
    `Monodromy.Counter.Reversible.PrimeCompression.componentTable,
    `Monodromy.Counter.Reversible.PortNetwork.relationLink,
    `Monodromy.Counter.Reversible.Radix.table,
    `Monodromy.CoupledContinuation.lower,
    `Monodromy.CoupledContinuation.feed,
    `Monodromy.CoupledContinuation.upper]
  for name in required do
    unless visited.contains name do
      throwError "Static native execution omits required construction {name}"
  logInfo m!"Canonical-only independent static audit: {visited.toList.length} dependency nodes; finite marks/radix/ports and actual successive lifts present; source interpreters and all complete evaluators absent."

open Lean Elab Command in
run_cmd do
  let forbidden : Array Name := #[
    `Turing.TM0.step, `Turing.TM1.step, `Turing.TM2.step, `Nat.Partrec.Code.eval,
    `Monodromy.Counter.step, `Monodromy.Counter.Recorded.step,
    `Monodromy.Counter.Reversible.step, `Monodromy.Counter.Reversible.eval,
    `Monodromy.Counter.Reversible.Action.apply, `Monodromy.Counter.Reversible.Action.enabled,
    `Monodromy.ReversibleControl.enabled,
    `Monodromy.CoupledContinuation.Program.indexInt,
    `Monodromy.CoupledContinuation.Program.nextInt,
    `Monodromy.CoupledContinuation.Word.evalInt]
  let environment ← getEnv
  let mut pending := [
    `Monodromy.ReversibleNativeTuring.macroStep,
    `Monodromy.ReversibleNativeTuring.reverseMacro]
  let mut visited : NameSet := {}
  while !pending.isEmpty do
    let name := pending.head!
    pending := pending.tail!
    unless visited.contains name do
      visited := visited.insert name
      if forbidden.contains name || (`Monodromy.AnalyticComparison).isPrefixOf name then
        throwError "Native first-return evaluator contains a source interpreter {name}"
      if let some information := environment.find? name then
        if let some body := information.value? then
          pending := body.getUsedConstants.toList ++ pending
  for name in #[
      `Monodromy.ReversibleCompilation.nativeMacro,
      `Monodromy.CoupledContinuation.Program.reverseReturn,
      `Monodromy.CoupledContinuation.Program.boundaryInverse,
      `Monodromy.CoupledContinuation.Program.eval,
      `Monodromy.CoupledContinuation.Program.step,
      `Monodromy.CoupledContinuation.Program.advance,
      `Monodromy.ReversibleTuring.Compression.mark,
      `Monodromy.CoupledContinuation.lower,
      `Monodromy.CoupledContinuation.feed,
      `Monodromy.CoupledContinuation.upper] do
    unless visited.contains name do
      throwError "Native first-return evaluator omits required component {name}"
  logInfo m!"Canonical-only independent macro audit: {visited.toList.length} dependency nodes; only native word execution is iterated to finite internal marks; source interpreters absent."
