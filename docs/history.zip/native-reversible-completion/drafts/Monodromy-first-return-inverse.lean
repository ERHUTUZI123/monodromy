module

public import Monodromy.FormalCompilation

@[expose] public section

namespace Monodromy.ReversibleReturn

variable {State : Type*}

/-- A relational execution avoiding the boundary is a positive first return of its advance. -/
theorem firstReturn_of_relation {advance : State → State} {boundary : State → Prop}
    {transition : State → State → Prop}
    (executes : ∀ {left right}, transition left right → advance left = right)
    {first after last : State} (initial : transition first after)
    (interior : Relation.ReflTransGen
      (fun left right => transition left right ∧ ¬ boundary left) after last)
    (marked_first : boundary first) (marked_last : boundary last) :
    FirstReturn advance boundary first last := by
  have traced : ∃ count : ℕ, 0 < count ∧ advance^[count] first = last ∧
      ∀ middle : ℕ, 0 < middle → middle < count → ¬ boundary (advance^[middle] first) := by
    clear marked_first marked_last
    induction interior with
    | refl =>
        refine ⟨1, by omega, executes initial, ?_⟩
        intro middle positive before
        omega
    | @tail left right _ edge previous =>
        obtain ⟨count, positive, reached, inside⟩ := previous
        refine ⟨count + 1, by omega, ?_, ?_⟩
        · rw [Function.iterate_succ_apply', reached]
          exact executes edge.1
        · intro middle after_start before_end
          by_cases before : middle < count
          · exact inside middle after_start before
          · have equal : middle = count := by omega
            rw [equal, reached]
            exact edge.2
  obtain ⟨count, positive, reached, inside⟩ := traced
  exact ⟨count, positive, reached, marked_first, marked_last, inside⟩

/-- A left inverse retraces any first return, with exactly the same return length. -/
theorem inverse_firstReturn {advance backward : State → State} {boundary : State → Prop}
    (inverse : Function.LeftInverse backward advance) {first last : State}
    (run : FirstReturn advance boundary first last) :
    FirstReturn backward boundary last first := by
  obtain ⟨count, positive, reached, marked_first, marked_last, inside⟩ := run
  have retraced (round : ℕ) (bound : round ≤ count) :
      backward^[round] last = advance^[count - round] first := by
    have parts : round + (count - round) = count := by omega
    have decompose : last = advance^[round] (advance^[count - round] first) := by
      rw [← Function.iterate_add_apply, parts]
      exact reached.symm
    rw [decompose]
    exact (inverse.iterate round) _
  refine ⟨count, positive, ?_, marked_last, marked_first, ?_⟩
  · simpa only [Nat.sub_self, Function.iterate_zero_apply] using retraced count (by omega)
  · intro middle after_start before_end marked
    rw [retraced middle (by omega)] at marked
    exact inside (count - middle) (by omega) (by omega) marked

end Monodromy.ReversibleReturn
