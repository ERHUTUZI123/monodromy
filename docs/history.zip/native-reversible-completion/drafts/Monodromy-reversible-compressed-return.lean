import Monodromy.FormalCompilation

/-!
The compressed reversible machine detects Turing returns from finite control.
Its macro executes the same two-counter table with a finite-control stopping
marker. The source transition is used only in correspondence proofs.
-/

noncomputable section

namespace Monodromy.ReversibleTuring.Compression

open Turing Counter.Reversible

variable (a q : ℕ) [NeZero a] [NeZero q]

/-- The original recording boundary depends only on its finite control position. -/
def sourceMark (machine : TM0.Machine (Fin a) (Fin q))
    (position : Fin (Recording.size (RecordedTuring.size a q machine))) : Bool :=
  decide (Recording.Marked (n := 2) (NativeTuring.counterMark a q machine)
    (position, fun _ => 0))

theorem sourceMark_true_iff (machine : TM0.Machine (Fin a) (Fin q))
    (state : State 4 (Recording.size (RecordedTuring.size a q machine))) :
    sourceMark a q machine state.1 = true ↔ ReversibleTuring.Boundary a q machine state := by
  change decide (Recording.Marked (n := 2) (NativeTuring.counterMark a q machine)
    (state.1, fun _ => 0)) = true ↔
      Recording.Marked (n := 2) (NativeTuring.counterMark a q machine) (state.1, fun _ => 0)
  exact ⟨of_decide_eq_true, decide_eq_true⟩

theorem sourceMark_false_iff (machine : TM0.Machine (Fin a) (Fin q))
    (state : State 4 (Recording.size (RecordedTuring.size a q machine))) :
    sourceMark a q machine state.1 = false ↔ ¬ ReversibleTuring.Boundary a q machine state := by
  rw [← sourceMark_true_iff a q machine state]
  cases sourceMark a q machine state.1 <;> decide

/-- Marked source boundaries inside the actual compressed control graph. -/
def Boundary (machine : TM0.Machine (Fin a) (Fin q))
    (state : State 2 (size a q machine)) : Prop :=
  PrimeCompression.Marked basis (ReversibleTuring.table a q machine)
    (source_deterministic a q machine) (source_targetCompatible a q machine)
    (sourceMark a q machine) state

instance boundary_decidable (machine : TM0.Machine (Fin a) (Fin q))
    (state : State 2 (size a q machine)) : Decidable (Boundary a q machine state) := by
  unfold Boundary PrimeCompression.Marked
  refine @Fintype.decidableExistsFintype
    (Fin (Recording.size (RecordedTuring.size a q machine))) _ ?_ inferInstance
  intro position
  dsimp only
  exact @instDecidableAnd _ _ (instDecidableEqFin _ _ _) (instDecidableEqBool _ _)

/-- The marker used by a native finite-root table has no memory input. -/
def mark (machine : TM0.Machine (Fin a) (Fin q)) (position : Fin (size a q machine)) : Bool :=
  decide (Boundary a q machine (position, fun _ => 0))

theorem mark_true_iff (machine : TM0.Machine (Fin a) (Fin q))
    (state : State 2 (size a q machine)) :
    mark a q machine state.1 = true ↔ Boundary a q machine state := by
  change decide (Boundary a q machine (state.1, fun _ => 0)) = true ↔
    Boundary a q machine (state.1, fun _ => 0)
  exact ⟨of_decide_eq_true, decide_eq_true⟩

theorem mark_false_iff (machine : TM0.Machine (Fin a) (Fin q))
    (state : State 2 (size a q machine)) :
    mark a q machine state.1 = false ↔ ¬ Boundary a q machine state := by
  rw [← mark_true_iff a q machine state]
  cases mark a q machine state.1 <;> decide

theorem boundary_encode (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    Boundary a q machine (encode a q machine state history) := by
  apply (PrimeCompression.marked_encode_iff basis (ReversibleTuring.table a q machine)
    (source_deterministic a q machine) (source_targetCompatible a q machine)
    (sourceMark a q machine) _).mpr
  exact (sourceMark_true_iff a q machine (ReversibleTuring.encode a q machine state history)).mpr
    (ReversibleTuring.boundary_encode a q machine state history)

/-- Each live Turing step reaches its next marked boundary with the same retained history. -/
theorem step_firstReturn (machine : TM0.Machine (Fin a) (Fin q))
    {first last : TM0.Cfg (Fin a) (Fin q)} (transition : TM0.step machine first = some last)
    (history : ℕ) :
    ∃ finalHistory, history < finalHistory ∧
      PrimeCompression.MarkedFirstReturn basis (ReversibleTuring.table a q machine)
        (source_deterministic a q machine) (source_targetCompatible a q machine)
        (sourceMark a q machine)
        (encode a q machine first history) (encode a q machine last finalHistory) := by
  obtain ⟨finalHistory, grew, first_marked, last_marked, middle, initial, rest⟩ :=
    ReversibleTuring.step_firstReturn a q machine transition history
  have source_rest : Relation.ReflTransGen
      (fun current next : State 4 (Recording.size (RecordedTuring.size a q machine)) =>
        step (ReversibleTuring.table a q machine) current = some next ∧
          sourceMark a q machine current.1 = false)
      middle (ReversibleTuring.encode a q machine last finalHistory) := by
    exact Relation.ReflTransGen.mono
      (fun current _ edge => ⟨edge.1, (sourceMark_false_iff a q machine current).mpr edge.2⟩)
      _ _ rest
  have first_valid : Recording.Valid (NativeTuring.source2 a q machine)
      (ReversibleTuring.encode a q machine first history) :=
    Recording.valid_encode (NativeTuring.source2 a q machine)
      (RecordedTuring.counterEncode a q machine first) history
  have actual := PrimeCompression.marked_firstReturn basis (ReversibleTuring.table a q machine)
    (source_deterministic a q machine) (source_targetCompatible a q machine)
    (Recording.unitShift (NativeTuring.source2 a q machine)) (sourceMark a q machine)
    (Recording.Valid (NativeTuring.source2 a q machine))
    (Recording.stable (NativeTuring.source2 a q machine))
    (Recording.valid_nonnegative (NativeTuring.source2 a q machine)) initial source_rest
    ((sourceMark_true_iff a q machine (ReversibleTuring.encode a q machine first history)).mpr first_marked)
    ((sourceMark_true_iff a q machine (ReversibleTuring.encode a q machine last finalHistory)).mpr last_marked)
    first_valid
  exact ⟨finalHistory, grew, actual⟩

/-- Stop the same transition table at its finite marked control positions. -/
def boundaryTransition (machine : TM0.Machine (Fin a) (Fin q))
    (state : State 2 (size a q machine)) : Option (State 2 (size a q machine)) :=
  if Boundary a q machine state then none else step (table a q machine) state

private theorem boundaryTransition_stops (machine : TM0.Machine (Fin a) (Fin q))
    {state : State 2 (size a q machine)} (marked : Boundary a q machine state) :
    boundaryTransition a q machine state = none := by
  simp only [boundaryTransition, ite_eq_left marked]

private theorem internal_marked_reaches (machine : TM0.Machine (Fin a) (Fin q))
    {first last : State 2 (size a q machine)}
    (run : PrimeCompression.InternalMarkedReaches basis (ReversibleTuring.table a q machine)
      (source_deterministic a q machine) (source_targetCompatible a q machine)
      (sourceMark a q machine) first last) :
    StateTransition.Reaches (boundaryTransition a q machine) first last := by
  induction run with
  | refl => exact Relation.ReflTransGen.refl
  | @tail first last _ edge previous =>
      apply previous.tail
      change (if Boundary a q machine first then none else step (table a q machine) first) = some last
      have unmarked : ¬ Boundary a q machine first := edge.2
      rw [ite_eq_right unmarked]
      exact edge.1

/-- Execute one actual step, then run the same table with its finite marker stop rule. -/
def macroStep (machine : TM0.Machine (Fin a) (Fin q)) (state : State 2 (size a q machine)) :
    Part (Option (State 2 (size a q machine))) :=
  match step (table a q machine) state with
  | none => Part.some none
  | some next => (StateTransition.eval (boundaryTransition a q machine) next).map some

theorem macroStep_halt (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) (halted : TM0.step machine state = none) :
    macroStep a q machine (encode a q machine state history) = Part.some none := by
  rw [macroStep, step_halt a q machine state history halted]

/-- The macro preserves the full next configuration and the actual strictly larger history. -/
theorem macroStep_live (machine : TM0.Machine (Fin a) (Fin q))
    {first last : TM0.Cfg (Fin a) (Fin q)} (transition : TM0.step machine first = some last)
    (history : ℕ) :
    ∃ finalHistory, history < finalHistory ∧
      macroStep a q machine (encode a q machine first history) =
        Part.some (some (encode a q machine last finalHistory)) := by
  obtain ⟨finalHistory, grew, _, marked, next, initial, rest⟩ :=
    step_firstReturn a q machine transition history
  have completed : StateTransition.eval (boundaryTransition a q machine) next =
      Part.some (encode a q machine last finalHistory) := by
    apply Part.eq_some_iff.mpr
    exact StateTransition.mem_eval.mpr
      ⟨internal_marked_reaches a q machine rest, boundaryTransition_stops a q machine marked⟩
  refine ⟨finalHistory, grew, ?_⟩
  change step (table a q machine) (encode a q machine first history) = some next at initial
  simp only [macroStep, initial, completed, Part.map_some]

/-- Source optional results occur only in this correctness statement, after table execution. -/
theorem macroStep_encode (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    ∃ finalHistory,
      macroStep a q machine (encode a q machine state history) =
        Part.some ((TM0.step machine state).map (fun next => encode a q machine next finalHistory)) ∧
      (TM0.step machine state ≠ none → history < finalHistory) := by
  cases transition : TM0.step machine state with
  | none =>
      refine ⟨history, ?_, ?_⟩
      · simpa only [transition, Option.map_none] using macroStep_halt a q machine state history transition
      · simp
  | some next =>
      obtain ⟨finalHistory, grew, result⟩ := macroStep_live a q machine transition history
      exact ⟨finalHistory, result, fun _ => grew⟩

end Monodromy.ReversibleTuring.Compression
