module

public import Monodromy.FormalCompilation

@[expose] public section

namespace Monodromy.CoupledContinuation.Program

variable {degree : ℕ} [NeZero degree]

theorem advance_of_step (program : Program degree) {first last : Memory}
    (transition : program.step first = some last) : program.advance first = last := by
  unfold step at transition
  split at transition
  · contradiction
  · exact Option.some.inj transition

end Monodromy.CoupledContinuation.Program
