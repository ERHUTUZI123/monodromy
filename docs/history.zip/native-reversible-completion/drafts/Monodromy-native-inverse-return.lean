module

public import Monodromy.FormalCompilation

@[expose] public section

namespace Monodromy.CoupledContinuation.Program

noncomputable section

variable {degree : ℕ} [NeZero degree]

/-- Run the inverse word table, stopping at the same finite root marks. -/
def boundaryInverse (backward boundary : Program degree) : Program degree :=
  { backward with stop := boundary.stop }

/-- Leave the current mark once, then use the inverse words until the next mark. -/
def reverseReturn (backward boundary : Program degree) (state : Memory) : Part Memory :=
  (boundaryInverse backward boundary).eval (backward.advance state)

/-- The same marked inverse execution recovers the start of any native first-return trace. -/
theorem reverseReturn_of_firstReturn (forward backward boundary : Program degree)
    (inverse : Function.LeftInverse backward.advance forward.advance)
    {first after last : Memory} (initial : forward.step first = some after)
    (interior : Relation.ReflTransGen
      (fun left right => forward.step left = some right ∧ boundary.haltSignal left ≠ 1)
      after last)
    (marked : boundary.haltSignal first = 1) :
    reverseReturn backward boundary last = Part.some first := by
  have undo : ∀ {left right}, forward.step left = some right → backward.advance right = left := by
    intro left right edge
    unfold step at edge
    split at edge
    · contradiction
    · exact (congrArg backward.advance (Option.some.inj edge)).symm.trans (inverse left)
  have retraced : ∃ previous, backward.advance last = previous ∧
      StateTransition.Reaches (boundaryInverse backward boundary).step previous first := by
    induction interior with
    | refl => exact ⟨first, undo initial, Relation.ReflTransGen.refl⟩
    | @tail left right _ edge previous =>
        obtain ⟨before, arrived, rest⟩ := previous
        refine ⟨left, undo edge.1, Relation.ReflTransGen.head ?_ rest⟩
        change (if boundary.haltSignal left = 1 then none else some (backward.advance left)) =
          some before
        rw [ite_eq_right edge.2, arrived]
  obtain ⟨previous, arrived, rest⟩ := retraced
  unfold reverseReturn
  rw [arrived]
  apply Part.eq_some_iff.mpr
  exact StateTransition.mem_eval.mpr ⟨rest, by
    change (if boundary.haltSignal first = 1 then none else some (backward.advance first)) = none
    rw [ite_eq_left marked]⟩

end

end Monodromy.CoupledContinuation.Program
