import Monodromy.Counter

/-! Finite source marks lift to first returns of the same native word table. -/

noncomputable section

namespace Monodromy.ReversibleCompilation

open Counter.Reversible CoupledContinuation

variable {q e : ℕ} [NeZero q]

/-- Only source vertices are observed; edge ports carry no source mark. -/
def markSource (mark : Fin q → Bool) (address : Fin (q + e)) : Bool :=
  match finSumFinEquiv.symm address with
  | .inl position => mark position
  | .inr _ => false

omit [NeZero q] in
@[simp] theorem markSource_source (mark : Fin q → Bool) (position : Fin q) :
    markSource (e := e) mark (Fin.castAdd e position) = mark position := by
  simp [markSource]

/-- The existing native words with a different finite stop table. -/
def markedProgram (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (mark : Fin q → Bool) : Program (11 * (q + e)) :=
  StagedProgram.markedCompile 11 (q + e) (stages table deterministic compatible) (markSource mark)

@[simp] theorem markedProgram_advance (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (mark : Fin q → Bool) :
    (markedProgram table deterministic compatible mark).advance =
      (haltingProgram table deterministic compatible).advance := rfl

/-- A source return is detected by the actual finite root observation. -/
def MarkedBoundary (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (mark : Fin q → Bool) (state : Memory) : Prop :=
  (markedProgram table deterministic compatible mark).haltSignal state = 1

theorem markedBoundary_iota_iff (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (mark : Fin q → Bool) (state : State 2 q) :
    MarkedBoundary table deterministic compatible mark (iota (e := e) state) ↔ mark state.1 = true := by
  have observed := StagedProgram.halt_embed_iff 11 (q + e)
    (stages table deterministic compatible) (markSource mark)
    (state.2 0) (state.2 1) 0 (Fin.castAdd e state.1) 0
  simpa only [MarkedBoundary, markedProgram, iota, sourcePoint, point, mul_zero, zero_add,
    true_and, markSource_source] using observed

private theorem stopped_phase (stages : Fin 11 → Program (q + e)) (bits : Fin (q + e) → Bool)
    (state : Memory) (stopped : (StagedProgram.markedCompile 11 (q + e) stages bits).haltSignal state = 1) :
    StagedProgram.PhaseBoundary 11 state := by
  obtain ⟨⟨base, phase⟩, rfl⟩ := (StagedProgram.packedEquiv 11).surjective state
  apply (StagedProgram.phaseBoundary_embed_iff 11 phase base).mpr
  by_contra nonzero
  have inactive : (StagedProgram.markedCompile 11 (q + e) stages bits).step
      (StagedProgram.embed 11 phase base) = none := by
    exact ite_eq_left stopped
  have active := StagedProgram.interior_step 11 (q + e) stages bits phase nonzero base
  rw [inactive] at active
  cases active

theorem markedBoundary_phase (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (mark : Fin q → Bool) {state : Memory}
    (marked : MarkedBoundary table deterministic compatible mark state) :
    StagedProgram.PhaseBoundary 11 state :=
  stopped_phase (stages table deterministic compatible) (markSource mark) state marked

def NativeInternalStep (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (mark : Fin q → Bool) (first last : Memory) : Prop :=
  (haltingProgram table deterministic compatible).step first = some last ∧
    ¬ MarkedBoundary table deterministic compatible mark first

abbrev NativeInternalReaches (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (mark : Fin q → Bool) :=
  Relation.ReflTransGen (NativeInternalStep table deterministic compatible mark)

def NativeFirstReturn (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (mark : Fin q → Bool) (first last : Memory) : Prop :=
  MarkedBoundary table deterministic compatible mark first ∧
  MarkedBoundary table deterministic compatible mark last ∧
  ∃ next, (haltingProgram table deterministic compatible).step first = some next ∧
    NativeInternalReaches table deterministic compatible mark next last

/-- After departure, one source edge visits no earlier packed phase-zero boundary. -/
theorem counter_departure (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (mark : Fin q → Bool) {first last : State 2 q}
    (transition : Counter.Reversible.step table first = some last) :
    ∃ next, (haltingProgram table deterministic compatible).step (iota (e := e) first) = some next ∧
      NativeInternalReaches table deterministic compatible mark next (iota (e := e) last) := by
  let P := haltingProgram table deterministic compatible
  let initial := iota (e := e) first
  obtain ⟨cycle, _, _, interior, _⟩ := step_firstReturn table deterministic compatible transition
  obtain ⟨edge, enabled, _⟩ := (Counter.Reversible.step_iff table deterministic).mp transition
  have initial_active : P.haltSignal initial ≠ 1 := by
    intro stopped
    exact ((haltSignal_iota_iff table deterministic compatible first).mp stopped) ⟨edge, enabled.1⟩
  have active (round : ℕ) (before : round < 11) :
      P.step (P.advance^[round] initial) = some (P.advance^[round + 1] initial) := by
    rw [Function.iterate_succ_apply']
    apply ite_eq_right
    by_cases zero : round = 0
    · subst round
      exact initial_active
    · intro stopped
      exact interior round (by omega) before
        (stopped_phase (stages table deterministic compatible) (haltMark table)
          (P.advance^[round] initial) stopped)
  have unmarked (round : ℕ) (positive : 0 < round) (before : round < 11) :
      ¬ MarkedBoundary table deterministic compatible mark (P.advance^[round] initial) := by
    intro marked
    exact interior round positive before (markedBoundary_phase table deterministic compatible mark marked)
  have middle (round : ℕ) (bound : round ≤ 10) :
      NativeInternalReaches table deterministic compatible mark (P.advance initial)
        (P.advance^[round + 1] initial) := by
    induction round with
    | zero => exact Relation.ReflTransGen.refl
    | succ round previous =>
        exact (previous (by omega)).tail ⟨active (round + 1) (by omega),
          unmarked (round + 1) (by omega) (by omega)⟩
  refine ⟨P.advance initial, ?_, ?_⟩
  · simpa only [Nat.zero_add, Function.iterate_zero_apply, Function.iterate_one] using active 0 (by decide)
  · have inside := middle 10 (by decide)
    rw [cycle] at inside
    exact inside

/-- An unmarked source instruction executes entirely inside the native marked boundary. -/
theorem counter_internal_step (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (mark : Fin q → Bool) {first last : State 2 q}
    (transition : Counter.Reversible.step table first = some last) (unmarked : mark first.1 = false) :
    NativeInternalReaches table deterministic compatible mark (iota (e := e) first) (iota (e := e) last) := by
  obtain ⟨next, initial, rest⟩ := counter_departure table deterministic compatible mark transition
  apply Relation.ReflTransGen.head (b := next) ?_ rest
  refine ⟨initial, ?_⟩
  rw [markedBoundary_iota_iff, unmarked]
  decide

theorem counter_internal_reaches (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (mark : Fin q → Bool) {first last : State 2 q}
    (run : Relation.ReflTransGen (fun first last : State 2 q =>
      Counter.Reversible.step table first = some last ∧ mark first.1 = false) first last) :
    NativeInternalReaches table deterministic compatible mark (iota (e := e) first) (iota (e := e) last) := by
  induction run with
  | refl => exact Relation.ReflTransGen.refl
  | tail _ edge previous =>
      exact previous.trans (counter_internal_step table deterministic compatible mark edge.1 edge.2)

/-- A finite marked counter return is the corresponding first native marked return. -/
theorem marked_firstReturn (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (mark : Fin q → Bool) {first middle last : State 2 q}
    (initial : Counter.Reversible.step table first = some middle)
    (rest : Relation.ReflTransGen (fun first last : State 2 q =>
      Counter.Reversible.step table first = some last ∧ mark first.1 = false) middle last)
    (first_marked : mark first.1 = true) (last_marked : mark last.1 = true) :
    NativeFirstReturn table deterministic compatible mark (iota (e := e) first) (iota (e := e) last) := by
  obtain ⟨next, head, inside⟩ := counter_departure table deterministic compatible mark initial
  exact ⟨(markedBoundary_iota_iff table deterministic compatible mark first).mpr first_marked,
    (markedBoundary_iota_iff table deterministic compatible mark last).mpr last_marked,
    next, head, inside.trans (counter_internal_reaches table deterministic compatible mark rest)⟩

/-- The marked evaluator retains the original words on every unmarked original step. -/
theorem marked_step_of_original (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (mark : Fin q → Bool) {first last : Memory}
    (transition : (haltingProgram table deterministic compatible).step first = some last)
    (unmarked : ¬ MarkedBoundary table deterministic compatible mark first) :
    (markedProgram table deterministic compatible mark).step first = some last := by
  change (if (markedProgram table deterministic compatible mark).haltSignal first = 1 then none
    else some ((markedProgram table deterministic compatible mark).advance first)) = some last
  change (markedProgram table deterministic compatible mark).haltSignal first ≠ 1 at unmarked
  rw [ite_eq_right unmarked, markedProgram_advance]
  unfold Program.step at transition
  split_ifs at transition
  exact transition

theorem internal_marked_reaches (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (mark : Fin q → Bool) {first last : Memory}
    (run : NativeInternalReaches table deterministic compatible mark first last) :
    StateTransition.Reaches (markedProgram table deterministic compatible mark).step first last := by
  induction run with
  | refl => exact Relation.ReflTransGen.refl
  | tail _ edge previous =>
      exact previous.tail (marked_step_of_original table deterministic compatible mark edge.1 edge.2)

/-- Execute the original native table once, then the same words until the next finite root mark. -/
def nativeMacro (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (mark : Fin q → Bool) (state : Memory) : Part (Option Memory) :=
  match (haltingProgram table deterministic compatible).step state with
  | none => Part.some none
  | some next => ((markedProgram table deterministic compatible mark).eval next).map some

theorem nativeMacro_of_halt (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (mark : Fin q → Bool) (state : Memory)
    (halted : (haltingProgram table deterministic compatible).step state = none) :
    nativeMacro table deterministic compatible mark state = Part.some none := by
  rw [nativeMacro, halted]

theorem nativeMacro_of_firstReturn (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (mark : Fin q → Bool) {first last : Memory}
    (run : NativeFirstReturn table deterministic compatible mark first last) :
    nativeMacro table deterministic compatible mark first = Part.some (some last) := by
  obtain ⟨_, marked, next, head, rest⟩ := run
  have completed : (markedProgram table deterministic compatible mark).eval next = Part.some last := by
    apply Part.eq_some_iff.mpr
    exact StateTransition.mem_eval.mpr ⟨internal_marked_reaches table deterministic compatible mark rest,
      ite_eq_left marked⟩
  simp only [nativeMacro, head, completed, Part.map_some]

end Monodromy.ReversibleCompilation
