import «Monodromy-reversible-native-marked»
import «Monodromy-reversible-compressed-return»
import «Monodromy-native-inverse-return»
import «Monodromy-first-return-inverse»
import «Monodromy-program-step-advance»

noncomputable section

namespace Monodromy.ReversibleNativeTuring

open Turing CoupledContinuation ReversibleTuring

variable (a q : ℕ) [NeZero a] [NeZero q]

/-- The same native words, with finite root marks for complete Turing steps. -/
def boundaryProgram (machine : TM0.Machine (Fin a) (Fin q)) :
    Program (11 * (Compression.size a q machine + Compression.edges a q machine)) :=
  ReversibleCompilation.markedProgram (Compression.table a q machine)
    (Compression.deterministic a q machine) (Compression.targetCompatible a q machine)
    (Compression.mark a q machine)

def Boundary (machine : TM0.Machine (Fin a) (Fin q)) (state : Memory) : Prop :=
  (boundaryProgram a q machine).haltSignal state = 1

theorem boundary_iota (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    Boundary a q machine (iota a q machine state history) := by
  apply (ReversibleCompilation.markedBoundary_iota_iff (Compression.table a q machine)
    (Compression.deterministic a q machine) (Compression.targetCompatible a q machine)
    (Compression.mark a q machine) _).mpr
  exact (Compression.mark_true_iff a q machine _).mpr (Compression.boundary_encode a q machine state history)

def FirstReturn (machine : TM0.Machine (Fin a) (Fin q)) (first last : Memory) : Prop :=
  ReversibleCompilation.NativeFirstReturn (Compression.table a q machine)
    (Compression.deterministic a q machine) (Compression.targetCompatible a q machine)
    (Compression.mark a q machine) first last

/-- A source step is precisely the next marked native word return, with its actual history. -/
theorem step_firstReturn (machine : TM0.Machine (Fin a) (Fin q))
    {first last : TM0.Cfg (Fin a) (Fin q)} (transition : TM0.step machine first = some last)
    (history : ℕ) :
    ∃ finalHistory, history < finalHistory ∧
      FirstReturn a q machine (iota a q machine first history) (iota a q machine last finalHistory) := by
  obtain ⟨finalHistory, grew, first_marked, last_marked, middle, initial, rest⟩ :=
    Compression.step_firstReturn a q machine transition history
  have inside : Relation.ReflTransGen
      (fun current next : Counter.Reversible.State 2 (Compression.size a q machine) =>
        Counter.Reversible.step (Compression.table a q machine) current = some next ∧
          Compression.mark a q machine current.1 = false)
      middle (Compression.encode a q machine last finalHistory) :=
    Relation.ReflTransGen.mono
      (fun current _ edge => ⟨edge.1, (Compression.mark_false_iff a q machine current).mpr edge.2⟩)
      _ _ rest
  exact ⟨finalHistory, grew, ReversibleCompilation.marked_firstReturn (Compression.table a q machine)
    (Compression.deterministic a q machine) (Compression.targetCompatible a q machine)
    (Compression.mark a q machine) initial inside
    ((Compression.mark_true_iff a q machine _).mpr first_marked)
    ((Compression.mark_true_iff a q machine _).mpr last_marked)⟩

/-- Native execution determines both departure and the next internal stopping boundary. -/
def macroStep (machine : TM0.Machine (Fin a) (Fin q)) (state : Memory) : Part (Option Memory) :=
  ReversibleCompilation.nativeMacro (Compression.table a q machine)
    (Compression.deterministic a q machine) (Compression.targetCompatible a q machine)
    (Compression.mark a q machine) state

/-- The inverse executes its own fixed word table and the same finite boundary observation. -/
def reverseMacro (machine : TM0.Machine (Fin a) (Fin q)) (state : Memory) : Part Memory :=
  Program.reverseReturn (reverseProgram a q machine) (boundaryProgram a q machine) state

theorem macroStep_of_firstReturn (machine : TM0.Machine (Fin a) (Fin q))
    {first last : Memory} (run : FirstReturn a q machine first last) :
    macroStep a q machine first = Part.some (some last) :=
  ReversibleCompilation.nativeMacro_of_firstReturn (Compression.table a q machine)
    (Compression.deterministic a q machine) (Compression.targetCompatible a q machine)
    (Compression.mark a q machine) run

theorem reverseMacro_of_firstReturn (machine : TM0.Machine (Fin a) (Fin q))
    {first last : Memory} (run : FirstReturn a q machine first last) :
    reverseMacro a q machine last = Part.some first := by
  obtain ⟨marked, _, after, initial, rest⟩ := run
  exact Program.reverseReturn_of_firstReturn (program a q machine) (reverseProgram a q machine)
    (boundaryProgram a q machine) (reverse_after_forward a q machine) initial rest marked

/-- The return has a positive native length and no marked intermediate word return. -/
theorem FirstReturn.iterates (machine : TM0.Machine (Fin a) (Fin q))
    {first last : Memory} (run : FirstReturn a q machine first last) :
    ReversibleReturn.FirstReturn (program a q machine).advance (Boundary a q machine) first last := by
  obtain ⟨marked_first, marked_last, after, initial, interior⟩ := run
  let P := program a q machine
  exact ReversibleReturn.firstReturn_of_relation (advance := P.advance)
    (boundary := Boundary a q machine) (transition := fun left right => P.step left = some right)
    (fun edge => P.advance_of_step edge) initial interior marked_first marked_last

/-- Reversing this native trace gives the first preceding boundary, with the same length. -/
theorem FirstReturn.inverse_iterates (machine : TM0.Machine (Fin a) (Fin q))
    {first last : Memory} (run : FirstReturn a q machine first last) :
    ReversibleReturn.FirstReturn (reverseProgram a q machine).advance (Boundary a q machine) last first :=
  ReversibleReturn.inverse_firstReturn (reverse_after_forward a q machine)
    (FirstReturn.iterates a q machine run)

/-- The two internally executed macros retain and recover the same complete configurations. -/
theorem step_return_pair (machine : TM0.Machine (Fin a) (Fin q))
    {first last : TM0.Cfg (Fin a) (Fin q)} (transition : TM0.step machine first = some last)
    (history : ℕ) :
    ∃ finalHistory, history < finalHistory ∧
      FirstReturn a q machine (iota a q machine first history) (iota a q machine last finalHistory) ∧
      macroStep a q machine (iota a q machine first history) =
        Part.some (some (iota a q machine last finalHistory)) ∧
      reverseMacro a q machine (iota a q machine last finalHistory) =
        Part.some (iota a q machine first history) := by
  obtain ⟨finalHistory, grew, run⟩ := step_firstReturn a q machine transition history
  exact ⟨finalHistory, grew, run, macroStep_of_firstReturn a q machine run,
    reverseMacro_of_firstReturn a q machine run⟩

/-- Halts and live steps agree with the source optional result under the causal native macro. -/
theorem macroStep_iota (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    ∃ finalHistory,
      macroStep a q machine (iota a q machine state history) =
        Part.some ((TM0.step machine state).map (fun next => iota a q machine next finalHistory)) ∧
      (TM0.step machine state ≠ none → history < finalHistory) := by
  cases transition : TM0.step machine state with
  | none =>
      refine ⟨history, ?_, ?_⟩
      · simpa only [transition, Option.map_none, macroStep] using
          ReversibleCompilation.nativeMacro_of_halt (Compression.table a q machine)
            (Compression.deterministic a q machine) (Compression.targetCompatible a q machine)
            (Compression.mark a q machine) _ (step_halt a q machine state history transition)
      · simp
  | some next =>
      obtain ⟨finalHistory, grew, _, completed, _⟩ := step_return_pair a q machine transition history
      exact ⟨finalHistory, completed, fun _ => grew⟩

/-- Complete reversible universality with endogenous forward and backward first-return macros. -/
theorem complete_native_universality (machine : TM0.Machine (Fin a) (Fin q)) :
    let P := program a q machine
    let R := reverseProgram a q machine
    let I := iota a q machine
    Function.Injective (fun pair : TM0.Cfg (Fin a) (Fin q) × ℕ => I pair.1 pair.2) ∧
    (∀ state, R.advance (P.advance state) = state ∧ P.advance (R.advance state) = state) ∧
    (∀ first last, TM0.step machine first = some last → ∀ history,
      ∃ finalHistory, history < finalHistory ∧
        FirstReturn a q machine (I first history) (I last finalHistory) ∧
        macroStep a q machine (I first history) = Part.some (some (I last finalHistory)) ∧
        reverseMacro a q machine (I last finalHistory) = Part.some (I first history)) ∧
    (∀ state history, TM0.step machine state = none →
      macroStep a q machine (I state history) = Part.some none) ∧
    (∀ first last history,
      (∃ finalHistory, I last finalHistory ∈ P.eval (I first history)) ↔
        last ∈ StateTransition.eval (TM0.step machine) first) ∧
    (∀ state history, (P.eval (I state history)).Dom ↔
      (StateTransition.eval (TM0.step machine) state).Dom) ∧
    (∀ state history, ¬ (P.eval (I state history)).Dom ↔
      ¬ (StateTransition.eval (TM0.step machine) state).Dom) ∧
    (∀ first last history, StateTransition.Reaches (TM0.step machine) first last →
      ∃ finalHistory, ∃ count : ℕ,
        let initial := I first history
        let driver := P.runDriver count initial
        intermediateCurve driver initial =
          CoupledPullback.lowerCovering.liftPath driver.restrictedPath
            (CoupledPullback.upperProjection (restrictedState initial))
            (driver.restrictedPath.source.trans (restrictedState_over_base initial).symm) ∧
        restrictedTrajectory driver initial =
          CoupledPullback.upperCovering.liftPath (intermediatePath driver initial) (restrictedState initial)
            (intermediatePath driver initial).source ∧
        restrictedTrajectory driver initial 1 = restrictedState (I last finalHistory)) := by
  dsimp only
  exact ⟨iota_injective a q machine,
    fun state => ⟨reverse_after_forward a q machine state, forward_after_reverse a q machine state⟩,
    fun _ _ transition history => step_return_pair a q machine transition history,
    fun state history halted => by
      obtain ⟨finalHistory, executed, _⟩ := macroStep_iota a q machine state history
      simpa only [halted, Option.map_none] using executed,
    result_iff a q machine, halting_iff a q machine, divergence_iff a q machine,
    fun _ _ history run => finite_run_actual_lifts a q machine history run⟩


end Monodromy.ReversibleNativeTuring

end
