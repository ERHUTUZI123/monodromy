module

public import Monodromy.Continuation
public import Monodromy.Tape
public import Mathlib.Computability.Primrec.List
public import Monodromy.IntegerPrimrec
public import Mathlib.Computability.PartrecCode

/-!
# The effective content of cover execution

Fixed words of the five native loops have primitive recursive integer
interpretations. Complete native word execution
agrees with this proof interpretation, including results and divergence.
The trajectory-generating core uses the actual covering lifts throughout.
-/

@[expose] public section

namespace Monodromy.Effectiveness

/-- A computable transition system has a partial recursive complete execution. -/
theorem partrec_eval {S : Type*} [Primcodable S] {transition : S → Option S}
    (effective : Computable transition) : Partrec (StateTransition.eval transition) := by
  let body : S → S ⊕ S := fun state => (transition state).elim (Sum.inl state) Sum.inr
  have body_computable : Computable body :=
    (Computable.option_casesOn effective Computable.sumInl
      (Computable.sumInr.comp Computable.snd).to₂).of_eq fun state => by
        cases result : transition state <;> simp [body, result]
  exact Partrec.fix body_computable.partrec

end Monodromy.Effectiveness



noncomputable section

namespace Monodromy.CoupledContinuation

/-- Integer labels are a proof interpretation, never an input to native path generation. -/
abbrev Labels := (ℤ × ℤ) × ℤ

def Labels.prepare (labels : Labels) : Memory := Monodromy.CoupledContinuation.prepare labels.1.1 labels.1.2 labels.2

/-- Proof-side arithmetic of one of the actual five loops or its reverse. -/
def Gate.evalInt (gate : Gate) (backward : Bool) (labels : Labels) : Labels :=
  let displacement : ℤ := if backward then -1 else 1
  match gate with
  | .left => ((labels.1.1 + displacement, labels.1.2), labels.2)
  | .right => ((labels.1.1, labels.1.2 + displacement), labels.2)
  | .zeroLeft => (labels.1, labels.2 + if labels.1.1 = 0 then displacement else 0)
  | .zeroRight => (labels.1, labels.2 + if labels.1.2 = 0 then displacement else 0)
  | .control => (labels.1, labels.2 + displacement)

def Word.evalInt : Word → Labels → Labels
  | [], labels => labels
  | (gate, backward) :: rest, labels => Word.evalInt rest (Gate.evalInt gate backward labels)

theorem Gate.primrec_evalInt (gate : Gate) (backward : Bool) : Primrec (Gate.evalInt gate backward) := by
  let displacement : ℤ := if backward then -1 else 1
  have first_coordinate : Primrec (fun labels : Labels => labels.1.1) := Primrec.fst.comp Primrec.fst
  have second_coordinate : Primrec (fun labels : Labels => labels.1.2) := Primrec.snd.comp Primrec.fst
  have control : Primrec (fun labels : Labels => labels.2) := Primrec.snd
  have left_test : PrimrecPred (fun labels : Labels => labels.1.1 = 0) :=
    Primrec.eq.comp first_coordinate (Primrec.const 0)
  have right_test : PrimrecPred (fun labels : Labels => labels.1.2 = 0) :=
    Primrec.eq.comp second_coordinate (Primrec.const 0)
  cases gate with
  | left =>
      exact ((IntegerPrimrec.add.comp first_coordinate (Primrec.const displacement)).pair second_coordinate).pair control
  | right =>
      exact (first_coordinate.pair (IntegerPrimrec.add.comp second_coordinate (Primrec.const displacement))).pair control
  | zeroLeft =>
      exact Primrec.fst.pair (IntegerPrimrec.add.comp control
        (Primrec.ite left_test (Primrec.const displacement) (Primrec.const 0)))
  | zeroRight =>
      exact Primrec.fst.pair (IntegerPrimrec.add.comp control
        (Primrec.ite right_test (Primrec.const displacement) (Primrec.const 0)))
  | control =>
      exact Primrec.fst.pair (IntegerPrimrec.add.comp control (Primrec.const displacement))

theorem Word.primrec_evalInt (word : Word) : Primrec (Word.evalInt word) := by
  induction word with
  | nil => exact Primrec.id
  | cons atom rest recursive =>
      rcases atom with ⟨gate, backward⟩
      exact recursive.comp (Gate.primrec_evalInt gate backward)

/-- All arithmetic cases are derived from native transport, including reverse conditional gates. -/
theorem Gate.execute_evalInt (gate : Gate) (backward : Bool) (labels : Labels) :
    execute (if backward then gate.driver.reverse else gate.driver) (Labels.prepare labels) =
      Labels.prepare (Gate.evalInt gate backward labels) := by
  rcases labels with ⟨⟨left, right⟩, control⟩
  cases gate with
  | left =>
      cases backward with
      | false => simpa [Gate.driver, Gate.evalInt, Labels.prepare] using execute_A_left left right control
      | true => simpa [Gate.driver, Gate.evalInt, Labels.prepare, sub_eq_add_neg] using execute_A_left_reverse left right control
  | right =>
      cases backward with
      | false => simpa [Gate.driver, Gate.evalInt, Labels.prepare] using execute_A_right left right control
      | true => simpa [Gate.driver, Gate.evalInt, Labels.prepare, sub_eq_add_neg] using execute_A_right_reverse left right control
  | zeroLeft =>
      cases backward with
      | false => simpa [Gate.driver, Gate.evalInt, Labels.prepare] using execute_B_left left right control
      | true =>
          have inverse := execute_driver_reverse B_left
            (prepare left right (control - if left = 0 then 1 else 0))
          rw [execute_B_left] at inverse
          simp only [sub_add_cancel] at inverse
          by_cases zero : left = 0 <;>
            simpa [Gate.driver, Gate.evalInt, Labels.prepare, zero, sub_eq_add_neg] using inverse
  | zeroRight =>
      cases backward with
      | false => simpa [Gate.driver, Gate.evalInt, Labels.prepare] using execute_B_right left right control
      | true =>
          have inverse := execute_driver_reverse B_right
            (prepare left right (control - if right = 0 then 1 else 0))
          rw [execute_B_right] at inverse
          simp only [sub_add_cancel] at inverse
          by_cases zero : right = 0 <;>
            simpa [Gate.driver, Gate.evalInt, Labels.prepare, zero, sub_eq_add_neg] using inverse
  | control =>
      cases backward with
      | false => simpa [Gate.driver, Gate.evalInt, Labels.prepare] using execute_control_prepare left right control
      | true => simpa [Gate.driver, Gate.evalInt, Labels.prepare, sub_eq_add_neg] using execute_control_reverse left right control

theorem Word.execute_evalInt (word : Word) (labels : Labels) :
    execute (Word.driver word) (Labels.prepare labels) = Labels.prepare (Word.evalInt word labels) := by
  induction word generalizing labels with
  | nil => exact execute_word_nil (Labels.prepare labels)
  | cons atom rest recursive =>
      rcases atom with ⟨gate, backward⟩
      rw [execute_word_cons, Gate.execute_evalInt, recursive]
      rfl

namespace Program

variable {degree : ℕ} [NeZero degree]

/-- Euclidean residues describe, but do not implement, finite-root routing. -/
def indexInt (degree : ℕ) [NeZero degree] (labels : Labels) : Fin degree :=
  ⟨(labels.2 % (degree : ℤ)).toNat, by
    apply (Int.toNat_lt_of_ne_zero (NeZero.ne degree)).mpr
    exact Int.emod_lt_of_pos _ (by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne degree))⟩

def nextInt (program : Program degree) (labels : Labels) : Labels :=
  Word.evalInt (program.table (indexInt degree labels)) labels

def haltInt (program : Program degree) (labels : Labels) : Bool :=
  program.stop (indexInt degree labels)

def stepInt (program : Program degree) (labels : Labels) : Option Labels :=
  if program.haltInt labels then none else some (program.nextInt labels)

def evalInt (program : Program degree) : Labels → Part Labels :=
  StateTransition.eval program.stepInt

theorem indexInt_cast (labels : Labels) :
    ((indexInt degree labels).val : ℤ) = labels.2 % (degree : ℤ) := by
  exact Int.toNat_of_nonneg (Int.emod_nonneg _ (by exact_mod_cast NeZero.ne degree))

theorem control_decomposition (labels : Labels) :
    (degree : ℤ) * (labels.2 / (degree : ℤ)) + (indexInt degree labels).val = labels.2 := by
  rw [indexInt_cast]
  exact Int.mul_ediv_add_emod _ _

theorem primrec_indexInt : Primrec (indexInt degree) := by
  apply Primrec.fin_val_iff.mp
  have degree_eq : degree - 1 + 1 = degree := by
    have positive := Nat.pos_of_ne_zero (NeZero.ne degree)
    omega
  exact ((IntegerPrimrec.remainder (degree - 1)).comp
    (Primrec.snd : Primrec (Prod.snd : Labels → ℤ))).of_eq
      (by intro labels; simp [degree_eq, indexInt])

theorem primrec_nextInt (program : Program degree) : Primrec program.nextInt :=
  (Primrec.fin_curry₁.mpr (fun index => Word.primrec_evalInt (program.table index))).comp
    primrec_indexInt Primrec.id

theorem primrec_haltInt (program : Program degree) : Primrec program.haltInt :=
  (Primrec.dom_finite program.stop).comp primrec_indexInt

theorem primrec_stepInt (program : Program degree) : Primrec program.stepInt := by
  have primitive := Primrec.cond (primrec_haltInt program) (Primrec.const none)
    (Primrec.option_some.comp (primrec_nextInt program))
  exact primitive.of_eq fun labels => by
    cases done : program.haltInt labels <;> simp [stepInt, done]

/-- Complete execution of a finite geometric word table is partial recursive. -/
theorem partrec_evalInt (program : Program degree) : Partrec program.evalInt :=
  Effectiveness.partrec_eval (primrec_stepInt program).to_comp

theorem advance_prepareInt (program : Program degree) (labels : Labels) :
    program.advance (Labels.prepare labels) = Labels.prepare (program.nextInt labels) := by
  have actual := program.advance_prepare labels.1.1 labels.1.2
    (labels.2 / (degree : ℤ)) (indexInt degree labels)
  rw [control_decomposition] at actual
  exact actual.trans (Word.execute_evalInt _ labels)

theorem haltSignal_prepareInt (program : Program degree) (labels : Labels) :
    program.haltSignal (Labels.prepare labels) = if program.haltInt labels then 1 else 0 := by
  have actual := program.haltSignal_prepare labels.1.1 labels.1.2
    (labels.2 / (degree : ℤ)) (indexInt degree labels)
  rw [control_decomposition] at actual
  exact actual

theorem step_prepareInt (program : Program degree) (labels : Labels) :
    program.step (Labels.prepare labels) = (program.stepInt labels).map Labels.prepare := by
  unfold step stepInt
  rw [haltSignal_prepareInt]
  cases program.haltInt labels <;> simp [advance_prepareInt]

/-- The partial-recursive interpretation preserves every result, halting, and divergence. -/
theorem eval_prepareInt (program : Program degree) (labels : Labels) :
    program.eval (Labels.prepare labels) = Labels.prepare <$> program.evalInt labels := by
  have refinement : StateTransition.Respects program.stepInt program.step
      (fun first second => Labels.prepare first = second) := by
    apply StateTransition.fun_respects.mpr
    intro source
    cases result : program.stepInt source with
    | none =>
        change program.step (Labels.prepare source) = none
        simp [step_prepareInt, result]
    | some successor =>
        apply Relation.TransGen.single
        simp [step_prepareInt, result]
  exact StateTransition.tr_eval' program.stepInt program.step Labels.prepare refinement labels

theorem eval_dom_prepareInt (program : Program degree) (labels : Labels) :
    (program.eval (Labels.prepare labels)).Dom ↔ (program.evalInt labels).Dom := by
  rw [eval_prepareInt]
  rfl

/-- Fixed effective interfaces preserve the ordinary partial-recursive upper bound. -/
theorem partrec_with_io (program : Program degree) {input : ℕ → Labels} {output : Labels → ℕ}
    (input_primitive : Primrec input) (output_primitive : Primrec output) :
    Partrec (fun value => (program.evalInt (input value)).map output) :=
  ((program.partrec_evalInt).comp input_primitive.to_comp).map
    (output_primitive.to_comp.comp Computable.snd).to₂

end Program

end Monodromy.CoupledContinuation

namespace Monodromy.PrimeReadout

/-- A bounded search reads a prime exponent without an unbounded factorization oracle. -/
def exponent (prime input : ℕ) : ℕ := input.findGreatest (fun power => prime ^ power ∣ input)

theorem primrec_power (base : ℕ) : Primrec (fun power : ℕ => base ^ power) :=
  (Primrec₂.unpaired'.mp Nat.Primrec.pow).comp (Primrec.const base) Primrec.id

theorem primrec_exponent (prime : ℕ) : Primrec (exponent prime) := by
  have divides : PrimrecRel (fun input power : ℕ => prime ^ power ∣ input) := by
    have remainder : Primrec (fun pair : ℕ × ℕ => pair.1 % prime ^ pair.2) :=
      Primrec.nat_mod.comp Primrec.fst ((primrec_power prime).comp Primrec.snd)
    exact (Primrec.eq.comp remainder (Primrec.const 0)).primrecRel.of_eq
      (fun _ _ => Nat.dvd_iff_mod_eq_zero.symm)
  exact Primrec.nat_findGreatest Primrec.id divides

/-- For a prime, the bounded readout agrees with the exact factorization exponent. -/
theorem exponent_eq_factorization {prime : ℕ} (is_prime : prime.Prime) (input : ℕ) :
    exponent prime input = input.factorization prime := by
  by_cases zero : input = 0
  · subst input
    simp [exponent]
  · apply Nat.findGreatest_eq_iff.mpr
    refine ⟨(Nat.factorization_lt prime zero).le, ?_, ?_⟩
    · intro _
      exact (is_prime.pow_dvd_iff_le_factorization zero).mpr le_rfl
    · intro power larger _ divides
      exact (not_lt_of_ge ((is_prime.pow_dvd_iff_le_factorization zero).mp divides)) larger

end Monodromy.PrimeReadout

namespace Monodromy.TapeCode.Readout

/-- The same fixed positional code is effective on finite words. -/
def wordCode (a : ℕ) (word : List (Fin a)) : ℕ :=
  Nat.ofDigits (a + 1) (word.map Fin.val)

theorem wordCode_foldr (a : ℕ) (word : List (Fin a)) :
    wordCode a word = word.foldr (fun letter total => letter.val + (a + 1) * total) 0 := by
  induction word with
  | nil => rfl
  | cons letter rest recursive => simpa [wordCode, Nat.ofDigits_cons] using congrArg (fun total => letter.val + (a + 1) * total) recursive

theorem primrec_wordCode (a : ℕ) : Primrec (wordCode a) := by
  have folded : Primrec (fun word : List (Fin a) =>
      word.foldr (fun letter total => letter.val + (a + 1) * total) 0) :=
    Primrec.list_foldr Primrec.id (Primrec.const 0)
      (Primrec.nat_add.comp
        (Primrec.fin_val.comp (Primrec.fst.comp Primrec.snd))
        (Primrec.nat_mul.comp (Primrec.const (a + 1)) (Primrec.snd.comp Primrec.snd))).to₂
  exact folded.of_eq (fun word => (wordCode_foldr a word).symm)

section Decoder

variable {a : ℕ} [NeZero a]

/-- The unused last residue is interpreted as blank by a fixed finite table. -/
def extend (read : Fin a → ℕ → ℕ) (letter : Fin (a + 1)) : ℕ → ℕ :=
  Fin.lastCases (read 0) read letter

def digit (a : ℕ) (value : ℕ) : Fin (a + 1) :=
  ⟨value % (a + 1), Nat.mod_lt _ (Nat.succ_pos a)⟩

def step (read : Fin a → ℕ → ℕ) (state : ℕ × ℕ) : ℕ × ℕ :=
  (state.1 / (a + 1), extend read (digit a state.1) state.2)

def run (read : Fin a → ℕ → ℕ) (fuel : ℕ) (state : ℕ × ℕ) : ℕ × ℕ :=
  (step read)^[fuel] state

/-- A bounded numeric readout, independent of the program producing the code. -/
def decode (read : Fin a → ℕ → ℕ) (value : ℕ) : ℕ :=
  (run read value (value, 0)).2

theorem primrec_digit (a : ℕ) : Primrec (digit a) :=
  Primrec.fin_val_iff.mp (Primrec.nat_mod.comp Primrec.id (Primrec.const (a + 1)))

theorem primrec_extend (read : Fin a → ℕ → ℕ) (effective : ∀ letter, Primrec (read letter)) :
    Primrec₂ (extend read) := by
  apply Primrec.fin_curry₁.mpr
  intro letter
  refine Fin.lastCases ?_ (fun original => ?_) letter
  · simpa [extend] using effective 0
  · simpa [extend] using effective original

theorem primrec_step (read : Fin a → ℕ → ℕ) (effective : ∀ letter, Primrec (read letter)) :
    Primrec (step read) :=
  (Primrec.nat_div.comp Primrec.fst (Primrec.const (a + 1))).pair
    ((primrec_extend read effective).comp ((primrec_digit a).comp Primrec.fst) Primrec.snd)

theorem primrec_run (read : Fin a → ℕ → ℕ) (effective : ∀ letter, Primrec (read letter)) :
    Primrec₂ (run read) :=
  (Primrec.nat_iterate Primrec.fst Primrec.snd
    ((primrec_step read effective).comp Primrec.snd).to₂).to₂

theorem primrec_decode (read : Fin a → ℕ → ℕ) (effective : ∀ letter, Primrec (read letter)) :
    Primrec (decode read) :=
  Primrec.snd.comp ((primrec_run read effective).comp Primrec.id (Primrec.id.pair (Primrec.const 0)))

variable (read : Fin a → ℕ → ℕ) (neutral : ∀ initial, read 0 initial = initial)

private theorem fold_blanks (neutral : ∀ initial, read 0 initial = initial) (count initial : ℕ) :
    (List.replicate count (0 : Fin a)).foldl (fun total letter => read letter total) initial = initial := by
  induction count generalizing initial with
  | zero => rfl
  | succ count recursive => simpa only [List.replicate_succ, List.foldl_cons, neutral] using recursive initial

/-- Neutral blank padding makes the human-readable fold a function of the complete half-tape. -/
def tapeFold (neutral : ∀ initial, read 0 initial = initial) (tape : Turing.ListBlank (Fin a)) (initial : ℕ) : ℕ :=
  tape.liftOn (fun word => word.foldl (fun total letter => read letter total) initial) (by
    rintro first _ ⟨count, rfl⟩
    simp [List.foldl_append, Fin.default_eq_zero, fold_blanks read neutral])

@[simp] theorem tapeFold_mk (word : List (Fin a)) (initial : ℕ) :
    tapeFold read neutral (Turing.ListBlank.mk word) initial =
      word.foldl (fun total letter => read letter total) initial := rfl

@[simp] theorem tapeFold_empty (initial : ℕ) :
    tapeFold read neutral (∅ : Turing.ListBlank (Fin a)) initial = initial := rfl

theorem tapeFold_cons (letter : Fin a) (tape : Turing.ListBlank (Fin a)) (initial : ℕ) :
    tapeFold read neutral (tape.cons letter) initial =
      tapeFold read neutral tape (read letter initial) := by
  refine Turing.ListBlank.induction_on tape (fun word => ?_)
  rw [Turing.ListBlank.cons_mk]
  rfl

theorem tapeFold_head_tail (tape : Turing.ListBlank (Fin a)) (initial : ℕ) :
    tapeFold read neutral tape initial = tapeFold read neutral tape.tail (read tape.head initial) := by
  simpa only [Turing.ListBlank.cons_head_tail] using tapeFold_cons read neutral tape.head tape.tail initial

theorem digit_encode (tape : Turing.ListBlank (Fin a)) :
    digit a (TapeCode.encode tape) = tape.head.castSucc := by
  apply Fin.ext
  exact TapeCode.head_code tape

theorem step_encode (tape : Turing.ListBlank (Fin a)) (initial : ℕ) :
    step read (TapeCode.encode tape, initial) = (TapeCode.encode tape.tail, read tape.head initial) := by
  simp [step, TapeCode.tail_code, digit_encode, extend]

theorem step_zero (neutral : ∀ initial, read 0 initial = initial) (initial : ℕ) : step read (0, initial) = (0, initial) := by
  have blank_digit : digit a 0 = (0 : Fin a).castSucc := by apply Fin.ext; rfl
  change (0 / (a + 1), extend read (digit a 0) initial) = (0, initial)
  rw [blank_digit]
  simp only [extend, Fin.lastCases_castSucc, neutral, Nat.zero_div]

theorem run_zero (neutral : ∀ initial, read 0 initial = initial) (fuel initial : ℕ) : run read fuel (0, initial) = (0, initial) :=
  Function.iterate_fixed (step_zero read neutral initial) fuel

theorem run_succ (fuel : ℕ) (state : ℕ × ℕ) :
    run read (fuel + 1) state = run read fuel (step read state) :=
  Function.iterate_succ_apply _ _ _

/-- The numeric code itself is a sufficient uniform bound on the number of useful reads. -/
private theorem run_code (neutral : ∀ initial, read 0 initial = initial) (code : ℕ) :
    ∀ tape : Turing.ListBlank (Fin a), TapeCode.encode tape = code →
      ∀ fuel : ℕ, code ≤ fuel → ∀ initial : ℕ,
        run read fuel (code, initial) = (0, tapeFold read neutral tape initial) := by
  induction code using Nat.strong_induction_on with
  | h code recursive =>
      intro tape encoding fuel enough initial
      by_cases zero : code = 0
      · have blank : tape = ∅ := (TapeCode.encode_eq_zero_iff tape).mp (encoding.trans zero)
        rw [zero, blank, tapeFold_empty]
        exact run_zero read neutral fuel initial
      · have positive : 0 < code := Nat.pos_of_ne_zero zero
        have base_large : 1 < a + 1 := by
          have nonempty := Nat.pos_of_ne_zero (NeZero.ne a)
          omega
        have smaller : TapeCode.encode tape.tail < code := by
          rw [← TapeCode.tail_code tape, encoding]
          exact Nat.div_lt_self positive base_large
        cases fuel with
        | zero => omega
        | succ fuel =>
            have actual_step : step read (code, initial) =
                (TapeCode.encode tape.tail, read tape.head initial) := by
              rw [← encoding]
              exact step_encode read tape initial
            rw [run_succ, actual_step]
            have rest := recursive (TapeCode.encode tape.tail) smaller tape.tail rfl fuel
              (by omega) (read tape.head initial)
            exact rest.trans (congrArg (fun value => (0, value))
              (tapeFold_head_tail read neutral tape initial).symm)

/-- The code is fully consumed and its fold is exact after any sufficient bounded iteration. -/
theorem run_tape_state (tape : Turing.ListBlank (Fin a)) (fuel : ℕ)
    (enough : TapeCode.encode tape ≤ fuel) (initial : ℕ) :
    run read fuel (TapeCode.encode tape, initial) = (0, tapeFold read neutral tape initial) :=
  run_code read neutral (TapeCode.encode tape) tape rfl fuel enough initial

/-- Every representative, including arbitrary blank padding, has the same bounded numeric readout. -/
theorem run_tape (tape : Turing.ListBlank (Fin a)) (fuel : ℕ)
    (enough : TapeCode.encode tape ≤ fuel) (initial : ℕ) :
    (run read fuel (TapeCode.encode tape, initial)).2 = tapeFold read neutral tape initial :=
  congrArg Prod.snd (run_tape_state read neutral tape fuel enough initial)

/-- The fixed total primitive-recursive decoder agrees with the blank-invariant tape fold. -/
theorem decode_tape (tape : Turing.ListBlank (Fin a)) :
    decode read (TapeCode.encode tape) = tapeFold read neutral tape 0 :=
  run_tape read neutral tape (TapeCode.encode tape) le_rfl 0

/-- In particular the same readout acts on every finite word, without choosing a representative. -/
theorem decode_word (neutral : ∀ initial, read 0 initial = initial) (word : List (Fin a)) :
    decode read (wordCode a word) = word.foldl (fun total letter => read letter total) 0 :=
  decode_tape read neutral (Turing.ListBlank.mk word)

end Decoder

end Monodromy.TapeCode.Readout
