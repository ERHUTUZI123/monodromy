# Mathematical note

[Manuscript](monodromy-note.tex) · [PDF](monodromy-note.pdf)

The note develops conditional winding, the three-root construction, native
operations, finite execution, and Theorem 5.1 on geometric Turing universality.
The two figures are vector diagrams written directly in LaTeX/TikZ.

## Proof companions

These files are complete, byte-identical copies of the cited canonical Lean
sources. Their names follow the printed mathematical objects or the supporting
section. When one canonical file proves several statements, it is copied once.
Appendix A gives exact declaration names.

| Manuscript | Companion | Canonical source |
| --- | --- | --- |
| Section 2; covering transport and pullbacks | [2_covering_transport.lean](2_covering_transport.lean) | [Covering.lean](../src/Monodromy/Covering.lean) |
| Section 2; the two logarithmic lifts | [2_construction_conditional_winding.lean](2_construction_conditional_winding.lean) | [Logarithm.lean](../src/Monodromy/Logarithm.lean) |
| Definition 3.1, Proposition 3.2, Example 3.3, Definition 4.1; actual execution, native gates, routing | [3.1_definition_successive_execution.lean](3.1_definition_successive_execution.lean) | [Continuation.lean](../src/Monodromy/Continuation.lean) |
| Section 4; analytic kernels used in Definition 4.1 | [4_analytic_branch_selection.lean](4_analytic_branch_selection.lean) | [Choice.lean](../src/Monodromy/Choice.lean) |
| Section 4; finite power-cover observation | [4_finite_root_observation.lean](4_finite_root_observation.lean) | [Radix.lean](../src/Monodromy/Radix.lean) |
| Proposition 4.2; counter compilation used in Theorem 5.1 | [4.2_proposition_counter_realization.lean](4.2_proposition_counter_realization.lean) | [Counter.lean](../src/Monodromy/Counter.lean) |
| Theorem 5.1; canonical half-tape coding | [5_tape_encoding.lean](5_tape_encoding.lean) | [Tape.lean](../src/Monodromy/Tape.lean) |
| Theorem 5.1; finite pointed source types | [5_finite_source_renaming.lean](5_finite_source_renaming.lean) | [FiniteSupport.lean](../src/Monodromy/FiniteSupport.lean) |
| Theorem 5.1; the complete native simulation and first returns | [5.1_theorem_native_geometric_turing_universality.lean](5.1_theorem_native_geometric_turing_universality.lean) | [FormalCompilation.lean](../src/Monodromy/FormalCompilation.lean) |
| Section 6 and Appendix A; transitive axiom audit | [6_verification_axiom_audit.lean](6_verification_axiom_audit.lean) | [Audit.lean](../src/Audit.lean) |

The active library remains `src/Monodromy/`. Companion imports retain those
canonical module names, so check them from the repository root, for example:

```sh
lake build
lake env lean -DautoImplicit=false -DwarningAsError=true notes/3.1_definition_successive_execution.lean
lake env lean -DautoImplicit=false -DwarningAsError=true notes/6_verification_axiom_audit.lean
```

[proofs.json](proofs.json) records the source path and SHA-256 of each copy.
Refresh the corresponding companion and manifest together if a canonical proof
changes. The numbered files introduce no second active implementation.

## Editorial revision

The main text now derives the operations before introducing programs, includes
two geometric diagrams and a complete calculation with retained roots, and
organizes universality as tape → three counters → two counters → lifted paths.
Lean identifiers are collected in Appendix A. The author should review the
mathematical scope in Section 6: exact return states, finite analytic routing,
and the distinction from a single autonomous flow. The originality assessment
also remains a matter for comparison with the cited literature.

To compile the standalone note:

```sh
cd notes
latexmk -pdf monodromy-note.tex
```

The compiled note has six pages of main text and one page of formal-source
references. Every numbered companion passes a strict Lean check; the repository
build and the 1427-declaration transitive axiom audit pass. Independent reviews
checked the geometry, first-return simulation, diagrams, source mapping, and
archive consistency. The editorial revision leaves the canonical Lean sources
unchanged.
