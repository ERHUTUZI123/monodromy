import «Monodromy-prime-compression-runs»
import «Monodromy-prime-compression-encoding»

/-!
First-return boundaries are observations of finite control positions.
Local radix steps remain actual compressed steps; their interior sources
avoid the retained source-machine boundaries.
-/

noncomputable section

namespace Monodromy.Counter.Reversible.PrimeCompression

variable {n q e : ℕ}

/-- Exactly the retained finite source execution boundaries. -/
def Boundary (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (state : State 2 (size basis source deterministic compatible)) : Prop :=
  ∃ position : Fin q, state.1 = PortNetwork.control (wiring basis source deterministic compatible)
    (boundary basis source position)

/-- State relocation changes only the finite control address. -/
def MappedState (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source) (block : Module source)
    (state : State 2 (Radix.size (modulus basis source block))) :
    State 2 (size basis source deterministic compatible) :=
  Glue.mapState (PortNetwork.control (wiring basis source deterministic compatible))
    (Glue.mapState (moduleNode basis source block) state)

/-- The actual compiled step with an observation on its source, not a new execution rule. -/
def InternalStep (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (first last : State 2 (size basis source deterministic compatible)) : Prop :=
  step (table basis source deterministic compatible) first = some last ∧
    ¬ Boundary basis source deterministic compatible first

abbrev InternalReaches (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source) :=
  Relation.ReflTransGen (InternalStep basis source deterministic compatible)

/-- A positive compiled run, with no earlier return to a source execution boundary. -/
def FirstReturn (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (first last : State 2 (size basis source deterministic compatible)) : Prop :=
  Boundary basis source deterministic compatible first ∧
  Boundary basis source deterministic compatible last ∧
  ∃ next, step (table basis source deterministic compatible) first = some next ∧
    InternalReaches basis source deterministic compatible next last

theorem boundary_encode (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (state : Counter.Configuration n q) :
    Boundary basis source deterministic compatible (encode basis source deterministic compatible state) :=
  ⟨state.pc, rfl⟩

/-- A local step is executed by precisely the retained compressed table. -/
theorem mapped_step (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source) (block : Module source)
    {first last : State 2 (Radix.size (modulus basis source block))}
    (transition : step (componentTable basis source block) first = some last) :
    step (table basis source deterministic compatible)
      (MappedState basis source deterministic compatible block first) =
      some (MappedState basis source deterministic compatible block last) :=
  PortNetwork.step_map_live (wiring basis source deterministic compatible)
    (raw_deterministic basis source) (component_step_map basis source block transition)

/-- A local state's control is retained whenever it is the source of an actual edge. -/
theorem module_source_unlinked (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source) (block : Module source)
    {first last : State 2 (Radix.size (modulus basis source block))}
    (transition : step (componentTable basis source block) first = some last) :
    (wiring basis source deterministic compatible).link (moduleNode basis source block first.1) = none := by
  obtain ⟨index, enabled, _⟩ := (step_iff (rawTable basis source) (raw_deterministic basis source)).mp
    (component_step_map basis source block transition)
  have source_eq : (rawTable basis source index).source = moduleNode basis source block first.1 := enabled.1
  rw [← source_eq]
  exact (wiring basis source deterministic compatible).source_free index

/-- No step of a source module targets its own input port. -/
theorem source_target_ne_input (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : SourceSite source)
    {first last : State 2 (Radix.size (modulus basis source (.inl site)))}
    (transition : step (componentTable basis source (.inl site)) first = some last) :
    last.1 ≠ sourceInputPosition basis source site := by
  obtain ⟨index, _, result⟩ := (step_iff _ (component_deterministic basis source (.inl site))).mp transition
  intro equal
  exact component_no_incoming_sourceInput basis source site index
    ((congrArg Prod.fst result).trans equal)

private theorem source_internal_step (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source) (site : SourceSite source)
    {first last : State 2 (Radix.size (modulus basis source (.inl site)))}
    (interior : first.1 ≠ sourceInputPosition basis source site)
    (transition : step (componentTable basis source (.inl site)) first = some last) :
    InternalStep basis source deterministic compatible
      (MappedState basis source deterministic compatible (.inl site) first)
      (MappedState basis source deterministic compatible (.inl site) last) := by
  refine ⟨mapped_step basis source deterministic compatible (.inl site) transition, ?_⟩
  rintro ⟨position, equal⟩
  have raw_equal := PortNetwork.control_unlinked_injective (wiring basis source deterministic compatible)
    (module_source_unlinked basis source deterministic compatible (.inl site) transition)
    (boundary_link_none basis source deterministic compatible position) equal
  exact sourceNode_ne_boundary basis source site first.1 interior position raw_equal

/-- A source-module run beginning past its input has only interior compiled sources. -/
theorem source_internal_reaches (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source) (site : SourceSite source)
    {first last : State 2 (Radix.size (modulus basis source (.inl site)))}
    (run : StateTransition.Reaches (step (componentTable basis source (.inl site))) first last)
    (interior : first.1 ≠ sourceInputPosition basis source site) :
    InternalReaches basis source deterministic compatible
      (MappedState basis source deterministic compatible (.inl site) first)
      (MappedState basis source deterministic compatible (.inl site) last) := by
  have lifted : InternalReaches basis source deterministic compatible
      (MappedState basis source deterministic compatible (.inl site) first)
      (MappedState basis source deterministic compatible (.inl site) last) ∧
      last.1 ≠ sourceInputPosition basis source site := by
    induction run with
    | refl => exact ⟨Relation.ReflTransGen.refl, interior⟩
    | tail _ transition previous =>
        exact ⟨previous.1.tail (source_internal_step basis source deterministic compatible site previous.2 transition),
          source_target_ne_input basis source site transition⟩
  exact lifted.1

/-- After its first actual step, every positive source-module run is interior
until its terminal port. No extra transition is inserted at departure. -/
theorem source_departure (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source) (site : SourceSite source)
    {first last : State 2 (Radix.size (modulus basis source (.inl site)))}
    (run : StateTransition.Reaches₁ (step (componentTable basis source (.inl site))) first last) :
    ∃ next, step (table basis source deterministic compatible)
      (MappedState basis source deterministic compatible (.inl site) first) = some next ∧
      InternalReaches basis source deterministic compatible next
        (MappedState basis source deterministic compatible (.inl site) last) := by
  obtain ⟨middle, initial, rest⟩ := Relation.TransGen.head'_iff.mp run
  exact ⟨MappedState basis source deterministic compatible (.inl site) middle,
    mapped_step basis source deterministic compatible (.inl site) initial,
    source_internal_reaches basis source deterministic compatible site rest
      (source_target_ne_input basis source site initial)⟩

private theorem restoreNode_ne_boundary (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : RestoreSite source) (position : Fin (Radix.size (modulus basis source (.inr site))))
    (target : Fin q) : moduleNode basis source (.inr site) position ≠ boundary basis source target := by
  intro same
  by_cases active : HasSource source target
  · simp only [boundary, dite_eq_left active, sourceInput] at same
    cases moduleNode_module basis source same
  · simp only [boundary, dite_eq_right active] at same
    exact haltNode_ne_moduleNode basis source ⟨target, active⟩ _ _ same.symm

private theorem restore_internal_step (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source) (site : RestoreSite source)
    {first last : State 2 (Radix.size (modulus basis source (.inr site)))}
    (transition : step (componentTable basis source (.inr site)) first = some last) :
    InternalStep basis source deterministic compatible
      (MappedState basis source deterministic compatible (.inr site) first)
      (MappedState basis source deterministic compatible (.inr site) last) := by
  refine ⟨mapped_step basis source deterministic compatible (.inr site) transition, ?_⟩
  rintro ⟨position, equal⟩
  have raw_equal := PortNetwork.control_unlinked_injective (wiring basis source deterministic compatible)
    (module_source_unlinked basis source deterministic compatible (.inr site) transition)
    (boundary_link_none basis source deterministic compatible position) equal
  exact restoreNode_ne_boundary basis source site first.1 position raw_equal

/-- Restoration has no source boundary until its terminal output is identified with one. -/
theorem restore_internal_reaches (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source) (site : RestoreSite source)
    {first last : State 2 (Radix.size (modulus basis source (.inr site)))}
    (run : StateTransition.Reaches (step (componentTable basis source (.inr site))) first last) :
    InternalReaches basis source deterministic compatible
      (MappedState basis source deterministic compatible (.inr site) first)
      (MappedState basis source deterministic compatible (.inr site) last) := by
  exact Relation.ReflTransGen.lift (MappedState basis source deterministic compatible (.inr site))
    (fun _ _ transition => restore_internal_step basis source deterministic compatible site transition) _ _ run

end Monodromy.Counter.Reversible.PrimeCompression
