import «Monodromy-prime-compression-step»
import «Monodromy-prime-compression-encoding»
import «Monodromy-prime-compression-first-return»

/-! A source test is executed by reaching its remainder port and restoring the code. -/

namespace Monodromy.Counter.Reversible.PrimeCompression

variable {n q e : ℕ}

theorem test_firstReturn (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (before : Counter.Configuration n q) (edge : Fin e) (register : Fin n) (flag : Bool)
    (at_source : (source edge).source = before.pc)
    (test : (source edge).action = .test register flag)
    (enabled : (source edge).action.enabled (fun index => (before.counters index : ℤ))) :
    FirstReturn basis source deterministic compatible
      (encode basis source deterministic compatible before)
      (encode basis source deterministic compatible ⟨(source edge).target, before.counters⟩) := by
  let first := siteOfEdge source edge
  let last := restoreOfTest source edge register flag test
  let value := basis.encode before.counters
  let p := modulus basis source (.inl first)
  let remainder := Counter.DivMod.residue p value
  have first_register : moduleRegister source (.inl first) = register :=
    sourceRegister_of_test source deterministic edge register flag test
  have last_register : moduleRegister source (.inr last) = register :=
    restoreRegister_of_test source compatible edge register flag test
  have same_modulus : p = modulus basis source (.inr last) :=
    congrArg basis.prime (first_register.trans last_register.symm)
  let restored : Fin (modulus basis source (.inr last)) :=
    ⟨remainder.val, by rw [← same_modulus]; exact remainder.isLt⟩
  have forward : reversed source (.inl first) = false := by
    obtain ⟨chosen, form⟩ := sourceForm_of_test source deterministic edge register flag test
    simp only [reversed, first, form]
  have zero_flag : decide (before.counters register = 0) = flag := by
    cases flag <;> simp_all [Action.enabled]
  have selected : decide (remainder.val ≠ 0) = flag := by
    change decide (value % p ≠ 0) = flag
    have prime : p = basis.prime register := congrArg basis.prime first_register
    rw [prime, residue_zero_flag, zero_flag]
  obtain ⟨next, initial_step, inside⟩ := source_departure basis source deterministic compatible first
    (forward_query_local_positive basis source first forward value)
  have restore := restore_internal_reaches basis source deterministic compatible last
    (restore_pack_local_positive basis source last restored (value / p)).to_reflTransGen
  simp only [MappedState, Glue.mapState, Radix.point] at initial_step inside restore
  have ports := connection_controls basis source deterministic compatible
    (test_connected basis source deterministic compatible edge register flag test remainder restored rfl selected)
  rw [ports] at inside
  change InternalReaches basis source deterministic compatible
    (PortNetwork.control (wiring basis source deterministic compatible)
      (restoreInput basis source last restored), ![((value / p : ℕ) : ℤ), 0])
    (PortNetwork.control (wiring basis source deterministic compatible)
      (restoreOutput basis source last),
      ![((modulus basis source (.inr last) * (value / p) + restored.val : ℕ) : ℤ), 0]) at restore
  have final_port := connection_controls basis source deterministic compatible (restore_connected basis source last)
  rw [final_port] at restore
  have arithmetic : modulus basis source (.inr last) * (value / p) + restored.val = value := by
    change modulus basis source (.inr last) * (value / p) + remainder.val = value
    rw [← same_modulus]
    change p * (value / p) + value % p = value
    have division := Nat.mod_add_div value p
    omega
  rw [arithmetic] at restore
  have initial : boundary basis source before.pc = sourceInput basis source first := by
    rw [← at_source]
    exact boundary_source basis source first
  have input : moduleNode basis source (.inl first) (Radix.entry p) =
      sourceInput basis source first := by
    simp only [sourceInput, sourceInputPosition, forward, Bool.false_eq_true, reduceIte]
    rfl
  rw [input, ← initial] at initial_step
  exact ⟨boundary_encode basis source deterministic compatible before,
    boundary_encode basis source deterministic compatible ⟨(source edge).target, before.counters⟩,
    next, initial_step, inside.trans restore⟩

end Monodromy.Counter.Reversible.PrimeCompression
