import «Monodromy-port-network»

/-! Read-only radix observation as an instance of finite port identification. -/

noncomputable section

namespace Monodromy.Counter.Reversible.RadixObservationNetwork

variable (p m : ℕ) [NeZero p]

abbrev RawNode := (Fin 2 × Fin m) × Fin (Radix.size p)
abbrev RawArc := (Fin 2 × Fin m) × Fin (Radix.edges p)

def rawSize : ℕ := (2 * m) * Radix.size p
def edges : ℕ := (2 * m) * Radix.edges p

def rawNodeEquiv : RawNode p m ≃ Fin (rawSize p m) :=
  (Equiv.prodCongr finProdFinEquiv (Equiv.refl _)).trans finProdFinEquiv

def arcEquiv : RawArc p m ≃ Fin (edges p m) :=
  (Equiv.prodCongr finProdFinEquiv (Equiv.refl _)).trans finProdFinEquiv

def rawControl (direction : Fin 2) (row : Fin m) (position : Fin (Radix.size p)) :
    Fin (rawSize p m) := rawNodeEquiv p m ((direction, row), position)

def component (direction : Fin 2) : Table 2 (Radix.size p) (Radix.edges p) :=
  if direction = 0 then Radix.table p else reverseTable (Radix.table p)

private theorem component_deterministic (direction : Fin 2) : Deterministic (component p direction) := by
  unfold component
  split_ifs
  · exact Radix.deterministic p
  · exact reverseTable_deterministic _ (Radix.targetCompatible p)

private theorem component_targetCompatible (direction : Fin 2) :
    TargetCompatible (component p direction) := by
  unfold component
  split_ifs
  · exact Radix.targetCompatible p
  · exact reverseTable_targetCompatible _ (Radix.deterministic p)

def rawTable : Table 2 (rawSize p m) (edges p m) := fun index =>
  let arc := (arcEquiv p m).symm index
  Glue.mapEdge (rawControl p m arc.1.1 arc.1.2) (component p arc.1.1 arc.2)

@[simp] theorem rawTable_arc (owner : Fin 2 × Fin m) (index : Fin (Radix.edges p)) :
    rawTable p m (arcEquiv p m (owner, index)) =
      Glue.mapEdge (rawControl p m owner.1 owner.2) (component p owner.1 index) := by
  simp only [rawTable, Equiv.symm_apply_apply]

omit [NeZero p] in
private theorem rawControl_eq_iff (first second : Fin 2 × Fin m)
    (initial final : Fin (Radix.size p)) :
    rawControl p m first.1 first.2 initial = rawControl p m second.1 second.2 final ↔
      first = second ∧ initial = final := by
  change rawNodeEquiv p m (first, initial) = rawNodeEquiv p m (second, final) ↔ _
  rw [(rawNodeEquiv p m).injective.eq_iff, Prod.mk.injEq]

private theorem raw_deterministic : Deterministic (rawTable p m) := by
  intro first second different same
  obtain ⟨⟨owner, first⟩, rfl⟩ := (arcEquiv p m).surjective first
  obtain ⟨⟨other, second⟩, rfl⟩ := (arcEquiv p m).surjective second
  simp only [rawTable_arc, Glue.mapEdge] at same ⊢
  have ports := (rawControl_eq_iff p m owner other _ _).mp same
  rcases ports with ⟨rfl, positions⟩
  exact component_deterministic p owner.1 first second
    (fun equal => different (by subst second; rfl)) positions

private theorem raw_targetCompatible : TargetCompatible (rawTable p m) := by
  intro first second different same
  obtain ⟨⟨owner, first⟩, rfl⟩ := (arcEquiv p m).surjective first
  obtain ⟨⟨other, second⟩, rfl⟩ := (arcEquiv p m).surjective second
  simp only [rawTable_arc, Glue.mapEdge] at same ⊢
  have ports := (rawControl_eq_iff p m owner other _ _).mp same
  rcases ports with ⟨rfl, positions⟩
  exact component_targetCompatible p owner.1 first second
    (fun equal => different (by subst second; rfl)) positions

/-- A finite node address exposes whether it is a radix finish port. -/
def finishQuery (position : Fin (Radix.size p)) : Option (Fin p) :=
  match (Radix.nodeEquiv p).symm position with
  | .inl _ => none
  | .inr (remainder, phase) => if phase = 7 then some remainder else none

omit [NeZero p] in
@[simp] theorem finishQuery_finish (remainder : Fin p) :
    finishQuery p (Radix.finish p remainder) = some remainder := by
  simp [finishQuery, Radix.finish, Radix.block]

omit [NeZero p] in
theorem finishQuery_some {position : Fin (Radix.size p)} {remainder : Fin p}
    (selected : finishQuery p position = some remainder) : position = Radix.finish p remainder := by
  unfold finishQuery at selected
  cases shape : (Radix.nodeEquiv p).symm position with
  | inl global => simp [shape] at selected
  | inr pair =>
    rcases pair with ⟨symbol, phase⟩
    rw [shape] at selected
    dsimp only at selected
    split_ifs at selected with last
    · have symbols := Option.some.inj selected
      subst symbol
      apply (Radix.nodeEquiv p).symm.injective
      simp only [Radix.finish, Radix.block, Equiv.symm_apply_apply, shape, last]

private theorem finishQuery_source (index : Fin (Radix.edges p)) :
    finishQuery p (Radix.table p index).source = none := by
  cases selected : finishQuery p (Radix.table p index).source with
  | none => rfl
  | some remainder =>
    exact (Radix.no_outgoing_finish p remainder ⟨index, finishQuery_some p selected⟩).elim

/-- Only forward finish ports are matched, directly to the corresponding reversed copy. -/
def link (permutation : Fin p → Equiv.Perm (Fin m)) (position : Fin (rawSize p m)) :
    Option (Fin (rawSize p m)) :=
  let node := (rawNodeEquiv p m).symm position
  if node.1.1 = 0 then
    (finishQuery p node.2).map fun remainder => rawControl p m 1 (permutation remainder node.1.2) node.2
  else none

omit [NeZero p] in
@[simp] theorem link_backward (permutation : Fin p → Equiv.Perm (Fin m))
    (row : Fin m) (position : Fin (Radix.size p)) :
    link p m permutation (rawControl p m 1 row position) = none := by
  simp [link, rawControl]

omit [NeZero p] in
@[simp] theorem link_finish (permutation : Fin p → Equiv.Perm (Fin m))
    (row : Fin m) (remainder : Fin p) :
    link p m permutation (rawControl p m 0 row (Radix.finish p remainder)) =
      some (rawControl p m 1 (permutation remainder row) (Radix.finish p remainder)) := by
  simp [link, rawControl]

omit [NeZero p] in
/-- Every link is a finish-port equality; its remainder is an address in a fixed finite table. -/
theorem link_some (permutation : Fin p → Equiv.Perm (Fin m))
    {exit entry : Fin (rawSize p m)} (linked : link p m permutation exit = some entry) :
    ∃ row remainder, exit = rawControl p m 0 row (Radix.finish p remainder) ∧
      entry = rawControl p m 1 (permutation remainder row) (Radix.finish p remainder) := by
  obtain ⟨⟨⟨direction, row⟩, position⟩, rfl⟩ := (rawNodeEquiv p m).surjective exit
  change link p m permutation (rawControl p m direction row position) = some entry at linked
  simp only [link, rawControl, Equiv.symm_apply_apply] at linked
  split_ifs at linked with forward
  · cases selected : finishQuery p position with
    | none => simp [selected] at linked
    | some remainder =>
      simp only [selected, Option.map_some] at linked
      have target : rawControl p m 1 (permutation remainder row) position = entry :=
        Option.some.inj linked
      have position_eq := finishQuery_some p selected
      exact ⟨row, remainder, by simp only [forward, position_eq, rawControl],
        by simpa only [position_eq] using target.symm⟩

/-- Finite wiring is the only new data; the two existing edge families are unchanged. -/
def wiring (permutation : Fin p → Equiv.Perm (Fin m)) : PortNetwork.Wiring (rawTable p m) where
  link := link p m permutation
  terminal := by
    intro exit entry linked
    obtain ⟨row, remainder, rfl, rfl⟩ := link_some p m permutation linked
    exact link_backward p m permutation _ _
  injective := by
    intro first second entry left right
    obtain ⟨row, remainder, rfl, equal_left⟩ := link_some p m permutation left
    obtain ⟨other, symbol, rfl, equal_right⟩ := link_some p m permutation right
    have ports := (rawControl_eq_iff p m (1, permutation remainder row)
      (1, permutation symbol other) _ _).mp (equal_left.symm.trans equal_right)
    have symbols : remainder = symbol := by
      apply Fin.ext
      have raw := (Radix.nodeEquiv p).injective ports.2
      exact congrArg (fun node : Radix.Node p => node.elim (fun _ => 0) (fun pair => pair.1.val)) raw
    subst symbol
    have rows := (permutation remainder).injective (congrArg Prod.snd ports.1)
    rw [rows]
  source_free := by
    intro index
    obtain ⟨⟨⟨direction, row⟩, index⟩, rfl⟩ := (arcEquiv p m).surjective index
    fin_cases direction <;> simp [rawTable_arc, Glue.mapEdge, component, link, rawControl, finishQuery_source]
  target_free := by
    intro index exit linked
    obtain ⟨row, remainder, _, equal⟩ := link_some p m permutation linked
    obtain ⟨⟨⟨direction, other⟩, index⟩, rfl⟩ := (arcEquiv p m).surjective index
    fin_cases direction
    · simp only [rawTable_arc, Glue.mapEdge] at equal
      change rawControl p m 0 other (Radix.table p index).target =
        rawControl p m 1 (permutation remainder row) (Radix.finish p remainder) at equal
      have impossible : ((0 : Fin 2), other) = (1, permutation remainder row) :=
        ((rawControl_eq_iff p m (0, other) (1, permutation remainder row) _ _).mp equal).1
      exact (by simpa using congrArg Prod.fst impossible)
    · simp only [rawTable_arc, Glue.mapEdge] at equal
      change rawControl p m 1 other (Radix.table p index).source =
        rawControl p m 1 (permutation remainder row) (Radix.finish p remainder) at equal
      have ports := (rawControl_eq_iff p m (1, other) (1, permutation remainder row) _ _).mp equal
      exact Radix.no_outgoing_finish p remainder ⟨index, ports.2⟩

def size (permutation : Fin p → Equiv.Perm (Fin m)) : ℕ := PortNetwork.size (wiring p m permutation)

def table (permutation : Fin p → Equiv.Perm (Fin m)) : Table 2 (size p m permutation) (edges p m) :=
  PortNetwork.table (wiring p m permutation)

def front (permutation : Fin p → Equiv.Perm (Fin m)) (row : Fin m)
    (position : Fin (Radix.size p)) : Fin (size p m permutation) :=
  PortNetwork.control (wiring p m permutation) (rawControl p m 0 row position)

def back (permutation : Fin p → Equiv.Perm (Fin m)) (row : Fin m)
    (position : Fin (Radix.size p)) : Fin (size p m permutation) :=
  PortNetwork.control (wiring p m permutation) (rawControl p m 1 row position)

theorem deterministic (permutation : Fin p → Equiv.Perm (Fin m)) : Deterministic (table p m permutation) :=
  PortNetwork.deterministic _ (raw_deterministic p m)

theorem targetCompatible (permutation : Fin p → Equiv.Perm (Fin m)) : TargetCompatible (table p m permutation) :=
  PortNetwork.targetCompatible _ (raw_targetCompatible p m)

theorem front_finish (permutation : Fin p → Equiv.Perm (Fin m)) (row : Fin m) (remainder : Fin p) :
    front p m permutation row (Radix.finish p remainder) =
      back p m permutation (permutation remainder row) (Radix.finish p remainder) :=
  PortNetwork.interface _ (link_finish p m permutation row remainder)

@[simp] theorem table_front (permutation : Fin p → Equiv.Perm (Fin m))
    (row : Fin m) (index : Fin (Radix.edges p)) :
    table p m permutation (arcEquiv p m ((0, row), index)) =
      Glue.mapEdge (front p m permutation row) (Radix.table p index) := by
  change Glue.mapEdge (PortNetwork.control (wiring p m permutation))
    (rawTable p m (arcEquiv p m ((0, row), index))) = _
  rw [rawTable_arc]
  simp only [component, ite_true]
  rfl

@[simp] theorem table_back (permutation : Fin p → Equiv.Perm (Fin m))
    (row : Fin m) (index : Fin (Radix.edges p)) :
    table p m permutation (arcEquiv p m ((1, row), index)) =
      Glue.mapEdge (back p m permutation row) (reverseTable (Radix.table p) index) := by
  change Glue.mapEdge (PortNetwork.control (wiring p m permutation))
    (rawTable p m (arcEquiv p m ((1, row), index))) = _
  rw [rawTable_arc]
  simp only [component, Fin.isValue, Fin.reduceEq, ite_false]
  rfl

def inputPort (permutation : Fin p → Equiv.Perm (Fin m)) (row : Fin m) :
    Fin (size p m permutation) := front p m permutation row (Radix.entry p)

def outputPort (permutation : Fin p → Equiv.Perm (Fin m)) (row : Fin m) :
    Fin (size p m permutation) := back p m permutation row (Radix.entry p)

def point (permutation : Fin p → Equiv.Perm (Fin m)) (position : Fin (size p m permutation))
    (left right : ℤ) : State 2 (size p m permutation) := (position, ![left, right])

instance [NeZero m] (permutation : Fin p → Equiv.Perm (Fin m)) : NeZero (size p m permutation) := by
  change NeZero (Fintype.card (PortNetwork.Node (wiring p m permutation)))
  exact ⟨Nat.ne_of_gt (Fintype.card_pos_iff.mpr
    ⟨PortNetwork.representative (wiring p m permutation) (rawControl p m 1 0 (Radix.entry p))⟩)⟩

/-- Output boundaries retain their absence of outgoing edges after port identification. -/
theorem no_outgoing_output (permutation : Fin p → Equiv.Perm (Fin m)) (row : Fin m) :
    ¬ ∃ index, (table p m permutation index).source = outputPort p m permutation row := by
  rintro ⟨index, same⟩
  have raw_equal := PortNetwork.control_unlinked_injective (wiring p m permutation)
    ((wiring p m permutation).source_free index)
    (link_backward p m permutation row (Radix.entry p)) same
  obtain ⟨⟨owner, index⟩, rfl⟩ := (arcEquiv p m).surjective index
  simp only [rawTable_arc, Glue.mapEdge] at raw_equal
  have ports := (rawControl_eq_iff p m owner (1, row) _ _).mp raw_equal
  rcases ports with ⟨rfl, position⟩
  exact Radix.no_incoming_entry p index
    (by simpa only [component, Fin.isValue, Fin.reduceEq, ite_false, reverseTable, reverseEdge] using position)

/-- The actual remainder port selects a reversed copy, which restores both counter values. -/
theorem reaches_result (permutation : Fin p → Equiv.Perm (Fin m)) (row : Fin m) (value : ℕ) :
    StateTransition.Reaches (step (table p m permutation))
      (point p m permutation (inputPort p m permutation row) value 0)
      (point p m permutation (outputPort p m permutation (permutation (Counter.DivMod.residue p value) row)) value 0) := by
  have forward := Glue.reaches_map_live (Radix.table p) (table p m permutation)
    (front p m permutation row) (fun index => arcEquiv p m ((0, row), index))
    (fun index => table_front p m permutation row index)
    (Radix.deterministic p) (deterministic p m permutation) (Radix.reaches_result p value)
  have backward := Glue.reaches_map_live (reverseTable (Radix.table p)) (table p m permutation)
    (back p m permutation (permutation (Counter.DivMod.residue p value) row))
    (fun index => arcEquiv p m ((1, permutation (Counter.DivMod.residue p value) row), index))
    (fun index => table_back p m permutation _ index)
    (reverseTable_deterministic _ (Radix.targetCompatible p)) (deterministic p m permutation)
    (Radix.reverse_pack p (value / p) (Counter.DivMod.residue p value))
  change StateTransition.Reaches (step (table p m permutation))
    (point p m permutation (inputPort p m permutation row) value 0)
    (point p m permutation (front p m permutation row (Radix.finish p (Counter.DivMod.residue p value)))
      (value / p : ℕ) 0) at forward
  rw [front_finish] at forward
  change StateTransition.Reaches (step (table p m permutation))
    (point p m permutation (back p m permutation (permutation (Counter.DivMod.residue p value) row)
      (Radix.finish p (Counter.DivMod.residue p value))) (value / p : ℕ) 0)
    (point p m permutation (outputPort p m permutation (permutation (Counter.DivMod.residue p value) row))
      (p * (value / p) + (Counter.DivMod.residue p value).val : ℕ) 0) at backward
  have restore : p * (value / p) + (Counter.DivMod.residue p value).val = value := by
    simpa only [Counter.DivMod.residue, Nat.add_comm] using Nat.mod_add_div value p
  rw [restore] at backward
  exact forward.trans backward

theorem halt_output (permutation : Fin p → Equiv.Perm (Fin m)) (row : Fin m)
    (values : Fin 2 → ℤ) : step (table p m permutation) (outputPort p m permutation row, values) = none := by
  rw [step_none_iff]
  rintro ⟨index, enabled⟩
  exact no_outgoing_output p m permutation row ⟨index, enabled.1⟩

/-- Complete execution changes finite control and restores the full two-counter memory. -/
theorem eval_result (permutation : Fin p → Equiv.Perm (Fin m)) (row : Fin m) (value : ℕ) :
    eval (table p m permutation) (point p m permutation (inputPort p m permutation row) value 0) =
      Part.some (point p m permutation
        (outputPort p m permutation (permutation (Counter.DivMod.residue p value) row)) value 0) := by
  apply Part.eq_some_iff.mpr
  exact StateTransition.mem_eval.mpr
    ⟨reaches_result p m permutation row value, halt_output p m permutation _ _⟩

/-- The existing five-gate compiler realizes the same port network on three persistent roots. -/
theorem native_eval [NeZero m] (permutation : Fin p → Equiv.Perm (Fin m))
    (row : Fin m) (value : ℕ) :
    (ReversibleCompilation.haltingProgram (table p m permutation)
      (deterministic p m permutation) (targetCompatible p m permutation)).eval
      (ReversibleCompilation.iota (e := edges p m)
        (point p m permutation (inputPort p m permutation row) value 0)) =
      Part.some (ReversibleCompilation.iota (e := edges p m)
        (point p m permutation
          (outputPort p m permutation (permutation (Counter.DivMod.residue p value) row)) value 0)) := by
  apply ReversibleCompilation.eval_of_reaches
  · exact reaches_result p m permutation row value
  · exact no_outgoing_output p m permutation _

end Monodromy.Counter.Reversible.RadixObservationNetwork
