import Monodromy.Counter

/-!
Finite control graphs compose by identifying output ports with input ports.
Only the port incidence changes: every original edge and action is retained.
-/

noncomputable section

namespace Monodromy.Counter.Reversible.PortNetwork

variable {n q e : ℕ}

/-- A partial injective matching from exits with no outgoing edge to entries
with no incoming edge. Destinations are not themselves matched exits. -/
structure Wiring (original : Table n q e) where
  link : Fin q → Option (Fin q)
  terminal : ∀ {exit entry}, link exit = some entry → link entry = none
  injective : ∀ {first second entry}, link first = some entry →
    link second = some entry → first = second
  source_free : ∀ index, link (original index).source = none
  target_free : ∀ index exit, link exit ≠ some (original index).target

variable {original : Table n q e} (wiring : Wiring original)

/-- Matched exits disappear; their incident targets use the selected entry. -/
abbrev Node := {position : Fin q // wiring.link position = none}

def representative (position : Fin q) : Node wiring :=
  match selected : wiring.link position with
  | none => ⟨position, selected⟩
  | some entry => ⟨entry, wiring.terminal selected⟩

def size : ℕ := Fintype.card (Node wiring)

def nodeEquiv : Node wiring ≃ Fin (size wiring) := Fintype.equivFin _

def control (position : Fin q) : Fin (size wiring) :=
  nodeEquiv wiring (representative wiring position)

def table : Table n (size wiring) e := fun index =>
  Glue.mapEdge (control wiring) (original index)

@[simp] theorem table_source (index : Fin e) :
    (table wiring index).source = control wiring (original index).source := rfl

@[simp] theorem table_target (index : Fin e) :
    (table wiring index).target = control wiring (original index).target := rfl

@[simp] theorem table_action (index : Fin e) :
    (table wiring index).action = (original index).action := rfl

@[simp] theorem representative_unlinked (position : Fin q)
    (unlinked : wiring.link position = none) :
    (representative wiring position).val = position := by
  unfold representative
  split <;> simp_all

@[simp] theorem representative_linked (exit entry : Fin q)
    (linked : wiring.link exit = some entry) :
    (representative wiring exit).val = entry := by
  unfold representative
  split <;> simp_all

/-- Retained vertices are already their own representatives. -/
@[simp] theorem control_on_retained (position : Node wiring) :
    control wiring position.val = nodeEquiv wiring position := by
  apply congrArg (nodeEquiv wiring)
  apply Subtype.ext
  exact representative_unlinked wiring position.val position.property

/-- A wire is a literal equality of control positions, not a new transition. -/
theorem interface {exit entry : Fin q} (linked : wiring.link exit = some entry) :
    control wiring exit = control wiring entry := by
  apply congrArg (nodeEquiv wiring)
  apply Subtype.ext
  rw [representative_linked wiring exit entry linked,
    representative_unlinked wiring entry (wiring.terminal linked)]

theorem control_unlinked_injective {first second : Fin q}
    (first_free : wiring.link first = none) (second_free : wiring.link second = none)
    (same : control wiring first = control wiring second) : first = second := by
  have representatives := (nodeEquiv wiring).injective same
  have positions := congrArg Subtype.val representatives
  simpa only [representative_unlinked wiring first first_free,
    representative_unlinked wiring second second_free] using positions

/-- Sources are never normalized, so their incidence is preserved exactly. -/
theorem source_eq_iff (first second : Fin e) :
    control wiring (original first).source = control wiring (original second).source ↔
      (original first).source = (original second).source := by
  constructor
  · exact control_unlinked_injective wiring (wiring.source_free first) (wiring.source_free second)
  · exact congrArg (control wiring)

/-- Distinct original targets cannot merge: matched entries have no incoming edge,
and the exit-to-entry wiring is injective. -/
theorem target_eq_iff (first second : Fin e) :
    control wiring (original first).target = control wiring (original second).target ↔
      (original first).target = (original second).target := by
  constructor
  · intro same
    have positions := congrArg Subtype.val ((nodeEquiv wiring).injective same)
    cases left : wiring.link (original first).target with
    | none =>
      cases right : wiring.link (original second).target with
      | none => exact control_unlinked_injective wiring left right same
      | some entry =>
        have eq_entry : (original first).target = entry := by
          simpa only [representative_unlinked wiring _ left,
            representative_linked wiring _ _ right] using positions
        exact False.elim (wiring.target_free first (original second).target (eq_entry ▸ right))
    | some entry =>
      cases right : wiring.link (original second).target with
      | none =>
        have eq_entry : entry = (original second).target := by
          simpa only [representative_linked wiring _ _ left,
            representative_unlinked wiring _ right] using positions
        exact False.elim (wiring.target_free second (original first).target (eq_entry ▸ left))
      | some other =>
        have entries : entry = other := by
          simpa only [representative_linked wiring _ _ left,
            representative_linked wiring _ _ right] using positions
        exact wiring.injective left (entries ▸ right)
  · exact congrArg (control wiring)

/-- Gluing preserves the original forward local reversibility condition. -/
theorem deterministic (valid : Deterministic original) : Deterministic (table wiring) := by
  intro first second different same
  exact valid first second different ((source_eq_iff wiring first second).mp same)

/-- Gluing preserves the original backward local reversibility condition. -/
theorem targetCompatible (valid : TargetCompatible original) : TargetCompatible (table wiring) := by
  intro first second different same
  exact valid first second different ((target_eq_iff wiring first second).mp same)

/-- Every original live step remains an actual step of the graph with identified ports. -/
theorem step_map_live (valid : Deterministic original) {first last : State n q}
    (transition : step original first = some last) :
    step (table wiring) (Glue.mapState (control wiring) first) =
      some (Glue.mapState (control wiring) last) := by
  exact Glue.step_map_live original (table wiring) (control wiring) id
    (fun _ => rfl) valid (deterministic wiring valid) transition

/-- Finite runs compose through literal port equalities and preserve all registers. -/
theorem reaches_map_live (valid : Deterministic original) {first last : State n q}
    (run : StateTransition.Reaches (step original) first last) :
    StateTransition.Reaches (step (table wiring))
      (Glue.mapState (control wiring) first) (Glue.mapState (control wiring) last) := by
  exact Glue.reaches_map_live original (table wiring) (control wiring) id
    (fun _ => rfl) valid (deterministic wiring valid) run

/-- A positive run remains positive even when an exit is identified with its own entry. -/
theorem reaches1_map_live (valid : Deterministic original) {first last : State n q}
    (run : StateTransition.Reaches₁ (step original) first last) :
    StateTransition.Reaches₁ (step (table wiring))
      (Glue.mapState (control wiring) first) (Glue.mapState (control wiring) last) := by
  exact Relation.TransGen.lift (Glue.mapState (control wiring))
    (fun _ _ transition => step_map_live wiring valid transition) _ _ run

end Monodromy.Counter.Reversible.PortNetwork
