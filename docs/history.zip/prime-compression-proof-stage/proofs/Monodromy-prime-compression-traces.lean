import «Monodromy-prime-compression-simulation»

/-! Exact compression of complete finite source traces on the natural lattice. -/

namespace Monodromy.Counter.Reversible.PrimeCompression

variable {n q e : ℕ}

def toNatural (state : State n q) : Counter.Configuration n q :=
  ⟨state.1, fun index => (state.2 index).toNat⟩

theorem naturalState_toNatural (state : State n q) (nonnegative : ∀ index, 0 ≤ state.2 index) :
    naturalState (toNatural state) = state := by
  apply Prod.ext
  · rfl
  · funext index
    exact Int.toNat_of_nonneg (nonnegative index)

/-- Every live step whose endpoints lie on the natural lattice has an actual positive compression. -/
theorem integer_step_reaches (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (unit : ∀ edge, Action.UnitShift (source edge).action)
    {first last : State n q} (transition : step source first = some last)
    (first_natural : ∀ index, 0 ≤ first.2 index) (last_natural : ∀ index, 0 ≤ last.2 index) :
    StateTransition.Reaches₁ (step (table basis source deterministic compatible))
      (encode basis source deterministic compatible (toNatural first))
      (encode basis source deterministic compatible (toNatural last)) := by
  apply step_reaches basis source deterministic compatible unit
  rw [naturalState_toNatural first first_natural, naturalState_toNatural last last_natural]
  exact transition

/-- A source invariant covers every intermediate step, not only the two encoded endpoints. -/
theorem integer_reaches1 (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (unit : ∀ edge, Action.UnitShift (source edge).action)
    {first last : State n q} (run : StateTransition.Reaches₁ (step source) first last)
    (natural : ∀ state, StateTransition.Reaches (step source) first state → ∀ index, 0 ≤ state.2 index) :
    StateTransition.Reaches₁ (step (table basis source deterministic compatible))
      (encode basis source deterministic compatible (toNatural first))
      (encode basis source deterministic compatible (toNatural last)) := by
  induction run with
  | single transition =>
      exact integer_step_reaches basis source deterministic compatible unit transition
        (natural _ Relation.ReflTransGen.refl) (natural _ (Relation.ReflTransGen.single transition))
  | @tail middle last earlier transition previous =>
      exact previous.trans (integer_step_reaches basis source deterministic compatible unit transition
        (natural middle earlier.to_reflTransGen)
        (natural last (earlier.to_reflTransGen.tail transition)))

end Monodromy.Counter.Reversible.PrimeCompression
