import «Monodromy-prime-compression-wiring»

/-! Static edge identities used by the exact execution simulation. -/

namespace Monodromy.Counter.Reversible.PrimeCompression

variable {n q e : ℕ}

def siteOfEdge (source : Table n q e) (edge : Fin e) : SourceSite source :=
  ⟨(source edge).source, edge, rfl⟩

def restoreOfTest (source : Table n q e) (edge : Fin e) (register : Fin n) (flag : Bool)
    (test : (source edge).action = .test register flag) : RestoreSite source :=
  ⟨(source edge).target, edge, rfl, register, flag, test⟩

theorem sourceEdge_of_shift (source : Table n q e) (deterministic : Deterministic source)
    (edge : Fin e) (register : Fin n) (amount : ℤ)
    (shift : (source edge).action = .shift register amount) :
    sourceEdge source (siteOfEdge source edge) = edge := by
  apply Eq.symm
  exact shift_owner_unique source (fun index => (source index).source) deterministic shift
    (sourceEdge_spec source (siteOfEdge source edge)).symm

theorem sourceRegister_of_shift (source : Table n q e) (deterministic : Deterministic source)
    (edge : Fin e) (register : Fin n) (amount : ℤ)
    (shift : (source edge).action = .shift register amount) :
    moduleRegister source (.inl (siteOfEdge source edge)) = register := by
  simp only [moduleRegister, sourceEdge_of_shift source deterministic edge register amount shift,
    shift, actionRegister]

theorem sourceForm_of_test (source : Table n q e) (deterministic : Deterministic source)
    (edge : Fin e) (register : Fin n) (flag : Bool)
    (test : (source edge).action = .test register flag) :
    ∃ chosen, (source (sourceEdge source (siteOfEdge source edge))).action = .test register chosen :=
  test_owner_form source (fun index => (source index).source) deterministic test
    (sourceEdge_spec source (siteOfEdge source edge)).symm

theorem sourceRegister_of_test (source : Table n q e) (deterministic : Deterministic source)
    (edge : Fin e) (register : Fin n) (flag : Bool)
    (test : (source edge).action = .test register flag) :
    moduleRegister source (.inl (siteOfEdge source edge)) = register := by
  obtain ⟨chosen, form⟩ := sourceForm_of_test source deterministic edge register flag test
  simp only [moduleRegister, form, actionRegister]

theorem restoreRegister_of_test (source : Table n q e) (compatible : TargetCompatible source)
    (edge : Fin e) (register : Fin n) (flag : Bool)
    (test : (source edge).action = .test register flag) :
    moduleRegister source (.inr (restoreOfTest source edge register flag test)) = register := by
  obtain ⟨chosen, form⟩ := test_owner_form source (fun index => (source index).target) compatible test
    (restoreEdge_spec source (restoreOfTest source edge register flag test)).1.symm
  simp only [moduleRegister, form, actionRegister]

/-- The end of a shift is joined directly to its statically specified target. -/
theorem shift_connected (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (edge : Fin e) (register : Fin n) (amount : ℤ)
    (shift : (source edge).action = .shift register amount) :
    Connection basis source (sourceShiftOutput basis source (siteOfEdge source edge))
      (boundary basis source (source edge).target) := by
  refine Or.inl ⟨siteOfEdge source edge, ?_, rfl, ?_⟩
  · simp only [sourceEdge_of_shift source deterministic edge register amount shift, shift, Action.IsShift]
  · rw [sourceEdge_of_shift source deterministic edge register amount shift]

/-- Restoration returns directly to the target execution boundary. -/
theorem restore_connected (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : RestoreSite source) :
    Connection basis source (restoreOutput basis source site) (boundary basis source site.val) :=
  Or.inr (Or.inl ⟨site, rfl, rfl⟩)

/-- A selected test edge identifies exactly the actually reached remainder ports. -/
theorem test_connected (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (edge : Fin e) (register : Fin n) (flag : Bool)
    (test : (source edge).action = .test register flag)
    (remainder : Fin (modulus basis source (.inl (siteOfEdge source edge))))
    (restored : Fin (modulus basis source (.inr (restoreOfTest source edge register flag test))))
    (same : remainder.val = restored.val) (selected : decide (remainder.val ≠ 0) = flag) :
    Connection basis source
      (moduleNode basis source (.inl (siteOfEdge source edge)) (Radix.finish _ remainder))
      (restoreInput basis source (restoreOfTest source edge register flag test) restored) := by
  refine Or.inr (Or.inr ⟨siteOfEdge source edge, restoreOfTest source edge register flag test,
    remainder, restored, edge, rfl, rfl, ?_, ?_, same, rfl, rfl⟩)
  · rw [testSelected_iff, sourceRegister_of_test source deterministic edge register flag test, selected]
    exact test
  · exact (sourceRegister_of_test source deterministic edge register flag test).trans
      (restoreRegister_of_test source compatible edge register flag test).symm

end Monodromy.Counter.Reversible.PrimeCompression
