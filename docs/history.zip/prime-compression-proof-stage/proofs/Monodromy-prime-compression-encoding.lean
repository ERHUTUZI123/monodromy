import «Monodromy-prime-compression-wiring»

/-!
A source boundary retains its finite control position and entire prime-coded
register vector. Static source halts remain genuine graph exits after gluing.
-/

noncomputable section

namespace Monodromy.Counter.Reversible.PrimeCompression

variable {n q e : ℕ}

/-- A retained source boundary is never removed by the static port matching. -/
theorem boundary_link_none (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source) (position : Fin q) :
    (wiring basis source deterministic compatible).link (boundary basis source position) = none := by
  change PortNetwork.relationLink (Connection basis source) (boundary basis source position) = none
  exact (PortNetwork.relationLink_none_iff (Connection basis source) _).mpr
    (boundary_unconnected basis source deterministic position)

/-- The complete natural source configuration occupies two integer counters. -/
def encode (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (state : Counter.Configuration n q) : State 2 (size basis source deterministic compatible) :=
  (PortNetwork.control (wiring basis source deterministic compatible)
    (boundary basis source state.pc), ![(basis.encode state.counters : ℤ), 0])

/-- No information about the finite address or the complete source register vector is lost. -/
theorem encode_injective (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source) :
    Function.Injective (encode basis source deterministic compatible) := by
  intro first second same
  have controls := congrArg Prod.fst same
  have raw_controls := PortNetwork.control_unlinked_injective
    (wiring basis source deterministic compatible)
    (boundary_link_none basis source deterministic compatible first.pc)
    (boundary_link_none basis source deterministic compatible second.pc) controls
  have addresses := boundary_injective basis source raw_controls
  have integer_codes := congrArg
    (fun state : State 2 (size basis source deterministic compatible) => state.2 0) same
  have codes : basis.encode first.counters = basis.encode second.counters := by
    apply Int.natCast_inj.mp
    simpa only [encode, Matrix.cons_val_zero] using integer_codes
  have registers := basis.encode_injective codes
  exact congrArg₂ Counter.Configuration.mk addresses registers

/-- A connection is a control-position equality, with no intermediate transition. -/
theorem connection_controls (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    {exit entry : Fin (rawSize basis source)} (connected : Connection basis source exit entry) :
    PortNetwork.control (wiring basis source deterministic compatible) exit =
      PortNetwork.control (wiring basis source deterministic compatible) entry := by
  apply PortNetwork.interface
  change PortNetwork.relationLink (Connection basis source) exit = some entry
  exact (PortNetwork.relationLink_some_iff (Connection basis source)
    (connection_functional basis source deterministic) exit entry).mpr connected

/-- A source address without outgoing edges is represented by an isolated raw vertex. -/
theorem raw_no_outgoing_halt (basis : PrimeCode.Basis n) (source : Table n q e)
    (position : Fin q) (halted : ¬ HasSource source position) (index : Fin (rawEdges basis source)) :
    (rawTable basis source index).source ≠ boundary basis source position := by
  intro same
  obtain ⟨⟨block, index⟩, rfl⟩ := (rawArcEquiv basis source).surjective index
  simp only [rawTable_arc, rawEdge, Glue.mapEdge, boundary, dite_eq_right halted] at same
  exact haltNode_ne_moduleNode basis source ⟨position, halted⟩ _ _ same.symm

/-- Static halts retain their absence of outgoing edges in the actual compressed table. -/
theorem no_outgoing_boundary (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (position : Fin q) (halted : ¬ HasSource source position) :
    ¬ ∃ index, (table basis source deterministic compatible index).source =
      PortNetwork.control (wiring basis source deterministic compatible)
        (boundary basis source position) := by
  rintro ⟨index, same⟩
  have raw_controls := PortNetwork.control_unlinked_injective
    (wiring basis source deterministic compatible)
    ((wiring basis source deterministic compatible).source_free index)
    (boundary_link_none basis source deterministic compatible position) same
  exact raw_no_outgoing_halt basis source position halted index raw_controls

/-- At a statically halted source address the compressed graph stops for every source value. -/
theorem step_encode_none_of_no_source (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (state : Counter.Configuration n q) (halted : ¬ HasSource source state.pc) :
    step (table basis source deterministic compatible)
      (encode basis source deterministic compatible state) = none := by
  rw [step_none_iff]
  rintro ⟨index, enabled⟩
  exact no_outgoing_boundary basis source deterministic compatible state.pc halted ⟨index, enabled.1⟩

end Monodromy.Counter.Reversible.PrimeCompression
