import «Monodromy-prime-compression»

/-! Backward uniqueness of the static finite prime-compression connections. -/

namespace Monodromy.Counter.Reversible.PrimeCompression

variable {n q e : ℕ}

private theorem boundary_ne_restoreInput (basis : PrimeCode.Basis n) (source : Table n q e)
    (position : Fin q) (site : RestoreSite source)
    (remainder : Fin (modulus basis source (.inr site))) :
    boundary basis source position ≠ restoreInput basis source site remainder := by
  intro same
  by_cases active : HasSource source position
  · simp only [boundary, dite_eq_left active, sourceInput, restoreInput] at same
    cases moduleNode_module basis source same
  · simp only [boundary, dite_eq_right active] at same
    exact haltNode_ne_moduleNode basis source ⟨position, active⟩ _ _ same

private theorem shift_connection_backward (basis : PrimeCode.Basis n) (source : Table n q e)
    (compatible : TargetCompatible source) {first last entry : Fin (rawSize basis source)}
    (left : ShiftConnection basis source first entry)
    (right : ShiftConnection basis source last entry) : first = last := by
  obtain ⟨left_site, left_shift, left_exit, left_entry⟩ := left
  obtain ⟨right_site, _, right_exit, right_entry⟩ := right
  have targets := boundary_injective basis source (left_entry.symm.trans right_entry)
  have edges : sourceEdge source left_site = sourceEdge source right_site := by
    cases action : (source (sourceEdge source left_site)).action with
    | test => simp [action, Action.IsShift] at left_shift
    | shift register amount =>
        exact shift_owner_unique source (fun edge => (source edge).target) compatible action targets
  have sites : left_site = right_site := Subtype.ext (by
    calc
      left_site.val = (source (sourceEdge source left_site)).source :=
        (sourceEdge_spec source left_site).symm
      _ = (source (sourceEdge source right_site)).source := congrArg (fun edge => (source edge).source) edges
      _ = right_site.val := sourceEdge_spec source right_site)
  subst right_site
  exact left_exit.trans right_exit.symm

private theorem shift_restore_disjoint (basis : PrimeCode.Basis n) (source : Table n q e)
    (compatible : TargetCompatible source) {first last entry : Fin (rawSize basis source)}
    (shift : ShiftConnection basis source first entry)
    (restore : RestoreConnection basis source last entry) : False := by
  obtain ⟨left, is_shift, _, left_entry⟩ := shift
  obtain ⟨right, _, right_entry⟩ := restore
  have targets := boundary_injective basis source (left_entry.symm.trans right_entry)
  obtain ⟨register, atZero, test⟩ := (restoreEdge_spec source right).2
  obtain ⟨flag, form⟩ := test_owner_form source (fun edge => (source edge).target) compatible test
    ((restoreEdge_spec source right).1.trans targets.symm)
  rw [form] at is_shift
  exact is_shift

private theorem test_connection_backward (basis : PrimeCode.Basis n) (source : Table n q e)
    (compatible : TargetCompatible source) {first last entry : Fin (rawSize basis source)}
    (left : TestConnection basis source first entry)
    (right : TestConnection basis source last entry) : first = last := by
  obtain ⟨left_site, left_target, left_r, left_s, left_edge, left_src, left_dst,
    left_selected, left_registers, left_values, left_exit, left_entry⟩ := left
  obtain ⟨right_site, right_target, right_r, right_s, right_edge, right_src, right_dst,
    right_selected, right_registers, right_values, right_exit, right_entry⟩ := right
  have targets : left_target = right_target := Sum.inr.inj
    (moduleNode_module basis source (left_entry.symm.trans right_entry))
  subst right_target
  have finishes := moduleNode_position basis source (.inr left_target)
    (left_entry.symm.trans right_entry)
  have restored : left_s = right_s := by
    have pair := (Radix.nodeEquiv _).injective finishes
    simpa only [Sum.inr.injEq, Prod.mk.injEq, and_true] using pair
  subst right_s
  have residues : left_r.val = right_r.val := left_values.trans right_values.symm
  have registers : moduleRegister source (.inl left_site) = moduleRegister source (.inl right_site) :=
    left_registers.trans right_registers.symm
  have right_chosen : testSelected source (moduleRegister source (.inl left_site)) left_r.val
      right_edge = true := by
    rw [registers, residues]
    exact right_selected
  have edges : left_edge = right_edge := target_test_matching source compatible
    (moduleRegister source (.inl left_site)) left_r.val left_edge right_edge
    left_selected right_chosen (left_dst.trans right_dst.symm)
  subst right_edge
  have sources : left_site = right_site := Subtype.ext (left_src.symm.trans right_src)
  subst right_site
  have residue : left_r = right_r := Fin.ext residues
  subst right_r
  exact left_exit.trans right_exit.symm

/-- Static port wiring is injective toward each entry, including all three connection forms. -/
theorem connection_backward (basis : PrimeCode.Basis n) (source : Table n q e)
    (compatible : TargetCompatible source) {first last entry : Fin (rawSize basis source)}
    (left : Connection basis source first entry)
    (right : Connection basis source last entry) : first = last := by
  rcases left with left | left | left <;> rcases right with right | right | right
  · exact shift_connection_backward basis source compatible left right
  · exact False.elim (shift_restore_disjoint basis source compatible left right)
  · obtain ⟨site, _, _, entered⟩ := left
    obtain ⟨_, target, _, residue, _, _, _, _, _, _, _, restored⟩ := right
    exact False.elim (boundary_ne_restoreInput basis source _ target residue
      (entered.symm.trans restored))
  · exact False.elim (shift_restore_disjoint basis source compatible right left)
  · obtain ⟨left_site, left_exit, left_entry⟩ := left
    obtain ⟨right_site, right_exit, right_entry⟩ := right
    have sites : left_site = right_site := Subtype.ext
      (boundary_injective basis source (left_entry.symm.trans right_entry))
    subst right_site
    exact left_exit.trans right_exit.symm
  · obtain ⟨site, _, entered⟩ := left
    obtain ⟨_, target, _, residue, _, _, _, _, _, _, _, restored⟩ := right
    exact False.elim (boundary_ne_restoreInput basis source site.val target residue
      (entered.symm.trans restored))
  · obtain ⟨_, target, _, residue, _, _, _, _, _, _, _, restored⟩ := left
    obtain ⟨site, _, _, entered⟩ := right
    exact False.elim (boundary_ne_restoreInput basis source _ target residue
      (entered.symm.trans restored))
  · obtain ⟨_, target, _, residue, _, _, _, _, _, _, _, restored⟩ := left
    obtain ⟨site, _, entered⟩ := right
    exact False.elim (boundary_ne_restoreInput basis source site.val target residue
      (entered.symm.trans restored))
  · exact test_connection_backward basis source compatible left right

end Monodromy.Counter.Reversible.PrimeCompression
