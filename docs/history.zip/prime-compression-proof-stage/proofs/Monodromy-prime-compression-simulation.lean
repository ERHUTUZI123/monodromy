import «Monodromy-prime-compression-increment»
import «Monodromy-prime-compression-decrement»
import «Monodromy-prime-compression-test-execution»

/-!
Every defined unit-shift source step between natural configurations is an
actual positive run of the compressed two-counter graph. This statement
concerns live source steps; static terminal addresses are treated separately.
-/

namespace Monodromy.Counter.Reversible.PrimeCompression

variable {n q e : ℕ}

/-- Natural configurations are viewed inside the integer source state space. -/
def naturalState (state : Counter.Configuration n q) : State n q :=
  (state.pc, fun index => (state.counters index : ℤ))

theorem naturalState_injective : Function.Injective (@naturalState n q) := by
  intro first second same
  apply congrArg₂ Counter.Configuration.mk
  · exact congrArg Prod.fst same
  · funext index
    exact Int.natCast_inj.mp (congrArg (fun state : State n q => state.2 index) same)

private theorem naturalState_shift (before : Counter.Configuration n q) (target : Fin q)
    (register : Fin n) (amount : ℤ) (value : ℕ)
    (arithmetic : (before.counters register : ℤ) + amount = value) :
    (target, Action.apply (.shift register amount) (naturalState before).2) =
      naturalState ⟨target, Function.update before.counters register value⟩ := by
  apply Prod.ext
  · rfl
  · funext index
    by_cases selected : index = register
    · subst index
      simpa only [naturalState, Action.apply, Function.update_self] using arithmetic
    · simp [naturalState, Action.apply, selected]

/-- Compression preserves a complete live source transition on the natural domain. -/
theorem step_reaches (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (unit : ∀ edge, Action.UnitShift (source edge).action)
    {before after : Counter.Configuration n q}
    (transition : step source (naturalState before) = some (naturalState after)) :
    StateTransition.Reaches₁ (step (table basis source deterministic compatible))
      (encode basis source deterministic compatible before)
      (encode basis source deterministic compatible after) := by
  obtain ⟨edge, enabled, result⟩ := (step_iff source deterministic).mp transition
  have at_source : (source edge).source = before.pc := enabled.1
  cases operation : (source edge).action with
  | shift register amount =>
      have elementary : amount = 1 ∨ amount = -1 := by
        simpa only [operation, Action.UnitShift] using unit edge
      simp only [Edge.execute, operation] at result
      rcases elementary with forward | backward
      · subst amount
        have shape :
            ⟨(source edge).target,
              Function.update before.counters register (before.counters register + 1)⟩ = after := by
          apply naturalState_injective
          exact (naturalState_shift before (source edge).target register 1
            (before.counters register + 1) (by simp)).symm.trans result
        subst after
        exact increment_reaches basis source deterministic compatible before edge register at_source operation
      · subst amount
        have selected : (before.counters register : ℤ) + (-1) = after.counters register := by
          simpa only [Action.apply, naturalState, Function.update_self] using
            congrArg (fun state : State n q => state.2 register) result
        have positive : before.counters register ≠ 0 := by
          have nonnegative := Int.natCast_nonneg (after.counters register)
          omega
        have arithmetic : (before.counters register : ℤ) + (-1) =
            (before.counters register - 1 : ℕ) := by omega
        have shape :
            ⟨(source edge).target,
              Function.update before.counters register (before.counters register - 1)⟩ = after := by
          apply naturalState_injective
          exact (naturalState_shift before (source edge).target register (-1)
            (before.counters register - 1) arithmetic).symm.trans result
        subst after
        exact decrement_reaches basis source deterministic compatible before edge register at_source operation positive
  | test register flag =>
      simp only [Edge.execute, operation, Action.apply] at result
      have shape : ⟨(source edge).target, before.counters⟩ = after := by
        apply naturalState_injective
        exact result
      subst after
      exact test_reaches basis source deterministic compatible before edge register flag
        at_source operation enabled.2

end Monodromy.Counter.Reversible.PrimeCompression
