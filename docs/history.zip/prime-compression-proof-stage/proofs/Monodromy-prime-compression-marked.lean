import «Monodromy-prime-compression-simulation-return»

/-!
Finite marked first returns survive compression. A source invariant supplies
the natural lattice at every intermediate source step; the fixed execution
table is unchanged.
-/

noncomputable section

namespace Monodromy.Counter.Reversible.PrimeCompression

variable {n q e : ℕ}

def toNatural (state : State n q) : Counter.Configuration n q :=
  ⟨state.1, fun index => (state.2 index).toNat⟩

theorem naturalState_toNatural (state : State n q) (nonnegative : ∀ index, 0 ≤ state.2 index) :
    naturalState (toNatural state) = state := by
  apply Prod.ext
  · rfl
  · funext index
    exact Int.toNat_of_nonneg (nonnegative index)

/-- Integer source endpoints on the natural lattice retain the exact compiled first return. -/
theorem integer_step_firstReturn (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (unit : ∀ edge, Action.UnitShift (source edge).action)
    {first last : State n q} (transition : step source first = some last)
    (first_natural : ∀ index, 0 ≤ first.2 index) (last_natural : ∀ index, 0 ≤ last.2 index) :
    FirstReturn basis source deterministic compatible
      (encode basis source deterministic compatible (toNatural first))
      (encode basis source deterministic compatible (toNatural last)) := by
  apply step_firstReturn basis source deterministic compatible unit
  rw [naturalState_toNatural first first_natural, naturalState_toNatural last last_natural]
  exact transition

/-- A finite marked subset of the retained source-control positions. -/
def Marked (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (mark : Fin q → Bool) (state : State 2 (size basis source deterministic compatible)) : Prop :=
  ∃ position : Fin q, state.1 = PortNetwork.control (wiring basis source deterministic compatible)
    (boundary basis source position) ∧ mark position = true

theorem marked_boundary (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    {mark : Fin q → Bool} {state : State 2 (size basis source deterministic compatible)}
    (marked : Marked basis source deterministic compatible mark state) :
    Boundary basis source deterministic compatible state := by
  obtain ⟨position, equal, _⟩ := marked
  exact ⟨position, equal⟩

theorem marked_encode_iff (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (mark : Fin q → Bool) (state : Counter.Configuration n q) :
    Marked basis source deterministic compatible mark
      (encode basis source deterministic compatible state) ↔ mark state.pc = true := by
  constructor
  · rintro ⟨position, equal, marked⟩
    have addresses := boundary_injective basis source
      (PortNetwork.control_unlinked_injective (wiring basis source deterministic compatible)
        (boundary_link_none basis source deterministic compatible state.pc)
        (boundary_link_none basis source deterministic compatible position) equal)
    rw [addresses]
    exact marked
  · exact fun marked => ⟨state.pc, rfl, marked⟩

def InternalMarkedStep (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source) (mark : Fin q → Bool)
    (first last : State 2 (size basis source deterministic compatible)) : Prop :=
  step (table basis source deterministic compatible) first = some last ∧
    ¬ Marked basis source deterministic compatible mark first

abbrev InternalMarkedReaches (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source) (mark : Fin q → Bool) :=
  Relation.ReflTransGen (InternalMarkedStep basis source deterministic compatible mark)

def MarkedFirstReturn (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source) (mark : Fin q → Bool)
    (first last : State 2 (size basis source deterministic compatible)) : Prop :=
  Marked basis source deterministic compatible mark first ∧
  Marked basis source deterministic compatible mark last ∧
  ∃ next, step (table basis source deterministic compatible) first = some next ∧
    InternalMarkedReaches basis source deterministic compatible mark next last

private theorem internal_to_marked (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source) (mark : Fin q → Bool)
    {first last : State 2 (size basis source deterministic compatible)}
    (run : InternalReaches basis source deterministic compatible first last) :
    InternalMarkedReaches basis source deterministic compatible mark first last := by
  exact Relation.ReflTransGen.mono
    (fun _ _ edge => ⟨edge.1, fun marked => edge.2 (marked_boundary basis source deterministic compatible marked)⟩)
    _ _ run

/-- An unmarked source step remains unmarked throughout its entire compiled execution. -/
theorem integer_unmarked_step (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (unit : ∀ edge, Action.UnitShift (source edge).action) (mark : Fin q → Bool)
    {first last : State n q} (transition : step source first = some last)
    (unmarked : mark first.1 = false)
    (first_natural : ∀ index, 0 ≤ first.2 index) (last_natural : ∀ index, 0 ≤ last.2 index) :
    InternalMarkedReaches basis source deterministic compatible mark
      (encode basis source deterministic compatible (toNatural first))
      (encode basis source deterministic compatible (toNatural last)) := by
  obtain ⟨_, _, next, initial, inside⟩ :=
    integer_step_firstReturn basis source deterministic compatible unit transition first_natural last_natural
  apply Relation.ReflTransGen.head (b := next) ?_
    (internal_to_marked basis source deterministic compatible mark inside)
  refine ⟨initial, ?_⟩
  rw [marked_encode_iff]
  change ¬ mark first.1 = true
  rw [unmarked]
  decide

/-- A preserved source invariant covers every intermediate unmarked source step. -/
theorem integer_internal_reaches (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (unit : ∀ edge, Action.UnitShift (source edge).action) (mark : Fin q → Bool)
    (valid : State n q → Prop) (stable : Stable source valid)
    (nonnegative : ∀ state, valid state → ∀ index, 0 ≤ state.2 index)
    {first last : State n q}
    (run : Relation.ReflTransGen (fun current next : State n q =>
      step source current = some next ∧ mark current.1 = false) first last)
    (first_valid : valid first) :
    InternalMarkedReaches basis source deterministic compatible mark
      (encode basis source deterministic compatible (toNatural first))
      (encode basis source deterministic compatible (toNatural last)) := by
  have lifted : valid last ∧ InternalMarkedReaches basis source deterministic compatible mark
      (encode basis source deterministic compatible (toNatural first))
      (encode basis source deterministic compatible (toNatural last)) := by
    induction run with
    | refl => exact ⟨first_valid, Relation.ReflTransGen.refl⟩
    | tail _ edge previous =>
        have last_valid := stable previous.1 edge.1
        exact ⟨last_valid, previous.2.trans
          (integer_unmarked_step basis source deterministic compatible unit mark edge.1 edge.2
            (nonnegative _ previous.1) (nonnegative _ last_valid))⟩
  exact lifted.2

/-- A marked source first return has exactly the same complete compressed endpoints. -/
theorem marked_firstReturn (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (unit : ∀ edge, Action.UnitShift (source edge).action) (mark : Fin q → Bool)
    (valid : State n q → Prop) (stable : Stable source valid)
    (nonnegative : ∀ state, valid state → ∀ index, 0 ≤ state.2 index)
    {first middle last : State n q} (initial : step source first = some middle)
    (rest : Relation.ReflTransGen (fun current next : State n q =>
      step source current = some next ∧ mark current.1 = false) middle last)
    (first_marked : mark first.1 = true) (last_marked : mark last.1 = true) (first_valid : valid first) :
    MarkedFirstReturn basis source deterministic compatible mark
      (encode basis source deterministic compatible (toNatural first))
      (encode basis source deterministic compatible (toNatural last)) := by
  have middle_valid := stable first_valid initial
  obtain ⟨_, _, next, head, inside⟩ := integer_step_firstReturn basis source deterministic compatible unit
    initial (nonnegative _ first_valid) (nonnegative _ middle_valid)
  refine ⟨(marked_encode_iff basis source deterministic compatible mark _).mpr first_marked,
    (marked_encode_iff basis source deterministic compatible mark _).mpr last_marked,
    next, head, ?_⟩
  exact (internal_to_marked basis source deterministic compatible mark inside).trans
    (integer_internal_reaches basis source deterministic compatible unit mark valid stable nonnegative rest middle_valid)

end Monodromy.Counter.Reversible.PrimeCompression
