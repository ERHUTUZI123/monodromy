import «Monodromy-port-relation»
import «Monodromy-prime-compression-modules»
import «Monodromy-prime-compression-tests»

/-!
Prime compression joins existing radix ports. Source addresses are actual
module entries; selected test exits meet the matching restoration entries.
Only static incidence is compiled. No connecting transition is introduced.
-/

noncomputable section

namespace Monodromy.Counter.Reversible.PrimeCompression

variable {n q e : ℕ}

/-- A unit shift leaves its radix module at the original target address. -/
def ShiftConnection (basis : PrimeCode.Basis n) (source : Table n q e)
    (exit entry : Fin (rawSize basis source)) : Prop :=
  ∃ site : SourceSite source,
    (source (sourceEdge source site)).action.IsShift ∧
    exit = sourceShiftOutput basis source site ∧
    entry = boundary basis source (source (sourceEdge source site)).target

/-- Restoring a tested code ends at the target's existing execution boundary. -/
def RestoreConnection (basis : PrimeCode.Basis n) (source : Table n q e)
    (exit entry : Fin (rawSize basis source)) : Prop :=
  ∃ site : RestoreSite source,
    exit = restoreOutput basis source site ∧ entry = boundary basis source site.val

/-- A reached remainder port chooses a static source edge and its restoration port. -/
def TestConnection (basis : PrimeCode.Basis n) (source : Table n q e)
    (exit entry : Fin (rawSize basis source)) : Prop :=
  ∃ first : SourceSite source, ∃ last : RestoreSite source,
    ∃ remainder : Fin (modulus basis source (.inl first)),
    ∃ restored : Fin (modulus basis source (.inr last)), ∃ edge : Fin e,
      (source edge).source = first.val ∧ (source edge).target = last.val ∧
      testSelected source (moduleRegister source (.inl first)) remainder.val edge = true ∧
      moduleRegister source (.inl first) = moduleRegister source (.inr last) ∧
      remainder.val = restored.val ∧
      exit = moduleNode basis source (.inl first) (Radix.finish _ remainder) ∧
      entry = restoreInput basis source last restored

/-- The entire connection relation is finite program data. -/
def Connection (basis : PrimeCode.Basis n) (source : Table n q e)
    (exit entry : Fin (rawSize basis source)) : Prop :=
  ShiftConnection basis source exit entry ∨
    RestoreConnection basis source exit entry ∨ TestConnection basis source exit entry

instance (basis : PrimeCode.Basis n) (source : Table n q e) :
    DecidableRel (Connection basis source) := by
  intro exit entry
  unfold Connection ShiftConnection RestoreConnection TestConnection
  infer_instance

private theorem sourceShiftOutput_injective (basis : PrimeCode.Basis n) (source : Table n q e) :
    Function.Injective (sourceShiftOutput basis source) := by
  intro first last same
  exact Sum.inl.inj (moduleNode_module basis source same)

private theorem restoreOutput_injective (basis : PrimeCode.Basis n) (source : Table n q e) :
    Function.Injective (restoreOutput basis source) := by
  intro first last same
  exact Sum.inr.inj (moduleNode_module basis source same)

private theorem source_restore_disjoint (basis : PrimeCode.Basis n) (source : Table n q e)
    (first : SourceSite source) (last : RestoreSite source)
    (initial : Fin (Radix.size (modulus basis source (.inl first))))
    (final : Fin (Radix.size (modulus basis source (.inr last)))) :
    moduleNode basis source (.inl first) initial ≠ moduleNode basis source (.inr last) final := by
  intro same
  cases moduleNode_module basis source same

private theorem selected_source_form (source : Table n q e) (deterministic : Deterministic source)
    (site : SourceSite source) (remainder : ℕ) (edge : Fin e)
    (same : (source edge).source = site.val)
    (chosen : testSelected source (moduleRegister source (.inl site)) remainder edge = true) :
    ∃ flag, (source (sourceEdge source site)).action =
      .test (moduleRegister source (.inl site)) flag := by
  exact test_owner_form source (fun index => (source index).source) deterministic
    ((testSelected_iff source _ _ edge).mp chosen)
    (same.trans (sourceEdge_spec source site).symm)

private theorem shift_test_disjoint (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) {exit first last : Fin (rawSize basis source)}
    (shift : ShiftConnection basis source exit first)
    (test : TestConnection basis source exit last) : False := by
  obtain ⟨site, is_shift, exit_shift, _⟩ := shift
  obtain ⟨start, finish, remainder, restored, edge, same_source, _, selected, _, _, exit_test, _⟩ := test
  have modules : (Sum.inl site : Module source) = Sum.inl start :=
    moduleNode_module basis source (exit_shift.symm.trans exit_test)
  have sites : site = start := Sum.inl.inj modules
  subst start
  obtain ⟨flag, form⟩ := selected_source_form source deterministic site remainder.val edge same_source selected
  rw [form] at is_shift
  exact is_shift

private theorem test_connection_functional (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) {exit first last : Fin (rawSize basis source)}
    (left : TestConnection basis source exit first)
    (right : TestConnection basis source exit last) : first = last := by
  obtain ⟨left_site, left_target, left_r, left_s, left_edge, left_src, left_dst,
    left_selected, _, left_values, left_exit, left_entry⟩ := left
  obtain ⟨right_site, right_target, right_r, right_s, right_edge, right_src, right_dst,
    right_selected, _, right_values, right_exit, right_entry⟩ := right
  have sites : left_site = right_site := Sum.inl.inj
    (moduleNode_module basis source (left_exit.symm.trans right_exit))
  subst right_site
  have finishes := moduleNode_position basis source (.inl left_site)
    (left_exit.symm.trans right_exit)
  have residues : left_r = right_r := by
    have pair := (Radix.nodeEquiv _).injective finishes
    simpa only [Sum.inr.injEq, Prod.mk.injEq, and_true] using pair
  subst right_r
  have edges : left_edge = right_edge := source_test_matching source deterministic
    (moduleRegister source (.inl left_site)) left_r.val
    left_edge right_edge left_selected right_selected (left_src.trans right_src.symm)
  subst right_edge
  have targets : left_target = right_target := Subtype.ext (left_dst.symm.trans right_dst)
  subst right_target
  have restored : left_s = right_s := Fin.ext (left_values.symm.trans right_values)
  subst right_s
  exact left_entry.trans right_entry.symm

/-- Each existing exit is identified with at most one existing entry. -/
theorem connection_functional (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) {exit first last : Fin (rawSize basis source)}
    (left : Connection basis source exit first)
    (right : Connection basis source exit last) : first = last := by
  rcases left with left | left | left <;> rcases right with right | right | right
  · obtain ⟨left_site, _, left_exit, left_entry⟩ := left
    obtain ⟨right_site, _, right_exit, right_entry⟩ := right
    have same := sourceShiftOutput_injective basis source (left_exit.symm.trans right_exit)
    subst right_site
    exact left_entry.trans right_entry.symm
  · obtain ⟨left_site, _, left_exit, _⟩ := left
    obtain ⟨right_site, right_exit, _⟩ := right
    exact False.elim (source_restore_disjoint basis source left_site right_site _ _
      (left_exit.symm.trans right_exit))
  · exact False.elim (shift_test_disjoint basis source deterministic left right)
  · obtain ⟨left_site, left_exit, _⟩ := left
    obtain ⟨right_site, _, right_exit, _⟩ := right
    exact False.elim (source_restore_disjoint basis source right_site left_site _ _
      (right_exit.symm.trans left_exit))
  · obtain ⟨left_site, left_exit, left_entry⟩ := left
    obtain ⟨right_site, right_exit, right_entry⟩ := right
    have same := restoreOutput_injective basis source (left_exit.symm.trans right_exit)
    subst right_site
    exact left_entry.trans right_entry.symm
  · obtain ⟨left_site, left_exit, _⟩ := left
    obtain ⟨right_site, _, right_r, _, _, _, _, _, _, _, right_exit, _⟩ := right
    exact False.elim (source_restore_disjoint basis source right_site left_site _ _
      (right_exit.symm.trans left_exit))
  · exact False.elim (shift_test_disjoint basis source deterministic right left)
  · obtain ⟨left_site, _, left_r, _, _, _, _, _, _, _, left_exit, _⟩ := left
    obtain ⟨right_site, right_exit, _⟩ := right
    exact False.elim (source_restore_disjoint basis source left_site right_site _ _
      (left_exit.symm.trans right_exit))
  · exact test_connection_functional basis source deterministic left right

end Monodromy.Counter.Reversible.PrimeCompression
