import «Monodromy-port-network»

/-! A finite connection relation determines the same static port identification. -/

namespace Monodromy.Counter.Reversible.PortNetwork

variable {n q e : ℕ}

/-- Bounded selection of an entry from a finite, functional port relation. -/
def relationLink (connection : Fin q → Fin q → Prop) [DecidableRel connection]
    (exit : Fin q) : Option (Fin q) :=
  if connected : ∃ entry, connection exit entry then
    some (Fin.find (connection exit) connected)
  else none

theorem relationLink_some_iff (connection : Fin q → Fin q → Prop) [DecidableRel connection]
    (functional : ∀ {exit first second}, connection exit first →
      connection exit second → first = second) (exit entry : Fin q) :
    relationLink connection exit = some entry ↔ connection exit entry := by
  unfold relationLink
  split_ifs with connected
  · rw [Option.some.injEq]
    constructor
    · intro same
      rw [← same]
      exact Fin.find_spec connected
    · intro actual
      exact functional (Fin.find_spec connected) actual
  · constructor
    · intro impossible
      cases impossible
    · intro actual
      exact False.elim (connected ⟨entry, actual⟩)

theorem relationLink_none_iff (connection : Fin q → Fin q → Prop) [DecidableRel connection]
    (exit : Fin q) :
    relationLink connection exit = none ↔ ∀ entry, ¬ connection exit entry := by
  unfold relationLink
  split_ifs with connected
  · constructor
    · intro impossible
      cases impossible
    · intro absent
      exact False.elim (absent _ (Fin.find_spec connected))
  · exact ⟨fun _ entry actual => connected ⟨entry, actual⟩, fun _ => rfl⟩

/-- A partial matching of existing exits and entries supplies static wiring. -/
def Wiring.ofRelation (original : Table n q e)
    (connection : Fin q → Fin q → Prop) [DecidableRel connection]
    (functional : ∀ {exit first second}, connection exit first →
      connection exit second → first = second)
    (backward : ∀ {first second entry}, connection first entry →
      connection second entry → first = second)
    (terminal : ∀ {exit entry}, connection exit entry → ∀ next, ¬ connection entry next)
    (source_free : ∀ index entry, ¬ connection (original index).source entry)
    (target_free : ∀ index exit, ¬ connection exit (original index).target) :
    Wiring original where
  link := relationLink connection
  terminal := fun linked => (relationLink_none_iff connection _).mpr
    (terminal ((relationLink_some_iff connection functional _ _).mp linked))
  injective := fun first second => backward
    ((relationLink_some_iff connection functional _ _).mp first)
    ((relationLink_some_iff connection functional _ _).mp second)
  source_free := fun index => (relationLink_none_iff connection _).mpr (source_free index)
  target_free := fun index exit linked => target_free index exit
    ((relationLink_some_iff connection functional _ _).mp linked)

end Monodromy.Counter.Reversible.PortNetwork
