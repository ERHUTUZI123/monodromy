import «Monodromy-prime-compression-step»
import «Monodromy-prime-compression-runs»
import «Monodromy-prime-compression-encoding»

/-! Exact source decrements through actual forward radix execution. -/

namespace Monodromy.Counter.Reversible.PrimeCompression

variable {n q e : ℕ}

/-- A positive source register is decremented by the reached remainder-zero exit. -/
theorem decrement_reaches (basis : PrimeCode.Basis n) (source : Table n q e)
    (source_deterministic : Deterministic source) (compatible : TargetCompatible source)
    (before : Counter.Configuration n q) (edge : Fin e) (register : Fin n)
    (at_source : (source edge).source = before.pc)
    (instruction : (source edge).action = .shift register (-1))
    (positive : before.counters register ≠ 0) :
    StateTransition.Reaches₁ (step (table basis source source_deterministic compatible))
      (encode basis source source_deterministic compatible before)
      (encode basis source source_deterministic compatible
        ⟨(source edge).target, Function.update before.counters register (before.counters register - 1)⟩) := by
  let site := siteOfEdge source edge
  let p := modulus basis source (.inl site)
  let value := basis.encode before.counters
  have forward : reversed source (.inl site) = false := by
    dsimp only [site, reversed]
    rw [sourceEdge_of_shift source source_deterministic edge register (-1) instruction, instruction]
    change decide ((-1 : ℤ) = 1) = false
    decide
  have prime_eq : p = basis.prime register := by
    dsimp only [p, modulus, site]
    rw [sourceRegister_of_shift source source_deterministic edge register (-1) instruction]
  have divisible : p ∣ value := by
    rw [prime_eq]
    exact (basis.prime_dvd_encode_iff before.counters register).mpr positive
  have remainder_zero : Counter.DivMod.residue p value = 0 := by
    apply Fin.ext
    change value % p = 0
    exact Nat.mod_eq_zero_of_dvd divisible
  have actual := forward_query_positive basis source site forward value
  change StateTransition.Reaches₁ (step (rawTable basis source))
    (sourceInput basis source site, ![(value : ℤ), 0])
    (moduleNode basis source (.inl site) (Radix.finish p (Counter.DivMod.residue p value)),
      ![((value / p : ℕ) : ℤ), 0]) at actual
  rw [remainder_zero] at actual
  have transported := PortNetwork.reaches1_map_live
    (wiring basis source source_deterministic compatible) (raw_deterministic basis source) actual
  have initial : sourceInput basis source site = boundary basis source before.pc := by
    rw [← boundary_source basis source site]
    exact congrArg (boundary basis source) at_source
  have finish : moduleNode basis source (.inl site) (Radix.finish p 0) =
      sourceShiftOutput basis source site := by
    simp only [sourceShiftOutput, forward, Bool.false_eq_true, reduceIte]
    rfl
  have endpoint := connection_controls basis source source_deterministic compatible
    (shift_connected basis source source_deterministic edge register (-1) instruction)
  have code : basis.encode (Function.update before.counters register (before.counters register - 1)) =
      value / p := by
    rw [prime_eq]
    exact basis.encode_decrement before.counters register positive
  change StateTransition.Reaches₁ (step (table basis source source_deterministic compatible))
    (PortNetwork.control (wiring basis source source_deterministic compatible)
      (sourceInput basis source site), ![(value : ℤ), 0])
    (PortNetwork.control (wiring basis source source_deterministic compatible)
      (moduleNode basis source (.inl site) (Radix.finish p 0)), ![((value / p : ℕ) : ℤ), 0]) at transported
  rw [initial, finish, endpoint, ← code] at transported
  exact transported

end Monodromy.Counter.Reversible.PrimeCompression
