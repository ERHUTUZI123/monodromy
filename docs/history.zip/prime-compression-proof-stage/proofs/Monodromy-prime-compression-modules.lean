import Monodromy.Counter

/-! Disjoint radix modules for reversible prime compression. -/

noncomputable section

namespace Monodromy.Counter.Reversible.PrimeCompression

variable {n q e : ℕ}

def HasSource (source : Table n q e) (position : Fin q) : Prop :=
  ∃ edge : Fin e, (source edge).source = position

instance (source : Table n q e) (position : Fin q) : Decidable (HasSource source position) :=
  inferInstanceAs (Decidable (∃ edge : Fin e, (source edge).source = position))

def HasRestore (source : Table n q e) (position : Fin q) : Prop :=
  ∃ edge : Fin e, (source edge).target = position ∧
    ∃ register : Fin n, ∃ atZero : Bool, (source edge).action = .test register atZero

instance (source : Table n q e) (position : Fin q) : Decidable (HasRestore source position) :=
  inferInstanceAs (Decidable (∃ edge : Fin e, (source edge).target = position ∧
    ∃ register : Fin n, ∃ atZero : Bool, (source edge).action = .test register atZero))

abbrev SourceSite (source : Table n q e) := {position : Fin q // HasSource source position}
abbrev RestoreSite (source : Table n q e) := {position : Fin q // HasRestore source position}
abbrev HaltSite (source : Table n q e) := {position : Fin q // ¬ HasSource source position}

def sourceEdge (source : Table n q e) (site : SourceSite source) : Fin e :=
  Fin.find (fun edge => (source edge).source = site.val) site.property

theorem sourceEdge_spec (source : Table n q e) (site : SourceSite source) :
    (source (sourceEdge source site)).source = site.val := Fin.find_spec site.property

def restoreEdge (source : Table n q e) (site : RestoreSite source) : Fin e :=
  Fin.find (fun edge => (source edge).target = site.val ∧
    ∃ register : Fin n, ∃ atZero : Bool, (source edge).action = .test register atZero) site.property

theorem restoreEdge_spec (source : Table n q e) (site : RestoreSite source) :
    (source (restoreEdge source site)).target = site.val ∧
      ∃ register : Fin n, ∃ atZero : Bool,
        (source (restoreEdge source site)).action = .test register atZero :=
  Fin.find_spec site.property

def actionRegister : Action n → Fin n
  | .shift register _ => register
  | .test register _ => register

abbrev Module (source : Table n q e) := SourceSite source ⊕ RestoreSite source

def moduleRegister (source : Table n q e) : Module source → Fin n
  | .inl site => actionRegister (source (sourceEdge source site)).action
  | .inr site => actionRegister (source (restoreEdge source site)).action

def modulus (basis : PrimeCode.Basis n) (source : Table n q e) (block : Module source) : ℕ :=
  basis.prime (moduleRegister source block)

instance (basis : PrimeCode.Basis n) (source : Table n q e) (block : Module source) :
    NeZero (modulus basis source block) := ⟨(basis.isPrime _).ne_zero⟩

def reversed (source : Table n q e) : Module source → Bool
  | .inl site => match (source (sourceEdge source site)).action with
      | .shift _ amount => decide (amount = 1)
      | .test _ _ => false
  | .inr _ => true

def componentTable (basis : PrimeCode.Basis n) (source : Table n q e) (block : Module source) :
    Table 2 (Radix.size (modulus basis source block)) (Radix.edges (modulus basis source block)) :=
  if reversed source block then reverseTable (Radix.table (modulus basis source block))
  else Radix.table (modulus basis source block)

theorem component_deterministic (basis : PrimeCode.Basis n) (source : Table n q e)
    (block : Module source) : Deterministic (componentTable basis source block) := by
  unfold componentTable
  split
  · exact reverseTable_deterministic _ (Radix.targetCompatible _)
  · exact Radix.deterministic _

theorem component_targetCompatible (basis : PrimeCode.Basis n) (source : Table n q e)
    (block : Module source) : TargetCompatible (componentTable basis source block) := by
  unfold componentTable
  split
  · exact reverseTable_targetCompatible _ (Radix.deterministic _)
  · exact Radix.targetCompatible _

abbrev RawPart (basis : PrimeCode.Basis n) (source : Table n q e) :=
  Σ block : Module source, Fin (Radix.size (modulus basis source block))

abbrev RawNode (basis : PrimeCode.Basis n) (source : Table n q e) :=
  HaltSite source ⊕ RawPart basis source

abbrev RawArc (basis : PrimeCode.Basis n) (source : Table n q e) :=
  Σ block : Module source, Fin (Radix.edges (modulus basis source block))

def rawSize (basis : PrimeCode.Basis n) (source : Table n q e) : ℕ :=
  Fintype.card (RawNode basis source)

def rawEdges (basis : PrimeCode.Basis n) (source : Table n q e) : ℕ :=
  Fintype.card (RawArc basis source)

def rawNodeEquiv (basis : PrimeCode.Basis n) (source : Table n q e) :
    RawNode basis source ≃ Fin (rawSize basis source) := Fintype.equivFin _

def rawArcEquiv (basis : PrimeCode.Basis n) (source : Table n q e) :
    RawArc basis source ≃ Fin (rawEdges basis source) := Fintype.equivFin _

def moduleNode (basis : PrimeCode.Basis n) (source : Table n q e) (block : Module source)
    (position : Fin (Radix.size (modulus basis source block))) : Fin (rawSize basis source) :=
  rawNodeEquiv basis source (.inr ⟨block, position⟩)

def haltNode (basis : PrimeCode.Basis n) (source : Table n q e) (site : HaltSite source) :
    Fin (rawSize basis source) := rawNodeEquiv basis source (.inl site)

theorem moduleNode_injective (basis : PrimeCode.Basis n) (source : Table n q e) :
    Function.Injective (fun point : RawPart basis source => moduleNode basis source point.1 point.2) :=
  (rawNodeEquiv basis source).injective.comp Sum.inr_injective

theorem haltNode_injective (basis : PrimeCode.Basis n) (source : Table n q e) :
    Function.Injective (haltNode basis source) :=
  (rawNodeEquiv basis source).injective.comp Sum.inl_injective

theorem haltNode_ne_moduleNode (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : HaltSite source) (block : Module source)
    (position : Fin (Radix.size (modulus basis source block))) :
    haltNode basis source site ≠ moduleNode basis source block position := by
  intro same
  have impossible := (rawNodeEquiv basis source).injective same
  cases impossible

def rawEdge (basis : PrimeCode.Basis n) (source : Table n q e) (arc : RawArc basis source) :
    Edge 2 (rawSize basis source) :=
  Glue.mapEdge (moduleNode basis source arc.1) (componentTable basis source arc.1 arc.2)

def rawTable (basis : PrimeCode.Basis n) (source : Table n q e) :
    Table 2 (rawSize basis source) (rawEdges basis source) :=
  fun index => rawEdge basis source ((rawArcEquiv basis source).symm index)

@[simp] theorem rawTable_arc (basis : PrimeCode.Basis n) (source : Table n q e)
    (arc : RawArc basis source) :
    rawTable basis source (rawArcEquiv basis source arc) = rawEdge basis source arc := by
  simp [rawTable]

theorem raw_deterministic (basis : PrimeCode.Basis n) (source : Table n q e) :
    Deterministic (rawTable basis source) := by
  intro first second different same
  obtain ⟨⟨left, first⟩, rfl⟩ := (rawArcEquiv basis source).surjective first
  obtain ⟨⟨right, second⟩, rfl⟩ := (rawArcEquiv basis source).surjective second
  simp only [rawTable_arc, rawEdge, Glue.mapEdge] at same ⊢
  have pairs : (⟨left, (componentTable basis source left first).source⟩ : RawPart basis source) =
      ⟨right, (componentTable basis source right second).source⟩ :=
    moduleNode_injective basis source same
  have blocks : left = right := congrArg Sigma.fst pairs
  subst right
  have positions : (componentTable basis source left first).source =
      (componentTable basis source left second).source := by
    simpa only [Sigma.mk.inj_iff, heq_eq_eq, true_and] using pairs
  exact component_deterministic basis source left first second
    (fun equal => different (by subst second; rfl)) positions

theorem raw_targetCompatible (basis : PrimeCode.Basis n) (source : Table n q e) :
    TargetCompatible (rawTable basis source) := by
  intro first second different same
  obtain ⟨⟨left, first⟩, rfl⟩ := (rawArcEquiv basis source).surjective first
  obtain ⟨⟨right, second⟩, rfl⟩ := (rawArcEquiv basis source).surjective second
  simp only [rawTable_arc, rawEdge, Glue.mapEdge] at same ⊢
  have pairs : (⟨left, (componentTable basis source left first).target⟩ : RawPart basis source) =
      ⟨right, (componentTable basis source right second).target⟩ :=
    moduleNode_injective basis source same
  have blocks : left = right := congrArg Sigma.fst pairs
  subst right
  have positions : (componentTable basis source left first).target =
      (componentTable basis source left second).target := by
    simpa only [Sigma.mk.inj_iff, heq_eq_eq, true_and] using pairs
  exact component_targetCompatible basis source left first second
    (fun equal => different (by subst second; rfl)) positions

/-- A live source address is the actual input port of its sole source module. -/
def sourceInputPosition (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : SourceSite source) : Fin (Radix.size (modulus basis source (.inl site))) :=
  if reversed source (.inl site) then Radix.finish _ 0 else Radix.entry _

def sourceInput (basis : PrimeCode.Basis n) (source : Table n q e) (site : SourceSite source) :
    Fin (rawSize basis source) :=
  moduleNode basis source (.inl site) (sourceInputPosition basis source site)

/-- Only shift modules use this single output; test modules use their actual remainder port. -/
def sourceShiftOutput (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : SourceSite source) : Fin (rawSize basis source) :=
  moduleNode basis source (.inl site)
    (if reversed source (.inl site) then Radix.entry _ else Radix.finish _ 0)

def restoreInput (basis : PrimeCode.Basis n) (source : Table n q e) (site : RestoreSite source)
    (remainder : Fin (modulus basis source (.inr site))) : Fin (rawSize basis source) :=
  moduleNode basis source (.inr site) (Radix.finish _ remainder)

def restoreOutput (basis : PrimeCode.Basis n) (source : Table n q e) (site : RestoreSite source) :
    Fin (rawSize basis source) :=
  moduleNode basis source (.inr site) (Radix.entry _)

/-- Source boundaries are existing input ports; a stopped address is a bare vertex. -/
def boundary (basis : PrimeCode.Basis n) (source : Table n q e) (position : Fin q) :
    Fin (rawSize basis source) :=
  if active : HasSource source position then sourceInput basis source ⟨position, active⟩
  else haltNode basis source ⟨position, active⟩

@[simp] theorem boundary_source (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : SourceSite source) : boundary basis source site.val = sourceInput basis source site := by
  simp only [boundary, dite_eq_left site.property]

@[simp] theorem boundary_halt (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : HaltSite source) : boundary basis source site.val = haltNode basis source site := by
  simp only [boundary, dite_eq_right site.property]

theorem sourceInput_injective (basis : PrimeCode.Basis n) (source : Table n q e) :
    Function.Injective (sourceInput basis source) := by
  intro first second same
  have pairs : (⟨Sum.inl first, sourceInputPosition basis source first⟩ : RawPart basis source) =
      ⟨Sum.inl second, sourceInputPosition basis source second⟩ :=
    moduleNode_injective basis source same
  have modules : Sum.inl first = (Sum.inl second : Module source) := congrArg Sigma.fst pairs
  exact Sum.inl.inj modules

theorem boundary_injective (basis : PrimeCode.Basis n) (source : Table n q e) :
    Function.Injective (boundary basis source) := by
  intro first second same
  by_cases left : HasSource source first
  · by_cases right : HasSource source second
    · simp only [boundary, dite_eq_left left, dite_eq_left right] at same
      exact congrArg Subtype.val (sourceInput_injective basis source same)
    · simp only [boundary, dite_eq_left left, dite_eq_right right, sourceInput] at same
      exact False.elim (haltNode_ne_moduleNode basis source ⟨second, right⟩ _ _ same.symm)
  · by_cases right : HasSource source second
    · simp only [boundary, dite_eq_right left, dite_eq_left right, sourceInput] at same
      exact False.elim (haltNode_ne_moduleNode basis source ⟨first, left⟩ _ _ same)
    · simp only [boundary, dite_eq_right left, dite_eq_right right] at same
      exact congrArg Subtype.val (haltNode_injective basis source same)

theorem component_no_incoming_sourceInput (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : SourceSite source) (index : Fin (Radix.edges (modulus basis source (.inl site)))) :
    (componentTable basis source (.inl site) index).target ≠ sourceInputPosition basis source site := by
  unfold componentTable sourceInputPosition
  split_ifs
  · exact fun same => Radix.no_outgoing_finish _ 0 ⟨index, same⟩
  · exact Radix.no_incoming_entry _ index

/-- No original edge enters a source boundary; only static port identification can enter it. -/
theorem raw_no_incoming_boundary (basis : PrimeCode.Basis n) (source : Table n q e)
    (position : Fin q) (index : Fin (rawEdges basis source)) :
    (rawTable basis source index).target ≠ boundary basis source position := by
  intro same
  obtain ⟨⟨block, index⟩, rfl⟩ := (rawArcEquiv basis source).surjective index
  simp only [rawTable_arc, rawEdge, Glue.mapEdge] at same
  by_cases active : HasSource source position
  · simp only [boundary, dite_eq_left active, sourceInput] at same
    have pairs : (⟨block, (componentTable basis source block index).target⟩ : RawPart basis source) =
        ⟨Sum.inl ⟨position, active⟩, sourceInputPosition basis source ⟨position, active⟩⟩ :=
      moduleNode_injective basis source same
    have blocks : block = Sum.inl ⟨position, active⟩ := congrArg Sigma.fst pairs
    subst block
    have ports : (componentTable basis source (.inl ⟨position, active⟩) index).target =
        sourceInputPosition basis source ⟨position, active⟩ := by
      simpa only [Sigma.mk.inj_iff, heq_eq_eq, true_and] using pairs
    exact component_no_incoming_sourceInput basis source ⟨position, active⟩ index ports
  · simp only [boundary, dite_eq_right active] at same
    exact haltNode_ne_moduleNode basis source ⟨position, active⟩ _ _ same.symm

/-- Module labels are preserved before the ports are identified. -/
theorem moduleNode_module (basis : PrimeCode.Basis n) (source : Table n q e)
    {first last : Module source}
    {initial : Fin (Radix.size (modulus basis source first))}
    {final : Fin (Radix.size (modulus basis source last))}
    (same : moduleNode basis source first initial = moduleNode basis source last final) :
    first = last := by
  have pairs : (⟨first, initial⟩ : RawPart basis source) = ⟨last, final⟩ :=
    moduleNode_injective basis source same
  exact congrArg Sigma.fst pairs

/-- Positions in one disjoint module retain their ordinary finite equality. -/
theorem moduleNode_position (basis : PrimeCode.Basis n) (source : Table n q e)
    (block : Module source)
    {first last : Fin (Radix.size (modulus basis source block))}
    (same : moduleNode basis source block first = moduleNode basis source block last) :
    first = last := by
  have pairs : (⟨block, first⟩ : RawPart basis source) = ⟨block, last⟩ :=
    moduleNode_injective basis source same
  simpa only [Sigma.mk.inj_iff, heq_eq_eq, true_and] using pairs

/-- A local exit has no outgoing edge in the entire disjoint family. -/
theorem raw_no_outgoing_moduleNode (basis : PrimeCode.Basis n) (source : Table n q e)
    (block : Module source) (position : Fin (Radix.size (modulus basis source block)))
    (no_outgoing : ∀ index, (componentTable basis source block index).source ≠ position)
    (index : Fin (rawEdges basis source)) :
    (rawTable basis source index).source ≠ moduleNode basis source block position := by
  intro same
  obtain ⟨⟨other, index⟩, rfl⟩ := (rawArcEquiv basis source).surjective index
  simp only [rawTable_arc, rawEdge, Glue.mapEdge] at same
  have blocks := moduleNode_module basis source same
  subst other
  exact no_outgoing index (moduleNode_position basis source block same)

/-- A local input has no incoming edge in the entire disjoint family. -/
theorem raw_no_incoming_moduleNode (basis : PrimeCode.Basis n) (source : Table n q e)
    (block : Module source) (position : Fin (Radix.size (modulus basis source block)))
    (no_incoming : ∀ index, (componentTable basis source block index).target ≠ position)
    (index : Fin (rawEdges basis source)) :
    (rawTable basis source index).target ≠ moduleNode basis source block position := by
  intro same
  obtain ⟨⟨other, index⟩, rfl⟩ := (rawArcEquiv basis source).surjective index
  simp only [rawTable_arc, rawEdge, Glue.mapEdge] at same
  have blocks := moduleNode_module basis source same
  subst other
  exact no_incoming index (moduleNode_position basis source block same)

/-- The source shift's selected exit is an exit in either orientation. -/
theorem raw_no_outgoing_sourceShiftOutput (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : SourceSite source) (index : Fin (rawEdges basis source)) :
    (rawTable basis source index).source ≠ sourceShiftOutput basis source site := by
  apply raw_no_outgoing_moduleNode
  intro localIndex
  unfold componentTable
  split_ifs with backwards
  · simpa only [sourceShiftOutput, backwards, reduceIte, reverseTable, reverseEdge] using
      Radix.no_incoming_entry (modulus basis source (.inl site)) localIndex
  · simpa only [sourceShiftOutput, backwards, reduceIte] using
      (fun same => Radix.no_outgoing_finish (modulus basis source (.inl site)) 0 ⟨localIndex, same⟩)

/-- A forward query's actual remainder exits have no outgoing edge. -/
theorem raw_no_outgoing_sourceFinish (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : SourceSite source) (remainder : Fin (modulus basis source (.inl site)))
    (forward : reversed source (.inl site) = false) (index : Fin (rawEdges basis source)) :
    (rawTable basis source index).source ≠
      moduleNode basis source (.inl site) (Radix.finish _ remainder) := by
  apply raw_no_outgoing_moduleNode
  intro localIndex
  simpa only [componentTable, forward, Bool.false_eq_true, reduceIte] using
    (fun same => Radix.no_outgoing_finish (modulus basis source (.inl site)) remainder ⟨localIndex, same⟩)

theorem raw_no_outgoing_restoreOutput (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : RestoreSite source) (index : Fin (rawEdges basis source)) :
    (rawTable basis source index).source ≠ restoreOutput basis source site := by
  apply raw_no_outgoing_moduleNode
  intro localIndex
  exact Radix.no_incoming_entry (modulus basis source (.inr site)) localIndex

theorem raw_no_incoming_restoreInput (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : RestoreSite source) (remainder : Fin (modulus basis source (.inr site)))
    (index : Fin (rawEdges basis source)) :
    (rawTable basis source index).target ≠ restoreInput basis source site remainder := by
  apply raw_no_incoming_moduleNode
  intro localIndex
  exact fun same => Radix.no_outgoing_finish (modulus basis source (.inr site)) remainder
    ⟨localIndex, same⟩

theorem radix_entry_ne_finish (p : ℕ) (remainder : Fin p) :
    Radix.entry p ≠ Radix.finish p remainder := by
  intro same
  cases (Radix.nodeEquiv p).injective same

/-- A source-module point can meet a boundary only at its own source input. -/
theorem sourceNode_ne_boundary (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : SourceSite source) (position : Fin (Radix.size (modulus basis source (.inl site))))
    (different : position ≠ sourceInputPosition basis source site) (target : Fin q) :
    moduleNode basis source (.inl site) position ≠ boundary basis source target := by
  intro same
  by_cases active : HasSource source target
  · simp only [boundary, dite_eq_left active] at same
    have sites : site = (⟨target, active⟩ : SourceSite source) :=
      Sum.inl.inj (moduleNode_module basis source same)
    have aligned := same.trans (congrArg (sourceInput basis source) sites).symm
    exact different (moduleNode_position basis source (.inl site) aligned)
  · simp only [boundary, dite_eq_right active] at same
    exact haltNode_ne_moduleNode basis source ⟨target, active⟩ _ _ same.symm

theorem sourceShiftOutput_ne_boundary (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : SourceSite source) (target : Fin q) :
    sourceShiftOutput basis source site ≠ boundary basis source target := by
  apply sourceNode_ne_boundary
  intro same
  unfold sourceInputPosition at same
  split_ifs at same
  · exact radix_entry_ne_finish _ 0 same
  · exact radix_entry_ne_finish _ 0 same.symm

theorem sourceFinish_ne_boundary (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : SourceSite source) (remainder : Fin (modulus basis source (.inl site)))
    (forward : reversed source (.inl site) = false) (target : Fin q) :
    moduleNode basis source (.inl site) (Radix.finish _ remainder) ≠ boundary basis source target := by
  apply sourceNode_ne_boundary
  intro same
  simp only [sourceInputPosition, forward, Bool.false_eq_true, reduceIte] at same
  exact radix_entry_ne_finish _ remainder same.symm

theorem restoreOutput_ne_boundary (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : RestoreSite source) (target : Fin q) :
    restoreOutput basis source site ≠ boundary basis source target := by
  intro same
  by_cases active : HasSource source target
  · simp only [boundary, dite_eq_left active] at same
    cases moduleNode_module basis source same
  · simp only [boundary, dite_eq_right active] at same
    exact haltNode_ne_moduleNode basis source ⟨target, active⟩ _ _ same.symm

theorem sourceNode_ne_restoreInput (basis : PrimeCode.Basis n) (source : Table n q e)
    (first : SourceSite source) (position : Fin (Radix.size (modulus basis source (.inl first))))
    (last : RestoreSite source) (remainder : Fin (modulus basis source (.inr last))) :
    moduleNode basis source (.inl first) position ≠ restoreInput basis source last remainder := by
  intro same
  cases moduleNode_module basis source same

theorem sourceShiftOutput_ne_restoreInput (basis : PrimeCode.Basis n) (source : Table n q e)
    (first : SourceSite source) (last : RestoreSite source)
    (remainder : Fin (modulus basis source (.inr last))) :
    sourceShiftOutput basis source first ≠ restoreInput basis source last remainder :=
  sourceNode_ne_restoreInput basis source first _ last remainder

theorem sourceFinish_ne_restoreInput (basis : PrimeCode.Basis n) (source : Table n q e)
    (first : SourceSite source) (initial : Fin (modulus basis source (.inl first)))
    (last : RestoreSite source) (remainder : Fin (modulus basis source (.inr last))) :
    moduleNode basis source (.inl first) (Radix.finish _ initial) ≠ restoreInput basis source last remainder :=
  sourceNode_ne_restoreInput basis source first _ last remainder

theorem restoreOutput_ne_restoreInput (basis : PrimeCode.Basis n) (source : Table n q e)
    (first last : RestoreSite source) (remainder : Fin (modulus basis source (.inr last))) :
    restoreOutput basis source first ≠ restoreInput basis source last remainder := by
  intro same
  have sites : first = last := Sum.inr.inj (moduleNode_module basis source same)
  subst first
  exact radix_entry_ne_finish _ remainder (moduleNode_position basis source (.inr last) same)

end Monodromy.Counter.Reversible.PrimeCompression
