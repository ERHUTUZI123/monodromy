import Monodromy.FormalCompilation
import «Monodromy-prime-compression-traces»

/-!
The recoverable-history Turing simulation occupies two integer counters.
All arithmetic and routing belongs to the fixed compressed radix table.
The source Turing transition occurs only in correspondence proofs.
-/

noncomputable section

namespace Monodromy.ReversibleTuring.Compression

open Turing Counter.Reversible

/-- Four source registers use one instance of the uniform finite prime code. -/
def basis : PrimeCode.Basis 4 where
  prime := ![2, 3, 5, 7]
  isPrime := by intro index; fin_cases index <;> decide
  distinct := by
    intro first second same
    fin_cases first <;> fin_cases second <;> simp_all

variable (a q : ℕ) [NeZero a] [NeZero q]

theorem source_deterministic (machine : TM0.Machine (Fin a) (Fin q)) :
    Deterministic (ReversibleTuring.table a q machine) :=
  Recording.deterministic (NativeTuring.source2 a q machine)

theorem source_targetCompatible (machine : TM0.Machine (Fin a) (Fin q)) :
    TargetCompatible (ReversibleTuring.table a q machine) :=
  Recording.targetCompatible (NativeTuring.source2 a q machine)

abbrev size (machine : TM0.Machine (Fin a) (Fin q)) : ℕ :=
  PrimeCompression.size basis (ReversibleTuring.table a q machine)
    (source_deterministic a q machine) (source_targetCompatible a q machine)

abbrev edges (machine : TM0.Machine (Fin a) (Fin q)) : ℕ :=
  PrimeCompression.rawEdges basis (ReversibleTuring.table a q machine)

/-- A fixed finite graph on two counters, with no source-step interpreter in its definition. -/
def table (machine : TM0.Machine (Fin a) (Fin q)) : Table 2 (size a q machine) (edges a q machine) :=
  PrimeCompression.table basis (ReversibleTuring.table a q machine)
    (source_deterministic a q machine) (source_targetCompatible a q machine)

/-- The entire source configuration and its recoverable history are retained. -/
def encode (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) : State 2 (size a q machine) :=
  PrimeCompression.encode basis (ReversibleTuring.table a q machine)
    (source_deterministic a q machine) (source_targetCompatible a q machine)
    (PrimeCompression.toNatural (ReversibleTuring.encode a q machine state history))

theorem deterministic (machine : TM0.Machine (Fin a) (Fin q)) :
    Deterministic (table a q machine) :=
  PrimeCompression.deterministic basis (ReversibleTuring.table a q machine)
    (source_deterministic a q machine) (source_targetCompatible a q machine)

theorem targetCompatible (machine : TM0.Machine (Fin a) (Fin q)) :
    TargetCompatible (table a q machine) :=
  PrimeCompression.targetCompatible basis (ReversibleTuring.table a q machine)
    (source_deterministic a q machine) (source_targetCompatible a q machine)

private theorem source_nonnegative (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    ∀ index, 0 ≤ (ReversibleTuring.encode a q machine state history).2 index := by
  intro index
  exact Recording.encode_reaches_nonnegative (NativeTuring.source2 a q machine)
    (RecordedTuring.counterEncode a q machine state) history Relation.ReflTransGen.refl index

theorem encode_injective (machine : TM0.Machine (Fin a) (Fin q)) :
    Function.Injective (fun pair : TM0.Cfg (Fin a) (Fin q) × ℕ =>
      encode a q machine pair.1 pair.2) := by
  intro first second same
  have natural := PrimeCompression.encode_injective basis (ReversibleTuring.table a q machine)
    (source_deterministic a q machine) (source_targetCompatible a q machine) same
  have original := congrArg PrimeCompression.naturalState natural
  rw [PrimeCompression.naturalState_toNatural _ (source_nonnegative a q machine first.1 first.2),
    PrimeCompression.naturalState_toNatural _ (source_nonnegative a q machine second.1 second.2)] at original
  exact ReversibleTuring.encode_injective a q machine original

/-- Local reversibility holds on every integer state of the compressed graph. -/
theorem defined_step_injective (machine : TM0.Machine (Fin a) (Fin q))
    {first second last : State 2 (size a q machine)}
    (left : step (table a q machine) first = some last)
    (right : step (table a q machine) second = some last) : first = second :=
  step_some_injective (table a q machine) (deterministic a q machine)
    (targetCompatible a q machine) left right

/-- Every Turing step runs the two-counter table with the same strictly growing history. -/
theorem step_reaches (machine : TM0.Machine (Fin a) (Fin q))
    {first last : TM0.Cfg (Fin a) (Fin q)} (transition : TM0.step machine first = some last)
    (history : ℕ) :
    ∃ finalHistory, history < finalHistory ∧
      StateTransition.Reaches₁ (step (table a q machine))
        (encode a q machine first history) (encode a q machine last finalHistory) := by
  obtain ⟨finalHistory, grew, run⟩ := ReversibleTuring.step_reaches a q machine transition history
  refine ⟨finalHistory, grew, ?_⟩
  exact PrimeCompression.integer_reaches1 basis (ReversibleTuring.table a q machine)
    (source_deterministic a q machine) (source_targetCompatible a q machine)
    (Recording.unitShift (NativeTuring.source2 a q machine)) run
    (fun state traversed index => Recording.encode_reaches_nonnegative
      (NativeTuring.source2 a q machine) (RecordedTuring.counterEncode a q machine first)
      history traversed index)

private theorem counter_instruction_halt {n m : ℕ} (program : Counter.Program n m)
    (state : Counter.Configuration n m) (halted : Counter.step program state = none) :
    program state.pc = .halt := by
  cases instruction : program state.pc with
  | halt => rfl
  | inc => simp [Counter.step, instruction] at halted
  | dec register zero nonzero =>
      cases value : state.counters register <;> simp [Counter.step, instruction, value] at halted

/-- A stopped Turing configuration enters a genuinely source-free recording dispatch. -/
theorem source_no_outgoing_of_halt (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) (halted : TM0.step machine state = none) :
    ¬ PrimeCompression.HasSource (ReversibleTuring.table a q machine)
      (PrimeCompression.toNatural (ReversibleTuring.encode a q machine state history)).pc := by
  have instruction := counter_instruction_halt (NativeTuring.source2 a q machine)
    (RecordedTuring.counterEncode a q machine state)
    (RecordedTuring.counter_halt a q machine state halted)
  rintro ⟨index, same⟩
  exact Recording.halt_no_outgoing (NativeTuring.source2 a q machine)
    (RecordedTuring.counterEncode a q machine state).pc instruction index same

/-- Static halting survives compression independently of the encoded memory values. -/
theorem no_outgoing_of_halt (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) (halted : TM0.step machine state = none) :
    ¬ ∃ index, (table a q machine index).source = (encode a q machine state history).1 :=
  PrimeCompression.no_outgoing_boundary basis (ReversibleTuring.table a q machine)
    (source_deterministic a q machine) (source_targetCompatible a q machine)
    (PrimeCompression.toNatural (ReversibleTuring.encode a q machine state history)).pc
    (source_no_outgoing_of_halt a q machine state history halted)

theorem step_halt (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) (halted : TM0.step machine state = none) :
    step (table a q machine) (encode a q machine state history) = none := by
  rw [step_none_iff]
  rintro ⟨index, enabled⟩
  exact no_outgoing_of_halt a q machine state history halted ⟨index, enabled.1⟩

def Related (machine : TM0.Machine (Fin a) (Fin q))
    (original : TM0.Cfg (Fin a) (Fin q)) (compiled : State 2 (size a q machine)) : Prop :=
  ∃ history, encode a q machine original history = compiled

theorem respects (machine : TM0.Machine (Fin a) (Fin q)) :
    StateTransition.Respects (TM0.step machine) (step (table a q machine)) (Related a q machine) := by
  intro original compiled related
  obtain ⟨history, rfl⟩ := related
  cases transition : TM0.step machine original with
  | none => exact step_halt a q machine original history transition
  | some next =>
      obtain ⟨finalHistory, _, run⟩ := step_reaches a q machine transition history
      exact ⟨encode a q machine next finalHistory, ⟨finalHistory, rfl⟩, run⟩

theorem halting_iff (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    (eval (table a q machine) (encode a q machine state history)).Dom ↔
      (StateTransition.eval (TM0.step machine) state).Dom :=
  StateTransition.tr_eval_dom (respects a q machine) ⟨history, rfl⟩

theorem divergence_iff (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    ¬ (eval (table a q machine) (encode a q machine state history)).Dom ↔
      ¬ (StateTransition.eval (TM0.step machine) state).Dom :=
  not_congr (halting_iff a q machine state history)

/-- Complete final configurations, including their retained history, correspond exactly. -/
theorem result_iff (machine : TM0.Machine (Fin a) (Fin q))
    (first last : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    (∃ finalHistory, encode a q machine last finalHistory ∈
      eval (table a q machine) (encode a q machine first history)) ↔
      last ∈ StateTransition.eval (TM0.step machine) first := by
  constructor
  · rintro ⟨finalHistory, finished⟩
    obtain ⟨original, ⟨originalHistory, related⟩, source_finished⟩ :=
      StateTransition.tr_eval_rev (respects a q machine) ⟨history, rfl⟩ finished
    have same : (original, originalHistory) = (last, finalHistory) :=
      @encode_injective a q _ _ machine (original, originalHistory) (last, finalHistory) related
    have configurations : original = last := congrArg Prod.fst same
    simpa only [configurations] using source_finished
  · intro source_finished
    obtain ⟨final, ⟨finalHistory, rfl⟩, finished⟩ :=
      StateTransition.tr_eval (respects a q machine) ⟨history, rfl⟩ source_finished
    exact ⟨finalHistory, finished⟩

/-- Reversing the same finite graph restores the entire prior configuration and history. -/
theorem step_retraces (machine : TM0.Machine (Fin a) (Fin q))
    {first last : TM0.Cfg (Fin a) (Fin q)} (transition : TM0.step machine first = some last)
    (history : ℕ) :
    ∃ finalHistory, history < finalHistory ∧
      StateTransition.Reaches (step (reverseTable (table a q machine)))
        (encode a q machine last finalHistory) (encode a q machine first history) := by
  obtain ⟨finalHistory, grew, run⟩ := step_reaches a q machine transition history
  exact ⟨finalHistory, grew, reaches_reverse (table a q machine)
    (deterministic a q machine) (targetCompatible a q machine) run.to_reflTransGen⟩

end Monodromy.ReversibleTuring.Compression
