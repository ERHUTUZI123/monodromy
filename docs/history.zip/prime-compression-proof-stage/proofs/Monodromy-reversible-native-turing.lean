import «Monodromy-reversible-turing-compressed»

/-!
Recoverable-history Turing execution by the original three-root path-lifting engine.
Both execution directions are fixed native word tables. Source transitions
occur only in the correspondence proofs below.
-/

noncomputable section

namespace Monodromy.ReversibleNativeTuring

open Turing CoupledContinuation ReversibleTuring

variable (a q : ℕ) [NeZero a] [NeZero q]

instance size_nonzero (machine : TM0.Machine (Fin a) (Fin q)) :
    NeZero (Compression.size a q machine) := by
  constructor
  have bound := (Compression.encode a q machine (TM0.init [] : TM0.Cfg (Fin a) (Fin q)) 0).1.isLt
  omega

/-- The same five geometric primitives execute the complete compressed finite table. -/
def program (machine : TM0.Machine (Fin a) (Fin q)) :
    Program (11 * (Compression.size a q machine + Compression.edges a q machine)) :=
  ReversibleCompilation.haltingProgram (Compression.table a q machine)
    (Compression.deterministic a q machine) (Compression.targetCompatible a q machine)

/-- Complete source configurations and histories occupy the original three-root fiber. -/
def iota (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) : Memory :=
  ReversibleCompilation.iota (e := Compression.edges a q machine) (Compression.encode a q machine state history)

theorem iota_injective (machine : TM0.Machine (Fin a) (Fin q)) :
    Function.Injective (fun pair : TM0.Cfg (Fin a) (Fin q) × ℕ =>
      iota a q machine pair.1 pair.2) := by
  intro first second same
  apply Compression.encode_injective a q machine
  exact ReversibleCompilation.iota_injective same

/-- Every source step is a positive run of actual native returns with its larger history. -/
theorem step_reaches (machine : TM0.Machine (Fin a) (Fin q))
    {first last : TM0.Cfg (Fin a) (Fin q)} (transition : TM0.step machine first = some last)
    (history : ℕ) :
    ∃ finalHistory, history < finalHistory ∧
      StateTransition.Reaches₁ (program a q machine).step
        (iota a q machine first history) (iota a q machine last finalHistory) := by
  obtain ⟨finalHistory, grew, run⟩ := Compression.step_reaches a q machine transition history
  have lifted := ReversibleCompilation.reaches_iota (Compression.table a q machine)
    (Compression.deterministic a q machine) (Compression.targetCompatible a q machine) run.to_reflTransGen
  rcases Relation.reflTransGen_iff_eq_or_transGen.mp lifted with same | positive
  · have states : (last, finalHistory) = (first, history) :=
      @iota_injective a q _ _ machine (last, finalHistory) (first, history) same
    have histories := congrArg Prod.snd states
    omega
  · exact ⟨finalHistory, grew, positive⟩

/-- Stopping is detected from the actual static halt address, without a global completeness premise. -/
theorem step_halt (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) (halted : TM0.step machine state = none) :
    (program a q machine).step (iota a q machine state history) = none := by
  have signal := (ReversibleCompilation.haltSignal_iota_iff (Compression.table a q machine)
    (Compression.deterministic a q machine) (Compression.targetCompatible a q machine)
    (Compression.encode a q machine state history)).mpr
      (Compression.no_outgoing_of_halt a q machine state history halted)
  change (if (program a q machine).haltSignal (iota a q machine state history) = 1 then none
    else some ((program a q machine).advance (iota a q machine state history))) = none
  exact ite_eq_left signal

def Related (machine : TM0.Machine (Fin a) (Fin q))
    (original : TM0.Cfg (Fin a) (Fin q)) (native : Memory) : Prop :=
  ∃ history, iota a q machine original history = native

theorem respects (machine : TM0.Machine (Fin a) (Fin q)) :
    StateTransition.Respects (TM0.step machine) (program a q machine).step (Related a q machine) := by
  intro original native related
  obtain ⟨history, rfl⟩ := related
  cases transition : TM0.step machine original with
  | none => exact step_halt a q machine original history transition
  | some next =>
      obtain ⟨finalHistory, _, run⟩ := step_reaches a q machine transition history
      exact ⟨iota a q machine next finalHistory, ⟨finalHistory, rfl⟩, run⟩

theorem halting_iff (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    ((program a q machine).eval (iota a q machine state history)).Dom ↔
      (StateTransition.eval (TM0.step machine) state).Dom :=
  StateTransition.tr_eval_dom (respects a q machine) ⟨history, rfl⟩

theorem divergence_iff (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    ¬ ((program a q machine).eval (iota a q machine state history)).Dom ↔
      ¬ (StateTransition.eval (TM0.step machine) state).Dom :=
  not_congr (halting_iff a q machine state history)

/-- The entire final configuration is recovered from the native result; history remains observable. -/
theorem result_iff (machine : TM0.Machine (Fin a) (Fin q))
    (first last : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    (∃ finalHistory, iota a q machine last finalHistory ∈
      (program a q machine).eval (iota a q machine first history)) ↔
      last ∈ StateTransition.eval (TM0.step machine) first := by
  constructor
  · rintro ⟨finalHistory, finished⟩
    obtain ⟨original, ⟨originalHistory, related⟩, source_finished⟩ :=
      StateTransition.tr_eval_rev (respects a q machine) ⟨history, rfl⟩ finished
    have same : (original, originalHistory) = (last, finalHistory) :=
      @iota_injective a q _ _ machine (original, originalHistory) (last, finalHistory) related
    have configurations : original = last := congrArg Prod.fst same
    simpa only [configurations] using source_finished
  · intro source_finished
    obtain ⟨native, ⟨finalHistory, rfl⟩, finished⟩ :=
      StateTransition.tr_eval (respects a q machine) ⟨history, rfl⟩ source_finished
    exact ⟨finalHistory, finished⟩

/-- The inverse is another fixed word table on the same fiber and with the same five primitives. -/
def reverseProgram (machine : TM0.Machine (Fin a) (Fin q)) :
    Program (11 * (Compression.size a q machine + Compression.edges a q machine)) :=
  ReversibleCompilation.reverseProgram (Compression.table a q machine)
    (Compression.deterministic a q machine) (Compression.targetCompatible a q machine)

theorem reverse_after_forward (machine : TM0.Machine (Fin a) (Fin q)) (state : Memory) :
    (reverseProgram a q machine).advance ((program a q machine).advance state) = state :=
  ReversibleCompilation.reverse_after_forward (Compression.table a q machine)
    (Compression.deterministic a q machine) (Compression.targetCompatible a q machine) state

theorem forward_after_reverse (machine : TM0.Machine (Fin a) (Fin q)) (state : Memory) :
    (program a q machine).advance ((reverseProgram a q machine).advance state) = state :=
  ReversibleCompilation.forward_after_reverse (Compression.table a q machine)
    (Compression.deterministic a q machine) (Compression.targetCompatible a q machine) state

def executionEquiv (machine : TM0.Machine (Fin a) (Fin q)) : Memory ≃ Memory :=
  ReversibleCompilation.executionEquiv (Compression.table a q machine)
    (Compression.deterministic a q machine) (Compression.targetCompatible a q machine)

theorem program_bijective (machine : TM0.Machine (Fin a) (Fin q)) :
    Function.Bijective (program a q machine).advance :=
  ReversibleCompilation.haltingProgram_bijective (Compression.table a q machine)
    (Compression.deterministic a q machine) (Compression.targetCompatible a q machine)

/-- Inverse native execution restores each whole source step and its prior history. -/
theorem step_retraces (machine : TM0.Machine (Fin a) (Fin q))
    {first last : TM0.Cfg (Fin a) (Fin q)} (transition : TM0.step machine first = some last)
    (history : ℕ) :
    ∃ finalHistory, history < finalHistory ∧ ∃ count : ℕ,
      ((reverseProgram a q machine).advance)^[count] (iota a q machine last finalHistory) =
        iota a q machine first history := by
  obtain ⟨finalHistory, grew, run⟩ := step_reaches a q machine transition history
  obtain ⟨count, reached⟩ := (program a q machine).reaches_iterate_advance run.to_reflTransGen
  refine ⟨finalHistory, grew, count, ?_⟩
  rw [← reached]
  exact (Function.LeftInverse.iterate (reverse_after_forward a q machine) count) _

/-- Every completed source computation has the two actual matching cover lifts generated by execution. -/
theorem result_actual_lifts (machine : TM0.Machine (Fin a) (Fin q))
    {first last : TM0.Cfg (Fin a) (Fin q)} (history : ℕ)
    (completed : last ∈ StateTransition.eval (TM0.step machine) first) :
    ∃ finalHistory, ∃ count : ℕ,
      let initial := iota a q machine first history
      let driver := (program a q machine).runDriver count initial
      intermediateCurve driver initial =
        CoupledPullback.lowerCovering.liftPath driver.restrictedPath
          (CoupledPullback.upperProjection (restrictedState initial))
          (driver.restrictedPath.source.trans (restrictedState_over_base initial).symm) ∧
      restrictedTrajectory driver initial =
        CoupledPullback.upperCovering.liftPath (intermediatePath driver initial) (restrictedState initial)
          (intermediatePath driver initial).source ∧
      restrictedTrajectory driver initial 1 = restrictedState (iota a q machine last finalHistory) := by
  obtain ⟨finalHistory, finished⟩ := (result_iff a q machine first last history).mpr completed
  obtain ⟨count, endpoint⟩ := (program a q machine).runDriver_of_eval finished
  refine ⟨finalHistory, count, ?_⟩
  dsimp only
  refine ⟨intermediateCurve_actual_lift _ _, restrictedTrajectory_actual_lift _ _, ?_⟩
  rw [restrictedTrajectory_end, endpoint]

/-- Every finite source execution, including a nonhalting prefix, is an actual native lifted path. -/
theorem finite_run_actual_lifts (machine : TM0.Machine (Fin a) (Fin q))
    {first last : TM0.Cfg (Fin a) (Fin q)} (history : ℕ)
    (run : StateTransition.Reaches (TM0.step machine) first last) :
    ∃ finalHistory, ∃ count : ℕ,
      let initial := iota a q machine first history
      let driver := (program a q machine).runDriver count initial
      intermediateCurve driver initial =
        CoupledPullback.lowerCovering.liftPath driver.restrictedPath
          (CoupledPullback.upperProjection (restrictedState initial))
          (driver.restrictedPath.source.trans (restrictedState_over_base initial).symm) ∧
      restrictedTrajectory driver initial =
        CoupledPullback.upperCovering.liftPath (intermediatePath driver initial) (restrictedState initial)
          (intermediatePath driver initial).source ∧
      restrictedTrajectory driver initial 1 = restrictedState (iota a q machine last finalHistory) := by
  obtain ⟨native, ⟨finalHistory, rfl⟩, actual⟩ :=
    StateTransition.tr_reaches (respects a q machine) ⟨history, rfl⟩ run
  obtain ⟨count, endpoint⟩ := (program a q machine).runDriver_of_reaches actual
  refine ⟨finalHistory, count, ?_⟩
  dsimp only
  refine ⟨intermediateCurve_actual_lift _ _, restrictedTrajectory_actual_lift _ _, ?_⟩
  rw [restrictedTrajectory_end, endpoint]

/-- Native reversible universality: complete configurations, causal positive simulation,
partial results and divergence, and every finite execution through the two actual covers. -/
theorem native_universality (machine : TM0.Machine (Fin a) (Fin q)) :
    let P := program a q machine
    let R := reverseProgram a q machine
    let I := iota a q machine
    Function.Injective (fun pair : TM0.Cfg (Fin a) (Fin q) × ℕ => I pair.1 pair.2) ∧
    (∀ state, R.advance (P.advance state) = state ∧ P.advance (R.advance state) = state) ∧
    (∀ first last, TM0.step machine first = some last → ∀ history,
      ∃ finalHistory, history < finalHistory ∧
        StateTransition.Reaches₁ P.step (I first history) (I last finalHistory)) ∧
    (∀ first last history,
      (∃ finalHistory, I last finalHistory ∈ P.eval (I first history)) ↔
        last ∈ StateTransition.eval (TM0.step machine) first) ∧
    (∀ state history, (P.eval (I state history)).Dom ↔
      (StateTransition.eval (TM0.step machine) state).Dom) ∧
    (∀ state history, ¬ (P.eval (I state history)).Dom ↔
      ¬ (StateTransition.eval (TM0.step machine) state).Dom) ∧
    (∀ first last history, StateTransition.Reaches (TM0.step machine) first last →
      ∃ finalHistory, ∃ count : ℕ,
        let initial := I first history
        let driver := P.runDriver count initial
        intermediateCurve driver initial =
          CoupledPullback.lowerCovering.liftPath driver.restrictedPath
            (CoupledPullback.upperProjection (restrictedState initial))
            (driver.restrictedPath.source.trans (restrictedState_over_base initial).symm) ∧
        restrictedTrajectory driver initial =
          CoupledPullback.upperCovering.liftPath (intermediatePath driver initial) (restrictedState initial)
            (intermediatePath driver initial).source ∧
        restrictedTrajectory driver initial 1 = restrictedState (I last finalHistory)) := by
  dsimp only
  exact ⟨iota_injective a q machine,
    fun state => ⟨reverse_after_forward a q machine state, forward_after_reverse a q machine state⟩,
    fun _ _ transition history => step_reaches a q machine transition history,
    result_iff a q machine, halting_iff a q machine, divergence_iff a q machine,
    fun _ _ history run => finite_run_actual_lifts a q machine history run⟩

end Monodromy.ReversibleNativeTuring
