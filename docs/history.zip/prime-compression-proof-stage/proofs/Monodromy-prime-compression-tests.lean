import Monodromy.Counter

/-!
Finite test-port matching for reversible prime compression.
A residue is a reached finite port. The definitions below only select static edges.
These matching lemmas support defined source steps on the natural domain. A
source with a disabled singleton test needs no outgoing matched residue port;
full execution correspondence therefore additionally uses an invariant or the
actual Turing simulation traces and its static terminal dispatches.
-/

namespace Monodromy.Counter.Reversible.PrimeCompression

variable {n q e : ℕ}

/-- An unconditional edge has no different edge at the same compatible owner. -/
theorem shift_owner_unique (table : Table n q e) (owner : Fin e → Fin q)
    (compatible : ∀ first second, first ≠ second → owner first = owner second →
      Action.Compatible (table first).action (table second).action)
    {first second : Fin e} {register : Fin n} {amount : ℤ}
    (shift : (table first).action = .shift register amount)
    (same : owner first = owner second) : first = second := by
  by_contra different
  have impossible := compatible first second different same
  rw [shift] at impossible
  cases (table second).action <;> exact impossible

/-- Different tests at a common compatible owner use the same register and opposite guards. -/
theorem test_owner_alternative (table : Table n q e) (owner : Fin e → Fin q)
    (compatible : ∀ first second, first ≠ second → owner first = owner second →
      Action.Compatible (table first).action (table second).action)
    {first second : Fin e} {register : Fin n} {atZero : Bool}
    (test : (table first).action = .test register atZero)
    (different : first ≠ second) (same : owner first = owner second) :
    (table second).action = .test register (!atZero) := by
  have alternatives := compatible first second different same
  rw [test] at alternatives
  cases result : (table second).action with
  | shift => simp [result, Action.Compatible] at alternatives
  | test other flag =>
      rw [result] at alternatives
      rcases alternatives with ⟨rfl, different_flags⟩
      cases atZero <;> cases flag <;> simp_all

/-- One test fixes the register of every edge at the same compatible owner. -/
theorem test_owner_form (table : Table n q e) (owner : Fin e → Fin q)
    (compatible : ∀ first second, first ≠ second → owner first = owner second →
      Action.Compatible (table first).action (table second).action)
    {first second : Fin e} {register : Fin n} {atZero : Bool}
    (test : (table first).action = .test register atZero)
    (same : owner first = owner second) :
    ∃ flag, (table second).action = .test register flag := by
  by_cases equal : first = second
  · subst second
    exact ⟨atZero, test⟩
  · exact ⟨!atZero, test_owner_alternative table owner compatible test equal same⟩

/-- Shared test modules have an unambiguous virtual register on either side. -/
theorem test_owner_register_unique (table : Table n q e) (owner : Fin e → Fin q)
    (compatible : ∀ first second, first ≠ second → owner first = owner second →
      Action.Compatible (table first).action (table second).action)
    {first second : Fin e} {register other : Fin n} {atZero otherZero : Bool}
    (first_test : (table first).action = .test register atZero)
    (second_test : (table second).action = .test other otherZero)
    (same : owner first = owner second) : register = other := by
  obtain ⟨flag, form⟩ := test_owner_form table owner compatible first_test same
  exact (Action.test.inj (form.symm.trans second_test)).1

/-- The residue port selects zero exactly when the represented exponent is zero. -/
def testSelected (table : Table n q e) (register : Fin n) (remainder : ℕ) (edge : Fin e) : Bool :=
  decide ((table edge).action = .test register (decide (remainder ≠ 0)))

@[simp] theorem testSelected_iff (table : Table n q e) (register : Fin n) (remainder : ℕ)
    (edge : Fin e) :
    testSelected table register remainder edge = true ↔
      (table edge).action = .test register (decide (remainder ≠ 0)) := by
  simp [testSelected]

/-- One reached residue chooses at most one test at each compatible owner. -/
theorem test_matching (table : Table n q e) (owner : Fin e → Fin q)
    (compatible : ∀ first second, first ≠ second → owner first = owner second →
      Action.Compatible (table first).action (table second).action)
    (register : Fin n) (remainder : ℕ) :
    ReversiblePorts.Matching owner (testSelected table register remainder) := by
  intro first second first_selected second_selected same
  by_contra different
  have alternatives := compatible first second different same
  rw [(testSelected_iff table register remainder first).mp first_selected,
    (testSelected_iff table register remainder second).mp second_selected] at alternatives
  exact alternatives.2 rfl

theorem source_test_matching (table : Table n q e) (deterministic : Deterministic table)
    (register : Fin n) (remainder : ℕ) :
    ReversiblePorts.Matching (fun edge => (table edge).source)
      (testSelected table register remainder) :=
  test_matching table (fun edge => (table edge).source) deterministic register remainder

theorem target_test_matching (table : Table n q e) (compatible : TargetCompatible table)
    (register : Fin n) (remainder : ℕ) :
    ReversiblePorts.Matching (fun edge => (table edge).target)
      (testSelected table register remainder) :=
  test_matching table (fun edge => (table edge).target) compatible register remainder

/-- A shared residue port therefore defines a partial one-to-one source-to-target connection. -/
theorem test_ports_partial_matching (table : Table n q e)
    (deterministic : Deterministic table) (compatible : TargetCompatible table)
    (register : Fin n) (remainder : ℕ) :
    ReversiblePorts.Matching (fun edge => (table edge).source)
        (testSelected table register remainder) ∧
      ReversiblePorts.Matching (fun edge => (table edge).target)
        (testSelected table register remainder) :=
  ⟨source_test_matching table deterministic register remainder,
    target_test_matching table compatible register remainder⟩

/-- Divisibility of the prime code reads the complementary zero/nonzero source test. -/
theorem residue_zero_flag (basis : Monodromy.PrimeCode.Basis n)
    (values : Fin n → ℕ) (register : Fin n) :
    decide (basis.encode values % basis.prime register ≠ 0) = decide (values register = 0) := by
  apply decide_eq_decide.mpr
  exact (not_congr (basis.remainder_zero_iff values register)).trans not_not

/-- Test-port selection agrees with the unchanged source guard on the encoded natural domain. -/
theorem testSelected_encoded_iff (table : Table n q e)
    (basis : Monodromy.PrimeCode.Basis n) (values : Fin n → ℕ)
    (register : Fin n) (edge : Fin e) (atZero : Bool)
    (test : (table edge).action = .test register atZero) :
    testSelected table register (basis.encode values % basis.prime register) edge = true ↔
      (table edge).action.enabled (fun index => (values index : ℤ)) := by
  rw [testSelected_iff, test, residue_zero_flag]
  cases atZero <;> simp [Action.enabled]

end Monodromy.Counter.Reversible.PrimeCompression
