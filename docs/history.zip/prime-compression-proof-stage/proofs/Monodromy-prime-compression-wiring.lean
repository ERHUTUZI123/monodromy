import «Monodromy-prime-compression-backward»

/-! The complete two-counter graph retains exactly the radix-module edges. -/

noncomputable section

namespace Monodromy.Counter.Reversible.PrimeCompression

variable {n q e : ℕ}

private theorem selected_forward (source : Table n q e) (deterministic : Deterministic source)
    (site : SourceSite source) (remainder : ℕ) (edge : Fin e)
    (same : (source edge).source = site.val)
    (chosen : testSelected source (moduleRegister source (.inl site)) remainder edge = true) :
    reversed source (.inl site) = false := by
  obtain ⟨flag, form⟩ := test_owner_form source (fun index => (source index).source) deterministic
    ((testSelected_iff source _ _ edge).mp chosen)
    (same.trans (sourceEdge_spec source site).symm)
  simp only [reversed, form]

/-- Only true module exits are connected; no original source is removed. -/
theorem connection_source_free (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (index : Fin (rawEdges basis source))
    (entry : Fin (rawSize basis source)) :
    ¬ Connection basis source (rawTable basis source index).source entry := by
  rintro (shift | restore | test)
  · obtain ⟨site, _, same, _⟩ := shift
    exact raw_no_outgoing_sourceShiftOutput basis source site index same
  · obtain ⟨site, same, _⟩ := restore
    exact raw_no_outgoing_restoreOutput basis source site index same
  · obtain ⟨site, _, remainder, _, edge, same_source, _, selected, _, _, same, _⟩ := test
    exact raw_no_outgoing_sourceFinish basis source site remainder
      (selected_forward source deterministic site remainder.val edge same_source selected) index same

/-- Every selected destination is an original input with no incoming edge. -/
theorem connection_target_free (basis : PrimeCode.Basis n) (source : Table n q e)
    (index : Fin (rawEdges basis source)) (exit : Fin (rawSize basis source)) :
    ¬ Connection basis source exit (rawTable basis source index).target := by
  rintro (shift | restore | test)
  · obtain ⟨site, _, _, same⟩ := shift
    exact raw_no_incoming_boundary basis source _ index same
  · obtain ⟨site, _, same⟩ := restore
    exact raw_no_incoming_boundary basis source site.val index same
  · obtain ⟨_, site, _, remainder, _, _, _, _, _, _, _, same⟩ := test
    exact raw_no_incoming_restoreInput basis source site remainder index same

/-- Original execution boundaries are retained vertices of the compressed graph. -/
theorem boundary_unconnected (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (position : Fin q)
    (entry : Fin (rawSize basis source)) :
    ¬ Connection basis source (boundary basis source position) entry := by
  rintro (shift | restore | test)
  · obtain ⟨site, _, same, _⟩ := shift
    exact sourceShiftOutput_ne_boundary basis source site position same.symm
  · obtain ⟨site, same, _⟩ := restore
    exact restoreOutput_ne_boundary basis source site position same.symm
  · obtain ⟨site, _, remainder, _, edge, same_source, _, selected, _, _, same, _⟩ := test
    exact sourceFinish_ne_boundary basis source site remainder
      (selected_forward source deterministic site remainder.val edge same_source selected)
      position same.symm

/-- Restoration entries are retained vertices, including their selected remainder. -/
theorem restoreInput_unconnected (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : RestoreSite source) (remainder : Fin (modulus basis source (.inr site)))
    (entry : Fin (rawSize basis source)) :
    ¬ Connection basis source (restoreInput basis source site remainder) entry := by
  rintro (shift | restore | test)
  · obtain ⟨first, _, same, _⟩ := shift
    exact sourceShiftOutput_ne_restoreInput basis source first site remainder same.symm
  · obtain ⟨first, same, _⟩ := restore
    exact restoreOutput_ne_restoreInput basis source first site remainder same.symm
  · obtain ⟨first, _, selected, _, _, _, _, _, _, _, same, _⟩ := test
    exact sourceFinish_ne_restoreInput basis source first selected site remainder same.symm

/-- Identification has depth one: its entry is already a retained control position. -/
theorem connection_terminal (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) {exit entry : Fin (rawSize basis source)}
    (connected : Connection basis source exit entry) (next : Fin (rawSize basis source)) :
    ¬ Connection basis source entry next := by
  rcases connected with shift | restore | test
  · obtain ⟨site, _, _, rfl⟩ := shift
    exact boundary_unconnected basis source deterministic _ next
  · obtain ⟨site, _, rfl⟩ := restore
    exact boundary_unconnected basis source deterministic site.val next
  · obtain ⟨_, site, _, remainder, _, _, _, _, _, _, _, rfl⟩ := test
    exact restoreInput_unconnected basis source site remainder next

/-- Finite port identification supplies the complete compressed execution table. -/
def wiring (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source) :
    PortNetwork.Wiring (rawTable basis source) :=
  PortNetwork.Wiring.ofRelation (rawTable basis source) (Connection basis source)
    (connection_functional basis source deterministic)
    (connection_backward basis source compatible)
    (connection_terminal basis source deterministic)
    (connection_source_free basis source deterministic)
    (connection_target_free basis source)

def size (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source) : ℕ :=
  PortNetwork.size (wiring basis source deterministic compatible)

/-- Every edge is an existing radix edge on the same two physical counters. -/
def table (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source) :
    Table 2 (size basis source deterministic compatible) (rawEdges basis source) :=
  PortNetwork.table (wiring basis source deterministic compatible)

theorem deterministic (basis : PrimeCode.Basis n) (source : Table n q e)
    (source_deterministic : Deterministic source) (compatible : TargetCompatible source) :
    Deterministic (table basis source source_deterministic compatible) :=
  PortNetwork.deterministic _ (raw_deterministic basis source)

theorem targetCompatible (basis : PrimeCode.Basis n) (source : Table n q e)
    (source_deterministic : Deterministic source) (compatible : TargetCompatible source) :
    TargetCompatible (table basis source source_deterministic compatible) :=
  PortNetwork.targetCompatible _ (raw_targetCompatible basis source)

end Monodromy.Counter.Reversible.PrimeCompression
