import «Monodromy-prime-compression-first-return»
import «Monodromy-prime-compression-step»

/-! Arithmetic instructions return for the first time to their encoded source boundaries. -/

namespace Monodromy.Counter.Reversible.PrimeCompression

variable {n q e : ℕ}

theorem increment_firstReturn (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (before : Counter.Configuration n q) (edge : Fin e) (register : Fin n)
    (at_source : (source edge).source = before.pc)
    (instruction : (source edge).action = .shift register 1) :
    FirstReturn basis source deterministic compatible
      (encode basis source deterministic compatible before)
      (encode basis source deterministic compatible
        ⟨(source edge).target, Function.update before.counters register (before.counters register + 1)⟩) := by
  let site := siteOfEdge source edge
  let p := modulus basis source (.inl site)
  let value := basis.encode before.counters
  have backwards : reversed source (.inl site) = true := by
    simp only [site, reversed,
      sourceEdge_of_shift source deterministic edge register 1 instruction, instruction,
      decide_true]
  have prime : p = basis.prime register := by
    exact congrArg basis.prime
      (sourceRegister_of_shift source deterministic edge register 1 instruction)
  have initial : boundary basis source before.pc = sourceInput basis source site := by
    rw [← at_source]
    exact boundary_source basis source site
  have input : moduleNode basis source (.inl site) (Radix.finish p 0) =
      sourceInput basis source site := by
    simp [sourceInput, sourceInputPosition, backwards, p]
  have output : moduleNode basis source (.inl site) (Radix.entry p) =
      sourceShiftOutput basis source site := by
    simp [sourceShiftOutput, backwards, p]
  have final := connection_controls basis source deterministic compatible
    (shift_connected basis source deterministic edge register 1 instruction)
  have code : p * value =
      basis.encode (Function.update before.counters register (before.counters register + 1)) := by
    rw [prime]
    exact (basis.encode_increment before.counters register).symm
  have departure := source_departure basis source deterministic compatible site
    (source_multiply_local_positive basis source site backwards value)
  simp only [MappedState, Glue.mapState, Radix.point] at departure
  rw [input, ← initial, output, final, code] at departure
  exact ⟨boundary_encode basis source deterministic compatible before,
    boundary_encode basis source deterministic compatible _, departure⟩

theorem decrement_firstReturn (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (before : Counter.Configuration n q) (edge : Fin e) (register : Fin n)
    (at_source : (source edge).source = before.pc)
    (instruction : (source edge).action = .shift register (-1))
    (positive : before.counters register ≠ 0) :
    FirstReturn basis source deterministic compatible
      (encode basis source deterministic compatible before)
      (encode basis source deterministic compatible
        ⟨(source edge).target, Function.update before.counters register (before.counters register - 1)⟩) := by
  let site := siteOfEdge source edge
  let p := modulus basis source (.inl site)
  let value := basis.encode before.counters
  have forward : reversed source (.inl site) = false := by
    dsimp only [site, reversed]
    rw [sourceEdge_of_shift source deterministic edge register (-1) instruction, instruction]
    change decide ((-1 : ℤ) = 1) = false
    decide
  have prime : p = basis.prime register := by
    dsimp only [p, modulus, site]
    rw [sourceRegister_of_shift source deterministic edge register (-1) instruction]
  have divisible : p ∣ value := by
    rw [prime]
    exact (basis.prime_dvd_encode_iff before.counters register).mpr positive
  have remainder_zero : Counter.DivMod.residue p value = 0 := by
    apply Fin.ext
    change value % p = 0
    exact Nat.mod_eq_zero_of_dvd divisible
  have initial : sourceInput basis source site = boundary basis source before.pc := by
    rw [← boundary_source basis source site]
    exact congrArg (boundary basis source) at_source
  have input : moduleNode basis source (.inl site) (Radix.entry p) =
      sourceInput basis source site := by
    simp [sourceInput, sourceInputPosition, forward, p]
  have output : moduleNode basis source (.inl site) (Radix.finish p 0) =
      sourceShiftOutput basis source site := by
    simp [sourceShiftOutput, forward, p]
  have final := connection_controls basis source deterministic compatible
    (shift_connected basis source deterministic edge register (-1) instruction)
  have code : basis.encode (Function.update before.counters register (before.counters register - 1)) =
      value / p := by
    rw [prime]
    exact basis.encode_decrement before.counters register positive
  have local_run := forward_query_local_positive basis source site forward value
  change StateTransition.Reaches₁ (step (componentTable basis source (.inl site)))
    (Radix.point p (Radix.entry p) value 0)
    (Radix.point p (Radix.finish p (Counter.DivMod.residue p value)) (value / p : ℕ) 0) at local_run
  rw [remainder_zero] at local_run
  have departure := source_departure basis source deterministic compatible site local_run
  simp only [MappedState, Glue.mapState, Radix.point] at departure
  rw [input, initial, output, final, ← code] at departure
  exact ⟨boundary_encode basis source deterministic compatible before,
    boundary_encode basis source deterministic compatible _, departure⟩

end Monodromy.Counter.Reversible.PrimeCompression
