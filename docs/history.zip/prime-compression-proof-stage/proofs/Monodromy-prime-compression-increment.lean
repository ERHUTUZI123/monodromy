import «Monodromy-prime-compression-step»
import «Monodromy-prime-compression-runs»
import «Monodromy-prime-compression-encoding»

/-! A source increment is executed by a reversed radix module and literal port gluing. -/

namespace Monodromy.Counter.Reversible.PrimeCompression

variable {n q e : ℕ}

/-- The actual compressed graph increments one virtual register without changing the others. -/
theorem increment_reaches (basis : PrimeCode.Basis n) (source : Table n q e)
    (deterministic : Deterministic source) (compatible : TargetCompatible source)
    (before : Counter.Configuration n q) (edge : Fin e) (register : Fin n)
    (at_source : (source edge).source = before.pc)
    (instruction : (source edge).action = .shift register 1) :
    StateTransition.Reaches₁ (step (table basis source deterministic compatible))
      (encode basis source deterministic compatible before)
      (encode basis source deterministic compatible
        ⟨(source edge).target, Function.update before.counters register (before.counters register + 1)⟩) := by
  let site := siteOfEdge source edge
  have backwards : reversed source (.inl site) = true := by
    simp only [site, reversed,
      sourceEdge_of_shift source deterministic edge register 1 instruction, instruction,
      decide_true]
  have prime : modulus basis source (.inl site) = basis.prime register := by
    exact congrArg basis.prime
      (sourceRegister_of_shift source deterministic edge register 1 instruction)
  have initial : boundary basis source before.pc = sourceInput basis source site := by
    rw [← at_source]
    exact boundary_source basis source site
  have final := connection_controls basis source deterministic compatible
    (shift_connected basis source deterministic edge register 1 instruction)
  have code : modulus basis source (.inl site) * basis.encode before.counters =
      basis.encode (Function.update before.counters register (before.counters register + 1)) := by
    rw [prime]
    exact (basis.encode_increment before.counters register).symm
  have raw_run := source_multiply_positive basis source site backwards (basis.encode before.counters)
  have run := PortNetwork.reaches1_map_live (wiring basis source deterministic compatible)
    (raw_deterministic basis source) raw_run
  simp only [Glue.mapState] at run
  rw [← initial, final, code] at run
  exact run

end Monodromy.Counter.Reversible.PrimeCompression
