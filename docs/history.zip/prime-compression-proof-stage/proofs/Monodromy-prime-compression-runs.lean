import «Monodromy-prime-compression-modules»

/-! Actual radix executions inside the disjoint compression modules. -/

namespace Monodromy.Counter.Reversible.PrimeCompression

variable {n q e : ℕ}

theorem component_step_map (basis : PrimeCode.Basis n) (source : Table n q e)
    (block : Module source)
    {first last : State 2 (Radix.size (modulus basis source block))}
    (transition : step (componentTable basis source block) first = some last) :
    step (rawTable basis source) (Glue.mapState (moduleNode basis source block) first) =
      some (Glue.mapState (moduleNode basis source block) last) := by
  exact Glue.step_map_live (componentTable basis source block) (rawTable basis source)
    (moduleNode basis source block) (fun index => rawArcEquiv basis source ⟨block, index⟩)
    (fun index => by rw [rawTable_arc]; rfl)
    (component_deterministic basis source block) (raw_deterministic basis source) transition

theorem component_reaches_map (basis : PrimeCode.Basis n) (source : Table n q e)
    (block : Module source)
    {first last : State 2 (Radix.size (modulus basis source block))}
    (run : StateTransition.Reaches (step (componentTable basis source block)) first last) :
    StateTransition.Reaches (step (rawTable basis source))
      (Glue.mapState (moduleNode basis source block) first)
      (Glue.mapState (moduleNode basis source block) last) := by
  exact Glue.reaches_map_live (componentTable basis source block) (rawTable basis source)
    (moduleNode basis source block) (fun index => rawArcEquiv basis source ⟨block, index⟩)
    (fun index => by rw [rawTable_arc]; rfl)
    (component_deterministic basis source block) (raw_deterministic basis source) run

theorem component_reaches1_map (basis : PrimeCode.Basis n) (source : Table n q e)
    (block : Module source)
    {first last : State 2 (Radix.size (modulus basis source block))}
    (run : StateTransition.Reaches₁ (step (componentTable basis source block)) first last) :
    StateTransition.Reaches₁ (step (rawTable basis source))
      (Glue.mapState (moduleNode basis source block) first)
      (Glue.mapState (moduleNode basis source block) last) := by
  induction run with
  | single transition => exact Relation.TransGen.single (component_step_map basis source block transition)
  | tail _ transition previous => exact previous.tail (component_step_map basis source block transition)

private theorem positive_of_control_ne {d f : ℕ} (table : Table 2 d f)
    {first last : State 2 d} (run : StateTransition.Reaches (step table) first last)
    (different : first.1 ≠ last.1) : StateTransition.Reaches₁ (step table) first last := by
  rcases Relation.reflTransGen_iff_eq_or_transGen.mp run with same | positive
  · exact False.elim (different (congrArg Prod.fst same.symm))
  · exact positive

/-- The forward radix module has a positive execution to its actual quotient and remainder. -/
theorem forward_query_local_positive (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : SourceSite source) (forward : reversed source (.inl site) = false) (value : ℕ) :
    let p := modulus basis source (.inl site)
    StateTransition.Reaches₁ (step (componentTable basis source (.inl site)))
      (Radix.point p (Radix.entry p) value 0)
      (Radix.point p (Radix.finish p (Counter.DivMod.residue p value)) (value / p : ℕ) 0) := by
  dsimp only
  apply positive_of_control_ne
  · simpa only [componentTable, forward, Bool.false_eq_true, reduceIte] using
      Radix.reaches_result (modulus basis source (.inl site)) value
  · exact radix_entry_ne_finish _ _

/-- The reversed radix module packs a zero remainder by actual positive execution. -/
theorem source_multiply_local_positive (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : SourceSite source) (backwards : reversed source (.inl site) = true) (value : ℕ) :
    let p := modulus basis source (.inl site)
    StateTransition.Reaches₁ (step (componentTable basis source (.inl site)))
      (Radix.point p (Radix.finish p 0) value 0)
      (Radix.point p (Radix.entry p) (p * value : ℕ) 0) := by
  dsimp only
  apply positive_of_control_ne
  · simpa only [componentTable, backwards, reduceIte, Fin.val_zero, Nat.add_zero] using
      Radix.reverse_pack (modulus basis source (.inl site)) value 0
  · exact (radix_entry_ne_finish _ 0).symm

/-- The restoration module positively packs its quotient and reached remainder. -/
theorem restore_pack_local_positive (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : RestoreSite source) (remainder : Fin (modulus basis source (.inr site))) (quotient : ℕ) :
    let p := modulus basis source (.inr site)
    StateTransition.Reaches₁ (step (componentTable basis source (.inr site)))
      (Radix.point p (Radix.finish p remainder) quotient 0)
      (Radix.point p (Radix.entry p) (p * quotient + remainder.val : ℕ) 0) := by
  dsimp only
  apply positive_of_control_ne
  · exact Radix.reverse_pack _ quotient remainder
  · exact (radix_entry_ne_finish _ remainder).symm

/-- A forward source module actually reaches its remainder port with the quotient. -/
theorem forward_query_positive (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : SourceSite source) (forward : reversed source (.inl site) = false) (value : ℕ) :
    StateTransition.Reaches₁ (step (rawTable basis source))
      (sourceInput basis source site, ![(value : ℤ), 0])
      (moduleNode basis source (.inl site)
        (Radix.finish _ (Counter.DivMod.residue (modulus basis source (.inl site)) value)),
        ![((value / modulus basis source (.inl site) : ℕ) : ℤ), 0]) := by
  simpa only [Glue.mapState, Radix.point, sourceInput, sourceInputPosition, forward,
    Bool.false_eq_true, reduceIte] using component_reaches1_map basis source (.inl site)
      (forward_query_local_positive basis source site forward value)

/-- A reversed source module multiplies by its fixed prime through the same radix graph. -/
theorem source_multiply_positive (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : SourceSite source) (backwards : reversed source (.inl site) = true) (value : ℕ) :
    StateTransition.Reaches₁ (step (rawTable basis source))
      (sourceInput basis source site, ![(value : ℤ), 0])
      (sourceShiftOutput basis source site,
        ![((modulus basis source (.inl site) * value : ℕ) : ℤ), 0]) := by
  simpa only [Glue.mapState, Radix.point, sourceInput, sourceInputPosition, sourceShiftOutput,
    backwards, reduceIte] using component_reaches1_map basis source (.inl site)
      (source_multiply_local_positive basis source site backwards value)

/-- A restoration module packs its actual quotient and reached remainder. -/
theorem restore_pack_positive (basis : PrimeCode.Basis n) (source : Table n q e)
    (site : RestoreSite source) (remainder : Fin (modulus basis source (.inr site))) (quotient : ℕ) :
    StateTransition.Reaches₁ (step (rawTable basis source))
      (restoreInput basis source site remainder, ![(quotient : ℤ), 0])
      (restoreOutput basis source site,
        ![((modulus basis source (.inr site) * quotient + remainder.val : ℕ) : ℤ), 0]) := by
  simpa only [Glue.mapState, Radix.point, restoreInput, restoreOutput] using
    component_reaches1_map basis source (.inr site)
      (restore_pack_local_positive basis source site remainder quotient)

end Monodromy.Counter.Reversible.PrimeCompression
