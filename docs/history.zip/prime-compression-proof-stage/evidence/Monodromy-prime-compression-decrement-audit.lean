import «Monodromy-prime-compression-decrement»

open Monodromy.Counter.Reversible.PrimeCompression

#check decrement_reaches
#print axioms decrement_reaches
