import «Monodromy-prime-compression-marked»
import Lean.Util.CollectAxioms
import Lean.Elab.Command

open Lean Elab Command in
run_cmd do
  let allowed : Array Name := #[`propext, `Quot.sound, `Classical.choice]
  for name in #[`Monodromy.Counter.Reversible.PrimeCompression.marked_encode_iff,
      `Monodromy.Counter.Reversible.PrimeCompression.integer_internal_reaches,
      `Monodromy.Counter.Reversible.PrimeCompression.marked_firstReturn] do
    for dependency in ← collectAxioms name do
      unless allowed.contains dependency do
        throwError "{name} depends on unexpected axiom {dependency}"
  logInfo "Marked first-return transport: only standard Lean axioms."

#check Monodromy.Counter.Reversible.PrimeCompression.marked_encode_iff
#check Monodromy.Counter.Reversible.PrimeCompression.integer_internal_reaches
#check Monodromy.Counter.Reversible.PrimeCompression.marked_firstReturn
