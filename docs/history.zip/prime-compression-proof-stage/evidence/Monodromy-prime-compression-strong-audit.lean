import «Monodromy-prime-compression-simulation-return»
import Lean.Util.CollectAxioms
import Lean.Elab.Command

open Lean Elab Command in
run_cmd do
  let allowed : Array Name := #[`propext, `Classical.choice, `Quot.sound]
  let mut checked : Nat := 0
  for (name, _) in (← getEnv).constants.toList do
    if (`Monodromy.Counter.Reversible.PrimeCompression).isPrefixOf name then
      checked := checked + 1
      for dependency in ← collectAxioms name do
        unless allowed.contains dependency do
          throwError "{name} depends on {dependency}"
  logInfo m!"Audited {checked} strong prime-compression declarations: standard axioms only."

#print axioms Monodromy.Counter.Reversible.PrimeCompression.step_firstReturn
#print axioms Monodromy.Counter.Reversible.PrimeCompression.step_reaches
