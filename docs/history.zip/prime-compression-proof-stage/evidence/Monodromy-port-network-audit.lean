import «Monodromy-port-network»
import Lean.Util.CollectAxioms
import Lean.Elab.Command

open Lean Elab Command in
run_cmd do
  let allowed : Array Name := #[`propext, `Quot.sound, `Classical.choice]
  let mut checked : Nat := 0
  for (name, _) in (← getEnv).constants.toList do
    if (`Monodromy.Counter.Reversible.PortNetwork).isPrefixOf name then
      checked := checked + 1
      for dependency in ← collectAxioms name do
        unless allowed.contains dependency do
          throwError "{name} depends on unexpected axiom {dependency}"
  logInfo m!"Audited {checked} PortNetwork declarations: only standard Lean axioms."

#check Monodromy.Counter.Reversible.PortNetwork.interface
#check Monodromy.Counter.Reversible.PortNetwork.source_eq_iff
#check Monodromy.Counter.Reversible.PortNetwork.target_eq_iff
#check Monodromy.Counter.Reversible.PortNetwork.reaches1_map_live
