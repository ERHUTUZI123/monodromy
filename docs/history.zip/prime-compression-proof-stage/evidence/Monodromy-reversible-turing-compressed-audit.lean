import «Monodromy-reversible-turing-compressed»
import Lean.Util.CollectAxioms
import Lean.Elab.Command

/-! Independent proof and constructor audit for the two-counter Turing simulation. -/

open Lean Elab Command in
run_cmd do
  let allowed : Array Name := #[`propext, `Quot.sound, `Classical.choice]
  let mut checked : Nat := 0
  for (name, _) in (← getEnv).constants.toList do
    if (`Monodromy.ReversibleTuring.Compression).isPrefixOf name then
      checked := checked + 1
      for dependency in ← collectAxioms name do
        unless allowed.contains dependency do
          throwError "{name} depends on unexpected axiom {dependency}"
  logInfo m!"Audited {checked} two-counter Turing declarations: only standard Lean axioms."

open Lean Elab Command in
run_cmd do
  let forbidden : Array Name := #[
    `Turing.TM0.step, `Turing.TM1.step, `Turing.TM2.step,
    `StateTransition.eval, `Nat.Partrec.Code.eval,
    `Monodromy.Counter.step, `Monodromy.Counter.eval,
    `Monodromy.Counter.Recorded.step,
    `Monodromy.Counter.Reversible.step, `Monodromy.Counter.Reversible.eval,
    `Monodromy.Counter.Reversible.Action.apply, `Monodromy.Counter.Reversible.Action.enabled,
    `Monodromy.ReversibleControl.enabled,
    `Monodromy.CoupledContinuation.Gate.evalInt,
    `Monodromy.CoupledContinuation.Word.evalInt,
    `Monodromy.CoupledContinuation.Program.indexInt,
    `Monodromy.CoupledContinuation.Program.nextInt,
    `Monodromy.CoupledContinuation.Program.stepInt,
    `Monodromy.CoupledContinuation.Program.evalInt]
  let mut pending := [`Monodromy.ReversibleTuring.Compression.table]
  let environment ← getEnv
  let mut visited : NameSet := {}
  let mut inspected : Nat := 0
  while !pending.isEmpty do
    let name := pending.head!
    pending := pending.tail!
    unless visited.contains name do
      visited := visited.insert name
      if forbidden.contains name || (`Monodromy.AnalyticComparison).isPrefixOf name then
        throwError "Table constructor depends on execution backend {name}"
      if let some declaration := environment.find? name then
        if let some body := declaration.value? then
          inspected := inspected + 1
          pending := body.getUsedConstants.toList ++ pending
  for required in #[
      `Monodromy.ReversibleTuring.table,
      `Monodromy.Counter.Reversible.Recording.table,
      `Monodromy.Counter.Reversible.PrimeCompression.table,
      `Monodromy.Counter.Reversible.PrimeCompression.componentTable,
      `Monodromy.Counter.Reversible.PortNetwork.relationLink,
      `Monodromy.Counter.Reversible.PortNetwork.table,
      `Monodromy.Counter.Reversible.Radix.table,
      `Monodromy.Counter.Reversible.reverseTable] do
    unless visited.contains required do
      throwError "Required finite compiler component absent: {required}"
  logInfo m!"Two-counter constructor audit: {inspected} definition bodies; fixed source AST, radix edges and finite port wiring present; source execution backends absent."

#print axioms Monodromy.ReversibleTuring.Compression.step_reaches
#print axioms Monodromy.ReversibleTuring.Compression.result_iff
#print axioms Monodromy.ReversibleTuring.Compression.step_retraces
