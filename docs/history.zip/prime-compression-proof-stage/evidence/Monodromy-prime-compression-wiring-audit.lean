import «Monodromy-prime-compression-wiring»
import Lean.Util.CollectAxioms
import Lean.Elab.Command

/-!
Independent audit of the candidate finite two-counter table.
The axiom audit includes transitive proof dependencies. The definition audit
follows executable definition bodies, skipping theorem and opaque bodies;
it inspects the static compiler and does not assert an execution equivalence.
-/

open Lean Elab Command in
run_cmd do
  let allowed : Array Name := #[`propext, `Quot.sound, `Classical.choice]
  let mut checked : Nat := 0
  for (name, _) in (← getEnv).constants.toList do
    if (`Monodromy.Counter.Reversible.PrimeCompression).isPrefixOf name then
      checked := checked + 1
      for dependency in ← collectAxioms name do
        unless allowed.contains dependency do
          throwError "{name} depends on unexpected axiom {dependency}"
  logInfo m!"Audited {checked} prime-compression declarations: only standard Lean axioms."

open Lean Elab Command in
run_cmd do
  let forbidden : Array Name := #[
    `Turing.TM0.step, `Turing.TM1.step, `Turing.TM2.step,
    `StateTransition.eval, `Nat.Partrec.Code.eval,
    `Monodromy.Counter.step, `Monodromy.Counter.eval,
    `Monodromy.Counter.Recorded.step,
    `Monodromy.Counter.Reversible.step, `Monodromy.Counter.Reversible.eval,
    `Monodromy.Counter.Reversible.Action.apply, `Monodromy.Counter.Reversible.Action.enabled,
    `Monodromy.ReversibleControl.enabled,
    `Monodromy.CoupledContinuation.Gate.evalInt,
    `Monodromy.CoupledContinuation.Word.evalInt,
    `Monodromy.CoupledContinuation.Program.indexInt,
    `Monodromy.CoupledContinuation.Program.nextInt,
    `Monodromy.CoupledContinuation.Program.stepInt,
    `Monodromy.CoupledContinuation.Program.evalInt]
  let mut pending := [`Monodromy.Counter.Reversible.PrimeCompression.table]
  let environment ← getEnv
  let mut visited : NameSet := {}
  let mut inspected : Nat := 0
  while !pending.isEmpty do
    let name := pending.head!
    pending := pending.tail!
    unless visited.contains name do
      visited := visited.insert name
      if forbidden.contains name || (`Monodromy.AnalyticComparison).isPrefixOf name then
        throwError "Static table depends on execution backend {name}"
      if let some declaration := environment.find? name then
        if let some body := declaration.value? then
          inspected := inspected + 1
          pending := body.getUsedConstants.toList ++ pending
  for required in #[
      `Monodromy.Counter.Reversible.PrimeCompression.rawTable,
      `Monodromy.Counter.Reversible.PrimeCompression.componentTable,
      `Monodromy.Counter.Reversible.PrimeCompression.sourceEdge,
      `Monodromy.Counter.Reversible.PrimeCompression.restoreEdge,
      `Monodromy.Counter.Reversible.PrimeCompression.Connection,
      `Monodromy.Counter.Reversible.PrimeCompression.testSelected,
      `Monodromy.Counter.Reversible.PortNetwork.Wiring.ofRelation,
      `Monodromy.Counter.Reversible.PortNetwork.relationLink,
      `Monodromy.Counter.Reversible.PortNetwork.table,
      `Monodromy.Counter.Reversible.PortNetwork.representative,
      `Monodromy.Counter.Reversible.Radix.table,
      `Monodromy.Counter.Reversible.reverseTable] do
    unless visited.contains required do
      throwError "Expected static radix/port component is absent: {required}"
  logInfo m!"Definition audit: {inspected} definition bodies; existing radix edges and finite port selection present; source interpreters absent."
