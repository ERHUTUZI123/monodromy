import «Monodromy-prime-compression-test-execution»
import «Monodromy-prime-compression-increment»
import «Monodromy-prime-compression-decrement»
import Lean.Util.CollectAxioms
import Lean.Elab.Command

open Lean Elab Command in
run_cmd do
  let allowed : Array Name := #[`propext, `Classical.choice, `Quot.sound]
  let mut count : Nat := 0
  for (name, _) in (← getEnv).constants.toList do
    if (`Monodromy.Counter.Reversible.PrimeCompression).isPrefixOf name then
      count := count + 1
      for dependency in ← collectAxioms name do
        unless allowed.contains dependency do
          throwError "{name} depends on {dependency}"
  logInfo m!"Audited {count} prime-compression declarations: standard Lean axioms only."

#print axioms Monodromy.Counter.Reversible.PrimeCompression.test_reaches
#print axioms Monodromy.Counter.Reversible.PrimeCompression.increment_reaches
#print axioms Monodromy.Counter.Reversible.PrimeCompression.decrement_reaches
