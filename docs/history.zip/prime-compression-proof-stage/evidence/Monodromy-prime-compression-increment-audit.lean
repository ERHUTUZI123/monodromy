import «Monodromy-prime-compression-increment»
import Lean.Util.CollectAxioms
import Lean.Elab.Command

open Lean Elab Command in
run_cmd do
  let name := `Monodromy.Counter.Reversible.PrimeCompression.increment_reaches
  for dependency in ← collectAxioms name do
    unless #[`propext, `Quot.sound, `Classical.choice].contains dependency do
      throwError "{name} depends on unexpected axiom {dependency}"
  logInfo "Increment simulation: only standard Lean axioms."

#check Monodromy.Counter.Reversible.PrimeCompression.increment_reaches
