import «Monodromy-prime-compression-first-return»
import Lean.Util.CollectAxioms
import Lean.Elab.Command

open Lean Elab Command in
run_cmd do
  let allowed : Array Name := #[`propext, `Quot.sound, `Classical.choice]
  for name in #[`Monodromy.Counter.Reversible.PrimeCompression.source_internal_reaches,
      `Monodromy.Counter.Reversible.PrimeCompression.restore_internal_reaches,
      `Monodromy.Counter.Reversible.PrimeCompression.source_departure,
      `Monodromy.Counter.Reversible.PrimeCompression.mapped_step] do
    for dependency in ← collectAxioms name do
      unless allowed.contains dependency do
        throwError "{name} depends on unexpected axiom {dependency}"
  logInfo "First-return bridge: only standard Lean axioms."

#check Monodromy.Counter.Reversible.PrimeCompression.source_internal_reaches
#check Monodromy.Counter.Reversible.PrimeCompression.restore_internal_reaches
#check Monodromy.Counter.Reversible.PrimeCompression.source_departure
