import «Monodromy-prime-compression-runs»

open Monodromy.Counter.Reversible.PrimeCompression

#check component_step_map
#print axioms component_step_map
#check component_reaches_map
#print axioms component_reaches_map
#check component_reaches1_map
#print axioms component_reaches1_map
#check forward_query_local_positive
#print axioms forward_query_local_positive
#check source_multiply_local_positive
#print axioms source_multiply_local_positive
#check restore_pack_local_positive
#print axioms restore_pack_local_positive
#check forward_query_positive
#print axioms forward_query_positive
#check source_multiply_positive
#print axioms source_multiply_positive
#check restore_pack_positive
#print axioms restore_pack_positive
