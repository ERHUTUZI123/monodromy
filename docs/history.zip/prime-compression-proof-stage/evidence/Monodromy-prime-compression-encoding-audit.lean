import «Monodromy-prime-compression-encoding»
import Lean.Util.CollectAxioms
import Lean.Elab.Command

open Lean Elab Command in
run_cmd do
  let allowed : Array Name := #[`propext, `Quot.sound, `Classical.choice]
  let mut checked : Nat := 0
  for (name, _) in (← getEnv).constants.toList do
    if (`Monodromy.Counter.Reversible.PrimeCompression).isPrefixOf name then
      checked := checked + 1
      for dependency in ← collectAxioms name do
        unless allowed.contains dependency do
          throwError "{name} depends on unexpected axiom {dependency}"
  logInfo m!"Audited {checked} prime-compression declarations: only standard Lean axioms."

#check Monodromy.Counter.Reversible.PrimeCompression.encode_injective
#check Monodromy.Counter.Reversible.PrimeCompression.connection_controls
#check Monodromy.Counter.Reversible.PrimeCompression.step_encode_none_of_no_source
