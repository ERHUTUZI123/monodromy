import «Monodromy-prime-compression-backward»
import Lean.Util.CollectAxioms
import Lean.Elab.Command

open Lean Elab Command in
run_cmd do
  let allowed : Array Name := #[`propext, `Quot.sound, `Classical.choice]
  for dependency in ← collectAxioms `Monodromy.Counter.Reversible.PrimeCompression.connection_backward do
    unless allowed.contains dependency do
      throwError "Unexpected axiom {dependency}"
  logInfo "Backward connection theorem: only standard Lean axioms."

#print axioms Monodromy.Counter.Reversible.PrimeCompression.connection_backward
