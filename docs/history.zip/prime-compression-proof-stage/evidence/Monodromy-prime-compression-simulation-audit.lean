import «Monodromy-prime-compression-simulation»
import Lean.Util.CollectAxioms
import Lean.Elab.Command

open Lean Elab Command in
run_cmd do
  let allowed : Array Name := #[`propext, `Quot.sound, `Classical.choice]
  let mut count : Nat := 0
  for (name, _) in (← getEnv).constants.toList do
    if (`Monodromy.Counter.Reversible.PrimeCompression).isPrefixOf name then
      count := count + 1
      for dependency in ← collectAxioms name do
        unless allowed.contains dependency do
          throwError "Unexpected axiom {dependency} in {name}"
  logInfo m!"Audited {count} complete prime-compression declarations: only standard Lean axioms."

#print axioms Monodromy.Counter.Reversible.PrimeCompression.step_reaches
#print axioms Monodromy.Counter.Reversible.PrimeCompression.naturalState_injective
