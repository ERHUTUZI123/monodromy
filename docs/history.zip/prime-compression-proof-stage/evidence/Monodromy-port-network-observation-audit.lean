import «Monodromy-port-network-observation»
import Lean.Util.CollectAxioms
import Lean.Elab.Command

open Lean Elab Command in
run_cmd do
  let allowed : Array Name := #[`propext, `Quot.sound, `Classical.choice]
  let mut checked : Nat := 0
  for (name, _) in (← getEnv).constants.toList do
    if (`Monodromy.Counter.Reversible.RadixObservationNetwork).isPrefixOf name then
      checked := checked + 1
      for dependency in ← collectAxioms name do
        unless allowed.contains dependency do
          throwError "{name} depends on unexpected axiom {dependency}"
  logInfo m!"Audited {checked} replacement observation declarations: only standard Lean axioms."

#check Monodromy.Counter.Reversible.RadixObservationNetwork.wiring
#check Monodromy.Counter.Reversible.RadixObservationNetwork.deterministic
#check Monodromy.Counter.Reversible.RadixObservationNetwork.targetCompatible
#check Monodromy.Counter.Reversible.RadixObservationNetwork.reaches_result
#check Monodromy.Counter.Reversible.RadixObservationNetwork.native_eval
