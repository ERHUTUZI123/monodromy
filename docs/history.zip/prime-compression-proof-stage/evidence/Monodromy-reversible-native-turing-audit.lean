import «Monodromy-reversible-native-turing»
import Lean.Util.CollectAxioms
import Lean.Elab.Command

open Monodromy.ReversibleNativeTuring

#check iota_injective
#check step_reaches
#check step_halt
#check respects
#check result_iff
#check halting_iff
#check divergence_iff
#check reverse_after_forward
#check forward_after_reverse
#check executionEquiv
#check step_retraces
#check result_actual_lifts
#check finite_run_actual_lifts
#check native_universality
#print axioms native_universality

open Lean Elab Command in
run_cmd do
  let allowed : Array Name := #[`propext, `Classical.choice, `Quot.sound]
  let mut checked : Nat := 0
  for (name, _) in (← getEnv).constants.toList do
    if (`Monodromy.ReversibleNativeTuring).isPrefixOf name then
      checked := checked + 1
      for dependency in ← collectAxioms name do
        unless allowed.contains dependency do
          throwError "{name} depends on {dependency}"
  logInfo m!"Audited {checked} reversible native Turing declarations: standard axioms only."

open Lean Elab Command in
run_cmd do
  let forbidden : Array Name := #[
    `Turing.TM0.step, `Monodromy.Counter.step, `Monodromy.Counter.Recorded.step,
    `Monodromy.Counter.Reversible.step, `Monodromy.Counter.Reversible.eval,
    `Monodromy.Counter.Reversible.Action.apply, `Monodromy.Counter.Reversible.Action.enabled,
    `Monodromy.ReversibleControl.enabled, `Monodromy.CoupledContinuation.Program.indexInt,
    `Monodromy.CoupledContinuation.Word.evalInt, `Monodromy.CoupledContinuation.Program.nextInt]
  let mut pending := [
    `Monodromy.ReversibleNativeTuring.program,
    `Monodromy.ReversibleNativeTuring.reverseProgram,
    `Monodromy.CoupledContinuation.Program.advance,
    `Monodromy.CoupledContinuation.Program.runDriver]
  let environment ← getEnv
  let mut visited : NameSet := {}
  while !pending.isEmpty do
    let name := pending.head!
    pending := pending.tail!
    unless visited.contains name do
      visited := visited.insert name
      if forbidden.contains name || (`Monodromy.AnalyticComparison).isPrefixOf name then
        throwError "Native definition depends on proof-side interpreter {name}"
      if let some declaration := environment.find? name then
        if let some body := declaration.value? then
          pending := body.getUsedConstants.toList ++ pending
  for required in #[`Monodromy.CoupledContinuation.lower,
      `Monodromy.CoupledContinuation.feed, `Monodromy.CoupledContinuation.upper] do
    unless visited.contains required do
      throwError "Actual lift component missing: {required}"
  logInfo "Native reversible program audit: actual lifts present; source interpreters absent."
