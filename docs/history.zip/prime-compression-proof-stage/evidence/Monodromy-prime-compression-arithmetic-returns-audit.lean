import «Monodromy-prime-compression-arithmetic-returns»

open Monodromy.Counter.Reversible.PrimeCompression

#check increment_firstReturn
#check decrement_firstReturn
#print axioms increment_firstReturn
#print axioms decrement_firstReturn
