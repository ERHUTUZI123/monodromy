Native reversible reconstruction, 2026-11-04.
The before/ sources are the separately verified mathematical-note snapshot.
Released proof drafts record static port routing, the eleven-stage native compiler,
explicit inverse tables, invariant-relative semantics, multiplication on natural
inputs, and static edge reversal. They were integrated into the existing
Continuation and Counter modules; no new persistent coordinate or native gate.
Some draft imports use temporary module names and serve only as historical evidence.
The active source distribution and its locked dependencies are in Monodromy.zip.
The final recorded full build passed 3071 Lake jobs; the audit checked 1945
Monodromy declarations and excluded proof-side interpreters from native definitions.
Universal compilation from arbitrary Turing machines through a reversible source
encoding is still open at this snapshot.
verified/ contains the complete locked source project for this 1945-declaration snapshot.
