import «Monodromy-reversible-source»
import Monodromy.Continuation
import Mathlib.Logic.Equiv.Fin.Basic

/-! Finite source vertices and edge ports are paired before any native execution. -/
namespace Monodromy.ReversiblePorts

variable {q e : ℕ}

/-- This finite lookup depends only on the static table and a finite vertex. -/
def mate (owner : Fin e → Fin q) (active : Fin e → Bool) (vertex : Fin q) : Option (Fin e) :=
  if found : ∃ edge, active edge = true ∧ owner edge = vertex then
    some (Fin.find (fun edge => active edge = true ∧ owner edge = vertex) found)
  else none

def Matching (owner : Fin e → Fin q) (active : Fin e → Bool) : Prop :=
  ∀ first second, active first = true → active second = true →
    owner first = owner second → first = second

theorem mate_some (owner : Fin e → Fin q) (active : Fin e → Bool)
    (matching : Matching owner active) (vertex : Fin q) (edge : Fin e) :
    mate owner active vertex = some edge ↔ active edge = true ∧ owner edge = vertex := by
  unfold mate
  split_ifs with found
  · constructor
    · intro same
      have chosen := Fin.find_spec found
      have equal_index := Option.some.inj same
      simpa only [equal_index] using chosen
    · intro selected
      apply congrArg some
      have chosen := Fin.find_spec found
      exact matching _ _ chosen.1 selected.1 (chosen.2.trans selected.2.symm)
  · constructor
    · simp
    · intro selected
      exact (found ⟨edge, selected⟩).elim

def exchange (owner : Fin e → Fin q) (active : Fin e → Bool) : Fin q ⊕ Fin e → Fin q ⊕ Fin e
  | .inl vertex => (mate owner active vertex).elim (.inl vertex) Sum.inr
  | .inr edge => if active edge then .inl (owner edge) else .inr edge

theorem exchange_involutive (owner : Fin e → Fin q) (active : Fin e → Bool)
    (matching : Matching owner active) : Function.Involutive (exchange owner active) := by
  intro port
  cases port with
  | inl vertex =>
      cases chosen : mate owner active vertex with
      | none => simp [exchange, chosen]
      | some edge =>
          obtain ⟨enabled, endpoint⟩ := (mate_some owner active matching vertex edge).mp chosen
          simp [exchange, chosen, enabled, endpoint]
  | inr edge =>
      cases selected : active edge with
      | false => simp [exchange, selected]
      | true =>
          have chosen := (mate_some owner active matching (owner edge) edge).mpr ⟨selected, rfl⟩
          simp [exchange, selected, chosen]

def pairing (owner : Fin e → Fin q) (active : Fin e → Bool)
    (matching : Matching owner active) : Equiv.Perm (Fin q ⊕ Fin e) where
  toFun := exchange owner active
  invFun := exchange owner active
  left_inv := exchange_involutive owner active matching
  right_inv := exchange_involutive owner active matching

def permutation (owner : Fin e → Fin q) (active : Fin e → Bool)
    (matching : Matching owner active) : Equiv.Perm (Fin (q + e)) :=
  finSumFinEquiv.symm.trans ((pairing owner active matching).trans finSumFinEquiv)

theorem permutation_apply (owner : Fin e → Fin q) (active : Fin e → Bool)
    (matching : Matching owner active) (port : Fin (q + e)) :
    permutation owner active matching port =
      finSumFinEquiv (exchange owner active (finSumFinEquiv.symm port)) := rfl

theorem permutation_involutive (owner : Fin e → Fin q) (active : Fin e → Bool)
    (matching : Matching owner active) : Function.Involutive (permutation owner active matching) := by
  intro port
  simp only [permutation_apply, Equiv.symm_apply_apply]
  rw [exchange_involutive owner active matching (finSumFinEquiv.symm port)]
  exact finSumFinEquiv.apply_symm_apply port

theorem permutation_owner (owner : Fin e → Fin q) (active : Fin e → Bool)
    (matching : Matching owner active) (edge : Fin e) (selected : active edge = true) :
    permutation owner active matching (Fin.castAdd e (owner edge)) = Fin.natAdd q edge := by
  have chosen := (mate_some owner active matching (owner edge) edge).mpr ⟨selected, rfl⟩
  simp [permutation_apply, exchange, chosen]

theorem permutation_port (owner : Fin e → Fin q) (active : Fin e → Bool)
    (matching : Matching owner active) (edge : Fin e) :
    permutation owner active matching (Fin.natAdd q edge) =
      if active edge then Fin.castAdd e (owner edge) else Fin.natAdd q edge := by
  cases selected : active edge <;> simp [permutation_apply, exchange, selected]

theorem permutation_fixed_owner (owner : Fin e → Fin q) (active : Fin e → Bool)
    (matching : Matching owner active) (vertex : Fin q)
    (missing : ∀ edge, active edge = true → owner edge ≠ vertex) :
    permutation owner active matching (Fin.castAdd e vertex) = Fin.castAdd e vertex := by
  have absent : ¬ ∃ edge, active edge = true ∧ owner edge = vertex := by
    rintro ⟨edge, selected, endpoint⟩
    exact missing edge selected endpoint
  simp [permutation_apply, exchange, mate, absent]

/-- Every owner outcome is a fixed vertex or its unique active edge port. -/
theorem permutation_vertex (owner : Fin e → Fin q) (active : Fin e → Bool)
    (matching : Matching owner active) (vertex : Fin q) :
    permutation owner active matching (Fin.castAdd e vertex) =
      (mate owner active vertex).elim (Fin.castAdd e vertex) (Fin.natAdd q) := by
  cases chosen : mate owner active vertex <;> simp [permutation_apply, exchange, chosen]

open Counter.Reversible

/-- The guard class depends only on a static source instruction. -/
def actionGuard : Action 2 → ReversibleControl.Guard
  | .shift _ _ => none
  | .test register atZero => some (register, atZero)

theorem compatible_guards_ne {first second : Action 2}
    (compatible : first.Compatible second) : actionGuard first ≠ actionGuard second := by
  cases first <;> cases second <;> simp only [Action.Compatible] at compatible
  rcases compatible with ⟨rfl, different⟩
  simpa only [actionGuard, ne_eq, Option.some.injEq, Prod.mk.injEq, true_and] using different

/-- Numerical guard evaluation is used only in the proof interpretation. -/
theorem guard_enabled_iff (action : Action 2) (values : Fin 2 → ℤ) :
    ReversibleControl.enabled (actionGuard action) (values 0) (values 1) = true ↔
      action.enabled values := by
  cases action with
  | shift => simp [actionGuard, ReversibleControl.enabled, Action.enabled]
  | test register atZero =>
      fin_cases register <;> cases atZero <;>
        simp [actionGuard, ReversibleControl.enabled, Action.enabled] <;>
          exact decide_eq_true_iff

/-- Static selection of one of the five possible guard classes. -/
def selected (table : Table 2 q e) (guard : ReversibleControl.Guard) (edge : Fin e) : Bool :=
  decide (actionGuard (table edge).action = guard)

@[simp] theorem selected_iff (table : Table 2 q e) (guard : ReversibleControl.Guard)
    (edge : Fin e) : selected table guard edge = true ↔ actionGuard (table edge).action = guard := by
  simp [selected]

theorem sourceMatching (table : Table 2 q e) (deterministic : Deterministic table)
    (guard : ReversibleControl.Guard) :
    Matching (fun edge => (table edge).source) (selected table guard) := by
  intro first second fs ss same_source
  by_contra different
  exact compatible_guards_ne (deterministic first second different same_source)
    (((selected_iff table guard first).mp fs).trans ((selected_iff table guard second).mp ss).symm)

theorem targetMatching (table : Table 2 q e) (compatible : TargetCompatible table)
    (guard : ReversibleControl.Guard) :
    Matching (fun edge => (table edge).target) (selected table guard) := by
  intro first second fs ss same_target
  by_contra different
  exact compatible_guards_ne (compatible first second different same_target)
    (((selected_iff table guard first).mp fs).trans ((selected_iff table guard second).mp ss).symm)

def sourcePermutation (table : Table 2 q e) (deterministic : Deterministic table)
    (guard : ReversibleControl.Guard) : Equiv.Perm (Fin (q + e)) :=
  permutation (fun edge => (table edge).source) (selected table guard)
    (sourceMatching table deterministic guard)

def targetPermutation (table : Table 2 q e) (compatible : TargetCompatible table)
    (guard : ReversibleControl.Guard) : Equiv.Perm (Fin (q + e)) :=
  permutation (fun edge => (table edge).target) (selected table guard)
    (targetMatching table compatible guard)

theorem sourcePermutation_involutive (table : Table 2 q e) (deterministic : Deterministic table)
    (guard : ReversibleControl.Guard) : Function.Involutive (sourcePermutation table deterministic guard) :=
  permutation_involutive _ _ _

theorem targetPermutation_involutive (table : Table 2 q e) (compatible : TargetCompatible table)
    (guard : ReversibleControl.Guard) : Function.Involutive (targetPermutation table compatible guard) :=
  permutation_involutive _ _ _

theorem sourcePermutation_owner (table : Table 2 q e) (deterministic : Deterministic table)
    (guard : ReversibleControl.Guard) (edge : Fin e) (chosen : actionGuard (table edge).action = guard) :
    sourcePermutation table deterministic guard (Fin.castAdd e (table edge).source) = Fin.natAdd q edge :=
  permutation_owner _ _ _ edge ((selected_iff table guard edge).mpr chosen)

theorem targetPermutation_owner (table : Table 2 q e) (compatible : TargetCompatible table)
    (guard : ReversibleControl.Guard) (edge : Fin e) (chosen : actionGuard (table edge).action = guard) :
    targetPermutation table compatible guard (Fin.castAdd e (table edge).target) = Fin.natAdd q edge :=
  permutation_owner _ _ _ edge ((selected_iff table guard edge).mpr chosen)

theorem sourcePermutation_port (table : Table 2 q e) (deterministic : Deterministic table)
    (guard : ReversibleControl.Guard) (edge : Fin e) :
    sourcePermutation table deterministic guard (Fin.natAdd q edge) =
      if selected table guard edge then Fin.castAdd e (table edge).source else Fin.natAdd q edge :=
  permutation_port _ _ _ edge

theorem targetPermutation_port (table : Table 2 q e) (compatible : TargetCompatible table)
    (guard : ReversibleControl.Guard) (edge : Fin e) :
    targetPermutation table compatible guard (Fin.natAdd q edge) =
      if selected table guard edge then Fin.castAdd e (table edge).target else Fin.natAdd q edge :=
  permutation_port _ _ _ edge

theorem sourcePermutation_fixed_owner (table : Table 2 q e) (deterministic : Deterministic table)
    (guard : ReversibleControl.Guard) (vertex : Fin q)
    (missing : ∀ edge, actionGuard (table edge).action = guard → (table edge).source ≠ vertex) :
    sourcePermutation table deterministic guard (Fin.castAdd e vertex) = Fin.castAdd e vertex := by
  apply permutation_fixed_owner
  intro edge chosen
  exact missing edge ((selected_iff table guard edge).mp chosen)

theorem targetPermutation_fixed_owner (table : Table 2 q e) (compatible : TargetCompatible table)
    (guard : ReversibleControl.Guard) (vertex : Fin q)
    (missing : ∀ edge, actionGuard (table edge).action = guard → (table edge).target ≠ vertex) :
    targetPermutation table compatible guard (Fin.castAdd e vertex) = Fin.castAdd e vertex := by
  apply permutation_fixed_owner
  intro edge chosen
  exact missing edge ((selected_iff table guard edge).mp chosen)

/-- These are all guard classes; the list is independent of the compiled table. -/
def guards : List ReversibleControl.Guard :=
  [none, some (0, true), some (0, false), some (1, true), some (1, false)]

theorem guards_distinct : guards.Nodup := by decide

theorem guards_exhaustive (guard : ReversibleControl.Guard) : guard ∈ guards := by
  cases guard with
  | none => simp [guards]
  | some entry =>
      rcases entry with ⟨register, atZero⟩
      fin_cases register <;> cases atZero <;> simp [guards]

end Monodromy.ReversiblePorts

#print axioms Monodromy.ReversiblePorts.sourceMatching
#print axioms Monodromy.ReversiblePorts.targetMatching
#print axioms Monodromy.ReversiblePorts.permutation_involutive
#print axioms Monodromy.ReversiblePorts.guard_enabled_iff
#print axioms Monodromy.ReversiblePorts.sourcePermutation_owner
#print axioms Monodromy.ReversiblePorts.guards_exhaustive
