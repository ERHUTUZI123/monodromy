import Monodromy.Continuation

/-! Static finite words for reversible guarded control; no native instruction is added. -/
noncomputable section

namespace Monodromy.ReversibleGuards

open CoupledContinuation

/-- None is unconditional; the Boolean requests a zero or nonzero test of one memory. -/
abbrev Guard := Option (Fin 2 × Bool)

/-- A proof interpretation of the guard; the word compiler never receives these labels. -/
def enabled (guard : Guard) (left right : ℤ) : Bool :=
  match guard with
  | none => true
  | some (register, testZero) =>
      if testZero then decide (![left, right] register = 0)
      else decide (![left, right] register ≠ 0)

def zeroGate (register : Fin 2) : Gate := if register = 0 then .zeroLeft else .zeroRight

/-- Signed repetitions of one of the two existing conditional loops. -/
def zeroWord (register : Fin 2) : ℤ → Word
  | .ofNat count => List.replicate count (zeroGate register, false)
  | .negSucc count => List.replicate (count + 1) (zeroGate register, true)

private theorem execute_zeroGate (register : Fin 2) (left right control : ℤ) :
    execute (zeroGate register).driver (prepare left right control) =
      prepare left right (control + if ![left, right] register = 0 then 1 else 0) := by
  refine Fin.cases ?_ (fun tail => ?_) register
  · exact execute_B_left left right control
  · have only : tail = 0 := Fin.eq_zero tail
    subst tail
    exact execute_B_right left right control

private theorem execute_zeroGate_reverse (register : Fin 2) (left right control : ℤ) :
    execute (zeroGate register).driver.reverse (prepare left right control) =
      prepare left right (control - if ![left, right] register = 0 then 1 else 0) := by
  have inverse := execute_driver_reverse (zeroGate register).driver
    (prepare left right (control - if ![left, right] register = 0 then 1 else 0))
  rw [execute_zeroGate] at inverse
  simpa only [sub_add_cancel] using inverse

private theorem repeat_forward (register : Fin 2) (count : ℕ) (left right control : ℤ) :
    execute (Word.driver (List.replicate count (zeroGate register, false))) (prepare left right control) =
      prepare left right (control + if ![left, right] register = 0 then (count : ℤ) else 0) := by
  induction count generalizing control with
  | zero => simp only [List.replicate_zero, execute_word_nil, Nat.cast_zero, ite_self, add_zero]
  | succ count induction_hypothesis =>
      rw [List.replicate_succ, execute_word_cons]
      change execute (Word.driver (List.replicate count (zeroGate register, false)))
        (execute (zeroGate register).driver (prepare left right control)) = _
      rw [execute_zeroGate, induction_hypothesis]
      congr 1
      split_ifs <;> push_cast <;> omega

private theorem repeat_backward (register : Fin 2) (count : ℕ) (left right control : ℤ) :
    execute (Word.driver (List.replicate count (zeroGate register, true))) (prepare left right control) =
      prepare left right (control - if ![left, right] register = 0 then (count : ℤ) else 0) := by
  induction count generalizing control with
  | zero => simp only [List.replicate_zero, execute_word_nil, Nat.cast_zero, ite_self, sub_zero]
  | succ count induction_hypothesis =>
      rw [List.replicate_succ, execute_word_cons]
      change execute (Word.driver (List.replicate count (zeroGate register, true)))
        (execute (zeroGate register).driver.reverse (prepare left right control)) = _
      rw [execute_zeroGate_reverse, induction_hypothesis]
      congr 1
      split_ifs <;> push_cast <;> omega

theorem execute_zeroWord (register : Fin 2) (amount left right control : ℤ) :
    execute (Word.driver (zeroWord register amount)) (prepare left right control) =
      prepare left right (control + if ![left, right] register = 0 then amount else 0) := by
  cases amount with
  | ofNat count => exact repeat_forward register count left right control
  | negSucc count =>
      rw [zeroWord, repeat_backward]
      congr 1
      split_ifs <;> omega

/-- All checks are actual B lifts: a nonzero guard cancels an unconditional shift only at zero. -/
def guardWord (guard : Guard) (amount : ℤ) : Word :=
  match guard with
  | none => Word.control amount
  | some (register, true) => zeroWord register amount
  | some (register, false) => Word.control amount ++ zeroWord register (-amount)

theorem execute_guardWord (guard : Guard) (amount left right control : ℤ) :
    execute (Word.driver (guardWord guard amount)) (prepare left right control) =
      prepare left right (control + if enabled guard left right then amount else 0) := by
  cases guard with
  | none => simpa [guardWord, enabled] using execute_control_word amount left right control
  | some pair =>
      rcases pair with ⟨register, testZero⟩
      cases testZero with
      | false =>
          rw [guardWord, execute_word_append, execute_control_word, execute_zeroWord]
          by_cases zero : ![left, right] register = 0 <;> simp [enabled, zero]
      | true => simpa [guardWord, enabled] using execute_zeroWord register amount left right control

theorem zeroWord_length (register : Fin 2) (amount : ℤ) :
    (zeroWord register amount).length = amount.natAbs := by
  cases amount <;> simp [zeroWord]

/-- Costs count existing signed primitive loops in the compiled finite word. -/
theorem guardWord_length (guard : Guard) (amount : ℤ) :
    (guardWord guard amount).length =
      match guard with | some (_, false) => 2 * amount.natAbs | _ => amount.natAbs := by
  cases guard with
  | none => exact control_word_length amount
  | some pair =>
      rcases pair with ⟨register, testZero⟩
      cases testZero <;> simp [guardWord, zeroWord_length, control_word_length, two_mul]

variable {degree : ℕ} [NeZero degree]

def table (guard : Guard) (permutation : Equiv.Perm (Fin degree)) (index : Fin degree) : Word :=
  guardWord guard ((permutation index).val - (index.val : ℤ))

/-- The Guard is only compiler data; the native Program still has exactly table and stop. -/
def program (guard : Guard) (permutation : Equiv.Perm (Fin degree)) : Program degree :=
  ⟨table guard permutation, fun _ => false⟩

theorem step_eq_some (guard : Guard) (permutation : Equiv.Perm (Fin degree)) (state : Memory) :
    (program guard permutation).step state = some ((program guard permutation).advance state) := by
  simp [Program.step, Program.haltSignal, program, Choice.dispatch]

/-- The whole control quotient is retained, whichever actual memory condition enables the permutation. -/
theorem advance_prepare (guard : Guard) (permutation : Equiv.Perm (Fin degree))
    (left right quotient : ℤ) (index : Fin degree) :
    (program guard permutation).advance (prepare left right ((degree : ℤ) * quotient + index.val)) =
      if enabled guard left right then
        prepare left right ((degree : ℤ) * quotient + (permutation index).val)
      else prepare left right ((degree : ℤ) * quotient + index.val) := by
  rw [Program.advance_prepare]
  change execute (Word.driver (guardWord guard ((permutation index).val - (index.val : ℤ))))
    (prepare left right ((degree : ℤ) * quotient + index.val)) = _
  rw [execute_guardWord]
  by_cases active : enabled guard left right = true
  · rw [ite_eq_left active, ite_eq_left active]
    congr 1
    omega
  · simp only [ite_eq_right active, add_zero]

theorem inverse_prepare (guard : Guard) (permutation : Equiv.Perm (Fin degree))
    (left right quotient : ℤ) (index : Fin degree) :
    (program guard permutation.symm).advance
      ((program guard permutation).advance (prepare left right ((degree : ℤ) * quotient + index.val))) =
        prepare left right ((degree : ℤ) * quotient + index.val) := by
  rw [advance_prepare]
  by_cases active : enabled guard left right = true
  · rw [ite_eq_left active, advance_prepare, ite_eq_left active, permutation.symm_apply_apply]
  · rw [ite_eq_right active, advance_prepare, ite_eq_right active]

private theorem prepared_residue_induction {property : Memory → Prop}
    (holds : ∀ left right quotient (index : Fin degree),
      property (prepare left right ((degree : ℤ) * quotient + index.val))) (state : Memory) :
    property state := by
  obtain ⟨⟨⟨left, right⟩, control⟩, rfl⟩ := prepare_surjective state
  let index : Fin degree := ⟨(control % (degree : ℤ)).toNat, by
    apply (Int.toNat_lt_of_ne_zero (NeZero.ne degree)).mpr
    exact Int.emod_lt_of_pos _ (by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne degree))⟩
  have remainder : (index.val : ℤ) = control % (degree : ℤ) :=
    Int.toNat_of_nonneg (Int.emod_nonneg _ (by exact_mod_cast NeZero.ne degree))
  have decomposition : (degree : ℤ) * (control / (degree : ℤ)) + index.val = control := by
    rw [remainder]
    exact Int.mul_ediv_add_emod _ _
  have result := holds left right (control / (degree : ℤ)) index
  rwa [decomposition] at result

/-- The returned roots alone select a finite inverse table for the same guard. -/
theorem inverse (guard : Guard) (permutation : Equiv.Perm (Fin degree)) (state : Memory) :
    (program guard permutation.symm).advance ((program guard permutation).advance state) = state :=
  prepared_residue_induction (degree := degree)
    (property := fun point =>
      (program guard permutation.symm).advance ((program guard permutation).advance point) = point)
    (inverse_prepare guard permutation) state

theorem compose_prepare (guard : Guard) (first second : Equiv.Perm (Fin degree))
    (left right quotient : ℤ) (index : Fin degree) :
    (program guard second).advance
      ((program guard first).advance (prepare left right ((degree : ℤ) * quotient + index.val))) =
    (program guard (first.trans second)).advance
      (prepare left right ((degree : ℤ) * quotient + index.val)) := by
  rw [advance_prepare]
  by_cases active : enabled guard left right = true
  · rw [ite_eq_left active, advance_prepare, ite_eq_left active, advance_prepare, ite_eq_left active]
    rfl
  · rw [ite_eq_right active, advance_prepare, ite_eq_right active, advance_prepare, ite_eq_right active]

theorem compose (guard : Guard) (first second : Equiv.Perm (Fin degree)) (state : Memory) :
    (program guard second).advance ((program guard first).advance state) =
      (program guard (first.trans second)).advance state :=
  prepared_residue_induction (degree := degree)
    (property := fun point => (program guard second).advance ((program guard first).advance point) =
      (program guard (first.trans second)).advance point)
    (compose_prepare guard first second) state

theorem identity (guard : Guard) (state : Memory) :
    (program guard (Equiv.refl (Fin degree))).advance state = state := by
  apply prepared_residue_induction (degree := degree)
    (property := fun point => (program guard (Equiv.refl (Fin degree))).advance point = point)
    (state := state)
  intro left right quotient index
  rw [advance_prepare]
  split_ifs <;> rfl

def executionEquiv (guard : Guard) (permutation : Equiv.Perm (Fin degree)) : Memory ≃ Memory where
  toFun := (program guard permutation).advance
  invFun := (program guard permutation.symm).advance
  left_inv := inverse guard permutation
  right_inv := by
    intro state
    simpa only [Equiv.symm_symm] using inverse guard permutation.symm state

/-- Compatibility wrapper for the original left-zero two-PC exchange. -/
def swap : Program 2 := program (some (0, true)) (Equiv.swap (0 : Fin 2) 1)

theorem swap_involutive : Function.Involutive swap.advance := by
  intro state
  have symmetry : (Equiv.swap (0 : Fin 2) 1).symm = Equiv.swap (0 : Fin 2) 1 := Equiv.symm_swap _ _
  simpa only [swap, symmetry] using inverse (some (0, true)) (Equiv.swap (0 : Fin 2) 1) state

end Monodromy.ReversibleGuards
