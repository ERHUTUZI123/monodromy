module

public import Monodromy.Effectiveness
public import Mathlib.Logic.Equiv.Fin.Basic
public import Mathlib.Logic.Equiv.Fin.Rotate

@[expose] public section

noncomputable section

namespace Monodromy.StagedProgram

open CoupledContinuation
open Fin.NatCast

/-- Scaling changes only the upper branch displacement, never the two memory coordinates. -/
def pack (factor : ℕ) (phase : ℤ) (labels : Labels) : Labels :=
  (labels.1, (factor : ℤ) * labels.2 + phase)

def scaleAtom (factor : ℕ) (atom : Gate × Bool) : Word :=
  match atom.1 with
  | .left | .right => [atom]
  | _ => List.replicate factor atom

def scaleWord (factor : ℕ) : Word → Word
  | [] => []
  | atom :: rest => scaleAtom factor atom ++ scaleWord factor rest

private theorem eval_append (first second : Word) (labels : Labels) :
    Word.evalInt (first ++ second) labels =
      Word.evalInt second (Word.evalInt first labels) := by
  induction first generalizing labels with
  | nil => rfl
  | cons atom rest recursive => simpa only [List.cons_append, Word.evalInt] using recursive _

private theorem repeat_shear (atom : Gate × Bool) (memory : ℤ × ℤ) (amount : ℤ)
    (action : ∀ control, Gate.evalInt atom.1 atom.2 (memory, control) = (memory, control + amount))
    (count : ℕ) (control : ℤ) :
    Word.evalInt (List.replicate count atom) (memory, control) =
      (memory, control + (count : ℤ) * amount) := by
  induction count generalizing control with
  | zero => simp [Word.evalInt]
  | succ count recursive =>
      rw [List.replicate_succ, Word.evalInt, action, recursive]
      congr 1
      push_cast
      ring

theorem scaleAtom_eval (factor : ℕ) (phase : ℤ) (atom : Gate × Bool) (labels : Labels) :
    Word.evalInt (scaleAtom factor atom) (pack factor phase labels) =
      pack factor phase (Gate.evalInt atom.1 atom.2 labels) := by
  rcases atom with ⟨gate, backward⟩
  rcases labels with ⟨⟨left, right⟩, control⟩
  cases gate with
  | left => simp [scaleAtom, Word.evalInt, Gate.evalInt, pack]
  | right => simp [scaleAtom, Word.evalInt, Gate.evalInt, pack]
  | zeroLeft =>
      have repeated := repeat_shear (.zeroLeft, backward) (left, right)
        (if left = 0 then (if backward then -1 else 1) else 0) (fun _ => rfl)
        factor ((factor : ℤ) * control + phase)
      change Word.evalInt (List.replicate factor (.zeroLeft, backward)) _ = _
      dsimp only [pack]
      rw [repeated]
      simp only [Gate.evalInt]
      congr 1
      ring
  | zeroRight =>
      have repeated := repeat_shear (.zeroRight, backward) (left, right)
        (if right = 0 then (if backward then -1 else 1) else 0) (fun _ => rfl)
        factor ((factor : ℤ) * control + phase)
      change Word.evalInt (List.replicate factor (.zeroRight, backward)) _ = _
      dsimp only [pack]
      rw [repeated]
      simp only [Gate.evalInt]
      congr 1
      ring
  | control =>
      have repeated := repeat_shear (.control, backward) (left, right)
        (if backward then -1 else 1) (fun _ => rfl)
        factor ((factor : ℤ) * control + phase)
      change Word.evalInt (List.replicate factor (.control, backward)) _ = _
      dsimp only [pack]
      rw [repeated]
      simp only [Gate.evalInt]
      congr 1
      ring

theorem scaleWord_eval (factor : ℕ) (phase : ℤ) (word : Word) (labels : Labels) :
    Word.evalInt (scaleWord factor word) (pack factor phase labels) =
      pack factor phase (Word.evalInt word labels) := by
  induction word generalizing labels with
  | nil => rfl
  | cons atom rest recursive =>
      rw [scaleWord, eval_append, scaleAtom_eval, recursive]
      rfl

theorem execute_scaleWord (factor : ℕ) (phase : ℤ) (word : Word) (labels : Labels) :
    execute (Word.driver (scaleWord factor word)) (Labels.prepare (pack factor phase labels)) =
      Labels.prepare (pack factor phase (Word.evalInt word labels)) := by
  rw [Word.execute_evalInt, scaleWord_eval]

def labelsEquiv : Labels ≃ Memory :=
  Equiv.ofBijective Labels.prepare ⟨prepare_injective, prepare_surjective⟩

variable (count degree : ℕ) [NeZero count] [NeZero degree]

/-- The finite stage is packed in the same upper integer branch. -/
def packing : Labels × Fin count ≃ Labels :=
  Equiv.ofBijective (fun pair => pack count pair.2.val pair.1) (by
    constructor
    · rintro ⟨first, phase⟩ ⟨second, other⟩ same
      have memories := congrArg (fun labels : Labels => labels.1) same
      change first.1 = second.1 at memories
      have controls : (count : ℤ) * first.2 + phase.val =
          (count : ℤ) * second.2 + other.val := congrArg (fun labels : Labels => labels.2) same
      have phase_mod (stage : Fin count) (control : ℤ) :
          ((count : ℤ) * control + stage.val) % (count : ℤ) = stage.val := by
        rw [add_comm, Int.add_mul_emod_self_left,
          Int.emod_eq_of_lt (by omega) (by exact_mod_cast stage.isLt)]
      have phases := congrArg (fun value : ℤ => value % (count : ℤ)) controls
      rw [phase_mod, phase_mod] at phases
      have phase_eq : phase = other := Fin.ext (by exact_mod_cast phases)
      subst other
      have counters : first.2 = second.2 := by
        apply (mul_right_injective₀ (by exact_mod_cast NeZero.ne count : (count : ℤ) ≠ 0))
        exact (add_right_cancel controls)
      exact Prod.ext (Prod.ext memories counters) rfl
    · intro labels
      refine ⟨((labels.1, labels.2 / (count : ℤ)), Program.indexInt count labels), ?_⟩
      exact Prod.ext rfl (Program.control_decomposition labels))

def packedEquiv : Memory × Fin count ≃ Memory :=
  (Equiv.prodCongr labelsEquiv.symm (Equiv.refl _)).trans
    ((packing count).trans labelsEquiv)

def embed (phase : Fin count) (state : Memory) : Memory := packedEquiv count (state, phase)

@[simp] theorem embed_prepare (phase : Fin count) (labels : Labels) :
    embed count phase (Labels.prepare labels) = Labels.prepare (pack count phase.val labels) := by
  change labelsEquiv (pack count phase.val (labelsEquiv.symm (labelsEquiv labels))) = _
  rw [labelsEquiv.symm_apply_apply]
  rfl

def address : Fin degree × Fin count ≃ Fin (count * degree) :=
  finProdFinEquiv.trans (finCongr (Nat.mul_comm degree count))

omit [NeZero count] [NeZero degree] in
theorem address_val (index : Fin degree) (phase : Fin count) :
    ((address count degree (index, phase)).val : ℤ) =
      (count : ℤ) * index.val + phase.val := by
  simp [address, finProdFinEquiv]
  ring

def clock (phase : Fin count) : ℤ :=
  ((finRotate count phase).val : ℤ) - phase.val

/-- The table consists solely of the existing words followed by a finite clock word. -/
def compile (stages : Fin count → Program degree) : Program (count * degree) where
  table index :=
    let pair := (address count degree).symm index
    scaleWord count ((stages pair.2).table pair.1) ++ Word.control (clock count pair.2)
  stop _ := false

omit [NeZero count] [NeZero degree] in
theorem compile_table (stages : Fin count → Program degree)
    (index : Fin degree) (phase : Fin count) :
    (compile count degree stages).table (address count degree (index, phase)) =
      scaleWord count ((stages phase).table index) ++ Word.control (clock count phase) := by
  simp [compile]

omit [NeZero count] in
theorem execute_stageWord (phase : Fin count) (word : Word) (labels : Labels) :
    execute (Word.driver (scaleWord count word ++ Word.control (clock count phase)))
      (Labels.prepare (pack count phase.val labels)) =
      Labels.prepare (pack count (finRotate count phase).val (Word.evalInt word labels)) := by
  rw [execute_word_append, execute_scaleWord]
  change execute (Word.driver (Word.control (clock count phase)))
    (prepare _ _ _) = prepare _ _ _
  rw [execute_control_word]
  congr 1
  simp [pack, clock]

theorem advance_prepare (stages : Fin count → Program degree)
    (left right quotient : ℤ) (index : Fin degree) (phase : Fin count) :
    (compile count degree stages).advance
      (prepare left right ((count : ℤ) * ((degree : ℤ) * quotient + index.val) + phase.val)) =
      Labels.prepare (pack count (finRotate count phase).val
        (Word.evalInt ((stages phase).table index)
          ((left, right), (degree : ℤ) * quotient + index.val))) := by
  have actual := (compile count degree stages).advance_prepare left right quotient
    (address count degree (index, phase))
  rw [compile_table] at actual
  have control :
      ((count * degree : ℕ) : ℤ) * quotient + (address count degree (index, phase)).val =
        (count : ℤ) * ((degree : ℤ) * quotient + index.val) + phase.val := by
    rw [address_val]
    push_cast
    ring
  rw [control] at actual
  apply actual.trans
  exact execute_stageWord count phase ((stages phase).table index)
    ((left, right), (degree : ℤ) * quotient + index.val)

theorem advance_embed (stages : Fin count → Program degree)
    (phase : Fin count) (state : Memory) :
    (compile count degree stages).advance (embed count phase state) =
      embed count (finRotate count phase) ((stages phase).advance state) := by
  obtain ⟨labels, rfl⟩ := labelsEquiv.surjective state
  change (compile count degree stages).advance (embed count phase (Labels.prepare labels)) =
    embed count (finRotate count phase) ((stages phase).advance (Labels.prepare labels))
  rw [embed_prepare, (stages phase).advance_prepareInt, embed_prepare]
  have actual := advance_prepare count degree stages labels.1.1 labels.1.2
    (labels.2 / (degree : ℤ)) (Program.indexInt degree labels) phase
  rw [Program.control_decomposition] at actual
  exact actual

theorem step_eq_some (stages : Fin count → Program degree) (state : Memory) :
    (compile count degree stages).step state = some ((compile count degree stages).advance state) := by
  simp [Program.step, Program.haltSignal, compile, Choice.dispatch]


/-- A complete cycle is the ordinary composition of the supplied stage advances. -/
theorem iterate_embed (stages : Fin count → Program degree) (steps : ℕ)
    (phase : Fin count) (state : Memory) :
    ((compile count degree stages).advance)^[steps] (embed count phase state) =
      embed count ((finRotate count)^[steps] phase)
        ((List.range steps).foldl
          (fun point position => (stages ((finRotate count)^[position] phase)).advance point) state) := by
  induction steps with
  | zero => rfl
  | succ steps recursive =>
      rw [Function.iterate_succ_apply', recursive, advance_embed]
      simp only [List.range_succ, List.foldl_append, List.foldl_cons, List.foldl_nil,
        Function.iterate_succ_apply']

theorem rotate_iterate (steps : ℕ) (phase : Fin count) :
    (finRotate count)^[steps] phase = phase + (steps : Fin count) := by
  induction steps with
  | zero => simp
  | succ steps recursive =>
      rw [Function.iterate_succ_apply', recursive, finRotate_apply]
      simp only [Nat.cast_add, Nat.cast_one, add_assoc]

theorem cycle (stages : Fin count → Program degree) (state : Memory) :
    ((compile count degree stages).advance)^[count] (embed count 0 state) =
      embed count 0 ((List.range count).foldl
        (fun (point : Memory) (position : ℕ) => (stages (position : Fin count)).advance point) state) := by
  have complete : ((count : ℕ) : Fin count) = 0 := by
    apply Fin.ext
    simp
  simpa only [rotate_iterate, zero_add, complete] using
    iterate_embed count degree stages count 0 state

theorem compile_bijective (stages : Fin count → Program degree)
    (reversible : ∀ phase, Function.Bijective (stages phase).advance) :
    Function.Bijective (compile count degree stages).advance := by
  let advance : Memory × Fin count → Memory × Fin count :=
    fun pair => ((stages pair.2).advance pair.1, finRotate count pair.2)
  have product_bijective : Function.Bijective advance := by
    constructor
    · rintro ⟨first, phase⟩ ⟨second, other⟩ same
      have phases : phase = other := (finRotate count).injective (congrArg Prod.snd same)
      subst other
      exact Prod.ext ((reversible phase).injective (congrArg Prod.fst same)) rfl
    · rintro ⟨state, phase⟩
      let previous := (finRotate count).symm phase
      obtain ⟨before, reached⟩ := (reversible previous).surjective state
      exact ⟨(before, previous), Prod.ext reached ((finRotate count).apply_symm_apply phase)⟩
  have conjugacy : (compile count degree stages).advance =
      (packedEquiv count) ∘ advance ∘ (packedEquiv count).symm := by
    funext state
    obtain ⟨⟨point, phase⟩, rfl⟩ := (packedEquiv count).surjective state
    simp only [Function.comp_apply, Equiv.symm_apply_apply]
    exact advance_embed count degree stages phase point
  rw [conjugacy]
  exact (packedEquiv count).bijective.comp
    (product_bijective.comp (packedEquiv count).symm.bijective)

/-- The backward clock changes stage while retaining the unpacked upper control. -/
def backClock (phase : Fin count) : ℤ :=
  (((finRotate count).symm phase).val : ℤ) - phase.val

/-- The inverse is another table of the same native words, selected from the returned roots. -/
def compileReverse (backward : Fin count → Program degree) : Program (count * degree) where
  table index :=
    let pair := (address count degree).symm index
    Word.control (backClock count pair.2) ++
      scaleWord count ((backward ((finRotate count).symm pair.2)).table pair.1)
  stop _ := false

omit [NeZero count] [NeZero degree] in
theorem compileReverse_table (backward : Fin count → Program degree)
    (index : Fin degree) (phase : Fin count) :
    (compileReverse count degree backward).table (address count degree (index, phase)) =
      Word.control (backClock count phase) ++
        scaleWord count ((backward ((finRotate count).symm phase)).table index) := by
  simp [compileReverse]

omit [NeZero count] in
theorem execute_reverseWord (phase : Fin count) (word : Word) (labels : Labels) :
    execute (Word.driver (Word.control (backClock count phase) ++ scaleWord count word))
      (Labels.prepare (pack count phase.val labels)) =
      Labels.prepare (pack count ((finRotate count).symm phase).val (Word.evalInt word labels)) := by
  rw [execute_word_append]
  change execute (Word.driver (scaleWord count word))
    (execute (Word.driver (Word.control (backClock count phase))) (prepare _ _ _)) = _
  rw [execute_control_word]
  dsimp only [pack]
  have clock_value : (count : ℤ) * labels.2 + phase.val + backClock count phase =
      (count : ℤ) * labels.2 + ((finRotate count).symm phase).val := by
    simp [backClock]
  rw [clock_value]
  exact execute_scaleWord count ((finRotate count).symm phase).val word labels

theorem reverse_advance_prepare (backward : Fin count → Program degree)
    (left right quotient : ℤ) (index : Fin degree) (phase : Fin count) :
    (compileReverse count degree backward).advance
      (prepare left right ((count : ℤ) * ((degree : ℤ) * quotient + index.val) + phase.val)) =
      Labels.prepare (pack count ((finRotate count).symm phase).val
        (Word.evalInt ((backward ((finRotate count).symm phase)).table index)
          ((left, right), (degree : ℤ) * quotient + index.val))) := by
  have actual := (compileReverse count degree backward).advance_prepare left right quotient
    (address count degree (index, phase))
  rw [compileReverse_table] at actual
  have control :
      ((count * degree : ℕ) : ℤ) * quotient + (address count degree (index, phase)).val =
        (count : ℤ) * ((degree : ℤ) * quotient + index.val) + phase.val := by
    rw [address_val]
    push_cast
    ring
  rw [control] at actual
  apply actual.trans
  exact execute_reverseWord count phase
    ((backward ((finRotate count).symm phase)).table index)
    ((left, right), (degree : ℤ) * quotient + index.val)

theorem reverse_advance_embed (backward : Fin count → Program degree)
    (phase : Fin count) (state : Memory) :
    (compileReverse count degree backward).advance (embed count phase state) =
      embed count ((finRotate count).symm phase)
        ((backward ((finRotate count).symm phase)).advance state) := by
  obtain ⟨labels, rfl⟩ := labelsEquiv.surjective state
  change (compileReverse count degree backward).advance (embed count phase (Labels.prepare labels)) =
    embed count ((finRotate count).symm phase)
      ((backward ((finRotate count).symm phase)).advance (Labels.prepare labels))
  rw [embed_prepare, (backward ((finRotate count).symm phase)).advance_prepareInt, embed_prepare]
  have actual := reverse_advance_prepare count degree backward labels.1.1 labels.1.2
    (labels.2 / (degree : ℤ)) (Program.indexInt degree labels) phase
  rw [Program.control_decomposition] at actual
  exact actual

theorem left_inverse (forward backward : Fin count → Program degree)
    (inverse : ∀ phase, Function.LeftInverse (backward phase).advance (forward phase).advance) :
    Function.LeftInverse (compileReverse count degree backward).advance
      (compile count degree forward).advance := by
  intro state
  obtain ⟨⟨point, phase⟩, rfl⟩ := (packedEquiv count).surjective state
  change (compileReverse count degree backward).advance
    ((compile count degree forward).advance (embed count phase point)) = embed count phase point
  rw [advance_embed, reverse_advance_embed, Equiv.symm_apply_apply, inverse]

theorem right_inverse (forward backward : Fin count → Program degree)
    (inverse : ∀ phase, Function.RightInverse (backward phase).advance (forward phase).advance) :
    Function.RightInverse (compileReverse count degree backward).advance
      (compile count degree forward).advance := by
  intro state
  obtain ⟨⟨point, phase⟩, rfl⟩ := (packedEquiv count).surjective state
  change (compile count degree forward).advance
    ((compileReverse count degree backward).advance (embed count phase point)) = embed count phase point
  rw [reverse_advance_embed, advance_embed, Equiv.apply_symm_apply, inverse]

def executionEquiv (forward backward : Fin count → Program degree)
    (left : ∀ phase, Function.LeftInverse (backward phase).advance (forward phase).advance)
    (right : ∀ phase, Function.RightInverse (backward phase).advance (forward phase).advance) :
    Memory ≃ Memory where
  toFun := (compile count degree forward).advance
  invFun := (compileReverse count degree backward).advance
  left_inv := left_inverse count degree forward backward left
  right_inv := right_inverse count degree forward backward right

theorem reverse_step_eq_some (backward : Fin count → Program degree) (state : Memory) :
    (compileReverse count degree backward).step state =
      some ((compileReverse count degree backward).advance state) := by
  simp [Program.step, Program.haltSignal, compileReverse, Choice.dispatch]
end Monodromy.StagedProgram
