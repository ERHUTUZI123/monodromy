import Monodromy.Counter

/-! Static reversal of reversible counter edges and their actual finite execution. -/

namespace Monodromy.Counter.Reversible

variable {n q e : ℕ}

def reverseAction : Action n → Action n
  | .shift register amount => .shift register (-amount)
  | .test register atZero => .test register atZero

@[simp] theorem reverseAction_involutive (action : Action n) :
    reverseAction (reverseAction action) = action := by
  cases action <;> simp [reverseAction]

@[simp] theorem reverseAction_enabled (action : Action n) (values : Fin n → ℤ) :
    (reverseAction action).enabled values ↔ action.enabled values := by
  cases action <;> rfl

@[simp] theorem reverseAction_apply (action : Action n) (values : Fin n → ℤ) :
    (reverseAction action).apply (action.apply values) = values := by
  cases action with
  | test => rfl
  | shift register amount =>
      funext index
      by_cases selected : index = register
      · subst index
        simp [reverseAction, Action.apply]
      · simp [reverseAction, Action.apply, Function.update_of_ne selected]

@[simp] theorem reverseAction_enabled_apply (action : Action n) (values : Fin n → ℤ) :
    (reverseAction action).enabled (action.apply values) ↔ action.enabled values := by
  cases action <;> rfl

@[simp] theorem reverseAction_compatible (first second : Action n) :
    Action.Compatible (reverseAction first) (reverseAction second) ↔
      Action.Compatible first second := by
  cases first <;> cases second <;> rfl

def reverseEdge (edge : Edge n q) : Edge n q :=
  ⟨edge.target, edge.source, reverseAction edge.action⟩

@[simp] theorem reverseEdge_involutive (edge : Edge n q) :
    reverseEdge (reverseEdge edge) = edge := by
  cases edge
  simp [reverseEdge]

def reverseTable (table : Table n q e) : Table n q e :=
  fun index => reverseEdge (table index)

@[simp] theorem reverseTable_involutive (table : Table n q e) :
    reverseTable (reverseTable table) = table := by
  funext index
  exact reverseEdge_involutive _

theorem reverseTable_deterministic (table : Table n q e) (compatible : TargetCompatible table) :
    Deterministic (reverseTable table) := by
  intro first second different same
  exact (reverseAction_compatible _ _).mpr (compatible first second different same)

theorem reverseTable_targetCompatible (table : Table n q e) (deterministic : Deterministic table) :
    TargetCompatible (reverseTable table) := by
  intro first second different same
  exact (reverseAction_compatible _ _).mpr (deterministic first second different same)

/-- Reversing an enabled edge retraces precisely the same values and control addresses. -/
theorem StepRel.reverse {table : Table n q e} {first last : State n q}
    (transition : StepRel table first last) : StepRel (reverseTable table) last first := by
  obtain ⟨index, enabled, rfl⟩ := transition
  refine ⟨index, ⟨rfl, ?_⟩, ?_⟩
  · exact (reverseAction_enabled_apply _ _).mpr enabled.2
  · apply Prod.ext
    · exact enabled.1
    · exact reverseAction_apply _ _

theorem StepRel_reverse_iff (table : Table n q e) (first last : State n q) :
    StepRel table first last ↔ StepRel (reverseTable table) last first := by
  constructor
  · exact StepRel.reverse
  · intro transition
    simpa only [reverseTable_involutive] using transition.reverse

/-- The bounded finite edge search realizes graph reversal exactly. -/
theorem step_reverse_iff (table : Table n q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (first last : State n q) :
    step table first = some last ↔ step (reverseTable table) last = some first := by
  rw [step_iff table deterministic,
    step_iff (reverseTable table) (reverseTable_deterministic table compatible), StepRel_reverse_iff]

/-- Every actual finite execution is traversable in reverse by the reversed static table. -/
theorem reaches_reverse (table : Table n q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) {first last : State n q}
    (run : StateTransition.Reaches (step table) first last) :
    StateTransition.Reaches (step (reverseTable table)) last first := by
  apply Relation.ReflTransGen.mono (fun before after transition =>
    (step_reverse_iff table deterministic compatible after before).mp transition)
  exact Relation.ReflTransGen.swap last first run

namespace Multiply

theorem no_incoming_entry (factor : ℕ) (index : Fin 12) : (table factor index).target ≠ 0 := by
  fin_cases index <;> simp [table]

theorem reverse_halt_input (factor input : ℕ) :
    step (reverseTable (table factor)) (point 0 input 0) = none := by
  rw [step_none_iff]
  rintro ⟨index, enabled⟩
  exact no_incoming_entry factor index enabled.1

/-- Reversing the proven multiplication trace divides a known multiple, restoring empty workspace. -/
theorem reverse_eval_result (factor input : ℕ) (positive : 0 < factor) :
    eval (reverseTable (table factor)) (point 10 (factor * input : ℕ) 0) =
      Part.some (point 0 input 0) := by
  apply Part.eq_some_iff.mpr
  exact StateTransition.mem_eval.mpr
    ⟨reaches_reverse (table factor) (deterministic factor) (targetCompatible factor)
      (reaches_result factor input positive), reverse_halt_input factor input⟩

end Multiply

end Monodromy.Counter.Reversible
