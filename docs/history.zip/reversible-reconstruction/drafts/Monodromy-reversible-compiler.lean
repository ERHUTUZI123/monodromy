import «Monodromy-reversible-source»
import «Monodromy-reversible-ports»
import «Monodromy-reversible-routing»
import Monodromy.Continuation

/-! Static edge-port updates inside the existing native three-root machine. -/
noncomputable section

namespace Monodromy.ReversibleCompilation

open Counter.Reversible CoupledContinuation ReversiblePorts

variable {q e : ℕ} [NeZero q]

instance : NeZero (q + e) := ⟨by have := NeZero.ne q; omega⟩

/-- A finite source instruction fixes a signed displacement before execution. -/
def displacement : Action 2 → ℤ × ℤ
  | .shift register amount => if register = 0 then (amount, 0) else (0, amount)
  | .test _ _ => (0, 0)

theorem apply_coordinates (action : Action 2) (values : Fin 2 → ℤ) :
    ((action.apply values) 0, (action.apply values) 1) =
      (values 0 + (displacement action).1, values 1 + (displacement action).2) := by
  cases action with
  | test => simp [Action.apply, displacement]
  | shift register amount => fin_cases register <;> simp [Action.apply, displacement]

theorem enabled_after_apply (action : Action 2) (values : Fin 2 → ℤ)
    (enabled : action.enabled values) : action.enabled (action.apply values) := by
  cases action <;> exact enabled

/-- Source vertices and edge ports are finite addresses in the same control root. -/
def point (address : Fin (q + e)) (values : Fin 2 → ℤ) : Memory :=
  prepare (values 0) (values 1) address.val

def sourcePoint (state : State 2 q) : Memory :=
  point (Fin.castAdd e state.1) state.2

def portPoint (edge : Fin e) (values : Fin 2 → ℤ) : Memory :=
  point (Fin.natAdd q edge) values

omit [NeZero q] in
theorem sourcePoint_injective : Function.Injective (@sourcePoint q e) := by
  rintro ⟨first, values⟩ ⟨second, other⟩ same
  change prepare (values 0) (values 1) (first.val : ℤ) =
    prepare (other 0) (other 1) (second.val : ℤ) at same
  have coordinates := @prepare_injective ((values 0, values 1), (first.val : ℤ))
    ((other 0, other 1), (second.val : ℤ)) same
  have first_values : values 0 = other 0 := congrArg (fun labels => labels.1.1) coordinates
  have second_values : values 1 = other 1 := congrArg (fun labels => labels.1.2) coordinates
  have controls : (first.val : ℤ) = second.val := congrArg (fun labels => labels.2) coordinates
  apply Prod.ext
  · exact Fin.ext (by exact_mod_cast controls)
  · funext register
    fin_cases register
    · exact first_values
    · exact second_values

/-- Program data specifies the displacement at each finite edge port. -/
def moves (table : Table 2 q e) (address : Fin (q + e)) : ℤ × ℤ :=
  match finSumFinEquiv.symm address with
  | .inl _ => (0, 0)
  | .inr edge => displacement (table edge).action

def update (table : Table 2 q e) : Program (q + e) := ReversibleMemory.program (moves table)

theorem update_port (table : Table 2 q e) (edge : Fin e) (values : Fin 2 → ℤ) :
    (update table).advance (portPoint (q := q) edge values) =
      portPoint (q := q) edge ((table edge).action.apply values) := by
  have actual := ReversibleMemory.advance_prepare (moves table) (values 0) (values 1) 0
    (Fin.natAdd q edge)
  simp only [mul_zero, zero_add] at actual
  have coordinates := apply_coordinates (table edge).action values
  have left : ((table edge).action.apply values) 0 =
      values 0 + (displacement (table edge).action).1 := congrArg Prod.fst coordinates
  have right : ((table edge).action.apply values) 1 =
      values 1 + (displacement (table edge).action).2 := congrArg Prod.snd coordinates
  simpa only [update, portPoint, point, moves, finSumFinEquiv_symm_apply_natAdd,
    left, right] using actual

theorem update_bijective (table : Table 2 q e) : Function.Bijective (update table).advance :=
  (ReversibleMemory.executionEquiv (moves table)).bijective

def sourceLayers (table : Table 2 q e) (deterministic : Deterministic table) :
    List (Program (q + e)) :=
  guards.map (ReversibleRouting.route table (fun edge => (table edge).source)
    (sourceMatching table deterministic))

def targetLayers (table : Table 2 q e) (compatible : TargetCompatible table) :
    List (Program (q + e)) :=
  guards.reverse.map (ReversibleRouting.route table (fun edge => (table edge).target)
    (targetMatching table compatible))

/-- Five outward matchings, one memory update, and five reverse inward matchings. -/
def layers (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) : List (Program (q + e)) :=
  sourceLayers table deterministic ++ update table :: targetLayers table compatible

omit [NeZero q] in
theorem layers_length (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) : (layers table deterministic compatible).length = 11 := by
  simp [layers, sourceLayers, targetLayers, guards]

theorem sourceLayers_edge (table : Table 2 q e) (deterministic : Deterministic table)
    (edge : Fin e) (values : Fin 2 → ℤ) (enabled : (table edge).action.enabled values) :
    (sourceLayers table deterministic).foldl (fun state program => program.advance state)
      (sourcePoint (e := e) ((table edge).source, values)) = portPoint (q := q) edge values := by
  simpa only [sourceLayers, List.foldl_map, sourcePoint, point, portPoint,
    ReversibleRouting.run, ReversibleRouting.point] using
    ReversibleRouting.run_owner table (fun edge => (table edge).source)
      (sourceMatching table deterministic) deterministic values edge enabled

theorem targetLayers_edge (table : Table 2 q e) (compatible : TargetCompatible table)
    (edge : Fin e) (values : Fin 2 → ℤ) (enabled : (table edge).action.enabled values) :
    (targetLayers table compatible).foldl (fun state program => program.advance state)
      (portPoint (q := q) edge values) = sourcePoint (e := e) ((table edge).target, values) := by
  simpa only [targetLayers, List.foldl_map, sourcePoint, point, portPoint,
    ReversibleRouting.run, ReversibleRouting.point] using
    ReversibleRouting.run_port table (fun edge => (table edge).target)
      (targetMatching table compatible) compatible values edge enabled

/-- The actual native layers execute an enabled source edge, without calling its successor. -/
theorem layers_edge (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (edge : Fin e) (values : Fin 2 → ℤ)
    (enabled : (table edge).action.enabled values) :
    (layers table deterministic compatible).foldl (fun state program => program.advance state)
      (sourcePoint (e := e) ((table edge).source, values)) =
      sourcePoint (e := e) ((table edge).target, (table edge).action.apply values) := by
  rw [layers, List.foldl_append, sourceLayers_edge table deterministic edge values enabled,
    List.foldl_cons, update_port, targetLayers_edge table compatible edge _
      (enabled_after_apply (table edge).action values enabled)]

/-- Finite stages are packed into the existing upper branch, with eleven fixed clock phases. -/
def stages (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (phase : Fin 11) : Program (q + e) :=
  (layers table deterministic compatible).get
    ⟨phase.val, by rw [layers_length]; exact phase.isLt⟩

omit [NeZero q] in
theorem ofFn_stages (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) :
    List.ofFn (stages table deterministic compatible) = layers table deterministic compatible := by
  apply List.ext_getElem
  · simp only [List.length_ofFn, layers_length]
  · intro index _ _
    rw [List.getElem_ofFn]
    rfl

def program (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) : Program (11 * (q + e)) :=
  StagedProgram.compile 11 (q + e) (stages table deterministic compatible)

def iota (state : State 2 q) : Memory := StagedProgram.embed 11 0 (sourcePoint (e := e) state)

omit [NeZero q] in
theorem iota_injective : Function.Injective (@iota q e) := by
  intro first second same
  have pair := (StagedProgram.packedEquiv 11).injective same
  exact sourcePoint_injective (congrArg Prod.fst pair)

/-- One source edge is eleven consecutive returns of one fixed native word table. -/
theorem cycle_edge (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (edge : Fin e) (values : Fin 2 → ℤ)
    (enabled : (table edge).action.enabled values) :
    ((program table deterministic compatible).advance)^[11]
      (iota (e := e) ((table edge).source, values)) =
      iota (e := e) ((table edge).target, (table edge).action.apply values) := by
  change ((StagedProgram.compile 11 (q + e) (stages table deterministic compatible)).advance)^[11]
    (StagedProgram.embed 11 0 (sourcePoint (e := e) ((table edge).source, values))) = _
  rw [StagedProgram.cycle_ofFn, ofFn_stages, layers_edge table deterministic compatible edge values enabled]
  rfl

theorem cycle_step (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) {first last : State 2 q}
    (transition : step table first = some last) :
    ((program table deterministic compatible).advance)^[11] (iota (e := e) first) =
      iota (e := e) last := by
  obtain ⟨edge, enabled, rfl⟩ := (step_iff table deterministic).mp transition
  rcases first with ⟨position, values⟩
  obtain ⟨rfl, action_enabled⟩ := enabled
  exact cycle_edge table deterministic compatible edge values action_enabled

/-- The only non-involutive layer is undone by the negated static memory displacement. -/
def backwardStages (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (phase : Fin 11) : Program (q + e) :=
  if phase = 5 then ReversibleMemory.program (ReversibleMemory.negate (moves table))
  else stages table deterministic compatible phase

omit [NeZero q] in
theorem stages_update (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) : stages table deterministic compatible 5 = update table := rfl

theorem stages_involutive (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (phase : Fin 11) (different : phase ≠ 5) :
    Function.Involutive (stages table deterministic compatible phase).advance := by
  fin_cases phase <;> first
    | exact (different rfl).elim
    | exact ReversibleRouting.route_involutive _ _ _ _

theorem backward_left (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (phase : Fin 11) (state : Memory) :
    (backwardStages table deterministic compatible phase).advance
      ((stages table deterministic compatible phase).advance state) = state := by
  by_cases middle : phase = 5
  · subst phase
    rw [backwardStages, ite_eq_left rfl, stages_update]
    exact ReversibleMemory.inverse (moves table) state
  · rw [backwardStages, ite_eq_right middle]
    exact stages_involutive table deterministic compatible phase middle state

theorem backward_right (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (phase : Fin 11) (state : Memory) :
    (stages table deterministic compatible phase).advance
      ((backwardStages table deterministic compatible phase).advance state) = state := by
  by_cases middle : phase = 5
  · subst phase
    rw [backwardStages, ite_eq_left rfl, stages_update]
    simpa only [update, ReversibleMemory.negate_negate] using
      ReversibleMemory.inverse (ReversibleMemory.negate (moves table)) state
  · rw [backwardStages, ite_eq_right middle]
    exact stages_involutive table deterministic compatible phase middle state

/-- Reverse execution is another fixed native word table, selected from returned roots. -/
def reverseProgram (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) : Program (11 * (q + e)) :=
  StagedProgram.compileReverse 11 (q + e) (backwardStages table deterministic compatible)

theorem reverse_after_forward (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (state : Memory) :
    (reverseProgram table deterministic compatible).advance
      ((program table deterministic compatible).advance state) = state :=
  StagedProgram.left_inverse 11 (q + e) _ _
    (backward_left table deterministic compatible) state

theorem forward_after_reverse (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (state : Memory) :
    (program table deterministic compatible).advance
      ((reverseProgram table deterministic compatible).advance state) = state :=
  StagedProgram.right_inverse 11 (q + e) _ _
    (backward_right table deterministic compatible) state

/-- Both directions are fixed native tables on the same retained fiber. -/
def executionEquiv (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) : Memory ≃ Memory where
  toFun := (program table deterministic compatible).advance
  invFun := (reverseProgram table deterministic compatible).advance
  left_inv := reverse_after_forward table deterministic compatible
  right_inv := forward_after_reverse table deterministic compatible

theorem program_bijective (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) : Function.Bijective (program table deterministic compatible).advance :=
  (executionEquiv table deterministic compatible).bijective

end Monodromy.ReversibleCompilation
