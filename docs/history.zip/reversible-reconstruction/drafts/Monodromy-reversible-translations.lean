import Monodromy.Continuation

/-! Static reversible memory updates, compiled solely from the existing A loops. -/
noncomputable section

namespace Monodromy.ReversibleTranslations

open CoupledContinuation

def memoryGate (register : Fin 2) : Gate := if register = 0 then .left else .right

def shiftWord (register : Fin 2) : ℤ → Word
  | .ofNat count => List.replicate count (memoryGate register, false)
  | .negSucc count => List.replicate (count + 1) (memoryGate register, true)

private theorem execute_memoryGate (register : Fin 2) (left right control : ℤ) :
    execute (memoryGate register).driver (prepare left right control) =
      prepare (left + if register = 0 then 1 else 0)
        (right + if register = 1 then 1 else 0) control := by
  refine Fin.cases ?_ (fun tail => ?_) register
  · change execute A_left _ = prepare (left + 1) (right + 0) control
    rw [add_zero]
    exact execute_A_left left right control
  · have only : tail = 0 := Fin.eq_zero tail
    subst tail
    change execute A_right _ = prepare (left + 0) (right + 1) control
    rw [add_zero]
    exact execute_A_right left right control

private theorem execute_memoryGate_reverse (register : Fin 2) (left right control : ℤ) :
    execute (memoryGate register).driver.reverse (prepare left right control) =
      prepare (left - if register = 0 then 1 else 0)
        (right - if register = 1 then 1 else 0) control := by
  refine Fin.cases ?_ (fun tail => ?_) register
  · change execute A_left.reverse _ = prepare (left - 1) (right - 0) control
    rw [sub_zero]
    exact execute_A_left_reverse left right control
  · have only : tail = 0 := Fin.eq_zero tail
    subst tail
    change execute A_right.reverse _ = prepare (left - 0) (right - 1) control
    rw [sub_zero]
    exact execute_A_right_reverse left right control

private theorem repeat_forward (register : Fin 2) (count : ℕ) (left right control : ℤ) :
    execute (Word.driver (List.replicate count (memoryGate register, false))) (prepare left right control) =
      prepare (left + if register = 0 then (count : ℤ) else 0)
        (right + if register = 1 then (count : ℤ) else 0) control := by
  induction count generalizing left right with
  | zero => simp only [List.replicate_zero, execute_word_nil, Nat.cast_zero, ite_self, add_zero]
  | succ count induction_hypothesis =>
      rw [List.replicate_succ, execute_word_cons]
      change execute (Word.driver (List.replicate count (memoryGate register, false)))
        (execute (memoryGate register).driver (prepare left right control)) = _
      rw [execute_memoryGate, induction_hypothesis]
      congr 1 <;> split_ifs <;> push_cast <;> omega

private theorem repeat_backward (register : Fin 2) (count : ℕ) (left right control : ℤ) :
    execute (Word.driver (List.replicate count (memoryGate register, true))) (prepare left right control) =
      prepare (left - if register = 0 then (count : ℤ) else 0)
        (right - if register = 1 then (count : ℤ) else 0) control := by
  induction count generalizing left right with
  | zero => simp only [List.replicate_zero, execute_word_nil, Nat.cast_zero, ite_self, sub_zero]
  | succ count induction_hypothesis =>
      rw [List.replicate_succ, execute_word_cons]
      change execute (Word.driver (List.replicate count (memoryGate register, true)))
        (execute (memoryGate register).driver.reverse (prepare left right control)) = _
      rw [execute_memoryGate_reverse, induction_hypothesis]
      congr 1 <;> split_ifs <;> push_cast <;> omega

theorem execute_shiftWord (register : Fin 2) (amount left right control : ℤ) :
    execute (Word.driver (shiftWord register amount)) (prepare left right control) =
      prepare (left + if register = 0 then amount else 0)
        (right + if register = 1 then amount else 0) control := by
  cases amount with
  | ofNat count => exact repeat_forward register count left right control
  | negSucc count =>
      rw [shiftWord, repeat_backward]
      congr 1 <;> split_ifs <;> omega

/-- A static displacement is two finite signed words in the original memory loops. -/
def memoryWord (move : ℤ × ℤ) : Word := shiftWord 0 move.1 ++ shiftWord 1 move.2

theorem execute_memoryWord (move : ℤ × ℤ) (left right control : ℤ) :
    execute (Word.driver (memoryWord move)) (prepare left right control) =
      prepare (left + move.1) (right + move.2) control := by
  simp [memoryWord, execute_word_append, execute_shiftWord]

theorem shiftWord_length (register : Fin 2) (amount : ℤ) :
    (shiftWord register amount).length = amount.natAbs := by
  cases amount <;> simp [shiftWord]

theorem memoryWord_length (move : ℤ × ℤ) :
    (memoryWord move).length = move.1.natAbs + move.2.natAbs := by
  simp [memoryWord, shiftWord_length]

/-- Actual lower translations leave every upper finite-root observation unchanged. -/
theorem controlRoot_memoryWord (degree : ℕ) [NeZero degree] (move : ℤ × ℤ) (state : Memory) :
    controlRoot degree (execute (Word.driver (memoryWord move)) state) = controlRoot degree state := by
  obtain ⟨⟨⟨left, right⟩, control⟩, rfl⟩ := prepare_surjective state
  rw [execute_memoryWord, controlRoot_prepare, controlRoot_prepare]

private theorem memoryWord_inverse (move : ℤ × ℤ) (state : Memory) :
    execute (Word.driver (memoryWord (-move.1, -move.2)))
      (execute (Word.driver (memoryWord move)) state) = state := by
  obtain ⟨⟨⟨left, right⟩, control⟩, rfl⟩ := prepare_surjective state
  rw [execute_memoryWord, execute_memoryWord]
  simp

variable {degree : ℕ} [NeZero degree]

def negate (moves : Fin degree → ℤ × ℤ) : Fin degree → ℤ × ℤ :=
  fun index => (-(moves index).1, -(moves index).2)

/-- The table contains only static finite words; it never receives a memory state. -/
def program (moves : Fin degree → ℤ × ℤ) : Program degree :=
  ⟨fun index => memoryWord (moves index), fun _ => false⟩

theorem step_eq_some (moves : Fin degree → ℤ × ℤ) (state : Memory) :
    (program moves).step state = some ((program moves).advance state) := by
  simp [Program.step, Program.haltSignal, program, Choice.dispatch]

theorem advance_prepare (moves : Fin degree → ℤ × ℤ) (left right quotient : ℤ) (index : Fin degree) :
    (program moves).advance (prepare left right ((degree : ℤ) * quotient + index.val)) =
      prepare (left + (moves index).1) (right + (moves index).2)
        ((degree : ℤ) * quotient + index.val) := by
  rw [Program.advance_prepare]
  exact execute_memoryWord (moves index) left right _

private theorem advance_of_root (moves : Fin degree → ℤ × ℤ) (state : Memory) (index : Fin degree)
    (observed : controlRoot degree state = (Radix.omega degree index : ℂ)) :
    (program moves).advance state = execute (Word.driver (memoryWord (moves index))) state :=
  executeRouted_eq degree (fun index => Word.driver (memoryWord (moves index))) state index observed

/-- The unchanged returned control root selects the negated update, with no retained history. -/
theorem inverse (moves : Fin degree → ℤ × ℤ) (state : Memory) :
    (program (negate moves)).advance ((program moves).advance state) = state := by
  obtain ⟨index, observed⟩ := controlRoot_is_root degree state
  have moved : controlRoot degree (execute (Word.driver (memoryWord (moves index))) state) =
      (Radix.omega degree index : ℂ) :=
    (controlRoot_memoryWord degree (moves index) state).trans observed
  rw [advance_of_root moves state index observed, advance_of_root (negate moves) _ index moved]
  exact memoryWord_inverse (moves index) state

omit [NeZero degree] in
@[simp] theorem negate_negate (moves : Fin degree → ℤ × ℤ) : negate (negate moves) = moves := by
  funext index
  simp [negate]

def executionEquiv (moves : Fin degree → ℤ × ℤ) : Memory ≃ Memory where
  toFun := (program moves).advance
  invFun := (program (negate moves)).advance
  left_inv := inverse moves
  right_inv := by
    intro state
    simpa only [negate_negate] using inverse (negate moves) state

end Monodromy.ReversibleTranslations
