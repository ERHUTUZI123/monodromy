import Mathlib.Logic.Function.Iterate
import Lean.Elab.Tactic.Omega

/-! First returns preserve backward uniqueness; a faithful irreversible source needs retained history. -/

namespace Monodromy.ReversibleReturn

variable {State Source : Type*}

/-- A positive return with no earlier positive visit to the same boundary. -/
def FirstReturn (advance : State → State) (boundary : State → Prop) (first last : State) : Prop :=
  ∃ count : ℕ, 0 < count ∧ advance^[count] first = last ∧ boundary first ∧ boundary last ∧
    ∀ middle : ℕ, 0 < middle → middle < count → ¬ boundary (advance^[middle] first)

private theorem equal_start_of_le {advance : State → State} {boundary : State → Prop}
    (injective : Function.Injective advance) {first second : State} {left right : ℕ}
    (positive : 0 < left) (ordered : left ≤ right)
    (ends : advance^[left] first = advance^[right] second)
    (starts : boundary first)
    (interior : ∀ middle : ℕ, 0 < middle → middle < right → ¬ boundary (advance^[middle] second)) :
    first = second := by
  have sum : left + (right - left) = right := by omega
  have shifted : first = advance^[right - left] second := by
    apply injective.iterate left
    rw [← Function.iterate_add_apply, sum]
    exact ends
  have offset_zero : right - left = 0 := by
    rcases Nat.eq_zero_or_pos (right - left) with zero | positive_offset
    · exact zero
    · have before_end : right - left < right := by omega
      have visited : boundary (advance^[right - left] second) := by
        rw [← shifted]
        exact starts
      exact False.elim (interior (right - left) positive_offset before_end visited)
  simpa only [offset_zero, Function.iterate_zero_apply] using shifted

/-- An injective advance has an injective first-return relation on any fixed boundary. -/
theorem backward_unique {advance : State → State} {boundary : State → Prop}
    (injective : Function.Injective advance) {first second last : State}
    (left : FirstReturn advance boundary first last)
    (right : FirstReturn advance boundary second last) : first = second := by
  rcases left with ⟨left_count, left_positive, left_end, left_start, _, left_interior⟩
  rcases right with ⟨right_count, right_positive, right_end, right_start, _, right_interior⟩
  by_cases ordered : left_count ≤ right_count
  · exact equal_start_of_le injective left_positive ordered (left_end.trans right_end.symm)
      left_start right_interior
  · exact (equal_start_of_le injective right_positive (by omega)
      (right_end.trans left_end.symm) right_start left_interior).symm

/-- A same-encoding first-return simulation by an injective advance preserves source predecessors.
The conclusion concerns defined transitions; no restriction is imposed on the set of source halts. -/
theorem source_defined_injective (sourceStep : Source → Option Source)
    (encode : Source → State) (faithful : Function.Injective encode)
    (advance : State → State) (boundary : State → Prop) (injective : Function.Injective advance)
    (simulates : ∀ first last, sourceStep first = some last →
      FirstReturn advance boundary (encode first) (encode last))
    {first second last : Source}
    (left : sourceStep first = some last) (right : sourceStep second = some last) : first = second :=
  faithful (backward_unique injective (simulates first last left) (simulates second last right))

end Monodromy.ReversibleReturn
