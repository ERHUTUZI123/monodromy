import Mathlib.Computability.StateTransition
import Mathlib.Data.Fin.Tuple.Basic
import Mathlib.Data.Int.Basic
import Mathlib.Logic.Function.Basic
import Mathlib.Tactic.SplitIfs

/-!
Locally reversible integer counter edge tables. This is a finite source
language and its proof semantics; it is not part of native path generation.
-/

namespace Monodromy.Counter.Reversible

inductive Action (n : ℕ)
  | shift (reg : Fin n) (amount : ℤ)
  | test (reg : Fin n) (atZero : Bool)
  deriving DecidableEq

abbrev State (n q : ℕ) := Fin q × (Fin n → ℤ)

structure Edge (n q : ℕ) where
  source : Fin q
  target : Fin q
  action : Action n
  deriving DecidableEq

abbrev Table (n q e : ℕ) := Fin e → Edge n q

namespace Action

variable {n : ℕ}

def enabled : Action n → (Fin n → ℤ) → Prop
  | .shift _ _, _ => True
  | .test reg atZero, values => (values reg = 0) ↔ atZero = true

instance (action : Action n) (values : Fin n → ℤ) : Decidable (enabled action values) := by
  cases action <;> simp only [enabled] <;> infer_instance

def apply : Action n → (Fin n → ℤ) → (Fin n → ℤ)
  | .shift reg amount, values => Function.update values reg (values reg + amount)
  | .test _ _, values => values

/-- The only two different alternatives allowed at a common port. -/
def Compatible : Action n → Action n → Prop
  | .test first firstZero, .test second secondZero => first = second ∧ firstZero ≠ secondZero
  | _, _ => False

theorem Compatible.symm {first second : Action n} (compatible : Compatible first second) :
    Compatible second first := by
  cases first <;> cases second <;> simp_all [Compatible, eq_comm]

theorem Compatible.not_both {first second : Action n} (compatible : Compatible first second)
    (values : Fin n → ℤ) : ¬ (enabled first values ∧ enabled second values) := by
  cases first <;> cases second <;> simp only [Compatible] at compatible
  rcases compatible with ⟨rfl, different⟩
  rename_i firstZero secondZero
  cases firstZero <;> cases secondZero <;> simp_all [enabled]

theorem apply_injective (action : Action n) : Function.Injective action.apply := by
  cases action with
  | test => exact Function.injective_id
  | shift reg amount =>
      intro first second same
      funext index
      by_cases selected : index = reg
      · subst index
        have at_register := congrFun same reg
        simpa only [apply, Function.update_self, Int.add_left_inj] using at_register
      · have elsewhere := congrFun same index
        simpa only [apply, Function.update_of_ne selected] using elsewhere

/-- Complementary tests preserve the values on which their guards disagree. -/
theorem Compatible.not_same_result {first second : Action n}
    (compatible : Compatible first second) {left right : Fin n → ℤ}
    (left_enabled : enabled first left) (right_enabled : enabled second right) :
    first.apply left ≠ second.apply right := by
  cases first <;> cases second <;> simp only [Compatible] at compatible
  rcases compatible with ⟨rfl, different⟩
  intro same
  change left = right at same
  subst right
  exact (Compatible.not_both (show Compatible (.test _ _) (.test _ _) from ⟨rfl, different⟩)
    left) ⟨left_enabled, right_enabled⟩

end Action

variable {n q e : ℕ}

namespace Edge

def enabled (edge : Edge n q) (state : State n q) : Prop :=
  edge.source = state.1 ∧ edge.action.enabled state.2

instance (edge : Edge n q) (state : State n q) : Decidable (edge.enabled state) :=
  inferInstanceAs (Decidable (edge.source = state.1 ∧ edge.action.enabled state.2))

def execute (edge : Edge n q) (state : State n q) : State n q :=
  (edge.target, edge.action.apply state.2)

end Edge

/-- Alternatives at the same source port have disjoint guards. -/
def Deterministic (table : Table n q e) : Prop :=
  ∀ first second, first ≠ second → (table first).source = (table second).source →
    Action.Compatible (table first).action (table second).action

/-- Alternatives at the same target port have disjoint, unchanged test data. -/
def TargetCompatible (table : Table n q e) : Prop :=
  ∀ first second, first ≠ second → (table first).target = (table second).target →
    Action.Compatible (table first).action (table second).action

/-- Every live address can move at every integer register valuation. -/
def Complete (table : Table n q e) : Prop :=
  ∀ state : State n q, (∃ index, (table index).source = state.1) →
    ∃ index, (table index).enabled state

/-- Relational source semantics, before selecting a finite edge index. -/
def StepRel (table : Table n q e) (first last : State n q) : Prop :=
  ∃ index, (table index).enabled first ∧ (table index).execute first = last

theorem enabled_index_unique (table : Table n q e) (deterministic : Deterministic table)
    {first second : Fin e} {state : State n q}
    (first_enabled : (table first).enabled state) (second_enabled : (table second).enabled state) :
    first = second := by
  by_contra different
  have compatible := deterministic first second different (first_enabled.1.trans second_enabled.1.symm)
  exact (compatible.not_both state.2) ⟨first_enabled.2, second_enabled.2⟩

theorem StepRel.deterministic (table : Table n q e) (deterministic : Deterministic table)
    {initial first second : State n q} (left : StepRel table initial first)
    (right : StepRel table initial second) : first = second := by
  obtain ⟨left_index, left_enabled, rfl⟩ := left
  obtain ⟨right_index, right_enabled, rfl⟩ := right
  rw [enabled_index_unique table deterministic left_enabled right_enabled]

theorem StepRel.backward_unique (table : Table n q e) (reversible : TargetCompatible table)
    {first second final : State n q} (left : StepRel table first final)
    (right : StepRel table second final) : first = second := by
  obtain ⟨left_index, left_enabled, left_result⟩ := left
  obtain ⟨right_index, right_enabled, right_result⟩ := right
  have same_result : (table left_index).execute first = (table right_index).execute second :=
    left_result.trans right_result.symm
  have same_target : (table left_index).target = (table right_index).target :=
    congrArg Prod.fst same_result
  have same_values : (table left_index).action.apply first.2 =
      (table right_index).action.apply second.2 := congrArg Prod.snd same_result
  by_cases same_index : left_index = right_index
  · subst right_index
    apply Prod.ext
    · exact left_enabled.1.symm.trans right_enabled.1
    · exact Action.apply_injective _ same_values
  · exact False.elim ((reversible left_index right_index same_index same_target).not_same_result
      left_enabled.2 right_enabled.2 same_values)

/-- Bounded finite search; this source executor is independent of native geometry. -/
def step (table : Table n q e) (state : State n q) : Option (State n q) :=
  if available : ∃ index, (table index).enabled state then
    some ((table (Fin.find (fun index => (table index).enabled state) available)).execute state)
  else none

theorem step_iff (table : Table n q e) (deterministic : Deterministic table)
    {first last : State n q} : step table first = some last ↔ StepRel table first last := by
  unfold step
  split_ifs with available
  · constructor
    · intro result
      exact ⟨_, Fin.find_spec available, Option.some.inj result⟩
    · intro result
      exact congrArg some (StepRel.deterministic table deterministic
        ⟨_, Fin.find_spec available, rfl⟩ result)
  · simp only [false_iff]
    rintro ⟨index, enabled, _⟩
    exact available ⟨index, enabled⟩

theorem step_some_injective (table : Table n q e) (deterministic : Deterministic table)
    (reversible : TargetCompatible table) {first second final : State n q}
    (left : step table first = some final) (right : step table second = some final) : first = second :=
  StepRel.backward_unique table reversible ((step_iff table deterministic).mp left)
    ((step_iff table deterministic).mp right)

theorem step_none_iff (table : Table n q e) (state : State n q) :
    step table state = none ↔ ¬ ∃ index, (table index).enabled state := by
  unfold step
  split_ifs <;> simp_all

/-- Completeness makes halting a static source-address property. -/
theorem step_none_iff_no_outgoing (table : Table n q e) (complete : Complete table)
    (state : State n q) : step table state = none ↔ ¬ ∃ index, (table index).source = state.1 := by
  rw [step_none_iff]
  constructor
  · intro halted outgoing
    exact halted (complete state outgoing)
  · rintro halted ⟨index, enabled⟩
    exact halted ⟨index, enabled.1⟩

namespace Action

def IsShift : Action n → Prop
  | .shift _ _ => True
  | .test _ _ => False

instance (action : Action n) : Decidable action.IsShift := by
  cases action <;> simp only [IsShift] <;> infer_instance

instance (first second : Action n) : Decidable (Compatible first second) := by
  cases first <;> cases second <;> simp only [Compatible] <;> infer_instance

theorem Compatible.one_enabled {first second : Action n}
    (compatible : Compatible first second) (values : Fin n → ℤ) :
    enabled first values ∨ enabled second values := by
  cases first with
  | shift => simp [Compatible] at compatible
  | test register firstZero =>
      cases second with
      | shift => simp [Compatible] at compatible
      | test other secondZero =>
          rcases compatible with ⟨rfl, different⟩
          by_cases zero : values register = 0 <;>
            cases firstZero <;> cases secondZero <;> simp_all [enabled]

theorem test_disabled (register : Fin n) (atZero : Bool) :
    ∃ values : Fin n → ℤ, ¬ enabled (.test register atZero) values := by
  cases atZero
  · exact ⟨fun _ => 0, by simp [enabled]⟩
  · exact ⟨fun _ => 1, by simp [enabled]⟩

end Action

/-- A live port is covered by one unconditional shift or two complementary tests. -/
def CoveredAt (table : Table n q e) (position : Fin q) : Prop :=
  (¬ ∃ index, (table index).source = position) ∨
  (∃ index, (table index).source = position ∧ (table index).action.IsShift) ∨
  ∃ first second, (table first).source = position ∧ (table second).source = position ∧
    Action.Compatible (table first).action (table second).action

instance (table : Table n q e) (position : Fin q) : Decidable (CoveredAt table position) :=
  inferInstanceAs (Decidable (
    (¬ ∃ index, (table index).source = position) ∨
    (∃ index, (table index).source = position ∧ (table index).action.IsShift) ∨
    ∃ first second, (table first).source = position ∧ (table second).source = position ∧
      Action.Compatible (table first).action (table second).action))

theorem complete_of_covered (table : Table n q e)
    (covered : ∀ position, CoveredAt table position) : Complete table := by
  intro state outgoing
  rcases covered state.1 with empty | ⟨index, source, shift⟩ | ⟨first, second, fs, ss, compatible⟩
  · exact False.elim (empty outgoing)
  · refine ⟨index, source, ?_⟩
    cases action : (table index).action with
    | shift => trivial
    | test => simp [Action.IsShift, action] at shift
  · rcases compatible.one_enabled state.2 with first_enabled | second_enabled
    · exact ⟨first, fs, first_enabled⟩
    · exact ⟨second, ss, second_enabled⟩

theorem covered_of_complete (table : Table n q e) (deterministic : Deterministic table)
    (complete : Complete table) : ∀ position, CoveredAt table position := by
  intro position
  by_cases outgoing : ∃ index, (table index).source = position
  · obtain ⟨index, source⟩ := outgoing
    cases action : (table index).action with
    | shift register amount =>
        exact Or.inr (Or.inl ⟨index, source, by simp [Action.IsShift, action]⟩)
    | test register atZero =>
        obtain ⟨values, disabled⟩ := Action.test_disabled register atZero
        obtain ⟨other, other_source, other_enabled⟩ :=
          complete (position, values) ⟨index, source⟩
        have different : index ≠ other := by
          intro same
          subst other
          exact disabled (action ▸ other_enabled)
        exact Or.inr (Or.inr ⟨index, other, source, other_source,
          deterministic index other different (source.trans other_source.symm)⟩)
  · exact Or.inl outgoing

/-- Semantic completeness of a deterministic table has a finite syntactic test. -/
theorem complete_iff_covered (table : Table n q e) (deterministic : Deterministic table) :
    Complete table ↔ ∀ position, CoveredAt table position :=
  ⟨covered_of_complete table deterministic, complete_of_covered table⟩

/-- All quantified positions and edge indices in the coverage criterion are finite. -/
def decideComplete (table : Table n q e) (deterministic : Deterministic table) :
    Decidable (Complete table) :=
  decidable_of_iff (∀ position, CoveredAt table position)
    (complete_iff_covered table deterministic).symm

/-- Complete partial execution retains the final halted source configuration. -/
def eval (table : Table n q e) : State n q → Part (State n q) :=
  StateTransition.eval (step table)

end Monodromy.Counter.Reversible

#print axioms Monodromy.Counter.Reversible.StepRel.deterministic
#print axioms Monodromy.Counter.Reversible.StepRel.backward_unique
#print axioms Monodromy.Counter.Reversible.step_iff
#print axioms Monodromy.Counter.Reversible.step_some_injective
#print axioms Monodromy.Counter.Reversible.step_none_iff_no_outgoing
#print axioms Monodromy.Counter.Reversible.complete_iff_covered
