import Monodromy.Continuation

/-! Static root stopping bits for the existing finite-stage native compiler. -/
noncomputable section

namespace Monodromy.StagedProgram

open CoupledContinuation
open Fin.NatCast

variable (count degree : ℕ) [NeZero count] [NeZero degree]

/-- The same finite words, stopped only at selected packed phase-zero addresses. -/
def markedCompile (stages : Fin count → Program degree) (mark : Fin degree → Bool) :
    Program (count * degree) where
  table := (compile count degree stages).table
  stop index :=
    let pair := (address count degree).symm index
    if pair.2 = 0 then mark pair.1 else false

@[simp] theorem markedCompile_advance (stages : Fin count → Program degree) (mark : Fin degree → Bool)
    : (markedCompile count degree stages mark).advance =
      (compile count degree stages).advance := rfl

omit [NeZero degree] in
@[simp] theorem markedCompile_stop_address (stages : Fin count → Program degree)
    (mark : Fin degree → Bool) (index : Fin degree) (phase : Fin count) :
    (markedCompile count degree stages mark).stop (address count degree (index, phase)) =
      if phase = 0 then mark index else false := by
  simp [markedCompile]

theorem haltSignal_embed (stages : Fin count → Program degree) (mark : Fin degree → Bool)
    (left right quotient : ℤ) (index : Fin degree) (phase : Fin count) :
    (markedCompile count degree stages mark).haltSignal
      (embed count phase (prepare left right ((degree : ℤ) * quotient + index.val))) =
      if (if phase = 0 then mark index else false) then 1 else 0 := by
  have actual := (markedCompile count degree stages mark).haltSignal_prepare left right quotient
    (address count degree (index, phase))
  rw [markedCompile_stop_address] at actual
  have control : ((count * degree : ℕ) : ℤ) * quotient +
      (address count degree (index, phase)).val =
      (count : ℤ) * ((degree : ℤ) * quotient + index.val) + phase.val := by
    rw [address_val]
    push_cast
    ring
  rw [control] at actual
  rw [show embed count phase (prepare left right ((degree : ℤ) * quotient + index.val)) =
      prepare left right ((count : ℤ) * ((degree : ℤ) * quotient + index.val) + phase.val) from
    embed_prepare count phase (((left, right), (degree : ℤ) * quotient + index.val) : Labels)]
  exact actual

theorem halt_embed_iff (stages : Fin count → Program degree) (mark : Fin degree → Bool)
    (left right quotient : ℤ) (index : Fin degree) (phase : Fin count) :
    (markedCompile count degree stages mark).haltSignal
      (embed count phase (prepare left right ((degree : ℤ) * quotient + index.val))) = 1 ↔
      phase = 0 ∧ mark index = true := by
  rw [haltSignal_embed]
  by_cases zero : phase = 0
  · cases mark index <;> simp [zero]
  · simp [zero]

theorem step_embed (stages : Fin count → Program degree) (mark : Fin degree → Bool)
    (left right quotient : ℤ) (index : Fin degree) (phase : Fin count) :
    (markedCompile count degree stages mark).step
      (embed count phase (prepare left right ((degree : ℤ) * quotient + index.val))) =
      if phase = 0 ∧ mark index = true then none else
        some (embed count (finRotate count phase)
          ((stages phase).advance (prepare left right ((degree : ℤ) * quotient + index.val)))) := by
  simp only [Program.step, halt_embed_iff, markedCompile_advance, advance_embed]

/-- Nonzero packed phases always execute their actual next stage. -/
theorem interior_step (stages : Fin count → Program degree) (mark : Fin degree → Bool)
    (phase : Fin count) (nonzero : phase ≠ 0) (state : Memory) :
    (markedCompile count degree stages mark).step (embed count phase state) =
      some (embed count (finRotate count phase) ((stages phase).advance state)) := by
  obtain ⟨labels, rfl⟩ := labelsEquiv.surjective state
  change (markedCompile count degree stages mark).step (embed count phase (Labels.prepare labels)) =
    some (embed count (finRotate count phase) ((stages phase).advance (Labels.prepare labels)))
  have actual := step_embed count degree stages mark labels.1.1 labels.1.2
    (labels.2 / (degree : ℤ)) (Program.indexInt degree labels) phase
  rw [Program.control_decomposition] at actual
  simpa only [nonzero, false_and, ite_false, Labels.prepare] using actual

/-- The existing finite root observation reads the packed clock phase. -/
theorem phaseRoot_embed (phase : Fin count) (state : Memory) :
    controlRoot count (embed count phase state) = (Radix.omega count phase : ℂ) := by
  obtain ⟨⟨⟨left, right⟩, control⟩, rfl⟩ := prepare_surjective state
  rw [show embed count phase (prepare left right control) =
      prepare left right ((count : ℤ) * control + phase.val) from
    embed_prepare count phase (((left, right), control) : Labels), controlRoot_prepare]
  exact congrArg (fun root : Circle => (root : ℂ)) (Radix.readRoot_digit count control phase)

/-- A phase-zero boundary is an actual power-cover root, not a stored clock register. -/
def PhaseBoundary (state : Memory) : Prop := controlRoot count state = 1

theorem phaseBoundary_embed_iff (phase : Fin count) (state : Memory) :
    PhaseBoundary count (embed count phase state) ↔ phase = 0 := by
  have root_zero : (Radix.omega count (0 : Fin count) : ℂ) = 1 := by simp [Radix.omega]
  unfold PhaseBoundary
  rw [phaseRoot_embed]
  constructor
  · intro same
    apply Radix.omega_injective count
    exact Subtype.ext (same.trans root_zero.symm)
  · rintro rfl
    exact root_zero

/-- Before a complete clock cycle, its phase cannot revisit zero. -/
theorem rotated_zero_ne_zero (steps : ℕ) (positive : 0 < steps) (before : steps < count) :
    ((finRotate count)^[steps] (0 : Fin count)) ≠ 0 := by
  rw [rotate_iterate, zero_add]
  intro same
  have values := congrArg Fin.val same
  simp only [Fin.val_natCast, Nat.mod_eq_of_lt before, Fin.val_zero] at values
  omega

/-- Arbitrary stage effects cannot create an early phase-zero return. -/
theorem cycle_interior (stages : Fin count → Program degree) (mark : Fin degree → Bool)
    (state : Memory) (steps : ℕ) (positive : 0 < steps) (before : steps < count) :
    ¬ PhaseBoundary count (((markedCompile count degree stages mark).advance)^[steps]
      (embed count 0 state)) := by
  simp only [markedCompile_advance]
  rw [iterate_embed, phaseBoundary_embed_iff]
  exact rotated_zero_ne_zero count steps positive before

private theorem positive_reaches_iterate {State : Type*}
    (advance : State → State) (transition : State → Option State) (state : State)
    (steps : ℕ) (positive : 0 < steps)
    (active : ∀ round : ℕ, round < steps →
      transition (advance^[round] state) = some (advance^[round + 1] state)) :
    StateTransition.Reaches₁ transition state (advance^[steps] state) := by
  revert positive active
  induction steps with
  | zero => intro impossible _; omega
  | succ steps recursive =>
      intro _ active
      by_cases first : steps = 0
      · subst steps
        apply Relation.TransGen.single
        exact active 0 (by omega)
      · have previous := recursive (by omega) (fun round before => active round (by omega))
        exact previous.tail (active steps (by omega))

/-- An unmarked phase-zero start executes one complete positive native stage cycle. -/
theorem cycle_reaches (stages : Fin count → Program degree) (mark : Fin degree → Bool)
    (left right quotient : ℤ) (index : Fin degree) (unmarked : mark index = false) :
    StateTransition.Reaches₁ (markedCompile count degree stages mark).step
      (embed count 0 (prepare left right ((degree : ℤ) * quotient + index.val)))
      (embed count 0 ((List.ofFn stages).foldl (fun point stage => stage.advance point)
        (prepare left right ((degree : ℤ) * quotient + index.val)))) := by
  have active : ∀ round : ℕ, round < count →
      (markedCompile count degree stages mark).step
        (((compile count degree stages).advance)^[round]
          (embed count 0 (prepare left right ((degree : ℤ) * quotient + index.val)))) =
      some (((compile count degree stages).advance)^[round + 1]
        (embed count 0 (prepare left right ((degree : ℤ) * quotient + index.val)))) := by
    intro round before
    rw [Function.iterate_succ_apply']
    by_cases initial : round = 0
    · subst round
      simp only [Function.iterate_zero_apply]
      rw [step_embed, advance_embed]
      simp [unmarked]
    · rw [iterate_embed]
      have phase_nonzero := rotated_zero_ne_zero count round (by omega) before
      rw [interior_step count degree stages mark _ phase_nonzero, advance_embed]
  have run := positive_reaches_iterate (compile count degree stages).advance
    (markedCompile count degree stages mark).step
    (embed count 0 (prepare left right ((degree : ℤ) * quotient + index.val))) count
    (Nat.pos_of_ne_zero (NeZero.ne count)) active
  rw [cycle_ofFn] at run
  exact run

/-- The exact phase-zero first return and its actual stopped-program execution certificate. -/
theorem cycle_firstReturn (stages : Fin count → Program degree) (mark : Fin degree → Bool)
    (left right quotient : ℤ) (index : Fin degree) (unmarked : mark index = false) :
    let initial := embed count 0 (prepare left right ((degree : ℤ) * quotient + index.val))
    let final := embed count 0 ((List.ofFn stages).foldl (fun point stage => stage.advance point)
      (prepare left right ((degree : ℤ) * quotient + index.val)))
    ((markedCompile count degree stages mark).advance)^[count] initial = final ∧
    PhaseBoundary count initial ∧ PhaseBoundary count final ∧
    (∀ round : ℕ, 0 < round → round < count →
      ¬ PhaseBoundary count (((markedCompile count degree stages mark).advance)^[round] initial)) ∧
    StateTransition.Reaches₁ (markedCompile count degree stages mark).step initial final := by
  dsimp only
  refine ⟨?_, ?_, ?_, ?_, cycle_reaches count degree stages mark left right quotient index unmarked⟩
  · rw [markedCompile_advance, cycle_ofFn]
  · exact (phaseBoundary_embed_iff count 0 _).mpr rfl
  · exact (phaseBoundary_embed_iff count 0 _).mpr rfl
  · intro round positive before
    exact cycle_interior count degree stages mark _ round positive before

end Monodromy.StagedProgram
