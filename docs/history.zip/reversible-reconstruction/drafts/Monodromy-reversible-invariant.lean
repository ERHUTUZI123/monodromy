import Monodromy.Counter

/-!
Invariant-relative completeness is a proof property of the source table.
The native word table and its static halting marks are unchanged.
-/

namespace Monodromy.Counter.Reversible

variable {n q e : ℕ}

/-- Every syntactically live address has an enabled edge on the stated invariant. -/
def CompleteOn (table : Table n q e) (invariant : State n q → Prop) : Prop :=
  ∀ state, invariant state → (∃ edge, (table edge).source = state.1) →
    ∃ edge, (table edge).enabled state

/-- Every defined source step preserves the stated invariant. -/
def Stable (table : Table n q e) (invariant : State n q → Prop) : Prop :=
  ∀ ⦃first last⦄, invariant first → step table first = some last → invariant last

theorem Complete.completeOn {table : Table n q e} (complete : Complete table)
    (invariant : State n q → Prop) : CompleteOn table invariant :=
  fun state _ outgoing => complete state outgoing

theorem step_none_iff_no_outgoing_on (table : Table n q e) (invariant : State n q → Prop)
    (complete : CompleteOn table invariant) (state : State n q) (valid : invariant state) :
    step table state = none ↔ ¬ ∃ edge, (table edge).source = state.1 := by
  rw [step_none_iff]
  constructor
  · intro halted outgoing
    exact halted (complete state valid outgoing)
  · rintro halted ⟨edge, enabled⟩
    exact halted ⟨edge, enabled.1⟩

end Monodromy.Counter.Reversible

namespace Monodromy.ReversibleCompilation

open Counter.Reversible CoupledContinuation

variable {q e : ℕ} [NeZero q]

/-- On the invariant, the existing static halting marks agree with source stopping. -/
theorem halting_at_iota_on (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (invariant : State 2 q → Prop)
    (complete : CompleteOn table invariant) (state : State 2 q) (valid : invariant state) :
    (haltingProgram table deterministic compatible).step (iota (e := e) state) = none ↔
      Counter.Reversible.step table state = none := by
  rw [Counter.Reversible.step_none_iff_no_outgoing_on table invariant complete state valid]
  unfold Program.step
  simp only [haltSignal_iota_iff]
  split_ifs <;> simp_all

/-- The invariant belongs to the simulation relation, rather than the runtime state. -/
theorem respects_on (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (invariant : State 2 q → Prop)
    (complete : CompleteOn table invariant) (stable : Stable table invariant) :
    StateTransition.Respects (Counter.Reversible.step table)
      (haltingProgram table deterministic compatible).step
      (fun original native => invariant original ∧ iota (e := e) original = native) := by
  intro state native related
  rcases related with ⟨valid, rfl⟩
  cases transition : Counter.Reversible.step table state with
  | none =>
      exact (halting_at_iota_on table deterministic compatible invariant complete state valid).mpr
        transition
  | some next =>
      exact ⟨iota (e := e) next, ⟨stable valid transition, rfl⟩,
        step_reaches table deterministic compatible transition⟩

/-- Every result and undefined computation is preserved from an invariant initial state. -/
theorem eval_iota_on (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (invariant : State 2 q → Prop)
    (complete : CompleteOn table invariant) (stable : Stable table invariant)
    (state : State 2 q) (valid : invariant state) :
    (haltingProgram table deterministic compatible).eval (iota (e := e) state) =
      iota (e := e) <$> Counter.Reversible.eval table state := by
  have simulation := respects_on table deterministic compatible invariant complete stable
  exact Part.ext fun final =>
    ⟨fun completed => by
      obtain ⟨source, related, result⟩ := StateTransition.tr_eval_rev simulation ⟨valid, rfl⟩ completed
      exact (Part.mem_map_iff _).mpr ⟨source, result, related.2⟩,
      fun completed => by
        obtain ⟨source, result, same⟩ := (Part.mem_map_iff _).mp completed
        obtain ⟨native, related, execution⟩ := StateTransition.tr_eval simulation ⟨valid, rfl⟩ result
        rw [← related.2, same] at execution
        exact execution⟩

theorem halting_iff_on (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (invariant : State 2 q → Prop)
    (complete : CompleteOn table invariant) (stable : Stable table invariant)
    (state : State 2 q) (valid : invariant state) :
    ((haltingProgram table deterministic compatible).eval (iota (e := e) state)).Dom ↔
      (Counter.Reversible.eval table state).Dom := by
  rw [eval_iota_on table deterministic compatible invariant complete stable state valid]
  rfl

theorem divergence_iff_on (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (invariant : State 2 q → Prop)
    (complete : CompleteOn table invariant) (stable : Stable table invariant)
    (state : State 2 q) (valid : invariant state) :
    ¬ ((haltingProgram table deterministic compatible).eval (iota (e := e) state)).Dom ↔
      ¬ (Counter.Reversible.eval table state).Dom :=
  not_congr (halting_iff_on table deterministic compatible invariant complete stable state valid)

end Monodromy.ReversibleCompilation
