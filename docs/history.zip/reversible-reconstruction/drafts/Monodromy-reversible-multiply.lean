import Monodromy.Counter

/-! Reversible fixed multiplication on the natural two-counter input domain. -/

namespace Monodromy.Counter.Reversible.Multiply

/-- Complementary tests at both loop heads keep every incoming port reversible. -/
def table (factor : ℕ) : Table 2 11 12 := ![
  ⟨0, 1, .test 1 true⟩,
  ⟨1, 2, .test 0 false⟩,
  ⟨2, 3, .shift 0 (-1)⟩,
  ⟨3, 4, .shift 1 factor⟩,
  ⟨4, 1, .test 1 false⟩,
  ⟨1, 5, .test 0 true⟩,
  ⟨5, 6, .test 0 true⟩,
  ⟨6, 7, .test 1 false⟩,
  ⟨7, 8, .shift 1 (-1)⟩,
  ⟨8, 9, .shift 0 1⟩,
  ⟨9, 6, .test 0 false⟩,
  ⟨6, 10, .test 1 true⟩]

theorem deterministic (factor : ℕ) : Deterministic (table factor) := by
  intro first second different same_source
  fin_cases first <;> fin_cases second <;>
    simp_all [table, Action.Compatible]

theorem targetCompatible (factor : ℕ) : TargetCompatible (table factor) := by
  intro first second different same_target
  fin_cases first <;> fin_cases second <;>
    simp_all [table, Action.Compatible]

/-- Only the two existing integer registers occur in the source configuration. -/
def point (position : Fin 11) (left right : ℤ) : State 2 11 :=
  (position, ![left, right])

/-- Natural counter values together with the domains of the guarded internal ports. -/
def Valid (state : State 2 11) : Prop :=
  0 ≤ state.2 0 ∧ 0 ≤ state.2 1 ∧
  (state.1 = 0 → state.2 1 = 0) ∧
  (state.1 = 2 → 0 < state.2 0) ∧
  (state.1 = 4 → state.2 1 ≠ 0) ∧
  (state.1 = 5 → state.2 0 = 0) ∧
  (state.1 = 7 → 0 < state.2 1) ∧
  (state.1 = 9 → state.2 0 ≠ 0)

theorem valid_input (input : ℕ) : Valid (point 0 input 0) := by
  simp [Valid, point]

theorem valid_output (output : ℕ) : Valid (point 10 output 0) := by
  simp [Valid, point]

/-- Every actual edge preserves the natural domain, including all singleton test guards. -/
theorem valid_step (factor : ℕ) (positive : 0 < factor) {first last : State 2 11}
    (valid : Valid first) (transition : step (table factor) first = some last) : Valid last := by
  obtain ⟨index, enabled, rfl⟩ := (step_iff (table factor) (deterministic factor)).mp transition
  rcases valid with ⟨left_nonnegative, right_nonnegative, entry, left_safe,
    consume_return, transfer_entry, right_safe, transfer_return⟩
  have factor_positive : 0 < (factor : ℤ) := by exact_mod_cast positive
  fin_cases index <;>
    simp_all [Valid, table, Edge.enabled, Edge.execute, Action.enabled, Action.apply] <;> omega

/-- Live finite control has an enabled edge throughout the invariant domain.
This is the pointwise form of CompleteOn, with no completeness claim outside Valid. -/
theorem completeOn (factor : ℕ) : CompleteOn (table factor) Valid := by
  rintro ⟨position, values⟩ valid outgoing
  fin_cases position <;>
    simp_all [Valid, Fin.exists_fin_succ, table, Edge.enabled, Action.enabled]
  all_goals exact (Classical.em _).symm

private theorem move (factor : ℕ) (index : Fin 12) (first last : State 2 11)
    (enabled : (table factor index).enabled first)
    (result : (table factor index).execute first = last) :
    StateTransition.Reaches (step (table factor)) first last := by
  apply Relation.ReflTransGen.single
  exact (step_iff (table factor) (deterministic factor)).mpr ⟨index, enabled, result⟩

/-- One pass consumes one unit of the first register and adds the fixed factor to the second. -/
theorem consume_cycle (factor input accumulator : ℕ) (positive : 0 < factor) :
    StateTransition.Reaches (step (table factor))
      (point 1 (input + 1 : ℕ) accumulator) (point 1 input (accumulator + factor : ℕ)) := by
  have first : StateTransition.Reaches (step (table factor))
      (point 1 (input + 1 : ℕ) accumulator) (point 2 (input + 1 : ℕ) accumulator) := by
    apply move factor 1
    · simp [table, Edge.enabled, Action.enabled, point]
      omega
    · rfl
  have second : StateTransition.Reaches (step (table factor))
      (point 2 (input + 1 : ℕ) accumulator) (point 3 input accumulator) := by
    apply move factor 2
    · simp [table, Edge.enabled, Action.enabled, point]
    · apply Prod.ext
      · rfl
      · funext register
        fin_cases register <;> simp [table, Edge.execute, Action.apply, point]
  have third : StateTransition.Reaches (step (table factor))
      (point 3 input accumulator) (point 4 input (accumulator + factor : ℕ)) := by
    apply move factor 3
    · simp [table, Edge.enabled, Action.enabled, point]
    · apply Prod.ext
      · rfl
      · funext register
        fin_cases register <;> simp [table, Edge.execute, Action.apply, point]
  have fourth : StateTransition.Reaches (step (table factor))
      (point 4 input (accumulator + factor : ℕ)) (point 1 input (accumulator + factor : ℕ)) := by
    apply move factor 4
    · simp [table, Edge.enabled, Action.enabled, point]
      omega
    · rfl
  exact first.trans (second.trans (third.trans fourth))

/-- The first loop transfers exactly the indicated natural amount. -/
theorem consume (factor input accumulator : ℕ) (positive : 0 < factor) :
    StateTransition.Reaches (step (table factor))
      (point 1 input accumulator) (point 1 0 (accumulator + factor * input : ℕ)) := by
  change Relation.ReflTransGen (fun first last => last ∈ step (table factor) first) _ _
  induction input generalizing accumulator with
  | zero => simp only [Nat.mul_zero, Nat.add_zero]; exact Relation.ReflTransGen.refl
  | succ input induction =>
      have run := (consume_cycle factor input accumulator positive).trans
        (induction (accumulator + factor))
      have arithmetic : accumulator + factor + factor * input = accumulator + factor * (input + 1) := by ring
      rw [arithmetic] at run
      exact run

/-- One transfer pass moves a unit back to the first register. -/
theorem transfer_cycle (factor input accumulator : ℕ) :
    StateTransition.Reaches (step (table factor))
      (point 6 accumulator (input + 1 : ℕ)) (point 6 (accumulator + 1 : ℕ) input) := by
  have first : StateTransition.Reaches (step (table factor))
      (point 6 accumulator (input + 1 : ℕ)) (point 7 accumulator (input + 1 : ℕ)) := by
    apply move factor 7
    · simp [table, Edge.enabled, Action.enabled, point]
      omega
    · rfl
  have second : StateTransition.Reaches (step (table factor))
      (point 7 accumulator (input + 1 : ℕ)) (point 8 accumulator input) := by
    apply move factor 8
    · simp [table, Edge.enabled, Action.enabled, point]
    · apply Prod.ext
      · rfl
      · funext register
        fin_cases register <;> simp [table, Edge.execute, Action.apply, point]
  have third : StateTransition.Reaches (step (table factor))
      (point 8 accumulator input) (point 9 (accumulator + 1 : ℕ) input) := by
    apply move factor 9
    · simp [table, Edge.enabled, Action.enabled, point]
    · apply Prod.ext
      · rfl
      · funext register
        fin_cases register <;> simp [table, Edge.execute, Action.apply, point]
  have fourth : StateTransition.Reaches (step (table factor))
      (point 9 (accumulator + 1 : ℕ) input) (point 6 (accumulator + 1 : ℕ) input) := by
    apply move factor 10
    · simp [table, Edge.enabled, Action.enabled, point]
      omega
    · rfl
  exact first.trans (second.trans (third.trans fourth))

theorem transfer (factor input accumulator : ℕ) :
    StateTransition.Reaches (step (table factor))
      (point 6 accumulator input) (point 6 (accumulator + input : ℕ) 0) := by
  change Relation.ReflTransGen (fun first last => last ∈ step (table factor) first) _ _
  induction input generalizing accumulator with
  | zero => simp only [Nat.add_zero]; exact Relation.ReflTransGen.refl
  | succ input induction =>
      have run := (transfer_cycle factor input accumulator).trans (induction (accumulator + 1))
      have arithmetic : accumulator + 1 + input = accumulator + (input + 1) := by omega
      rw [arithmetic] at run
      exact run

/-- Exact terminating multiplication, on the natural input domain with empty workspace. -/
theorem reaches_result (factor input : ℕ) (positive : 0 < factor) :
    StateTransition.Reaches (step (table factor)) (point 0 input 0) (point 10 (factor * input : ℕ) 0) := by
  have entry : StateTransition.Reaches (step (table factor)) (point 0 input 0) (point 1 input 0) := by
    apply move factor 0
    · simp [table, Edge.enabled, Action.enabled, point]
    · rfl
  have middle : StateTransition.Reaches (step (table factor))
      (point 1 0 (factor * input : ℕ)) (point 6 0 (factor * input : ℕ)) := by
    have first : StateTransition.Reaches (step (table factor))
        (point 1 0 (factor * input : ℕ)) (point 5 0 (factor * input : ℕ)) := by
      apply move factor 5
      · simp [table, Edge.enabled, Action.enabled, point]
      · rfl
    apply first.trans
    apply move factor 6
    · simp [table, Edge.enabled, Action.enabled, point]
    · rfl
  have finish : StateTransition.Reaches (step (table factor))
      (point 6 (factor * input : ℕ) 0) (point 10 (factor * input : ℕ) 0) := by
    apply move factor 11
    · simp [table, Edge.enabled, Action.enabled, point]
    · rfl
  have consumption := consume factor input 0 positive
  have transfer := transfer factor (factor * input) 0
  simp only [zero_add] at consumption transfer
  exact entry.trans (consumption.trans (middle.trans (transfer.trans finish)))

/-- Entry and exit are distinct, so the constructed execution has positive length. -/
theorem reaches_positive (factor input : ℕ) (positive : 0 < factor) :
    StateTransition.Reaches₁ (step (table factor))
      (point 0 input 0) (point 10 (factor * input : ℕ) 0) := by
  rcases Relation.reflTransGen_iff_eq_or_transGen.mp (reaches_result factor input positive) with
    same | run
  · have impossible := congrArg Prod.fst same
    norm_num [point] at impossible
  · exact run

theorem halt_result (factor input : ℕ) : step (table factor) (point 10 input 0) = none := by
  rw [step_none_iff]
  rintro ⟨index, enabled⟩
  fin_cases index <;> simp_all [table, Edge.enabled, point]

theorem eval_result (factor input : ℕ) (positive : 0 < factor) :
    eval (table factor) (point 0 input 0) = Part.some (point 10 (factor * input : ℕ) 0) := by
  apply Part.eq_some_iff.mpr
  exact StateTransition.mem_eval.mpr ⟨reaches_result factor input positive, halt_result factor _⟩

/-- The unchanged three-root geometric compiler performs the same reversible multiplication. -/
theorem native_eval (factor input : ℕ) (positive : 0 < factor) :
    (ReversibleCompilation.haltingProgram (table factor) (deterministic factor)
      (targetCompatible factor)).eval (ReversibleCompilation.iota (e := 12) (point 0 input 0)) =
      Part.some (ReversibleCompilation.iota (e := 12) (point 10 (factor * input : ℕ) 0)) := by
  have stable : Stable (table factor) Valid := by
    intro first last valid transition
    exact valid_step factor positive valid transition
  rw [ReversibleCompilation.eval_iota_on (table factor) (deterministic factor)
    (targetCompatible factor) Valid (completeOn factor) stable _ (valid_input input),
    eval_result factor input positive]
  rfl

end Monodromy.Counter.Reversible.Multiply
