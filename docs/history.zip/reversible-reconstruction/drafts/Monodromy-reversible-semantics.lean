import «Monodromy-reversible-compiler»

/-! Static halting marks and complete source semantics for the native reversible compiler.
The source registers are integers. Completeness makes halting a finite control property.
-/
noncomputable section

namespace Monodromy.ReversibleCompilation

open Counter.Reversible CoupledContinuation

variable {q e : ℕ} [NeZero q]

/-- This finite bit table examines only static source edges, never current register values. -/
def haltMark (table : Table 2 q e) (address : Fin (q + e)) : Bool :=
  match finSumFinEquiv.symm address with
  | .inl position => decide (¬ ∃ edge, (table edge).source = position)
  | .inr _ => false

omit [NeZero q] in
@[simp] theorem haltMark_source (table : Table 2 q e) (position : Fin q) :
    haltMark table (Fin.castAdd e position) =
      decide (¬ ∃ edge, (table edge).source = position) := by
  simp [haltMark]

omit [NeZero q] in
@[simp] theorem haltMark_port (table : Table 2 q e) (edge : Fin e) :
    haltMark table (Fin.natAdd q edge) = false := by
  simp [haltMark]

/-- Only stopping bits change; the entire fixed geometric word table is retained. -/
def haltingProgram (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) : Program (11 * (q + e)) :=
  StagedProgram.markedCompile 11 (q + e) (stages table deterministic compatible) (haltMark table)

@[simp] theorem haltingProgram_advance (table : Table 2 q e)
    (deterministic : Deterministic table) (compatible : TargetCompatible table) :
    (haltingProgram table deterministic compatible).advance = (program table deterministic compatible).advance := rfl

theorem haltingProgram_bijective (table : Table 2 q e)
    (deterministic : Deterministic table) (compatible : TargetCompatible table) :
    Function.Bijective (haltingProgram table deterministic compatible).advance := by
  rw [haltingProgram_advance]
  exact program_bijective table deterministic compatible

theorem haltSignal_iota (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (state : State 2 q) :
    (haltingProgram table deterministic compatible).haltSignal (iota (e := e) state) =
      if haltMark table (Fin.castAdd e state.1) then 1 else 0 := by
  have actual := StagedProgram.haltSignal_embed 11 (q + e)
    (stages table deterministic compatible) (haltMark table)
    (state.2 0) (state.2 1) 0 (Fin.castAdd e state.1) 0
  simpa only [haltingProgram, iota, sourcePoint, point, mul_zero, zero_add, ite_true] using actual

theorem haltSignal_iota_iff (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (state : State 2 q) :
    (haltingProgram table deterministic compatible).haltSignal (iota (e := e) state) = 1 ↔
      ¬ ∃ edge, (table edge).source = state.1 := by
  rw [haltSignal_iota, haltMark_source]
  by_cases outgoing : ∃ edge, (table edge).source = state.1 <;> simp [outgoing]

/-- Completeness is the explicit hypothesis identifying finite address halting with source halting. -/
theorem halting_at_iota (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (complete : Complete table) (state : State 2 q) :
    (haltingProgram table deterministic compatible).step (iota (e := e) state) = none ↔
      Counter.Reversible.step table state = none := by
  rw [Counter.Reversible.step_none_iff_no_outgoing table complete]
  unfold Program.step
  simp only [haltSignal_iota_iff]
  split_ifs <;> simp_all

/-- Every live source transition is a positive sequence of the actual stopped native returns. -/
theorem step_reaches (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) {first last : State 2 q}
    (transition : Counter.Reversible.step table first = some last) :
    StateTransition.Reaches₁ (haltingProgram table deterministic compatible).step
      (iota (e := e) first) (iota (e := e) last) := by
  obtain ⟨edge, enabled, _⟩ := (Counter.Reversible.step_iff table deterministic).mp transition
  have outgoing : ∃ edge, (table edge).source = first.1 := ⟨edge, enabled.1⟩
  have unmarked : haltMark table (Fin.castAdd e first.1) = false := by
    simp [haltMark_source, outgoing]
  have run := StagedProgram.cycle_reaches 11 (q + e)
    (stages table deterministic compatible) (haltMark table)
    (first.2 0) (first.2 1) 0 (Fin.castAdd e first.1) unmarked
  have ending :
      StagedProgram.embed 11 0
        ((List.ofFn (stages table deterministic compatible)).foldl
          (fun point stage => stage.advance point) (sourcePoint (e := e) first)) =
      iota (e := e) last :=
    (StagedProgram.cycle_ofFn 11 (q + e) (stages table deterministic compatible)
      (sourcePoint (e := e) first)).symm.trans
      (cycle_step table deterministic compatible transition)
  have actual :
      StateTransition.Reaches₁ (haltingProgram table deterministic compatible).step
        (iota (e := e) first)
        (StagedProgram.embed 11 0
          ((List.ofFn (stages table deterministic compatible)).foldl
            (fun point stage => stage.advance point) (sourcePoint (e := e) first))) := by
    simpa only [haltingProgram, iota, sourcePoint, point, mul_zero, zero_add] using run
  rw [ending] at actual
  exact actual

theorem respects (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (complete : Complete table) :
    StateTransition.Respects (Counter.Reversible.step table)
      (haltingProgram table deterministic compatible).step
      (fun original native => iota (e := e) original = native) := by
  apply StateTransition.fun_respects.mpr
  intro state
  cases transition : Counter.Reversible.step table state with
  | none => exact (halting_at_iota table deterministic compatible complete state).mpr transition
  | some next => exact step_reaches table deterministic compatible transition

/-- The entire final integer configuration, and undefinedness, are preserved. -/
theorem eval_iota (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (complete : Complete table) (state : State 2 q) :
    (haltingProgram table deterministic compatible).eval (iota (e := e) state) =
      iota (e := e) <$> Counter.Reversible.eval table state :=
  StateTransition.tr_eval' (Counter.Reversible.step table)
    (haltingProgram table deterministic compatible).step (iota (e := e))
    (respects table deterministic compatible complete) state

theorem halting_iff (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (complete : Complete table) (state : State 2 q) :
    ((haltingProgram table deterministic compatible).eval (iota (e := e) state)).Dom ↔
      (Counter.Reversible.eval table state).Dom := by
  rw [eval_iota table deterministic compatible complete]
  rfl

theorem divergence_iff (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (complete : Complete table) (state : State 2 q) :
    ¬ ((haltingProgram table deterministic compatible).eval (iota (e := e) state)).Dom ↔
      ¬ (Counter.Reversible.eval table state).Dom :=
  not_congr (halting_iff table deterministic compatible complete state)

theorem result (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (complete : Complete table) {first last : State 2 q}
    (completed : last ∈ Counter.Reversible.eval table first) :
    iota (e := e) last ∈ (haltingProgram table deterministic compatible).eval (iota (e := e) first) := by
  rw [eval_iota table deterministic compatible complete]
  exact (Part.mem_map_iff _).mpr ⟨last, completed, rfl⟩

theorem result_iff (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (complete : Complete table) (first last : State 2 q) :
    iota (e := e) last ∈ (haltingProgram table deterministic compatible).eval (iota (e := e) first) ↔
      last ∈ Counter.Reversible.eval table first := by
  rw [eval_iota table deterministic compatible complete]
  constructor
  · intro found
    obtain ⟨source, completed, same⟩ := (Part.mem_map_iff _).mp found
    have recovered := iota_injective same
    simpa only [recovered] using completed
  · intro completed
    exact (Part.mem_map_iff _).mpr ⟨last, completed, rfl⟩

/-- Eleven actual native returns form the first positive phase-zero return. -/
theorem step_firstReturn (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) {first last : State 2 q}
    (transition : Counter.Reversible.step table first = some last) :
    ((haltingProgram table deterministic compatible).advance)^[11] (iota (e := e) first) =
        iota (e := e) last ∧
      StagedProgram.PhaseBoundary 11 (iota (e := e) first) ∧
      StagedProgram.PhaseBoundary 11 (iota (e := e) last) ∧
      (∀ round : ℕ, 0 < round → round < 11 →
        ¬ StagedProgram.PhaseBoundary 11
          (((haltingProgram table deterministic compatible).advance)^[round] (iota (e := e) first))) ∧
      StateTransition.Reaches₁ (haltingProgram table deterministic compatible).step
        (iota (e := e) first) (iota (e := e) last) := by
  refine ⟨?_, ?_, ?_, ?_, step_reaches table deterministic compatible transition⟩
  · rw [haltingProgram_advance]
    exact cycle_step table deterministic compatible transition
  · exact (StagedProgram.phaseBoundary_embed_iff 11 0 (sourcePoint (e := e) first)).mpr rfl
  · exact (StagedProgram.phaseBoundary_embed_iff 11 0 (sourcePoint (e := e) last)).mpr rfl
  · intro round positive before
    exact StagedProgram.cycle_interior 11 (q + e) (stages table deterministic compatible)
      (haltMark table) (sourcePoint (e := e) first) round positive before

/-- A complete result is realized by the two actual covering lifts of the native generated path. -/
theorem result_actual_lifts (table : Table 2 q e) (deterministic : Deterministic table)
    (compatible : TargetCompatible table) (complete : Complete table) {first last : State 2 q}
    (completed : last ∈ Counter.Reversible.eval table first) :
    ∃ count : ℕ,
      let initial := iota (e := e) first
      let driver := (haltingProgram table deterministic compatible).runDriver count initial
      intermediateCurve driver initial =
        CoupledPullback.lowerCovering.liftPath driver.restrictedPath
          (CoupledPullback.upperProjection (restrictedState initial))
          (driver.restrictedPath.source.trans (restrictedState_over_base initial).symm) ∧
      restrictedTrajectory driver initial =
        CoupledPullback.upperCovering.liftPath (intermediatePath driver initial) (restrictedState initial)
          (intermediatePath driver initial).source ∧
      restrictedTrajectory driver initial 1 = restrictedState (iota (e := e) last) := by
  obtain ⟨count, endpoint⟩ := (haltingProgram table deterministic compatible).runDriver_of_eval
    (result table deterministic compatible complete completed)
  refine ⟨count, ?_⟩
  dsimp only
  refine ⟨intermediateCurve_actual_lift _ _, restrictedTrajectory_actual_lift _ _, ?_⟩
  rw [restrictedTrajectory_end, endpoint]

end Monodromy.ReversibleCompilation
