import «Monodromy-reversible-ports»

/-! Guarded finite port matchings execute through the existing native words. -/

namespace Monodromy.ReversibleRouting

open CoupledContinuation Counter.Reversible ReversiblePorts

variable {q e : ℕ} [NeZero (q + e)]

/-- Alternatives attached to a common owner are complementary unchanged tests. -/
def CompatibleOwner (table : Table 2 q e) (owner : Fin e → Fin q) : Prop :=
  ∀ first second, first ≠ second → owner first = owner second →
    Action.Compatible (table first).action (table second).action

variable (table : Table 2 q e) (owner : Fin e → Fin q)
  (matching : ∀ guard, Matching owner (selected table guard))

/-- This stage contains only a fixed guard and its static finite port permutation. -/
def route (guard : ReversibleControl.Guard) : Program (q + e) :=
  ReversibleControl.program guard (permutation owner (selected table guard) (matching guard))

/-- Head-first execution of actual native return maps. -/
noncomputable def run (stages : List ReversibleControl.Guard) (state : Memory) : Memory :=
  stages.foldl (fun current guard => (route table owner matching guard).advance current) state

@[simp] theorem run_nil (state : Memory) : run table owner matching [] state = state := rfl

@[simp] theorem run_cons (guard : ReversibleControl.Guard)
    (stages : List ReversibleControl.Guard) (state : Memory) :
    run table owner matching (guard :: stages) state =
      run table owner matching stages ((route table owner matching guard).advance state) := rfl

/-- Only the finite address is abbreviated; the retained state is the same three roots. -/
noncomputable def point (values : Fin 2 → ℤ) (index : Fin (q + e)) : Memory :=
  prepare (values 0) (values 1) (index.val : ℤ)

theorem route_prepare (guard : ReversibleControl.Guard) (values : Fin 2 → ℤ)
    (index : Fin (q + e)) :
    (route table owner matching guard).advance (point values index) =
      if ReversibleControl.enabled guard (values 0) (values 1) then
        point values (permutation owner (selected table guard) (matching guard) index)
      else point values index := by
  simpa only [route, point, mul_zero, zero_add] using
    ReversibleControl.advance_prepare guard
      (permutation owner (selected table guard) (matching guard)) (values 0) (values 1) 0 index

theorem route_bijective (guard : ReversibleControl.Guard) :
    Function.Bijective (route table owner matching guard).advance :=
  (ReversibleControl.executionEquiv guard
    (permutation owner (selected table guard) (matching guard))).bijective

/-- The same actual native route reverses itself on the entire state fiber. -/
theorem route_involutive (guard : ReversibleControl.Guard) :
    Function.Involutive (route table owner matching guard).advance := by
  let pairing := permutation owner (selected table guard) (matching guard)
  have symmetry : pairing.symm = pairing := by
    apply Equiv.ext
    intro index
    apply pairing.injective
    calc
      pairing (pairing.symm index) = index := pairing.apply_symm_apply index
      _ = pairing (pairing index) :=
        (permutation_involutive owner (selected table guard) (matching guard) index).symm
  intro state
  change (ReversibleControl.program guard pairing).advance
    ((ReversibleControl.program guard pairing).advance state) = state
  simpa only [symmetry] using ReversibleControl.inverse guard pairing state

omit [NeZero (q + e)] in
/-- A different guard cannot activate any alternative at the enabled edge's owner. -/
theorem off_guard_owner (compatible : CompatibleOwner table owner)
    (values : Fin 2 → ℤ) (edge : Fin e) (enabled : (table edge).action.enabled values)
    (guard : ReversibleControl.Guard) (different : actionGuard (table edge).action ≠ guard)
    (active : ReversibleControl.enabled guard (values 0) (values 1) = true) :
    ∀ other, selected table guard other = true → owner other ≠ owner edge := by
  intro other chosen same_owner
  have other_guard := (selected_iff table guard other).mp chosen
  have other_enabled : (table other).action.enabled values :=
    (guard_enabled_iff (table other).action values).mp (other_guard ▸ active)
  have distinct : other ≠ edge := by
    intro same
    subst other
    exact different other_guard
  exact (compatible other edge distinct same_owner).not_both values ⟨other_enabled, enabled⟩

theorem route_owner (compatible : CompatibleOwner table owner) (values : Fin 2 → ℤ)
    (edge : Fin e) (enabled : (table edge).action.enabled values)
    (guard : ReversibleControl.Guard) :
    (route table owner matching guard).advance (point values (Fin.castAdd e (owner edge))) =
      if actionGuard (table edge).action = guard then point values (Fin.natAdd q edge)
      else point values (Fin.castAdd e (owner edge)) := by
  rw [route_prepare]
  by_cases chosen : actionGuard (table edge).action = guard
  · have active : ReversibleControl.enabled guard (values 0) (values 1) = true :=
      chosen ▸ (guard_enabled_iff (table edge).action values).mpr enabled
    rw [ite_eq_left active, ite_eq_left chosen,
      permutation_owner owner (selected table guard) (matching guard) edge
        ((selected_iff table guard edge).mpr chosen)]
  · rw [ite_eq_right chosen]
    by_cases active : ReversibleControl.enabled guard (values 0) (values 1) = true
    · rw [ite_eq_left active,
        permutation_fixed_owner owner (selected table guard) (matching guard) (owner edge)
          (off_guard_owner table owner compatible values edge enabled guard chosen active)]
    · rw [ite_eq_right active]

theorem route_port (values : Fin 2 → ℤ) (edge : Fin e)
    (enabled : (table edge).action.enabled values) (guard : ReversibleControl.Guard) :
    (route table owner matching guard).advance (point values (Fin.natAdd q edge)) =
      if actionGuard (table edge).action = guard then point values (Fin.castAdd e (owner edge))
      else point values (Fin.natAdd q edge) := by
  rw [route_prepare]
  by_cases chosen : actionGuard (table edge).action = guard
  · have active : ReversibleControl.enabled guard (values 0) (values 1) = true :=
      chosen ▸ (guard_enabled_iff (table edge).action values).mpr enabled
    rw [ite_eq_left active, permutation_port, ite_eq_left ((selected_iff table guard edge).mpr chosen),
      ite_eq_left chosen]
  · rw [ite_eq_right chosen]
    by_cases active : ReversibleControl.enabled guard (values 0) (values 1) = true
    · rw [ite_eq_left active, permutation_port]
      have unselected : selected table guard edge = false := by simpa [selected] using chosen
      rw [unselected]
      rfl
    · rw [ite_eq_right active]

/-- A guard occurring once exchanges precisely the enabled owner and its edge port. -/
theorem run_pair (compatible : CompatibleOwner table owner) (values : Fin 2 → ℤ)
    (edge : Fin e) (enabled : (table edge).action.enabled values)
    (stages : List ReversibleControl.Guard) (distinct : stages.Nodup) :
    (run table owner matching stages (point values (Fin.castAdd e (owner edge))) =
      if actionGuard (table edge).action ∈ stages then point values (Fin.natAdd q edge)
      else point values (Fin.castAdd e (owner edge))) ∧
    (run table owner matching stages (point values (Fin.natAdd q edge)) =
      if actionGuard (table edge).action ∈ stages then point values (Fin.castAdd e (owner edge))
      else point values (Fin.natAdd q edge)) := by
  induction stages with
  | nil => simp
  | cons guard stages induction_hypothesis =>
      obtain ⟨not_member, rest_distinct⟩ := List.nodup_cons.mp distinct
      obtain ⟨owner_run, port_run⟩ := induction_hypothesis rest_distinct
      by_cases chosen : actionGuard (table edge).action = guard
      · constructor
        · rw [run_cons, route_owner table owner matching compatible values edge enabled,
            ite_eq_left chosen, port_run]
          simp [chosen, not_member]
        · rw [run_cons, route_port table owner matching values edge enabled,
            ite_eq_left chosen, owner_run]
          simp [chosen, not_member]
      · constructor
        · rw [run_cons, route_owner table owner matching compatible values edge enabled,
            ite_eq_right chosen, owner_run]
          simp [chosen]
        · rw [run_cons, route_port table owner matching values edge enabled,
            ite_eq_right chosen, port_run]
          simp [chosen]

/-- All five stages send an enabled source or target owner to its exact edge port. -/
theorem run_owner (compatible : CompatibleOwner table owner) (values : Fin 2 → ℤ)
    (edge : Fin e) (enabled : (table edge).action.enabled values) :
    run table owner matching guards (point values (Fin.castAdd e (owner edge))) =
      point values (Fin.natAdd q edge) := by
  have result := (run_pair table owner matching compatible values edge enabled guards guards_distinct).1
  simpa only [ite_eq_left (guards_exhaustive _)] using result

/-- Reverse stage order returns the edge port to its owner with both memories unchanged. -/
theorem run_port (compatible : CompatibleOwner table owner) (values : Fin 2 → ℤ)
    (edge : Fin e) (enabled : (table edge).action.enabled values) :
    run table owner matching guards.reverse (point values (Fin.natAdd q edge)) =
      point values (Fin.castAdd e (owner edge)) := by
  have result := (run_pair table owner matching compatible values edge enabled guards.reverse
    (List.nodup_reverse.mpr guards_distinct)).2
  simpa only [List.mem_reverse, ite_eq_left (guards_exhaustive _)] using result

end Monodromy.ReversibleRouting

#print axioms Monodromy.ReversibleRouting.route_bijective
#print axioms Monodromy.ReversibleRouting.run_pair
#print axioms Monodromy.ReversibleRouting.run_owner
#print axioms Monodromy.ReversibleRouting.run_port

#print axioms Monodromy.ReversibleRouting.route_involutive
