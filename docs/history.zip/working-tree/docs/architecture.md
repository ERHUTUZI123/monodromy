# Monodromy — 原生延拓

**保留根是状态，基路径是程序，实际提升产生下一状态。**

当前核心 [Continuation.lean](../src/Monodromy/Continuation.lean) 使用三个持久复坐标：两个下层记忆根与一个上层控制根。所有操作共享同一覆盖关系。

## 同一个几何对象

令 \(Y=\mathbb C\setminus\{0,1\}\)，\(D=\exp^{-1}(Y)\)。两层匹配的覆盖为
\[
(D\times D)\times\mathbb C
\xrightarrow{p}(D\times D)\times\mathbb C^*
\xrightarrow{q}(Y\times Y)\times\mathbb C^*,
\]
其中
\[
p(w_1,w_2,z)=\left(w_1,w_2,\frac{e^z}{w_1w_2}\right),\qquad
q(w_1,w_2,v)=(e^{w_1},e^{w_2},v).
\]

上层是指数覆盖的连续拉回，下层是两个限制指数覆盖与恒等覆盖的乘积。`CoupledPullback.upperCovering`、`lowerCovering` 分别验证它们。拉回关系中的 \(v\) 由三个根唯一决定；同胚 `chart` 将它消去。

复合投影为
\[
F(w_1,w_2,z)=\left(e^{w_1},e^{w_2},\frac{e^z}{w_1w_2}\right).
\]
状态是基点 \((e,e,1)\) 上的整个纤维。每个状态恰有唯一表示
\[
w_j=1+2\pi i k_j,\qquad z=\log w_1+\log w_2+2\pi i m,
\quad(k_1,k_2,m)\in\mathbb Z^3.
\]
`prepare_surjective` 与 `prepare_injective` 证明这一完整性。整数标签用于初始化与描述结果；执行直接接收保留的三个复根。

## 路径怎样执行

`Driver` 给出基回路 \((u_1,u_2,v)\)。运行先实际提升 \(u_1,u_2\)，得到 \(w_1(t),w_2(t)\)，再生成上层输入
\[
\eta(t)=v(t)w_1(t)w_2(t).
\]
第二次实际指数提升产生 \(z(t)\)，`execute` 保留三个实际终根。

`intermediateCurve_actual_lift` 与 `restrictedTrajectory_actual_lift` 将完整运行曲线分别识别为匹配下层、上层覆盖的 Mathlib `liftPath`。起点、每个时刻的投影关系与实际终点均有定理。显式轨迹只用于提升唯一性的证明。

## 五个固定回路

在一个下层坐标使用
\[
A(t)=\exp(1+2\pi it),\qquad B(t)=\exp(e^{2\pi it}),
\]
其他基坐标保持不动，得到 \(A_1,A_2,B_1,B_2\)。第三个基坐标绕单位圆一次，得到 \(C\)。实际执行满足
\[
\begin{aligned}
A_1 &: (k_1,k_2,m)\mapsto(k_1+1,k_2,m),\\
A_2 &: (k_1,k_2,m)\mapsto(k_1,k_2+1,m),\\
B_j &: (k_1,k_2,m)\mapsto(k_1,k_2,m+\mathbf1_{k_j=0}),\\
C &: (k_1,k_2,m)\mapsto(k_1,k_2,m+1).
\end{aligned}
\]

条件写入来自下层实际提升的绕行：\(B\) 提升为以 \(2\pi i k_j\) 为中心的单位圆，仅零分支绕过上层对数的缺点。对应定理为 `execute_A_left/right`、`execute_B_left/right`、`execute_control_prepare`。

一个手算实例为
\[
(-1,1,0)\xrightarrow{A_1}(0,1,0)\xrightarrow{B_1}(0,1,1)
\xrightarrow{B_2}(0,1,1)\xrightarrow{A_2^{-1}}(0,0,1)
\xrightarrow{B_2}(0,0,2).
\]
`example_run` 与 `example_reverse` 验证整个路径词及其逆。一般串接与双向恢复由 `execute_driver_trans`、`execute_driver_reverse`、`execute_after_driver_reverse` 从提升唯一性导出。

`execute_homotopic` 证明完整状态只依赖允许基空间内的端点固定同伦类。两层实际提升将这一不变性传递到全部保留根。

## 根怎样选择下一条路径

固定正整数 \(N\)，读取
\[
\rho_N(w_1,w_2,z)=\exp\!\left(\frac{z-\log w_1-\log w_2}{N}\right).
\]
整个返回纤维上都有 \(\rho_N^N=1\)。有限幂覆盖的归一化核在这些根上恰为零或一，因此固定有限路径表产生整条基路径
\[
\gamma_s(t)=\sum_{j<N}K_j(\rho_N(s))\,\gamma_j(t),
\]
逐坐标取和。`routeDriver_eq` 证明它全程等于其中一条合法路径；`executeRouted` 随后调用同一个实际提升执行器。`executeRouted_prepare` 给出控制标签 \(Nq+j\) 的精确路由。

这里 \(m\) 仍是无界整数，有限的是控制观察。下层返回根的实部均为一，`analyticAt_control_observation` 证明读出在每个返回态附近具有复解析延伸。执行采用精确根与离散返回语义；纤维外混合路径的安全性、数值误差和单一自治流属于后续问题。

## 可逆反馈

原生条件写入、内部有限根路由与固定路径组合已经闭合。表项保持控制根时，`routedEquiv` 给出整表的双向逆；随后组合任意固定条件门，`feedbackEquiv` 仍为整个几何纤维上的双射。其逆先反向执行条件门，再由恢复的控制根选择反向表项。

两项表 \(A_1,A_2\) 接条件门 \(B_1\)，产生
\[
(-1,0,0)\longmapsto(0,0,1)\longmapsto(0,1,2).
\]
第一次写入改变控制根，第二次因此选择另一侧记忆操作。`shiftFeedback_two_steps` 验证这段完整内部反馈，全部信息保留于原有三个根。一般路径表的可逆性仍取决于相应控制条件。

## 有限程序与计算能力

`Word` 是五回路的有限有符号词，`Program` 是有限词表与有限停止根表。运行通过当前控制根选择整条基路径，并在标记的根上停止。整数位移 \(d\) 展开为 \(|d|\) 次控制绕行；`Word.inverse` 给出等长逆程序。

[Counter.lean](../src/Monodromy/Counter.lean) 中的 `CounterContinuation.compile` 将任意有限双计数器程序编译为这些路径词。源地址 \(q\) 与两个中间阶段使用同一控制分支中的 \(3q,3q+1,3q+2\)。每个活动源步骤恰经过两次原生返回，各返回包含预先固定的有限词；中间阶段继续执行。

`encode_injective`、`step_bind_step_encode` 与 `eval_encode` 分别证明完整配置的单射表示、单步交换等式，以及
\[
\operatorname{eval}_{P}(\iota c)=\iota_*\operatorname{eval}_{M}(c).
\]
这是完整部分结果的等式，因而同时保留结果、停机与发散。自然数计数器的零分支与正分支由实际条件门区分。

[Effectiveness.lean](../src/Monodromy/Effectiveness.lean) 为固定有限词和程序表给出原始递归整数解释，并证明它与完整实际执行一致。`Program.partrec_with_io` 得到固定原始递归输入输出映射下的部分递归上界。算术解释处于后继证明层；执行核心依赖覆盖与实际提升。

[ForwardBoundary.lean](../src/Monodromy/ForwardBoundary.lean) 证明删除两个条件门及其逆后，控制余数形成自主演化的有限商；少于控制度数次的返回观察即可决定停机。另一方面，仅含固定词 \([B_1]\) 的 `zeroTest` 在输入 \(\operatorname{prepare}(n,0,0)\) 上恰于 \(n=0\) 时停机。同一输入表示下，删门子语言无法实现该停机域。这给出固定接口下的严格表达能力分离。

## 下一段证明

当前集中连接任意图灵机与双计数器机的经典归约，以完成新原生执行的图灵通用性总定理。几何、回路和三个状态坐标保持固定。经典源编码与算术宏作为证明层构造逐步核验。

旧有限覆盖演算的图灵模拟、部分递归函数刻画和 Forward 分离继续保留，范围见 [structure.md](structure.md)。它们与当前原生路径词演算分别记录。

## 文件归属

- [Covering.lean](../src/Monodromy/Covering.lean)：一般输运、提升唯一性、拉回与积覆盖。
- [Logarithm.lean](../src/Monodromy/Logarithm.lean)：原有对数数学与两层指数提升的基础实例，公开名称和证明保留。
- [Continuation.lean](../src/Monodromy/Continuation.lean)：统一三根几何、实际执行、固定回路与内部根路由。
- [Counter.lean](../src/Monodromy/Counter.lean)：双计数器语义、有限几何编译与完整模拟。
- [Effectiveness.lean](../src/Monodromy/Effectiveness.lean)、[ForwardBoundary.lean](../src/Monodromy/ForwardBoundary.lean)：递归解释与可证明的子语言边界。

当前核心替换旧执行机制，Lean 模块总数仍为 44。四根模型、已有证明与两篇稿件保持冻结。此前候选与失败证据集中于本机[研究证据包](/tmp/Monodromy-A-evidence.zip)。
