# 现在

**四项验收已通过；统一三根几何已完成有限词执行、内部反馈、双计数器完整模拟与递归上界。**

[Continuation.lean](../src/Monodromy/Continuation.lean) 的统一投影为
\[
F(w_1,w_2,z)=\left(e^{w_1},e^{w_2},\frac{e^z}{w_1w_2}\right).
\]
运行先做两条实际下层提升，再将其乘积与第三个基路径组成上层输入，实际提升的终根成为下一状态。整个纤维恰由三个整数分支表示，执行直接使用三个复根。

## 正式证据

| 验收 | Lean 声明 |
| --- | --- |
| 两层真实覆盖及匹配空间 | `CoupledPullback.lowerCovering`、`upperCovering`、`composite_formula` |
| 第一层实际曲线生成第二层输入 | `lower`、`feed`、`upper`、`execute` |
| 完整曲线确为两层实际提升 | `intermediateCurve_actual_lift`、`restrictedTrajectory_actual_lift`、`restricted_runtime_diagram` |
| 零分支前进、其他分支保持 | `execute_B_left/right`、`execute_B_left_zero`、`execute_B_left_nonzero` |
| 组合与双向恢复 | `execute_driver_trans`、`execute_driver_reverse`、`execute_after_driver_reverse` |
| 全部纤维分支的唯一表示 | `prepare_surjective`、`prepare_injective` |
| 手算实例及恢复 | `example_run`、`example_reverse` |
| 内部根观察与整条路径选择 | `controlRoot_pow`、`routeDriver_eq`、`executeRouted_prepare` |
| 可逆内部反馈 | `routedEquiv`、`feedbackEquiv`、`feedbackEquiv_inverse`、`shiftFeedback_two_steps` |
| 基路径变形保持全部终根 | `execute_homotopic` |
| 有效有限词与等长逆程序 | `Word.driver`、`Word.inverse`、`Word.inverse_length`、`execute_inverse_word_eq` |

除覆盖空间声明外，表内名称均位于 `Monodromy.CoupledContinuation`。数学对象与证明逻辑见 [architecture.md](architecture.md)。

五个固定回路实际实现
\[
A_j:k_j\mapsto k_j+1,\qquad B_j:m\mapsto m+\mathbf1_{k_j=0},\qquad C:m\mapsto m+1.
\]
条件来自提升曲线的绕行关系。控制根的有限幂覆盖观察通过归一化核选择下一整条基路径，随后继续实际提升。整数零判断与模运算用于正确性证明。

## 完整程序结果

任意有限双计数器程序已原生编译：完整配置编码单射，每个活动源步骤对应两次实际返回，有限词表与停止根表由源程序静态确定。三个阶段位于同一个控制坐标。正式声明位于 `Monodromy.CounterContinuation`：

- `encode_injective`：完整配置的单射表示。
- `step_bind_step_encode`：两次原生步骤与源单步的交换等式，包括停止。
- `eval_encode`：完整部分结果等式；`halting_iff`、`divergence_iff` 给出停机及发散对应。

有限路径词演算另有两项结果：

- `CoupledContinuation.Program.eval_prepareInt`、`partrec_evalInt`、`partrec_with_io`：实际完整执行与原始递归单步解释一致，固定原始递归接口下属于部分递归函数。
- `Program.probeFree_native_halting_primrec`：删除两个条件门及其逆后，有限控制商给出原始递归停机判定；`zeroTest_native_dom` 与 `no_probeFree_zeroTest` 严格区分同一输入表示下的停机域表达能力。

可逆反馈也已单独证明：保持控制根的整表路由组合固定条件门，仍为全纤维双射；`shiftFeedback_two_steps` 验证 \((-1,0,0)\to(0,0,1)\to(0,1,2)\)。普通源程序编译保留其原有语义，可逆性由相应控制条件确定。

路由针对精确返回纤维，读出在每个返回态附近具有复解析延伸。数值逼近与单一自治流属于另一项数学问题。

## 当前集中问题

**在 Lean 中接通任意图灵机到双计数器机的经典归约，从而完成原生图灵通用性总定理。**

几何及五个回路保持固定。下一段工作只在证明层建立经典源编码与有限算术宏；不扩展原生状态或指令。素数幂编码已在 Lean 工作稿核验，乘法、商余宏及完整源编译继续构造。新路径词演算的精确部分递归刻画仍以这一连接为完成条件。

## 保留与收敛

原 `Autonomy.lean` 的 36 个公开数学声明，以及两层指数覆盖实例的全部证明，已归入 [Logarithm.lean](../src/Monodromy/Logarithm.lean)。一般拉回与积覆盖归入 [Covering.lean](../src/Monodromy/Covering.lean)。统一三根构造原位接替 [Continuation.lean](../src/Monodromy/Continuation.lean)，模块总数仍为 44。

旧演算的图灵通用性、固定有效接口下恰为部分递归函数的刻画、删除下降后的 Forward 分离继续成立，证据链见 [structure.md](structure.md)。四根模型、其他原有源码及两篇稿件均保持冻结并核对哈希。

已退役的三段解析流与普通解析比较器在全时间轨道及停止语义上相同；先前拉回图表、仿射群候选也未成为原生执行器。试作与验证记录集中在本机[研究证据包](/tmp/Monodromy-A-evidence.zip)，当前构造沿实际覆盖提升继续。

## 核验

整库构建（3113 项任务）与 2553 个 Monodromy 声明的传递公理审计通过，仅使用 `propext`、`Classical.choice`、`Quot.sound`。36 个原公开名称及旧总定理核对通过；独立代理重新加载仓库，核验了 27 项核心声明及公理范围。

执行核心的本地依赖闭包包含覆盖、对数与有限根数学，排除计数器源语义、算术解释层及递归性证明层；原生转移由实际提升生成。44 个模块、已有数学与冻结稿件均保留。

```sh
lake build
lake env lean -DautoImplicit=false -DwarningAsError=true src/Audit.lean
```
