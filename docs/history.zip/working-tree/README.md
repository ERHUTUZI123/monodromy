# Monodromy
a computational model 