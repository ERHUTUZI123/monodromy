module

public import Monodromy.Lifting
public import Monodromy.Finite
public import Monodromy.Observation
public import Monodromy.Feedback
public import Monodromy.Logarithm
public import Monodromy.Choice
public import Monodromy.Continuation
public import Monodromy.Cubic
public import Monodromy.Counter
public import Monodromy.ProgramCounter
public import Monodromy.Lattice
public import Monodromy.Control
public import Monodromy.Radix
public import Monodromy.Tower
public import Monodromy.TwoStacks
public import Monodromy.Machine
public import Monodromy.Universality
public import Monodromy.Scaling
public import Monodromy.Cosine
public import Monodromy.Resolution
public import Monodromy.CoverExpressions
public import Monodromy.CoverTables
public import Monodromy.CoverPrograms
public import Monodromy.CoverCompiler
public import Monodromy.CoverSyntax
public import Monodromy.FiniteSupport
public import Monodromy.FormalCompilation
public import Monodromy.Effectiveness
public import Monodromy.NativeLowerBound
public import Monodromy.CanonicalIO
public import Monodromy.BlockCoding
public import Monodromy.NativeIO
public import Monodromy.ForwardBoundary
public import Monodromy.Structure

/-!
# Monodromy

A root is memory; continuation carries it through a computation.

The quartic is a fixed finite example. Finite persistent state has precise
computational bounds; logarithmic branches provide integer memory.
A marked regular root gives an analytic fiber selector. Internal feedback
uses it to generate paths, write state, and change subsequent selection.
Every finite run of the return system agrees with actual path transport.

An exponential power-cover tower gives ordered word memory. Two word branches
and a finite analytic controller simulate every finite TM0 table, preserving
the complete tape, halting, and divergence. Native finite runs are realized
by their own generated continuation paths. These theorems concern the finite
covering calculus and its analytic successor semantics.

The coupled continuation kernel generates transitions by successive actual
logarithmic lifts. Two lower memory roots feed one upper control root; fixed
loops perform zero-conditional writes, and finite root kernels route the next
base path. Finite words of these loops simulate arbitrary two-counter
programs with complete configuration, halting, and divergence fidelity.
Their exact integer interpretation is partial recursive; removing the two
conditional loops leaves a finite stopping quotient. The classical Turing
reductions now compose into a faithful native simulation of arbitrary finite
Post–Turing tables, including exact first returns and actual matching-cover
path realization of every finite execution.

The cubic supplies a second mechanism: one fixed loop acts selectively on
different roots, as proved from its explicit continuous lifts.
-/
