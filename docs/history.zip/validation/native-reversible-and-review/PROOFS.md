# Mathematical claims and formal proofs

Read the manuscript for the construction. The entries below identify the
canonical definitions and proofs; all declarations have prefix `Monodromy`.
The full source is included, with its original module names and imports.

| Manuscript claim | Canonical file | Declarations |
| --- | --- | --- |
| Conditional winding, Section 2 | [Logarithm.lean](src/Monodromy/Logarithm.lean) | `NestedRestricted.firstCovering`; `NestedContinuation.execute_prepare` |
| The two covering maps | [Continuation.lean](src/Monodromy/Continuation.lean) | `CoupledPullback.upperCovering`, `lowerCovering`, `composite_formula` |
| All retained branch states | [Continuation.lean](src/Monodromy/Continuation.lean) | `CoupledContinuation.prepare_surjective`, `prepare_injective` |
| Successive execution, Definition 3.1 | [Continuation.lean](src/Monodromy/Continuation.lean) | `CoupledContinuation.intermediateCurve_actual_lift`, `restrictedTrajectory_actual_lift` |
| Five native operations, Proposition 3.2 | [Continuation.lean](src/Monodromy/Continuation.lean) | `CoupledContinuation.execute_A_left`, `execute_A_right`, `execute_B_left`, `execute_B_right`, `execute_control_prepare` |
| Worked execution, Example 3.3 | [Continuation.lean](src/Monodromy/Continuation.lean) | `CoupledContinuation.example_run`, `example_reverse` |
| Analytic finite selection | [Choice.lean](src/Monodromy/Choice.lean), [Radix.lean](src/Monodromy/Radix.lean) | `Choice.dispatch_root`, `analyticAt_kernel`; `Radix.kernel_root` |
| Internal programs, Definition 4.1 | [Continuation.lean](src/Monodromy/Continuation.lean) | `CoupledContinuation.routeDriver_eq`, `Program.step_prepare` |
| Counter realization, Proposition 4.2 | [Counter.lean](src/Monodromy/Counter.lean) | `CounterContinuation.two_returns`, `eval_encode` |
| Canonical complete tape encoding | [Tape.lean](src/Monodromy/Tape.lean) | `TapeCode.encode_injective`, `head_code`, `tail_code` |
| Classical finite machine reductions | [Counter.lean](src/Monodromy/Counter.lean) | `Counter.TuringCompiler.step_firstReturn`, `eval_encode`; `Counter.Compression.step_firstReturn`, `eval_encode` |
| Finite source alphabets and controls | [FiniteSupport.lean](src/Monodromy/FiniteSupport.lean) | `FiniteRenaming.configuration_injective`, `step_configuration`, `eval_configuration` |
| Native simulation macro, Theorem 5.1 | [FormalCompilation.lean](src/Monodromy/FormalCompilation.lean) | `NativeTuring.macroStep`, `boundaryProgram`, `macroStep_iota` |
| Native universality, Theorem 5.1 | [FormalCompilation.lean](src/Monodromy/FormalCompilation.lean) | `NativeTuring.native_universality`, `finiteMacro_iota`, `finite_eval_iota` |
| Causal paths and actual lifted results | [FormalCompilation.lean](src/Monodromy/FormalCompilation.lean), [Continuation.lean](src/Monodromy/Continuation.lean) | `NativeTuring.result_actual_lifts`; `CoupledContinuation.Program.runDriver_actual_lifts` |
| Transitive axiom audit | [Audit.lean](src/Audit.lean) | Checks all exported `Monodromy` declarations and their proof dependencies |

The source machine is used for static compilation and the simulation proof.
Native execution uses only finite geometric words, finite root routing, and
actual successive covering lifts. It does not invoke the source transition
function or the direct analytic comparison when generating its successor.

The later supporting results in `Effectiveness.lean`, `ForwardBoundary.lean`,
and `Structure.lean` are included as part of the complete project. The note's
main theorem and claim index remain restricted to native geometric universality.
