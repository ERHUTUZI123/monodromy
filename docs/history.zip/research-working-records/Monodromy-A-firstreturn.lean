import Monodromy.FormalCompilation

/-! Authoritative proofs are exported by the repository modules. -/
