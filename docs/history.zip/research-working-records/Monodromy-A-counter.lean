import Monodromy.Continuation
import Monodromy.Counter
import Mathlib.Logic.Equiv.Fin.Basic
import Mathlib.Tactic.FinCases

noncomputable section

namespace Monodromy.CoupledContinuation

open unitInterval

/-- The finite alphabet consists of the five existing geometric loops. -/
inductive Gate
  | left | right | zeroLeft | zeroRight | control

def Gate.driver : Gate → Driver
  | .left => A_left
  | .right => A_right
  | .zeroLeft => B_left
  | .zeroRight => B_right
  | .control => controlTurn

/-- A Boolean sign means reverse the same actual base path. -/
abbrev Word := List (Gate × Bool)

def idle : Driver where
  left := Path.refl NestedContinuation.base
  right := Path.refl NestedContinuation.base
  control := Path.refl one
  left_avoids := fun _ => base_ne_one
  right_avoids := fun _ => base_ne_one

theorem execute_idle (state : Memory) : execute idle state = state := by
  apply Subtype.ext
  let constant : C(I, Point) := ContinuousMap.const I state.val
  have same : trajectory idle state = constant :=
    coupled_curve_unique _ _
      (fun t => (trajectory_projects idle state t).trans state.property.symm)
      (trajectory_start idle state)
  exact congrArg (fun curve : C(I, Point) => curve 1) same

def Word.driver : Word → Driver
  | [] => idle
  | (gate, backward) :: rest =>
      (if backward then gate.driver.reverse else gate.driver).concat (Word.driver rest)

def Word.atom (gate : Gate) (backward : Bool := false) : Word := [(gate, backward)]

def Word.control : ℤ → Word
  | .ofNat count => List.replicate count (.control, false)
  | .negSucc count => List.replicate (count + 1) (.control, true)

theorem execute_word_nil (state : Memory) : execute (Word.driver []) state = state := execute_idle state

theorem execute_word_cons (gate : Gate) (backward : Bool) (rest : Word) (state : Memory) :
    execute (Word.driver ((gate, backward) :: rest)) state =
      execute (Word.driver rest) (execute (if backward then gate.driver.reverse else gate.driver) state) :=
  execute_driver_trans _ _ _

theorem execute_word_atom (gate : Gate) (backward : Bool) (state : Memory) :
    execute (Word.driver (Word.atom gate backward)) state =
      execute (if backward then gate.driver.reverse else gate.driver) state := by
  rw [Word.atom, execute_word_cons, execute_word_nil]

theorem execute_word_append (first second : Word) (state : Memory) :
    execute (Word.driver (first ++ second)) state =
      execute (Word.driver second) (execute (Word.driver first) state) := by
  induction first generalizing state with
  | nil => simp only [List.nil_append, execute_word_nil]
  | cons atom rest induction_hypothesis =>
      rcases atom with ⟨gate, backward⟩
      rw [List.cons_append, execute_word_cons, execute_word_cons, induction_hypothesis]

theorem execute_repeat_control (count : ℕ) (left right control : ℤ) :
    execute (Word.driver (List.replicate count (Gate.control, false))) (prepare left right control) =
      prepare left right (control + (count : ℤ)) := by
  induction count generalizing control with
  | zero => simp only [List.replicate_zero, execute_word_nil, Nat.cast_zero, add_zero]
  | succ count induction_hypothesis =>
      rw [List.replicate_succ, execute_word_cons]
      change execute (Word.driver (List.replicate count (Gate.control, false)))
        (execute controlTurn (prepare left right control)) = _
      rw [execute_control_prepare, induction_hypothesis]
      congr 1
      push_cast
      ring

theorem execute_repeat_control_reverse (count : ℕ) (left right control : ℤ) :
    execute (Word.driver (List.replicate count (Gate.control, true))) (prepare left right control) =
      prepare left right (control - (count : ℤ)) := by
  induction count generalizing control with
  | zero => simp only [List.replicate_zero, execute_word_nil, Nat.cast_zero, sub_zero]
  | succ count induction_hypothesis =>
      rw [List.replicate_succ, execute_word_cons]
      change execute (Word.driver (List.replicate count (Gate.control, true)))
        (execute controlTurn.reverse (prepare left right control)) = _
      rw [execute_control_reverse, induction_hypothesis]
      congr 1
      push_cast
      ring

theorem execute_control_word (amount left right control : ℤ) :
    execute (Word.driver (Word.control amount)) (prepare left right control) =
      prepare left right (control + amount) := by
  cases amount with
  | ofNat count => exact execute_repeat_control count left right control
  | negSucc count =>
      rw [Word.control, execute_repeat_control_reverse]
      congr 1

theorem control_word_length (amount : ℤ) : (Word.control amount).length = amount.natAbs := by
  cases amount <;> simp [Word.control]

end Monodromy.CoupledContinuation

namespace Monodromy.CoupledContinuation

/-- A finite program consists only of geometric words and marked stopping roots. -/
structure Program (degree : ℕ) where
  table : Fin degree → Word
  stop : Fin degree → Bool

namespace Program

variable {degree : ℕ} [NeZero degree]

def advance (program : Program degree) (state : Memory) : Memory :=
  executeRouted degree (fun index => Word.driver (program.table index)) state

/-- Stopping reads the same finite cover root through fixed normalized kernels. -/
def haltSignal (program : Program degree) (state : Memory) : ℂ :=
  Choice.dispatch (fun value : ℂ => value ^ degree)
    (fun index => (Radix.omega degree index : ℂ))
    (fun index => if program.stop index then 1 else 0) (controlRoot degree state)

def step (program : Program degree) (state : Memory) : Option Memory :=
  if program.haltSignal state = 1 then none else some (program.advance state)

def eval (program : Program degree) : Memory → Part Memory :=
  StateTransition.eval program.step

theorem advance_prepare (program : Program degree) (left right quotient : ℤ) (index : Fin degree) :
    program.advance (prepare left right ((degree : ℤ) * quotient + index.val)) =
      execute (Word.driver (program.table index))
        (prepare left right ((degree : ℤ) * quotient + index.val)) :=
  executeRouted_prepare degree (fun index => Word.driver (program.table index)) left right quotient index

theorem haltSignal_prepare (program : Program degree) (left right quotient : ℤ) (index : Fin degree) :
    program.haltSignal (prepare left right ((degree : ℤ) * quotient + index.val)) =
      if program.stop index then 1 else 0 := by
  unfold haltSignal
  rw [controlRoot_prepare]
  have root := congrArg (fun value : Circle => (value : ℂ))
    (Radix.readRoot_digit degree quotient index)
  rw [root]
  exact Choice.dispatch_root
    (fun first second same => Radix.omega_injective degree (Subtype.ext same))
    (fun first second => (Radix.omega_complex_pow degree first).trans
      (Radix.omega_complex_pow degree second).symm)
    (Radix.omega_regular degree) index

theorem step_prepare (program : Program degree) (left right quotient : ℤ) (index : Fin degree) :
    program.step (prepare left right ((degree : ℤ) * quotient + index.val)) =
      if program.stop index then none else
        some (execute (Word.driver (program.table index))
          (prepare left right ((degree : ℤ) * quotient + index.val))) := by
  unfold step
  rw [haltSignal_prepare]
  cases program.stop index <;> simp [advance_prepare]

end Program

end Monodromy.CoupledContinuation

namespace Monodromy.CounterContinuation

open CoupledContinuation

/-- Three finite program phases share the existing upper control coordinate. -/
def label {m : ℕ} (position : Fin m) (phase : Fin 3) : ℤ :=
  (finProdFinEquiv (position, phase)).val

theorem label_eq {m : ℕ} (position : Fin m) (phase : Fin 3) :
    label position phase = (phase.val : ℤ) + 3 * (position.val : ℤ) := by
  simp [label, finProdFinEquiv]

def memoryGate (register : Fin 2) : Gate := if register = 0 then .left else .right

def zeroGate (register : Fin 2) : Gate := if register = 0 then .zeroLeft else .zeroRight

def instructionWord {m : ℕ} (program : Counter.Program 2 m) (position : Fin m) (phase : Fin 3) : Word :=
  match program position with
  | .halt => []
  | .inc register target =>
      if phase = 0 then Word.control 1
      else if phase = 1 then
        Word.atom (memoryGate register) ++ Word.control (label target 0 - label position 1)
      else []
  | .dec register zero nonzero =>
      if phase = 0 then Word.control 1 ++ Word.atom (zeroGate register)
      else if phase = 1 then
        Word.atom (memoryGate register) true ++ Word.control (label nonzero 0 - label position 1)
      else Word.control (label zero 0 - label position 2)

def instructionStop {m : ℕ} (instruction : Counter.Instruction 2 m) : Bool :=
  match instruction with | .halt => true | _ => false

def stopping {m : ℕ} (program : Counter.Program 2 m) (position : Fin m) (phase : Fin 3) : Bool :=
  if phase = 0 then instructionStop (program position) else false

def wordTable {m : ℕ} (program : Counter.Program 2 m) (index : Fin (m * 3)) : Word :=
  let address := finProdFinEquiv.symm index
  instructionWord program address.1 address.2

def stopTable {m : ℕ} (program : Counter.Program 2 m) (index : Fin (m * 3)) : Bool :=
  let address := finProdFinEquiv.symm index
  stopping program address.1 address.2

def compile {m : ℕ} (program : Counter.Program 2 m) : CoupledContinuation.Program (m * 3) :=
  ⟨wordTable program, stopTable program⟩

def encode {m : ℕ} (state : Counter.Configuration 2 m) : Memory :=
  prepare (state.counters 0 : ℤ) (state.counters 1 : ℤ) (label state.pc 0)

theorem compile_table_address {m : ℕ} (program : Counter.Program 2 m)
    (position : Fin m) (phase : Fin 3) :
    (compile program).table (finProdFinEquiv (position, phase)) = instructionWord program position phase := by
  simp [compile, wordTable]

theorem compile_stop_address {m : ℕ} (program : Counter.Program 2 m)
    (position : Fin m) (phase : Fin 3) :
    (compile program).stop (finProdFinEquiv (position, phase)) = stopping program position phase := by
  simp [compile, stopTable]

variable {m : ℕ} [NeZero m]

theorem advance_at (program : Counter.Program 2 m) (left right : ℤ)
    (position : Fin m) (phase : Fin 3) :
    (compile program).advance (prepare left right (label position phase)) =
      execute (Word.driver (instructionWord program position phase))
        (prepare left right (label position phase)) := by
  have run := CoupledContinuation.Program.advance_prepare (compile program) left right 0
    (finProdFinEquiv (position, phase))
  simpa only [mul_zero, zero_add, compile_table_address, label] using run

theorem step_at (program : Counter.Program 2 m) (left right : ℤ)
    (position : Fin m) (phase : Fin 3) :
    (compile program).step (prepare left right (label position phase)) =
      if stopping program position phase then none else
        some (execute (Word.driver (instructionWord program position phase))
          (prepare left right (label position phase))) := by
  have run := CoupledContinuation.Program.step_prepare (compile program) left right 0
    (finProdFinEquiv (position, phase))
  simpa only [mul_zero, zero_add, compile_table_address, compile_stop_address, label] using run

end Monodromy.CounterContinuation

namespace Monodromy.CounterContinuation

open CoupledContinuation

variable {m : ℕ} [NeZero m]

theorem advance_inc_first (program : Counter.Program 2 m) (position target : Fin m)
    (register : Fin 2) (instruction : program position = .inc register target) (left right : ℤ) :
    (compile program).advance (prepare left right (label position 0)) =
      prepare left right (label position 1) := by
  rw [advance_at]
  simp [instructionWord, instruction]
  rw [execute_control_word]
  congr 1
  simp [label_eq]
  omega

theorem advance_inc_second (program : Counter.Program 2 m) (position target : Fin m)
    (register : Fin 2) (instruction : program position = .inc register target) (left right : ℤ) :
    (compile program).advance (prepare left right (label position 1)) =
      prepare (left + if register = 0 then 1 else 0) (right + if register = 1 then 1 else 0)
        (label target 0) := by
  rw [advance_at]
  simp [instructionWord, instruction]
  rw [execute_word_append, execute_word_atom]
  fin_cases register
  · change execute (Word.driver (Word.control _)) (execute A_left _) = _
    rw [execute_A_left, execute_control_word]
    congr 1 <;> simp
  · change execute (Word.driver (Word.control _)) (execute A_right _) = _
    rw [execute_A_right, execute_control_word]
    congr 1 <;> simp

theorem advance_dec_first (program : Counter.Program 2 m) (position zero nonzero : Fin m)
    (register : Fin 2) (instruction : program position = .dec register zero nonzero) (left right : ℤ) :
    (compile program).advance (prepare left right (label position 0)) =
      prepare left right (label position 1 + if (![left, right] register) = 0 then 1 else 0) := by
  rw [advance_at]
  simp [instructionWord, instruction]
  rw [execute_word_append, execute_control_word, execute_word_atom]
  fin_cases register
  · change execute B_left _ = _
    rw [execute_B_left]
    congr 1
    simp [label_eq]
    omega
  · change execute B_right _ = _
    rw [execute_B_right]
    congr 1
    simp [label_eq]
    omega

theorem advance_dec_positive (program : Counter.Program 2 m) (position zero nonzero : Fin m)
    (register : Fin 2) (instruction : program position = .dec register zero nonzero) (left right : ℤ) :
    (compile program).advance (prepare left right (label position 1)) =
      prepare (left - if register = 0 then 1 else 0) (right - if register = 1 then 1 else 0)
        (label nonzero 0) := by
  rw [advance_at]
  simp [instructionWord, instruction]
  rw [execute_word_append, execute_word_atom]
  fin_cases register
  · change execute (Word.driver (Word.control _)) (execute A_left.reverse _) = _
    rw [execute_A_left_reverse, execute_control_word]
    congr 1 <;> simp
  · change execute (Word.driver (Word.control _)) (execute A_right.reverse _) = _
    rw [execute_A_right_reverse, execute_control_word]
    congr 1 <;> simp

theorem advance_dec_zero (program : Counter.Program 2 m) (position zero nonzero : Fin m)
    (register : Fin 2) (instruction : program position = .dec register zero nonzero) (left right : ℤ) :
    (compile program).advance (prepare left right (label position 2)) =
      prepare left right (label zero 0) := by
  rw [advance_at]
  simp [instructionWord, instruction]
  rw [execute_control_word]
  congr 1
  omega

theorem step_running_at (program : Counter.Program 2 m) (position : Fin m) (phase : Fin 3)
    (running : stopping program position phase = false) (left right : ℤ) :
    (compile program).step (prepare left right (label position phase)) =
      some ((compile program).advance (prepare left right (label position phase))) := by
  rw [step_at, running]
  simp only [Bool.false_eq_true, ↓reduceIte]
  rw [advance_at]

theorem step_phase_one (program : Counter.Program 2 m) (position : Fin m) (left right : ℤ) :
    (compile program).step (prepare left right (label position 1)) =
      some ((compile program).advance (prepare left right (label position 1))) := by
  apply step_running_at
  simp [stopping]

theorem step_phase_two (program : Counter.Program 2 m) (position : Fin m) (left right : ℤ) :
    (compile program).step (prepare left right (label position 2)) =
      some ((compile program).advance (prepare left right (label position 2))) := by
  apply step_running_at
  simp [stopping]

end Monodromy.CounterContinuation

namespace Monodromy.CounterContinuation

open CoupledContinuation

variable {m : ℕ}

/-- The three retained roots preserve the whole finite-control, two-counter configuration. -/
theorem encode_injective : Function.Injective (@encode m) := by
  intro first second same
  have labels : (((first.counters 0 : ℤ), (first.counters 1 : ℤ)), label first.pc 0) =
      (((second.counters 0 : ℤ), (second.counters 1 : ℤ)), label second.pc 0) :=
    CoupledContinuation.prepare_injective same
  have positions : first.pc = second.pc := by
    apply Fin.ext
    have control := congrArg Prod.snd labels
    simp only [label_eq, Fin.val_zero, Nat.cast_zero, zero_add] at control
    exact_mod_cast (show (first.pc.val : ℤ) = (second.pc.val : ℤ) by omega)
  have lefts : first.counters 0 = second.counters 0 := by
    have casted : (first.counters 0 : ℤ) = (second.counters 0 : ℤ) :=
      congrArg (fun value : (ℤ × ℤ) × ℤ => value.1.1) labels
    exact_mod_cast casted
  have rights : first.counters 1 = second.counters 1 := by
    have casted : (first.counters 1 : ℤ) = (second.counters 1 : ℤ) :=
      congrArg (fun value : (ℤ × ℤ) × ℤ => value.1.2) labels
    exact_mod_cast casted
  have registers : first.counters = second.counters := by
    funext register
    fin_cases register <;> assumption
  cases first
  cases second
  cases positions
  cases registers
  rfl

variable [NeZero m]

/-- A source halt is read by the native finite-root stopping signal. -/
theorem step_halt (program : Counter.Program 2 m) (state : Counter.Configuration 2 m)
    (instruction : program state.pc = .halt) : (compile program).step (encode state) = none := by
  unfold encode
  rw [step_at]
  simp [stopping, instructionStop, instruction]

/-- Every live source step is realized by exactly two nonempty native returns. -/
theorem two_returns (program : Counter.Program 2 m)
    (state result : Counter.Configuration 2 m) (source_step : Counter.step program state = some result) :
    ∃ middle : Memory,
      (compile program).step (encode state) = some middle ∧
      (compile program).step middle = some (encode result) := by
  cases instruction : program state.pc with
  | halt => simp [Counter.step, instruction] at source_step
  | inc register target =>
      have result_eq : result =
          ⟨target, Function.update state.counters register (state.counters register + 1)⟩ := by
        simpa [Counter.step, instruction] using source_step.symm
      subst result
      have running : stopping program state.pc 0 = false := by
        simp [stopping, instructionStop, instruction]
      refine ⟨prepare (state.counters 0 : ℤ) (state.counters 1 : ℤ) (label state.pc 1), ?_, ?_⟩
      · change (compile program).step
          (prepare (state.counters 0 : ℤ) (state.counters 1 : ℤ) (label state.pc 0)) = _
        rw [step_running_at program state.pc 0 running,
          advance_inc_first program state.pc target register instruction]
      · rw [step_phase_one, advance_inc_second program state.pc target register instruction]
        apply congrArg some
        unfold encode
        fin_cases register <;> simp [Function.update]
  | dec register zero nonzero =>
      have running : stopping program state.pc 0 = false := by
        simp [stopping, instructionStop, instruction]
      cases counter : state.counters register with
      | zero =>
          have result_eq : result = ⟨zero, state.counters⟩ := by
            simpa [Counter.step, instruction, counter] using source_step.symm
          subst result
          have zero_value : (![((state.counters 0 : ℤ)), ((state.counters 1 : ℤ))] register) = 0 := by
            have casted := congrArg (fun value : ℕ => (value : ℤ)) counter
            fin_cases register <;> simpa using casted
          have first_return :
              (compile program).advance
                (prepare (state.counters 0 : ℤ) (state.counters 1 : ℤ) (label state.pc 0)) =
              prepare (state.counters 0 : ℤ) (state.counters 1 : ℤ) (label state.pc 2) := by
            rw [advance_dec_first program state.pc zero nonzero register instruction, zero_value]
            simp only [ite_true]
            congr 1
            simp [label_eq]
            omega
          refine ⟨prepare (state.counters 0 : ℤ) (state.counters 1 : ℤ) (label state.pc 2), ?_, ?_⟩
          · change (compile program).step
              (prepare (state.counters 0 : ℤ) (state.counters 1 : ℤ) (label state.pc 0)) = _
            rw [step_running_at program state.pc 0 running, first_return]
          · rw [step_phase_two, advance_dec_zero program state.pc zero nonzero register instruction]
            rfl
      | succ value =>
          have result_eq : result = ⟨nonzero, Function.update state.counters register value⟩ := by
            simpa [Counter.step, instruction, counter] using source_step.symm
          subst result
          have nonzero_value : (![((state.counters 0 : ℤ)), ((state.counters 1 : ℤ))] register) ≠ 0 := by
            have casted := congrArg (fun value : ℕ => (value : ℤ)) counter
            have positive : (![((state.counters 0 : ℤ)), ((state.counters 1 : ℤ))] register) = (value : ℤ) + 1 := by
              fin_cases register <;> simpa using casted
            omega
          have first_return :
              (compile program).advance
                (prepare (state.counters 0 : ℤ) (state.counters 1 : ℤ) (label state.pc 0)) =
              prepare (state.counters 0 : ℤ) (state.counters 1 : ℤ) (label state.pc 1) := by
            simpa only [ite_eq_right nonzero_value, add_zero] using
              advance_dec_first program state.pc zero nonzero register instruction
                (state.counters 0 : ℤ) (state.counters 1 : ℤ)
          refine ⟨prepare (state.counters 0 : ℤ) (state.counters 1 : ℤ) (label state.pc 1), ?_, ?_⟩
          · change (compile program).step
              (prepare (state.counters 0 : ℤ) (state.counters 1 : ℤ) (label state.pc 0)) = _
            rw [step_running_at program state.pc 0 running, first_return]
          · rw [step_phase_one, advance_dec_positive program state.pc zero nonzero register instruction]
            apply congrArg some
            unfold encode
            fin_cases register <;> simp_all [Function.update]

/-- The geometric program refines the standard two-counter transition system. -/
theorem simulates (program : Counter.Program 2 m) :
    StateTransition.Respects (Counter.step program) (compile program).step
      (fun first second => encode first = second) := by
  apply StateTransition.fun_respects.mpr
  intro state
  cases source_step : Counter.step program state with
  | none =>
      change (compile program).step (encode state) = none
      cases instruction : program state.pc with
      | halt => exact step_halt program state instruction
      | inc register target => simp [Counter.step, instruction] at source_step
      | dec register zero nonzero =>
          cases counter : state.counters register <;>
            simp [Counter.step, instruction, counter] at source_step
  | some result =>
      change StateTransition.Reaches₁ (compile program).step (encode state) (encode result)
      obtain ⟨middle, first_return, second_return⟩ := two_returns program state result source_step
      have first_reach : StateTransition.Reaches₁ (compile program).step (encode state) middle :=
        Relation.TransGen.single first_return
      exact first_reach.tail second_return

/-- Complete results, halting, and divergence agree through the faithful native encoding. -/
theorem eval_encode (program : Counter.Program 2 m) (state : Counter.Configuration 2 m) :
    (compile program).eval (encode state) = encode <$> Counter.eval program state :=
  StateTransition.tr_eval' (Counter.step program) (compile program).step encode (simulates program) state

theorem halting_iff (program : Counter.Program 2 m) (state : Counter.Configuration 2 m) :
    ((compile program).eval (encode state)).Dom ↔ (Counter.eval program state).Dom := by
  have same := congrArg Part.Dom (eval_encode program state)
  exact same.to_iff

theorem divergence_iff (program : Counter.Program 2 m) (state : Counter.Configuration 2 m) :
    ¬ ((compile program).eval (encode state)).Dom ↔ ¬ (Counter.eval program state).Dom :=
  not_congr (halting_iff program state)

end Monodromy.CounterContinuation

#print axioms Monodromy.CounterContinuation.two_returns
#print axioms Monodromy.CounterContinuation.eval_encode

namespace Monodromy.CounterContinuation

variable {m : ℕ} [NeZero m]

/-- Two actual native returns commute with one complete source transition, including halt. -/
theorem step_bind_step_encode (program : Counter.Program 2 m) (state : Counter.Configuration 2 m) :
    ((compile program).step (encode state)).bind (compile program).step =
      (Counter.step program state).map encode := by
  cases source_step : Counter.step program state with
  | none =>
      have stopped := StateTransition.fun_respects.mp (simulates program) (a₁ := state)
      rw [source_step] at stopped
      change (compile program).step (encode state) = none at stopped
      rw [stopped]
      rfl
  | some result =>
      obtain ⟨middle, first_return, second_return⟩ := two_returns program state result source_step
      rw [first_return]
      exact second_return

end Monodromy.CounterContinuation

#print axioms Monodromy.CounterContinuation.encode_injective
#print axioms Monodromy.CounterContinuation.step_bind_step_encode
