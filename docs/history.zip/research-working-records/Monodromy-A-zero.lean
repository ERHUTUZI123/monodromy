import Monodromy.Continuation

namespace Monodromy.CoupledContinuation

/-- Zero-branch transport changes the retained root, not merely its integer description. -/
theorem execute_B_left_zero_ne (state : Memory) (zero : state.val.1.1.val = 1) :
    execute B_left state ≠ state := by
  intro same
  have upper := congrArg (fun root : Memory => root.val.2) same
  rw [execute_B_left_zero state zero] at upper
  have vanished : NestedContinuation.period 1 = 0 :=
    add_left_cancel (upper.trans (add_zero state.val.2).symm)
  have impossible : (1 : ℤ) = 0 := NestedContinuation.period_injective (by
    simpa only [NestedContinuation.period, Int.cast_zero, zero_mul] using vanished)
  exact one_ne_zero impossible

end Monodromy.CoupledContinuation
