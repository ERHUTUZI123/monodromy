import Monodromy.Counter
import Mathlib.Logic.Function.Basic

noncomputable section

namespace Monodromy.Counter.RegisterRelocation

variable {n k m : ℕ}

def instruction (register : Fin n → Fin k) : Instruction n m → Instruction k m
  | .inc source target => .inc (register source) target
  | .dec source zero nonzero => .dec (register source) zero nonzero
  | .halt => .halt

def program (register : Fin n → Fin k) (source : Program n m) : Program k m :=
  fun address => instruction register (source address)

/-- Registers outside the image retain their arbitrary fixed background values. -/
def embed (register : Fin n → Fin k) (background : Fin k → ℕ)
    (state : Configuration n m) : Configuration k m :=
  ⟨state.pc, Function.extend register state.counters background⟩

theorem embed_read (register : Fin n → Fin k) (faithful : Function.Injective register)
    (background : Fin k → ℕ) (state : Configuration n m) (index : Fin n) :
    (embed register background state).counters (register index) = state.counters index :=
  faithful.extend_apply _ _ _

theorem embed_outside (register : Fin n → Fin k) (background : Fin k → ℕ)
    (state : Configuration n m) (index : Fin k) (outside : ∀ source, register source ≠ index) :
    (embed register background state).counters index = background index :=
  Function.extend_apply' _ _ _ (by rintro ⟨source, same⟩; exact outside source same)

/-- A register injection preserves each complete step, including the zero and halt cases. -/
theorem step_embed (register : Fin n → Fin k) (faithful : Function.Injective register)
    (background : Fin k → ℕ) (source : Program n m) (state : Configuration n m) :
    step (program register source) (embed register background state) =
      (step source state).map (embed register background) := by
  cases operation : source state.pc with
  | inc index target =>
      simp [step, program, instruction, embed, operation, faithful.extend_apply, faithful.extend_update]
  | dec index zero nonzero =>
      cases value : state.counters index <;>
        simp [step, program, instruction, embed, operation, value,
          faithful.extend_apply, faithful.extend_update]
  | halt => simp [step, program, instruction, embed, operation]

/-- The same relocation transports any finite arithmetic macro run. -/
theorem reaches_embed (register : Fin n → Fin k) (faithful : Function.Injective register)
    (background : Fin k → ℕ) (source : Program n m) {first last : Configuration n m}
    (run : StateTransition.Reaches (step source) first last) :
    StateTransition.Reaches (step (program register source))
      (embed register background first) (embed register background last) := by
  induction run with
  | refl => exact Relation.ReflTransGen.refl
  | tail _ edge previous =>
      apply previous.tail
      have actual : step source _ = some _ := edge
      rw [step_embed register faithful background source, actual]
      rfl

/-- Partial results, halting and divergence survive register relocation exactly. -/
theorem eval_embed (register : Fin n → Fin k) (faithful : Function.Injective register)
    (background : Fin k → ℕ) (source : Program n m) (state : Configuration n m) :
    eval (program register source) (embed register background state) =
      embed register background <$> eval source state := by
  apply StateTransition.tr_eval' (step source) (step (program register source)) (embed register background)
  apply StateTransition.fun_respects.mpr
  intro current
  cases result : step source current with
  | none =>
      change step (program register source) (embed register background current) = none
      simp [step_embed register faithful background source, result]
  | some next =>
      apply Relation.TransGen.single
      simp [step_embed register faithful background source, result]

/-- Either stack and the shared third scratch register can host the same two-register macro. -/
def pairIntoThree (active : Fin 2) (index : Fin 2) : Fin 3 :=
  if index = 0 then active.castSucc else 2

theorem pairIntoThree_injective (active : Fin 2) : Function.Injective (pairIntoThree active) := by
  intro first second same
  fin_cases active <;> fin_cases first <;> fin_cases second <;>
    first | rfl | norm_num [pairIntoThree] at same

end Monodromy.Counter.RegisterRelocation
