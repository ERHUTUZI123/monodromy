import «Monodromy-A-source»

namespace Monodromy.CounterPrimeProbe

variable (p : ℕ) [NeZero p]

/-- The program contains only the two already checked finite arithmetic tables. -/
def size : ℕ := Counter.DivMod.size p + (p + 4)

def divBlock (address : Fin (Counter.DivMod.size p)) : Fin (size p) :=
  Fin.castAdd (p + 4) address

def mulAddress (address : Fin (p + 4)) : Fin (size p) :=
  Fin.natAdd (Counter.DivMod.size p) address

/-- Nonzero remainder exits enter the multiplier's existing bounded countdown. -/
def divAddress (address : Fin (Counter.DivMod.size p)) : Fin (size p) :=
  match Counter.DivMod.program p address with
  | .halt =>
      if address.val = 3 * p then divBlock p address
      else mulAddress p (CounterMultiplication.phase p (address.val - 3 * p))
  | _ => divBlock p address

def entry : Fin (size p) := divAddress p (Counter.DivMod.consume p 0)
def success : Fin (size p) := divBlock p (Counter.DivMod.finish p 0)
def failure : Fin (size p) := mulAddress p (CounterMultiplication.finish p)

/-- Rewired finite program counters provide the conditional; the instructions remain inc/dec/halt. -/
def program : Counter.Program 2 (size p) :=
  Fin.addCases
    (fun address => Counter.mapInstruction (divAddress p) (Counter.DivMod.program p address))
    (fun address => Counter.mapInstruction (mulAddress p) (CounterMultiplication.program p address))

def configuration (address : Fin (size p)) (first second : ℕ) : Counter.Configuration 2 (size p) :=
  ⟨address, ![first, second]⟩

@[simp] theorem entry_eq : entry p = divBlock p (Counter.DivMod.consume p 0) := by
  simp [entry, divAddress]

@[simp] theorem program_divBlock (address : Fin (Counter.DivMod.size p)) :
    program p (divBlock p address) =
      Counter.mapInstruction (divAddress p) (Counter.DivMod.program p address) := by
  simp [program, divBlock]

@[simp] theorem program_mulAddress (address : Fin (p + 4)) :
    program p (mulAddress p address) =
      Counter.mapInstruction (mulAddress p) (CounterMultiplication.program p address) := by
  simp [program, mulAddress]

theorem div_agrees (address : Fin (Counter.DivMod.size p))
    (live : Counter.DivMod.program p address ≠ .halt) :
    program p (divAddress p address) =
      Counter.mapInstruction (divAddress p) (Counter.DivMod.program p address) := by
  have actual : divAddress p address = divBlock p address := by
    unfold divAddress
    cases operation : Counter.DivMod.program p address <;> simp_all
  rw [actual, program_divBlock]

@[simp] theorem div_finish_zero :
    divAddress p (Counter.DivMod.finish p 0) = success p := by
  unfold divAddress
  rw [Counter.DivMod.program_finish]
  simp [success, Counter.DivMod.finish]

theorem div_finish_nonzero (remainder : Fin p) (nonzero : remainder.val ≠ 0) :
    divAddress p (Counter.DivMod.finish p remainder) =
      mulAddress p (CounterMultiplication.phase p remainder.val) := by
  have different : 3 * p + remainder.val ≠ 3 * p := by omega
  unfold divAddress
  rw [Counter.DivMod.program_finish]
  change (if 3 * p + remainder.val = 3 * p then divBlock p (Counter.DivMod.finish p remainder)
    else mulAddress p (CounterMultiplication.phase p ((3 * p + remainder.val) - 3 * p))) = _
  rw [ite_eq_right different]
  simp only [Nat.add_sub_cancel_left]

@[simp] theorem program_success : program p (success p) = .halt := by
  simp [success, Counter.mapInstruction]

@[simp] theorem program_failure : program p (failure p) = .halt := by
  simp [failure, Counter.mapInstruction, CounterMultiplication.program_finish]

/-- The two final addresses are distinct finite-control outcomes. -/
theorem exits_distinct : success p ≠ failure p := by
  intro same
  have values := congrArg Fin.val same
  dsimp [success, failure, divBlock, mulAddress, Counter.DivMod.finish,
    Counter.DivMod.size, CounterMultiplication.finish] at values
  omega

private theorem div_configuration (address : Fin (Counter.DivMod.size p)) (first second : ℕ) :
    Counter.mapConfiguration (divAddress p) (Counter.DivMod.configuration p address first second) =
      configuration p (divAddress p address) first second := rfl

omit [NeZero p] in
private theorem mul_configuration (address : Fin (p + 4)) (first second : ℕ) :
    Counter.mapConfiguration (mulAddress p) (CounterMultiplication.configuration p address first second) =
      configuration p (mulAddress p address) first second := rfl

/-- Division reaches a success address or an actual multiplier countdown entry. -/
theorem divide_reaches (input : ℕ) :
    StateTransition.Reaches (Counter.step (program p))
      (configuration p (entry p) input 0)
      (configuration p (divAddress p (Counter.DivMod.finish p (Counter.DivMod.residue p input)))
        (input / p) 0) := by
  have run := Counter.reaches_map_live (divAddress p) (Counter.DivMod.program p) (program p)
    (div_agrees p) (Counter.DivMod.reaches_divmod p input)
  simpa only [div_configuration, entry] using run

/-- The multiplier countdown first writes the bounded remainder, then restores the original number. -/
theorem restore_reaches (remainder : Fin p) (quotient : ℕ) :
    StateTransition.Reaches (Counter.step (program p))
      (configuration p (mulAddress p (CounterMultiplication.phase p remainder.val)) quotient 0)
      (configuration p (failure p) (remainder.val + p * quotient) 0) := by
  have seeded := CounterMultiplication.increments_reach p remainder.val quotient 0
    (Nat.le_of_lt remainder.isLt)
  simp only [Nat.zero_add] at seeded
  have consumed := CounterMultiplication.consume_reach p quotient remainder.val
  have transferred := CounterMultiplication.transfer_reach p 0 (remainder.val + p * quotient)
  simp only [Nat.zero_add] at transferred
  have run : StateTransition.Reaches (Counter.step (CounterMultiplication.program p))
      (CounterMultiplication.configuration p (CounterMultiplication.phase p remainder.val) quotient 0)
      (CounterMultiplication.configuration p (CounterMultiplication.finish p) (remainder.val + p * quotient) 0) :=
    seeded.trans (consumed.trans
      (Relation.ReflTransGen.head
        (CounterMultiplication.step_begin_transfer p (remainder.val + p * quotient))
        (transferred.tail (CounterMultiplication.step_finish p (remainder.val + p * quotient)))))
  have mapped := Counter.reaches_map_live (mulAddress p) (CounterMultiplication.program p) (program p)
    (fun address _ => program_mulAddress p address) run
  simpa only [mul_configuration, failure] using mapped

/-- Divisible inputs are divided; the workspace returns to zero. -/
theorem reaches_success (input : ℕ) (divides : p ∣ input) :
    StateTransition.Reaches (Counter.step (program p))
      (configuration p (entry p) input 0)
      (configuration p (success p) (input / p) 0) := by
  have remainder_zero : Counter.DivMod.residue p input = 0 := by
    apply Fin.ext
    exact Nat.dvd_iff_mod_eq_zero.mp divides
  simpa only [remainder_zero, div_finish_zero] using divide_reaches p input

/-- Every other input is restored exactly, with a distinct final control outcome. -/
theorem reaches_failure (input : ℕ) (nondivides : ¬ p ∣ input) :
    StateTransition.Reaches (Counter.step (program p))
      (configuration p (entry p) input 0)
      (configuration p (failure p) input 0) := by
  have remainder_nonzero : (Counter.DivMod.residue p input).val ≠ 0 := by
    intro zero
    exact nondivides (Nat.dvd_iff_mod_eq_zero.mpr zero)
  have divided := divide_reaches p input
  rw [div_finish_nonzero p _ remainder_nonzero] at divided
  have restored := restore_reaches p (Counter.DivMod.residue p input) (input / p)
  have reconstruct : (Counter.DivMod.residue p input).val + p * (input / p) = input :=
    Nat.mod_add_div input p
  rw [reconstruct] at restored
  exact divided.trans restored

/-- Complete evaluation returns exactly one of the two finite-control outcomes. -/
theorem eval_result (input : ℕ) :
    Counter.eval (program p) (configuration p (entry p) input 0) =
      Part.some (if p ∣ input then configuration p (success p) (input / p) 0
        else configuration p (failure p) input 0) := by
  apply Part.eq_some_iff.mpr
  apply StateTransition.mem_eval.mpr
  by_cases divides : p ∣ input
  · simp only [ite_eq_left divides]
    exact ⟨reaches_success p input divides,
      Counter.step_halt _ _ (program_success p)⟩
  · simp only [ite_eq_right divides]
    exact ⟨reaches_failure p input divides,
      Counter.step_halt _ _ (program_failure p)⟩

theorem entry_live : program p (entry p) ≠ .halt := by
  rw [entry_eq, program_divBlock, Counter.DivMod.program_consume]
  simp [Counter.mapInstruction]

theorem entry_ne_success : entry p ≠ success p := by
  rw [entry_eq]
  intro same
  have values := congrArg Fin.val same
  have positive : 0 < p := Nat.pos_of_ne_zero (NeZero.ne p)
  dsimp [success, divBlock, Counter.DivMod.consume, Counter.DivMod.finish] at values
  omega

theorem entry_ne_failure : entry p ≠ failure p := by
  rw [entry_eq]
  intro same
  have values := congrArg Fin.val same
  dsimp [failure, divBlock, mulAddress, Counter.DivMod.consume,
    Counter.DivMod.size, CounterMultiplication.finish] at values
  omega

private theorem positive_run {first last : Counter.Configuration 2 (size p)}
    (run : StateTransition.Reaches (Counter.step (program p)) first last)
    (different : first ≠ last) :
    StateTransition.Reaches₁ (Counter.step (program p)) first last := by
  unfold StateTransition.Reaches at run
  unfold StateTransition.Reaches₁
  rcases Relation.reflTransGen_iff_eq_or_transGen.mp run with same | moves
  · exact False.elim (different same.symm)
  · exact moves

/-- Positivity survives later rewiring, including source-machine self-loops. -/
theorem reaches_success₁ (input : ℕ) (divides : p ∣ input) :
    StateTransition.Reaches₁ (Counter.step (program p))
      (configuration p (entry p) input 0)
      (configuration p (success p) (input / p) 0) := by
  apply positive_run p (reaches_success p input divides)
  intro same
  exact entry_ne_success p (congrArg Counter.Configuration.pc same)

theorem reaches_failure₁ (input : ℕ) (nondivides : ¬ p ∣ input) :
    StateTransition.Reaches₁ (Counter.step (program p))
      (configuration p (entry p) input 0)
      (configuration p (failure p) input 0) := by
  apply positive_run p (reaches_failure p input nondivides)
  intro same
  exact entry_ne_failure p (congrArg Counter.Configuration.pc same)

end Monodromy.CounterPrimeProbe

#print axioms Monodromy.CounterPrimeProbe.eval_result
#print axioms Monodromy.CounterPrimeProbe.reaches_success₁
