import Monodromy.Continuation

/-! Causal finite native runs, using only the retained actual roots. -/
noncomputable section

namespace Monodromy.CoupledContinuation.Program

variable {degree : ℕ} [NeZero degree]

/-- A fixed-length advance prefix. Each next driver uses the preceding actual lift result.
The step/eval hypotheses below certify which prefixes respect native stopping. -/
def runDriver (program : Program degree) : ℕ → Memory → Driver
  | 0, _ => idle
  | count + 1, state =>
      (routeDriver degree (fun index => Word.driver (program.table index)) state).concat
        (runDriver program count (program.advance state))

/-- Arbitrary counts describe advance iteration, including counts beyond a stopping return. -/
theorem execute_runDriver (program : Program degree) (count : ℕ) (state : Memory) :
    execute (program.runDriver count state) state = (program.advance)^[count] state := by
  induction count generalizing state with
  | zero => exact execute_idle state
  | succ count induction_hypothesis =>
      rw [runDriver, execute_driver_trans]
      change execute (program.runDriver count (program.advance state)) (program.advance state) = _
      rw [induction_hypothesis, Function.iterate_succ_apply]

private theorem advance_of_step (program : Program degree) {first last : Memory}
    (transition : program.step first = some last) : program.advance first = last := by
  unfold step at transition
  split at transition
  · contradiction
  · exact Option.some.inj transition

/-- A finite native step run has the corresponding number of actual advances. -/
theorem reaches_iterate_advance (program : Program degree) {initial final : Memory}
    (run : StateTransition.Reaches program.step initial final) :
    ∃ count, (program.advance)^[count] initial = final := by
  induction run with
  | refl => exact ⟨0, rfl⟩
  | tail _ edge previous =>
      rcases previous with ⟨count, reached⟩
      refine ⟨count + 1, ?_⟩
      rw [Function.iterate_succ_apply', reached]
      exact advance_of_step program edge

/-- Stopping-respecting finite execution is realized by its causally generated base path. -/
theorem runDriver_of_reaches (program : Program degree) {initial final : Memory}
    (run : StateTransition.Reaches program.step initial final) :
    ∃ count, execute (program.runDriver count initial) initial = final := by
  obtain ⟨count, reached⟩ := reaches_iterate_advance program run
  exact ⟨count, (execute_runDriver program count initial).trans reached⟩

/-- Every complete partial result is obtained by the same actual path construction. -/
theorem runDriver_of_eval (program : Program degree) {initial final : Memory}
    (result : final ∈ program.eval initial) :
    ∃ count, execute (program.runDriver count initial) initial = final :=
  runDriver_of_reaches program (StateTransition.mem_eval.mp result).1

/-- The whole generated prefix is literally lifted through the two matching real covers. -/
theorem runDriver_actual_lifts (program : Program degree) (count : ℕ) (state : Memory) :
    let driver := program.runDriver count state
    intermediateCurve driver state =
      CoupledPullback.lowerCovering.liftPath driver.restrictedPath
        (CoupledPullback.upperProjection (restrictedState state))
        (driver.restrictedPath.source.trans (restrictedState_over_base state).symm) ∧
    restrictedTrajectory driver state =
      CoupledPullback.upperCovering.liftPath (intermediatePath driver state) (restrictedState state)
        (intermediatePath driver state).source ∧
    restrictedTrajectory driver state 1 = restrictedState ((program.advance)^[count] state) := by
  dsimp only
  refine ⟨intermediateCurve_actual_lift _ _, restrictedTrajectory_actual_lift _ _, ?_⟩
  rw [restrictedTrajectory_end, execute_runDriver]

/-- A native finite run ends at the actual endpoint of this generated upper lift. -/
theorem runDriver_endpoint_of_reaches (program : Program degree) {initial final : Memory}
    (run : StateTransition.Reaches program.step initial final) :
    ∃ count,
      restrictedTrajectory (program.runDriver count initial) initial 1 = restrictedState final := by
  obtain ⟨count, reached⟩ := runDriver_of_reaches program run
  refine ⟨count, ?_⟩
  rw [restrictedTrajectory_end, reached]

end Monodromy.CoupledContinuation.Program
