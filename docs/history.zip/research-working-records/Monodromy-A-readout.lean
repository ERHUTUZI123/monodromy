import «Monodromy-A-source»
import Mathlib.Computability.Primrec.List

namespace Monodromy.TapeCode.Readout

/-- The same fixed positional code is effective on finite words. -/
def wordCode (a : ℕ) (word : List (Fin a)) : ℕ :=
  Nat.ofDigits (a + 1) (word.map Fin.val)

theorem wordCode_foldr (a : ℕ) (word : List (Fin a)) :
    wordCode a word = word.foldr (fun letter total => letter.val + (a + 1) * total) 0 := by
  induction word with
  | nil => rfl
  | cons letter rest recursive => simpa [wordCode, Nat.ofDigits_cons] using congrArg (fun total => letter.val + (a + 1) * total) recursive

theorem primrec_wordCode (a : ℕ) : Primrec (wordCode a) := by
  have folded : Primrec (fun word : List (Fin a) =>
      word.foldr (fun letter total => letter.val + (a + 1) * total) 0) :=
    Primrec.list_foldr Primrec.id (Primrec.const 0)
      (Primrec.nat_add.comp
        (Primrec.fin_val.comp (Primrec.fst.comp Primrec.snd))
        (Primrec.nat_mul.comp (Primrec.const (a + 1)) (Primrec.snd.comp Primrec.snd))).to₂
  exact folded.of_eq (fun word => (wordCode_foldr a word).symm)

section Decoder

variable {a : ℕ} [NeZero a]

/-- The unused last residue is interpreted as blank by a fixed finite table. -/
def extend (read : Fin a → ℕ → ℕ) (letter : Fin (a + 1)) : ℕ → ℕ :=
  Fin.lastCases (read 0) read letter

def digit (a : ℕ) (value : ℕ) : Fin (a + 1) :=
  ⟨value % (a + 1), Nat.mod_lt _ (Nat.succ_pos a)⟩

def step (read : Fin a → ℕ → ℕ) (state : ℕ × ℕ) : ℕ × ℕ :=
  (state.1 / (a + 1), extend read (digit a state.1) state.2)

def run (read : Fin a → ℕ → ℕ) (fuel : ℕ) (state : ℕ × ℕ) : ℕ × ℕ :=
  (step read)^[fuel] state

/-- A bounded numeric readout, independent of the program producing the code. -/
def decode (read : Fin a → ℕ → ℕ) (value : ℕ) : ℕ :=
  (run read value (value, 0)).2

theorem primrec_digit (a : ℕ) : Primrec (digit a) :=
  Primrec.fin_val_iff.mp (Primrec.nat_mod.comp Primrec.id (Primrec.const (a + 1)))

theorem primrec_extend (read : Fin a → ℕ → ℕ) (effective : ∀ letter, Primrec (read letter)) :
    Primrec₂ (extend read) := by
  apply Primrec.fin_curry₁.mpr
  intro letter
  refine Fin.lastCases ?_ (fun original => ?_) letter
  · simpa [extend] using effective 0
  · simpa [extend] using effective original

theorem primrec_step (read : Fin a → ℕ → ℕ) (effective : ∀ letter, Primrec (read letter)) :
    Primrec (step read) :=
  (Primrec.nat_div.comp Primrec.fst (Primrec.const (a + 1))).pair
    ((primrec_extend read effective).comp ((primrec_digit a).comp Primrec.fst) Primrec.snd)

theorem primrec_run (read : Fin a → ℕ → ℕ) (effective : ∀ letter, Primrec (read letter)) :
    Primrec₂ (run read) :=
  (Primrec.nat_iterate Primrec.fst Primrec.snd
    ((primrec_step read effective).comp Primrec.snd).to₂).to₂

theorem primrec_decode (read : Fin a → ℕ → ℕ) (effective : ∀ letter, Primrec (read letter)) :
    Primrec (decode read) :=
  Primrec.snd.comp ((primrec_run read effective).comp Primrec.id (Primrec.id.pair (Primrec.const 0)))

variable (read : Fin a → ℕ → ℕ) (neutral : ∀ initial, read 0 initial = initial)

private theorem fold_blanks (neutral : ∀ initial, read 0 initial = initial) (count initial : ℕ) :
    (List.replicate count (0 : Fin a)).foldl (fun total letter => read letter total) initial = initial := by
  induction count generalizing initial with
  | zero => rfl
  | succ count recursive => simpa only [List.replicate_succ, List.foldl_cons, neutral] using recursive initial

/-- Neutral blank padding makes the human-readable fold a function of the complete half-tape. -/
def tapeFold (neutral : ∀ initial, read 0 initial = initial) (tape : Turing.ListBlank (Fin a)) (initial : ℕ) : ℕ :=
  tape.liftOn (fun word => word.foldl (fun total letter => read letter total) initial) (by
    rintro first _ ⟨count, rfl⟩
    simp [List.foldl_append, Fin.default_eq_zero, fold_blanks read neutral])

@[simp] theorem tapeFold_mk (word : List (Fin a)) (initial : ℕ) :
    tapeFold read neutral (Turing.ListBlank.mk word) initial =
      word.foldl (fun total letter => read letter total) initial := rfl

@[simp] theorem tapeFold_empty (initial : ℕ) :
    tapeFold read neutral (∅ : Turing.ListBlank (Fin a)) initial = initial := rfl

theorem tapeFold_cons (letter : Fin a) (tape : Turing.ListBlank (Fin a)) (initial : ℕ) :
    tapeFold read neutral (tape.cons letter) initial =
      tapeFold read neutral tape (read letter initial) := by
  refine Turing.ListBlank.induction_on tape (fun word => ?_)
  rw [Turing.ListBlank.cons_mk]
  rfl

theorem tapeFold_head_tail (tape : Turing.ListBlank (Fin a)) (initial : ℕ) :
    tapeFold read neutral tape initial = tapeFold read neutral tape.tail (read tape.head initial) := by
  simpa only [Turing.ListBlank.cons_head_tail] using tapeFold_cons read neutral tape.head tape.tail initial

theorem digit_encode (tape : Turing.ListBlank (Fin a)) :
    digit a (TapeCode.encode tape) = tape.head.castSucc := by
  apply Fin.ext
  exact TapeCode.head_code tape

theorem step_encode (tape : Turing.ListBlank (Fin a)) (initial : ℕ) :
    step read (TapeCode.encode tape, initial) = (TapeCode.encode tape.tail, read tape.head initial) := by
  simp [step, TapeCode.tail_code, digit_encode, extend]

theorem step_zero (neutral : ∀ initial, read 0 initial = initial) (initial : ℕ) : step read (0, initial) = (0, initial) := by
  have blank_digit : digit a 0 = (0 : Fin a).castSucc := by apply Fin.ext; rfl
  change (0 / (a + 1), extend read (digit a 0) initial) = (0, initial)
  rw [blank_digit]
  simp only [extend, Fin.lastCases_castSucc, neutral, Nat.zero_div]

theorem run_zero (neutral : ∀ initial, read 0 initial = initial) (fuel initial : ℕ) : run read fuel (0, initial) = (0, initial) :=
  Function.iterate_fixed (step_zero read neutral initial) fuel

theorem run_succ (fuel : ℕ) (state : ℕ × ℕ) :
    run read (fuel + 1) state = run read fuel (step read state) :=
  Function.iterate_succ_apply _ _ _

/-- The numeric code itself is a sufficient uniform bound on the number of useful reads. -/
private theorem run_code (neutral : ∀ initial, read 0 initial = initial) (code : ℕ) :
    ∀ tape : Turing.ListBlank (Fin a), TapeCode.encode tape = code →
      ∀ fuel : ℕ, code ≤ fuel → ∀ initial : ℕ,
        run read fuel (code, initial) = (0, tapeFold read neutral tape initial) := by
  induction code using Nat.strong_induction_on with
  | h code recursive =>
      intro tape encoding fuel enough initial
      by_cases zero : code = 0
      · have blank : tape = ∅ := (TapeCode.encode_eq_zero_iff tape).mp (encoding.trans zero)
        rw [zero, blank, tapeFold_empty]
        exact run_zero read neutral fuel initial
      · have positive : 0 < code := Nat.pos_of_ne_zero zero
        have base_large : 1 < a + 1 := by
          have nonempty := Nat.pos_of_ne_zero (NeZero.ne a)
          omega
        have smaller : TapeCode.encode tape.tail < code := by
          rw [← TapeCode.tail_code tape, encoding]
          exact Nat.div_lt_self positive base_large
        cases fuel with
        | zero => omega
        | succ fuel =>
            have actual_step : step read (code, initial) =
                (TapeCode.encode tape.tail, read tape.head initial) := by
              rw [← encoding]
              exact step_encode read tape initial
            rw [run_succ, actual_step]
            have rest := recursive (TapeCode.encode tape.tail) smaller tape.tail rfl fuel
              (by omega) (read tape.head initial)
            exact rest.trans (congrArg (fun value => (0, value))
              (tapeFold_head_tail read neutral tape initial).symm)

/-- The code is fully consumed and its fold is exact after any sufficient bounded iteration. -/
theorem run_tape_state (tape : Turing.ListBlank (Fin a)) (fuel : ℕ)
    (enough : TapeCode.encode tape ≤ fuel) (initial : ℕ) :
    run read fuel (TapeCode.encode tape, initial) = (0, tapeFold read neutral tape initial) :=
  run_code read neutral (TapeCode.encode tape) tape rfl fuel enough initial

/-- Every representative, including arbitrary blank padding, has the same bounded numeric readout. -/
theorem run_tape (tape : Turing.ListBlank (Fin a)) (fuel : ℕ)
    (enough : TapeCode.encode tape ≤ fuel) (initial : ℕ) :
    (run read fuel (TapeCode.encode tape, initial)).2 = tapeFold read neutral tape initial :=
  congrArg Prod.snd (run_tape_state read neutral tape fuel enough initial)

/-- The fixed total primitive-recursive decoder agrees with the blank-invariant tape fold. -/
theorem decode_tape (tape : Turing.ListBlank (Fin a)) :
    decode read (TapeCode.encode tape) = tapeFold read neutral tape 0 :=
  run_tape read neutral tape (TapeCode.encode tape) le_rfl 0

/-- In particular the same readout acts on every finite word, without choosing a representative. -/
theorem decode_word (neutral : ∀ initial, read 0 initial = initial) (word : List (Fin a)) :
    decode read (wordCode a word) = word.foldl (fun total letter => read letter total) 0 :=
  decode_tape read neutral (Turing.ListBlank.mk word)

end Decoder

end Monodromy.TapeCode.Readout

#print axioms Monodromy.TapeCode.Readout.primrec_wordCode
#print axioms Monodromy.TapeCode.Readout.primrec_decode
#print axioms Monodromy.TapeCode.Readout.decode_tape
