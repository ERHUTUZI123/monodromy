import Monodromy.Counter

/-! Proof-only source-return marks in the existing native control root. -/
noncomputable section

namespace Monodromy.CounterContinuation

open CoupledContinuation

/-- A source boundary is observed from the actual cubic control root alone. -/
def SourceBoundary (state : Memory) : Prop := controlRoot 3 state = 1

theorem controlRoot_label {m : ℕ} (position : Fin m) (phase : Fin 3) (left right : ℤ) :
    controlRoot 3 (prepare left right (label position phase)) = (Radix.omega 3 phase : ℂ) := by
  rw [controlRoot_prepare, label_eq]
  have reorder : (phase.val : ℤ) + 3 * (position.val : ℤ) =
      (3 : ℤ) * (position.val : ℤ) + phase.val := by omega
  rw [reorder]
  exact congrArg (fun root : Circle => (root : ℂ))
    (Radix.readRoot_digit 3 (position.val : ℤ) phase)

theorem sourceBoundary_label_iff {m : ℕ} (position : Fin m) (phase : Fin 3)
    (left right : ℤ) :
    SourceBoundary (prepare left right (label position phase)) ↔ phase = 0 := by
  have root_zero : (Radix.omega 3 (0 : Fin 3) : ℂ) = 1 := by simp [Radix.omega]
  constructor
  · intro boundary
    apply Radix.omega_injective 3
    apply Subtype.ext
    exact (controlRoot_label position phase left right).symm.trans (boundary.trans root_zero.symm)
  · rintro rfl
    exact (controlRoot_label position 0 left right).trans root_zero

@[simp] theorem sourceBoundary_encode {m : ℕ} (state : Counter.Configuration 2 m) :
    SourceBoundary (encode state) :=
  (sourceBoundary_label_iff state.pc 0 _ _).mpr rfl

variable {m : ℕ} [NeZero m]

/-- The first actual native return moves every live source state to phase one or two. -/
theorem advance_live_phase (program : Counter.Program 2 m) (state : Counter.Configuration 2 m)
    (live : program state.pc ≠ .halt) :
    (compile program).advance (encode state) =
      prepare (state.counters 0 : ℤ) (state.counters 1 : ℤ) (label state.pc 1) ∨
    (compile program).advance (encode state) =
      prepare (state.counters 0 : ℤ) (state.counters 1 : ℤ) (label state.pc 2) := by
  unfold encode
  cases instruction : program state.pc with
  | halt => exact False.elim (live instruction)
  | inc register target =>
      exact Or.inl (advance_inc_first program state.pc target register instruction _ _)
  | dec register zero nonzero =>
      rw [advance_dec_first program state.pc zero nonzero register instruction]
      by_cases zero_value : (![(state.counters 0 : ℤ), (state.counters 1 : ℤ)] register) = 0
      · right
        rw [ite_eq_left zero_value]
        congr 1
        simp only [label_eq]
        omega
      · left
        simp only [ite_eq_right zero_value, add_zero]

theorem advance_live_not_boundary (program : Counter.Program 2 m)
    (state : Counter.Configuration 2 m) (live : program state.pc ≠ .halt) :
    ¬ SourceBoundary ((compile program).advance (encode state)) := by
  rcases advance_live_phase program state live with first | second
  · rw [first, sourceBoundary_label_iff]
    decide
  · rw [second, sourceBoundary_label_iff]
    decide

/-- Exactly two actual native returns separate consecutive marked source states. -/
theorem two_returns_with_boundary (program : Counter.Program 2 m)
    (state result : Counter.Configuration 2 m) (source_step : Counter.step program state = some result) :
    ∃ middle : Memory,
      SourceBoundary (encode state) ∧
      (compile program).step (encode state) = some middle ∧
      ¬ SourceBoundary middle ∧
      (compile program).step middle = some (encode result) ∧
      SourceBoundary (encode result) := by
  obtain ⟨middle, first, second⟩ := two_returns program state result source_step
  have live : program state.pc ≠ .halt := by
    intro halted
    simp [Counter.step, halted] at source_step
  have running : stopping program state.pc 0 = false := by
    cases instruction : program state.pc <;> simp [stopping, instructionStop, instruction] at live ⊢
  have actual_first : (compile program).step (encode state) =
      some ((compile program).advance (encode state)) :=
    step_running_at program state.pc 0 running _ _
  have identifies : middle = (compile program).advance (encode state) :=
    Option.some.inj (first.symm.trans actual_first)
  refine ⟨middle, sourceBoundary_encode state, first, ?_, second, sourceBoundary_encode result⟩
  rw [identifies]
  exact advance_live_not_boundary program state live

end Monodromy.CounterContinuation
