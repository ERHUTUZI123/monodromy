import Monodromy.FormalCompilation
import Monodromy.Effectiveness

/-! Authoritative proofs are exported by the repository modules. -/
