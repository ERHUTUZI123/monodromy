# Monodromy A

当前正式源码：`/Users/xiaoyangliu/Desktop/monodromy/src/Monodromy/`。

原生几何图灵通用性、精确首次返回与实际提升证明已整合。
当前正在完成目录收敛、固定接口刻画、干净构建与公理审计。
B 短文现位于 `notes/monodromy-note.tex`，按附加写作要求修订。

最新状态与证据入口：`docs/NOW.md`、`docs/structure.md`。
旧源码及工作证明已封存于 `docs/history.zip`。
