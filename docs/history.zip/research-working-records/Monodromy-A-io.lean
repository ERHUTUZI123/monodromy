import Mathlib.Computability.Primrec.Basic
import Mathlib.Data.Nat.Factorization.Basic

namespace Monodromy.PrimeReadout

/-- A bounded search reads a prime exponent without an unbounded factorization oracle. -/
def exponent (prime input : ℕ) : ℕ := input.findGreatest (fun power => prime ^ power ∣ input)

theorem primrec_power (base : ℕ) : Primrec (fun power : ℕ => base ^ power) :=
  (Primrec₂.unpaired'.mp Nat.Primrec.pow).comp (Primrec.const base) Primrec.id

theorem primrec_exponent (prime : ℕ) : Primrec (exponent prime) := by
  have divides : PrimrecRel (fun input power : ℕ => prime ^ power ∣ input) := by
    have remainder : Primrec (fun pair : ℕ × ℕ => pair.1 % prime ^ pair.2) :=
      Primrec.nat_mod.comp Primrec.fst ((primrec_power prime).comp Primrec.snd)
    exact (Primrec.eq.comp remainder (Primrec.const 0)).primrecRel.of_eq
      (fun _ _ => Nat.dvd_iff_mod_eq_zero.symm)
  exact Primrec.nat_findGreatest Primrec.id divides

/-- For a prime, the bounded readout agrees with the exact factorization exponent. -/
theorem exponent_eq_factorization {prime : ℕ} (is_prime : prime.Prime) (input : ℕ) :
    exponent prime input = input.factorization prime := by
  by_cases zero : input = 0
  · subst input
    simp [exponent]
  · apply Nat.findGreatest_eq_iff.mpr
    refine ⟨(Nat.factorization_lt prime zero).le, ?_, ?_⟩
    · intro _
      exact (is_prime.pow_dvd_iff_le_factorization zero).mpr le_rfl
    · intro power larger _ divides
      exact (not_lt_of_ge ((is_prime.pow_dvd_iff_le_factorization zero).mp divides)) larger

end Monodromy.PrimeReadout
