import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Logic.Function.Basic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Lean.Elab.Tactic.Omega

namespace Monodromy.PrimeCode

/-- A classical proof-side encoding of three source registers, using fixed distinct primes. -/
def prime (index : Fin 3) : ℕ := if index = 0 then 2 else if index = 1 then 3 else 5

def encode (registers : Fin 3 → ℕ) : ℕ :=
  2 ^ registers 0 * 3 ^ registers 1 * 5 ^ registers 2

theorem prime_prime (index : Fin 3) : (prime index).Prime := by
  fin_cases index <;> norm_num [prime] <;> decide

theorem encode_positive (registers : Fin 3 → ℕ) : 0 < encode registers := by
  unfold encode
  positivity

/-- Prime valuations recover each source register exactly. -/
theorem factorization_encode (registers : Fin 3 → ℕ) (index : Fin 3) :
    (encode registers).factorization (prime index) = registers index := by
  unfold encode
  rw [Nat.factorization_mul
      (mul_ne_zero (pow_ne_zero _ (by decide)) (pow_ne_zero _ (by decide)))
      (pow_ne_zero _ (by decide)),
    Nat.factorization_mul (pow_ne_zero _ (by decide)) (pow_ne_zero _ (by decide)),
    (show Nat.Prime 2 by decide).factorization_pow,
    (show Nat.Prime 3 by decide).factorization_pow,
    (show Nat.Prime 5 by decide).factorization_pow]
  fin_cases index <;> simp [prime]

def decode (code : ℕ) : Fin 3 → ℕ := fun index => code.factorization (prime index)

theorem decode_encode : Function.LeftInverse decode encode := by
  intro registers
  funext index
  exact factorization_encode registers index

theorem encode_injective : Function.Injective encode := decode_encode.injective

@[simp] theorem encode_zero : encode (fun _ => 0) = 1 := by simp [encode]

/-- Incrementing a source register multiplies the single code by its fixed prime. -/
theorem encode_increment (registers : Fin 3 → ℕ) (index : Fin 3) :
    encode (Function.update registers index (registers index + 1)) = prime index * encode registers := by
  fin_cases index <;> norm_num [encode, prime, Function.update_apply, pow_add] <;> ring

/-- Divisibility is precisely the nonzero test for the corresponding source register. -/
theorem prime_dvd_encode_iff (registers : Fin 3 → ℕ) (index : Fin 3) :
    prime index ∣ encode registers ↔ registers index ≠ 0 := by
  rw [(prime_prime index).dvd_iff_one_le_factorization (encode_positive registers).ne',
    factorization_encode]
  omega

theorem register_zero_iff (registers : Fin 3 → ℕ) (index : Fin 3) :
    registers index = 0 ↔ ¬ prime index ∣ encode registers := by
  rw [prime_dvd_encode_iff]
  omega

theorem remainder_zero_iff (registers : Fin 3 → ℕ) (index : Fin 3) :
    encode registers % prime index = 0 ↔ registers index ≠ 0 := by
  rw [← Nat.dvd_iff_mod_eq_zero, prime_dvd_encode_iff]

/-- A nonzero source decrement is exact division of the positive code. -/
theorem encode_decrement (registers : Fin 3 → ℕ) (index : Fin 3)
    (nonzero : registers index ≠ 0) :
    encode (Function.update registers index (registers index - 1)) = encode registers / prime index := by
  let previous := Function.update registers index (registers index - 1)
  have restores : Function.update previous index (previous index + 1) = registers := by
    funext other
    by_cases same : other = index
    · subst other
      simp only [previous, Function.update_self]
      omega
    · simp [previous, same]
  have restores_code := encode_increment previous index
  rw [restores] at restores_code
  change encode previous = encode registers / prime index
  rw [restores_code, Nat.mul_div_cancel_left _ (prime_prime index).pos]

end Monodromy.PrimeCode
