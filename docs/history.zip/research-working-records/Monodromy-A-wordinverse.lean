import «Monodromy-A-counter»

noncomputable section

namespace Monodromy.CoupledContinuation

/-- An inverse program reverses the word and each oriented geometric loop. -/
def Word.inverse : Word → Word
  | [] => []
  | (gate, backward) :: rest => Word.inverse rest ++ Word.atom gate (!backward)

private theorem execute_opposite (gate : Gate) (backward : Bool) (state : Memory) :
    execute (if !backward then gate.driver.reverse else gate.driver)
      (execute (if backward then gate.driver.reverse else gate.driver) state) = state := by
  cases backward
  · exact execute_driver_reverse gate.driver state
  · exact execute_after_driver_reverse gate.driver state

theorem execute_word_inverse (word : Word) (state : Memory) :
    execute (Word.driver word.inverse) (execute (Word.driver word) state) = state := by
  induction word generalizing state with
  | nil => rw [Word.inverse, execute_word_nil, execute_word_nil]
  | cons atom rest inverse_rest =>
      rcases atom with ⟨gate, backward⟩
      rw [Word.inverse, execute_word_append, execute_word_cons, inverse_rest, execute_word_atom]
      exact execute_opposite gate backward state

theorem Word.inverse_inverse (word : Word) : word.inverse.inverse = word := by
  have append_inverse : ∀ first second : Word,
      (first ++ second).inverse = second.inverse ++ first.inverse := by
    intro first second
    induction first with
    | nil => simp [Word.inverse]
    | cons atom rest recursive =>
        rcases atom with ⟨gate, backward⟩
        simp [Word.inverse, recursive, List.append_assoc]
  induction word with
  | nil => rfl
  | cons atom rest recursive =>
      rcases atom with ⟨gate, backward⟩
      simp [Word.inverse, append_inverse, recursive, Word.atom]

theorem execute_after_word_inverse (word : Word) (state : Memory) :
    execute (Word.driver word) (execute (Word.driver word.inverse) state) = state := by
  have backwards := execute_word_inverse word.inverse state
  simpa only [Word.inverse_inverse] using backwards

end Monodromy.CoupledContinuation

namespace Monodromy.CoupledContinuation

theorem Word.inverse_length (word : Word) : word.inverse.length = word.length := by
  induction word with
  | nil => rfl
  | cons atom rest recursive =>
      rcases atom with ⟨gate, backward⟩
      simp [Word.inverse, Word.atom, recursive]

/-- The finite inverse program has exactly the transport of the actual reverse path. -/
theorem execute_inverse_word_eq (word : Word) (state : Memory) :
    execute (Word.driver word.inverse) state = execute (Word.driver word).reverse state := by
  have inverse := execute_word_inverse word (execute (Word.driver word).reverse state)
  rw [execute_after_driver_reverse] at inverse
  exact inverse

end Monodromy.CoupledContinuation
