import Monodromy.Continuation

namespace Monodromy.CoupledContinuation

/-- An admissible based deformation preserves the complete native root state. -/
theorem execute_homotopic (first second : Driver)
    (deformation : first.restrictedPath.Homotopic second.restrictedPath) (state : Memory) :
    execute first state = execute second state := by
  have lower_deformation : (intermediateCurve first state).HomotopicRel
      (intermediateCurve second state) {0, 1} := by
    rw [intermediateCurve_actual_lift first state, intermediateCurve_actual_lift second state]
    exact CoupledPullback.lowerCovering.homotopicRel_liftPath deformation
      (CoupledPullback.upperProjection (restrictedState state))
      (first.restrictedPath.source.trans (restrictedState_over_base state).symm)
      (second.restrictedPath.source.trans (restrictedState_over_base state).symm)
  have upper_end := CoupledPullback.upperCovering.liftPath_apply_one_eq_of_homotopicRel
    lower_deformation (restrictedState state)
      (intermediatePath first state).source (intermediatePath second state).source
  have endpoints : restrictedTrajectory first state 1 = restrictedTrajectory second state 1 := by
    rw [restrictedTrajectory_actual_lift first state, restrictedTrajectory_actual_lift second state]
    exact upper_end
  apply Subtype.ext
  exact congrArg forgetPoint endpoints

end Monodromy.CoupledContinuation
