import «Monodromy-A-source»
import Mathlib.Computability.TuringMachine.PostTuringMachine

/-! A classical finite-table source compiler. Native geometry is unchanged. -/
noncomputable section

namespace Monodromy.Counter.TuringCompiler

open Turing

variable (a q : ℕ) [NeZero a] [NeZero q]

def base : ℕ := a + 1
instance base_neZero : NeZero (base a) := ⟨by simp [base]⟩

abbrev Row := Fin q × Fin a
abbrev Phase := Unit ⊕ (Fin (base a + 4) ⊕ (Fin a ⊕ Fin (DivMod.size (base a))))
abbrev Address := Row a q × Phase a

def size : ℕ := Fintype.card (Address a q)

def address : Address a q ≃ Fin (size a q) := Fintype.equivFin _

def dispatch (row : Row a q) : Fin (size a q) := address a q (row, Sum.inl ())
def multiply (row : Row a q) (cell : Fin (base a + 4)) : Fin (size a q) :=
  address a q (row, Sum.inr (Sum.inl cell))
def add (row : Row a q) (remaining : Fin a) : Fin (size a q) :=
  address a q (row, Sum.inr (Sum.inr (Sum.inl remaining)))
def divide (row : Row a q) (cell : Fin (DivMod.size (base a))) : Fin (size a q) :=
  address a q (row, Sum.inr (Sum.inr (Sum.inr cell)))

omit [NeZero a] [NeZero q] in
@[simp] theorem address_dispatch (row : Row a q) :
    (address a q).symm (dispatch a q row) = (row, Sum.inl ()) :=
  (address a q).symm_apply_apply _
omit [NeZero a] [NeZero q] in
@[simp] theorem address_multiply (row : Row a q) (cell : Fin (base a + 4)) :
    (address a q).symm (multiply a q row cell) = (row, Sum.inr (Sum.inl cell)) :=
  (address a q).symm_apply_apply _
omit [NeZero a] [NeZero q] in
@[simp] theorem address_add (row : Row a q) (remaining : Fin a) :
    (address a q).symm (add a q row remaining) =
      (row, Sum.inr (Sum.inr (Sum.inl remaining))) :=
  (address a q).symm_apply_apply _
omit [NeZero a] [NeZero q] in
@[simp] theorem address_divide (row : Row a q) (cell : Fin (DivMod.size (base a))) :
    (address a q).symm (divide a q row cell) =
      (row, Sum.inr (Sum.inr (Sum.inr cell))) :=
  (address a q).symm_apply_apply _

omit [NeZero a] [NeZero q] in
theorem dispatch_injective : Function.Injective (dispatch a q) := by
  intro first second same
  exact congrArg Prod.fst ((address a q).injective same)

def counters (left right : ℕ) : Fin 3 → ℕ := ![left, right, 0]

def encode (state : TM0.Cfg (Fin a) (Fin q)) : Configuration 3 (size a q) :=
  ⟨dispatch a q (state.q, state.Tape.head),
    counters (TapeCode.encode state.Tape.left) (TapeCode.encode state.Tape.right)⟩

omit [NeZero q] in
theorem encode_injective : Function.Injective (encode a q) := by
  intro first second same
  cases first with
  | mk fq ft =>
    cases second with
    | mk sq st =>
      cases ft with
      | mk fh fl fr =>
        cases st with
        | mk sh sl sr =>
          have row := dispatch_injective a q (congrArg Configuration.pc same)
          have left : TapeCode.encode fl = TapeCode.encode sl :=
            congrFun (congrArg Configuration.counters same) 0
          have right : TapeCode.encode fr = TapeCode.encode sr :=
            congrFun (congrArg Configuration.counters same) 1
          have heq : fh = sh := congrArg Prod.snd row
          have qeq : fq = sq := congrArg Prod.fst row
          have leq := TapeCode.encode_injective left
          have req := TapeCode.encode_injective right
          cases heq
          cases qeq
          cases leq
          cases req
          rfl

def pushRegister : Dir → Fin 2 | .left => 1 | .right => 0
def popRegister : Dir → Fin 2 | .left => 0 | .right => 1

def mulTarget (row : Row a q) (cell : Fin (base a + 4)) : Fin (size a q) :=
  if cell = CounterMultiplication.finish (base a) then add a q row row.2
  else multiply a q row cell

def symbol (remainder : Fin (base a)) : Fin a :=
  if bound : remainder.val < a then ⟨remainder.val, bound⟩ else 0

def divTarget (row : Row a q) (target : Fin q)
    (cell : Fin (DivMod.size (base a))) : Fin (size a q) :=
  if terminal : ∃ remainder, cell = DivMod.finish (base a) remainder then
    dispatch a q (target, symbol a terminal.choose)
  else divide a q row cell

omit [NeZero a] [NeZero q] in
@[simp] theorem mulTarget_finish (row : Row a q) :
    mulTarget a q row (CounterMultiplication.finish (base a)) = add a q row row.2 := by
  simp [mulTarget]

omit [NeZero q] in
@[simp] theorem divTarget_finish (row : Row a q) (target : Fin q)
    (remainder : Fin (base a)) :
    divTarget a q row target (DivMod.finish (base a) remainder) =
      dispatch a q (target, symbol a remainder) := by
  have terminal : ∃ r, DivMod.finish (base a) remainder = DivMod.finish (base a) r :=
    ⟨remainder, rfl⟩
  have chosen : terminal.choose = remainder :=
    (DivMod.finish_injective (base a) terminal.choose_spec).symm
  simp only [divTarget, dite_eq_left terminal, chosen]

def previous (remaining : Fin a) : Fin a :=
  ⟨remaining.val - 1, lt_of_le_of_lt (Nat.sub_le _ _) remaining.isLt⟩

def body (machine : TM0.Machine (Fin a) (Fin q)) (location : Address a q) :
    Instruction 3 (size a q) :=
  let row := location.1
  match machine row.1 row.2 with
  | none => .halt
  | some (target, .write value) =>
      match location.2 with
      | .inl () => .dec 2 (dispatch a q (target, value)) (dispatch a q (target, value))
      | .inr _ => .halt
  | some (target, .move direction) =>
      match location.2 with
      | .inl () => .dec 2 (mulTarget a q row 0) (mulTarget a q row 0)
      | .inr (.inl cell) =>
          mapInstruction (mulTarget a q row)
            (RegisterRelocation.instruction
              (RegisterRelocation.pairIntoThree (pushRegister direction))
              (CounterMultiplication.program (base a) cell))
      | .inr (.inr (.inl remaining)) =>
          if remaining.val = 0 then
            .dec 2 (divTarget a q row target (DivMod.consume (base a) 0))
              (divTarget a q row target (DivMod.consume (base a) 0))
          else .inc (pushRegister direction).castSucc (add a q row (previous a remaining))
      | .inr (.inr (.inr cell)) =>
          mapInstruction (divTarget a q row target)
            (RegisterRelocation.instruction
              (RegisterRelocation.pairIntoThree (popRegister direction))
              (DivMod.program (base a) cell))

def program (machine : TM0.Machine (Fin a) (Fin q)) : Program 3 (size a q) :=
  fun cell => body a q machine ((address a q).symm cell)

@[simp] theorem program_dispatch (machine : TM0.Machine (Fin a) (Fin q)) (row : Row a q) :
    program a q machine (dispatch a q row) =
      match machine row.1 row.2 with
      | none => .halt
      | some (target, .write value) =>
          .dec 2 (dispatch a q (target, value)) (dispatch a q (target, value))
      | some (_, .move _) => .dec 2 (mulTarget a q row 0) (mulTarget a q row 0) := by
  simp only [program, address_dispatch, body]

theorem halt_encode (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) :
    step (program a q machine) (encode a q state) = none ↔ TM0.step machine state = none := by
  simp only [step, encode, program_dispatch, TM0.step]
  cases result : machine state.q state.Tape.head with
  | none => simp
  | some command =>
      rcases command with ⟨target, operation⟩
      cases operation <;> simp [counters]

theorem write_step (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (target : Fin q) (value : Fin a)
    (instruction : machine state.q state.Tape.head = some (target, .write value)) :
    step (program a q machine) (encode a q state) =
      some (encode a q ⟨target, state.Tape.write value⟩) := by
  simp [step, encode, instruction, counters, Tape.write]

/-- A marked source boundary is determined by the finite program counter alone. -/
def Boundary (cell : Fin (size a q)) : Prop := ∃ row, cell = dispatch a q row

omit [NeZero q] in
@[simp] theorem encode_boundary (state : TM0.Cfg (Fin a) (Fin q)) :
    Boundary a q (encode a q state).pc := ⟨(state.q, state.Tape.head), rfl⟩

omit [NeZero a] [NeZero q] in
theorem multiply_not_boundary (row : Row a q) (cell : Fin (base a + 4)) :
    ¬ Boundary a q (multiply a q row cell) := by
  rintro ⟨other, same⟩
  have incompatible := congrArg Prod.snd ((address a q).injective same)
  cases incompatible

omit [NeZero a] [NeZero q] in
theorem add_not_boundary (row : Row a q) (remaining : Fin a) :
    ¬ Boundary a q (add a q row remaining) := by
  rintro ⟨other, same⟩
  have incompatible := congrArg Prod.snd ((address a q).injective same)
  cases incompatible

omit [NeZero a] [NeZero q] in
theorem divide_not_boundary (row : Row a q) (cell : Fin (DivMod.size (base a))) :
    ¬ Boundary a q (divide a q row cell) := by
  rintro ⟨other, same⟩
  have incompatible := congrArg Prod.snd ((address a q).injective same)
  cases incompatible

/-- Internal arithmetic transitions exclude dispatch cells at their source. -/
def InternalStep (machine : TM0.Machine (Fin a) (Fin q))
    (first last : Configuration 3 (size a q)) : Prop :=
  step (program a q machine) first = some last ∧ ¬ Boundary a q first.pc

abbrev InternalReaches (machine : TM0.Machine (Fin a) (Fin q)) :=
  Relation.ReflTransGen (InternalStep a q machine)

private theorem map_internal {m : ℕ}
    (machine : TM0.Machine (Fin a) (Fin q)) (oldProgram : Program 3 m)
    (rename : Fin m → Fin (size a q))
    (agrees : ∀ cell, oldProgram cell ≠ .halt →
      program a q machine (rename cell) = mapInstruction rename (oldProgram cell))
    (internal : ∀ cell, oldProgram cell ≠ .halt → ¬ Boundary a q (rename cell))
    {first last : Configuration 3 m}
    (run : StateTransition.Reaches (step oldProgram) first last) :
    InternalReaches a q machine (mapConfiguration rename first) (mapConfiguration rename last) := by
  induction run with
  | refl => exact Relation.ReflTransGen.refl
  | @tail middle last _ edge previous =>
      apply previous.tail
      constructor
      · exact step_map_live rename oldProgram (program a q machine) agrees edge
      · apply internal
        intro halted
        simp [step, halted] at edge

private theorem mul_live (machine : TM0.Machine (Fin a) (Fin q))
    (row : Row a q) (target : Fin q) (direction : Dir)
    (selected : machine row.1 row.2 = some (target, .move direction))
    (cell : Fin (base a + 4))
    (live : RegisterRelocation.program
      (RegisterRelocation.pairIntoThree (pushRegister direction))
      (CounterMultiplication.program (base a)) cell ≠ .halt) :
    program a q machine (mulTarget a q row cell) =
      mapInstruction (mulTarget a q row)
        (RegisterRelocation.program
          (RegisterRelocation.pairIntoThree (pushRegister direction))
          (CounterMultiplication.program (base a)) cell) ∧
    ¬ Boundary a q (mulTarget a q row cell) := by
  have not_finish : cell ≠ CounterMultiplication.finish (base a) := by
    intro same
    subst cell
    simp [RegisterRelocation.program, RegisterRelocation.instruction,
      CounterMultiplication.program_finish] at live
  constructor
  · simp [mulTarget, not_finish, program, body, selected, RegisterRelocation.program]
  · simpa only [mulTarget, ite_eq_right not_finish] using multiply_not_boundary a q row cell

private theorem div_live (machine : TM0.Machine (Fin a) (Fin q))
    (row : Row a q) (target : Fin q) (direction : Dir)
    (selected : machine row.1 row.2 = some (target, .move direction))
    (cell : Fin (DivMod.size (base a)))
    (live : RegisterRelocation.program
      (RegisterRelocation.pairIntoThree (popRegister direction))
      (DivMod.program (base a)) cell ≠ .halt) :
    program a q machine (divTarget a q row target cell) =
      mapInstruction (divTarget a q row target)
        (RegisterRelocation.program
          (RegisterRelocation.pairIntoThree (popRegister direction))
          (DivMod.program (base a)) cell) ∧
    ¬ Boundary a q (divTarget a q row target cell) := by
  have not_finish : ¬ ∃ remainder, cell = DivMod.finish (base a) remainder := by
    rintro ⟨remainder, rfl⟩
    simp [RegisterRelocation.program, RegisterRelocation.instruction] at live
  constructor
  · simp [divTarget, not_finish, program, body, selected, RegisterRelocation.program]
  · simpa only [divTarget, dite_eq_right not_finish] using divide_not_boundary a q row cell

def frame (active : Fin 2) (first spectator : ℕ) : Fin 3 → ℕ :=
  if active = 0 then counters first spectator else counters spectator first

private theorem extend_frame (active : Fin 2) (old value spectator : ℕ) :
    Function.extend (RegisterRelocation.pairIntoThree active) ![value, 0]
      (frame active old spectator) = frame active value spectator := by
  have first := (RegisterRelocation.pairIntoThree_injective active).extend_apply
    ![value, 0] (frame active old spectator) (0 : Fin 2)
  have scratch := (RegisterRelocation.pairIntoThree_injective active).extend_apply
    ![value, 0] (frame active old spectator) (1 : Fin 2)
  fin_cases active <;> funext index <;> fin_cases index
  all_goals first
    | exact first
    | exact scratch
    | apply Function.extend_apply'
      rintro ⟨source, same⟩
      fin_cases source <;> norm_num [RegisterRelocation.pairIntoThree] at same

/-- Multiplication uses only its allocated stack and the shared zero scratch. -/
theorem multiply_reaches (machine : TM0.Machine (Fin a) (Fin q))
    (row : Row a q) (target : Fin q) (direction : Dir)
    (selected : machine row.1 row.2 = some (target, .move direction))
    (value spectator : ℕ) :
    InternalReaches a q machine
      ⟨mulTarget a q row 0, frame (pushRegister direction) value spectator⟩
      ⟨add a q row row.2, frame (pushRegister direction) (base a * value) spectator⟩ := by
  have relocated := RegisterRelocation.reaches_embed
    (RegisterRelocation.pairIntoThree (pushRegister direction))
    (RegisterRelocation.pairIntoThree_injective (pushRegister direction))
    (frame (pushRegister direction) value spectator)
    (CounterMultiplication.program (base a))
    (CounterMultiplication.reaches_result (base a) value)
  have embedded := map_internal a q machine _ (mulTarget a q row)
    (fun cell live => (mul_live a q machine row target direction selected cell live).1)
    (fun cell live => (mul_live a q machine row target direction selected cell live).2)
    relocated
  simpa only [mapConfiguration, RegisterRelocation.embed, CounterMultiplication.configuration,
    extend_frame, mulTarget_finish] using embedded

/-- Division returns the remainder in finite control and clears the shared scratch. -/
theorem divide_reaches (machine : TM0.Machine (Fin a) (Fin q))
    (row : Row a q) (target : Fin q) (direction : Dir)
    (selected : machine row.1 row.2 = some (target, .move direction))
    (value spectator : ℕ) :
    InternalReaches a q machine
      ⟨divTarget a q row target (DivMod.consume (base a) 0),
        frame (popRegister direction) value spectator⟩
      ⟨dispatch a q (target, symbol a (DivMod.residue (base a) value)),
        frame (popRegister direction) (value / base a) spectator⟩ := by
  have relocated := RegisterRelocation.reaches_embed
    (RegisterRelocation.pairIntoThree (popRegister direction))
    (RegisterRelocation.pairIntoThree_injective (popRegister direction))
    (frame (popRegister direction) value spectator)
    (DivMod.program (base a)) (DivMod.reaches_divmod (base a) value)
  have embedded := map_internal a q machine _ (divTarget a q row target)
    (fun cell live => (div_live a q machine row target direction selected cell live).1)
    (fun cell live => (div_live a q machine row target direction selected cell live).2)
    relocated
  simpa only [mapConfiguration, RegisterRelocation.embed, DivMod.configuration,
    extend_frame, divTarget_finish] using embedded

private theorem frame_scratch (active : Fin 2) (value spectator : ℕ) :
    frame active value spectator 2 = 0 := by
  fin_cases active <;> rfl

private theorem frame_increment (active : Fin 2) (value spectator : ℕ) :
    Function.update (frame active value spectator) active.castSucc
      (frame active value spectator active.castSucc + 1) = frame active (value + 1) spectator := by
  fin_cases active <;> funext index <;> fin_cases index <;> simp [frame, counters]

/-- A finite countdown writes the old head digit, then enters the division macro. -/
theorem add_reaches (machine : TM0.Machine (Fin a) (Fin q))
    (row : Row a q) (target : Fin q) (direction : Dir)
    (selected : machine row.1 row.2 = some (target, .move direction))
    (remaining : Fin a) (value spectator : ℕ) :
    InternalReaches a q machine
      ⟨add a q row remaining, frame (pushRegister direction) value spectator⟩
      ⟨divTarget a q row target (DivMod.consume (base a) 0),
        frame (pushRegister direction) (value + remaining.val) spectator⟩ := by
  have countdown : ∀ count (digit : Fin a), digit.val = count → ∀ current,
      InternalReaches a q machine
        ⟨add a q row digit, frame (pushRegister direction) current spectator⟩
        ⟨divTarget a q row target (DivMod.consume (base a) 0),
          frame (pushRegister direction) (current + count) spectator⟩ := by
    intro count
    induction count with
    | zero =>
        intro digit digit_zero current
        apply Relation.ReflTransGen.single
        constructor
        · simpa only [Nat.add_zero] using
            step_dec_zero (program a q machine)
              ⟨add a q row digit, frame (pushRegister direction) current spectator⟩
              (reg := 2)
              (zero := divTarget a q row target (DivMod.consume (base a) 0))
              (nonzero := divTarget a q row target (DivMod.consume (base a) 0))
              (by simp [program, body, selected, digit_zero])
              (frame_scratch (pushRegister direction) current spectator)
        · exact add_not_boundary a q row digit
    | succ count induction_hypothesis =>
        intro digit digit_succ current
        have nonzero : digit.val ≠ 0 := by omega
        have previous_count : (previous a digit).val = count := by
          simp only [previous]
          omega
        have edge : step (program a q machine)
            ⟨add a q row digit, frame (pushRegister direction) current spectator⟩ =
            some ⟨add a q row (previous a digit),
              frame (pushRegister direction) (current + 1) spectator⟩ := by
          simpa only [frame_increment] using
            step_inc (program a q machine)
              ⟨add a q row digit, frame (pushRegister direction) current spectator⟩
              (reg := (pushRegister direction).castSucc)
              (next := add a q row (previous a digit))
              (by simp [program, body, selected, nonzero])
        have rest := induction_hypothesis (previous a digit) previous_count (current + 1)
        have arithmetic : current + 1 + count = current + (count + 1) := by omega
        rw [arithmetic] at rest
        exact Relation.ReflTransGen.head ⟨edge, add_not_boundary a q row digit⟩ rest
  exact countdown remaining.val remaining rfl value

theorem symbol_tape (tape : ListBlank (Fin a)) :
    symbol a (DivMod.residue (base a) (TapeCode.encode tape)) = tape.head := by
  have remainder : (DivMod.residue (base a) (TapeCode.encode tape)).val = tape.head.val :=
    TapeCode.head_code tape
  have small : (DivMod.residue (base a) (TapeCode.encode tape)).val < a := by
    rw [remainder]
    exact tape.head.isLt
  apply Fin.ext
  simp only [symbol, dite_eq_left small]
  exact remainder

/-- A move traverses only arithmetic PCs until its exact successor dispatch. -/
theorem move_reaches (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (target : Fin q) (direction : Dir)
    (selected : machine state.q state.Tape.head = some (target, .move direction)) :
    InternalReaches a q machine
      ⟨mulTarget a q (state.q, state.Tape.head) 0, (encode a q state).counters⟩
      (encode a q ⟨target, state.Tape.move direction⟩) := by
  cases direction with
  | left =>
      have multiplied := multiply_reaches a q machine (state.q, state.Tape.head) target .left
        selected (TapeCode.encode state.Tape.right) (TapeCode.encode state.Tape.left)
      have written := add_reaches a q machine (state.q, state.Tape.head) target .left
        selected state.Tape.head (base a * TapeCode.encode state.Tape.right)
        (TapeCode.encode state.Tape.left)
      have divided := divide_reaches a q machine (state.q, state.Tape.head) target .left
        selected (TapeCode.encode state.Tape.left)
        (base a * TapeCode.encode state.Tape.right + state.Tape.head.val)
      have combined := multiplied.trans (written.trans divided)
      rw [symbol_tape a state.Tape.left] at combined
      simpa [encode, Tape.move, TapeCode.encode_cons, ← TapeCode.tail_code,
        pushRegister, popRegister, frame, counters, Nat.add_comm, base] using combined
  | right =>
      have multiplied := multiply_reaches a q machine (state.q, state.Tape.head) target .right
        selected (TapeCode.encode state.Tape.left) (TapeCode.encode state.Tape.right)
      have written := add_reaches a q machine (state.q, state.Tape.head) target .right
        selected state.Tape.head (base a * TapeCode.encode state.Tape.left)
        (TapeCode.encode state.Tape.right)
      have divided := divide_reaches a q machine (state.q, state.Tape.head) target .right
        selected (TapeCode.encode state.Tape.right)
        (base a * TapeCode.encode state.Tape.left + state.Tape.head.val)
      have combined := multiplied.trans (written.trans divided)
      rw [symbol_tape a state.Tape.right] at combined
      simpa [encode, Tape.move, TapeCode.encode_cons, ← TapeCode.tail_code,
        pushRegister, popRegister, frame, counters, Nat.add_comm, base] using combined

/-- One dispatch edge followed by arithmetic steps whose sources are all unmarked. -/
def FirstReturn (machine : TM0.Machine (Fin a) (Fin q))
    (first last : Configuration 3 (size a q)) : Prop :=
  ∃ after, step (program a q machine) first = some after ∧
    InternalReaches a q machine after last

theorem internal_from_boundary (machine : TM0.Machine (Fin a) (Fin q))
    {first last : Configuration 3 (size a q)}
    (run : InternalReaches a q machine first last) (boundary : Boundary a q first.pc) :
    first = last := by
  rcases Relation.ReflTransGen.cases_head run with same | ⟨next, edge, _⟩
  · exact same
  · exact False.elim (edge.2 boundary)

/-- Each source transition is precisely one positive finite first return. -/
theorem step_firstReturn (machine : TM0.Machine (Fin a) (Fin q))
    {first last : TM0.Cfg (Fin a) (Fin q)} (source : TM0.step machine first = some last) :
    FirstReturn a q machine (encode a q first) (encode a q last) := by
  cases transition : machine first.q first.Tape.head with
  | none => simp [TM0.step, transition] at source
  | some command =>
      rcases command with ⟨target, operation⟩
      cases operation with
      | write value =>
          have destination : (⟨target, first.Tape.write value⟩ : TM0.Cfg (Fin a) (Fin q)) = last := by
            simpa [TM0.step, transition] using source
          subst last
          exact ⟨_, write_step a q machine first target value transition, Relation.ReflTransGen.refl⟩
      | move direction =>
          have destination : (⟨target, first.Tape.move direction⟩ : TM0.Cfg (Fin a) (Fin q)) = last := by
            simpa [TM0.step, transition] using source
          subst last
          refine ⟨⟨mulTarget a q (first.q, first.Tape.head) 0, (encode a q first).counters⟩, ?_,
            move_reaches a q machine first target direction transition⟩
          simp [step, encode, transition, counters]

theorem firstReturn_positive (machine : TM0.Machine (Fin a) (Fin q))
    {first last : Configuration 3 (size a q)} (run : FirstReturn a q machine first last) :
    StateTransition.Reaches₁ (step (program a q machine)) first last := by
  rcases run with ⟨after, initial, rest⟩
  apply Relation.TransGen.head'
    (r := fun current next => next ∈ step (program a q machine) current) initial
  induction rest with
  | refl => exact Relation.ReflTransGen.refl
  | tail _ edge previous => exact previous.tail edge.1

/-- The statically compiled table refines the entire TM transition system. -/
theorem respects (machine : TM0.Machine (Fin a) (Fin q)) :
    StateTransition.Respects (TM0.step machine) (step (program a q machine))
      (fun source target => encode a q source = target) := by
  apply StateTransition.fun_respects.mpr
  intro state
  cases transition : TM0.step machine state with
  | none =>
      change step (program a q machine) (encode a q state) = none
      exact (halt_encode a q machine state).mpr transition
  | some next =>
      exact firstReturn_positive a q machine (step_firstReturn a q machine transition)

/-- Complete configurations, termination, and divergence are preserved together. -/
theorem eval_encode (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) :
    eval (program a q machine) (encode a q state) =
      encode a q <$> StateTransition.eval (TM0.step machine) state :=
  StateTransition.tr_eval' (TM0.step machine) (step (program a q machine))
    (encode a q) (respects a q machine) state

theorem eval_dom_encode (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) :
    (eval (program a q machine) (encode a q state)).Dom ↔
      (StateTransition.eval (TM0.step machine) state).Dom := by
  rw [eval_encode]
  rfl

end Monodromy.Counter.TuringCompiler
