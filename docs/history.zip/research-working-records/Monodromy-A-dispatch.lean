import Monodromy.Counter

/-! A static finite entry table for fixed input encodings. -/

namespace Monodromy.Counter.EntryDispatch

variable {a m : ℕ}

/-- Prefix addresses contain only jumps through an already-zero workspace counter. -/
def program (source : Program 2 m) (entries : Fin a → Fin m) : Program 2 (a + m) :=
  Fin.addCases
    (fun symbol => .dec 1 (Fin.natAdd a (entries symbol)) (Fin.natAdd a (entries symbol)))
    (fun cell => mapInstruction (Fin.natAdd a) (source cell))

def entryState (symbol : Fin a) (registers : Fin 2 → ℕ) : Configuration 2 (a + m) :=
  ⟨Fin.castAdd m symbol, registers⟩

@[simp] theorem program_prefix (source : Program 2 m) (entries : Fin a → Fin m)
    (symbol : Fin a) :
    program source entries (Fin.castAdd m symbol) =
      .dec 1 (Fin.natAdd a (entries symbol)) (Fin.natAdd a (entries symbol)) := by
  simp [program]

@[simp] theorem program_body (source : Program 2 m) (entries : Fin a → Fin m) (cell : Fin m) :
    program source entries (Fin.natAdd a cell) = mapInstruction (Fin.natAdd a) (source cell) := by
  simp [program]

theorem address_injective : Function.Injective (Fin.natAdd a : Fin m → Fin (a + m)) := by
  intro first second same
  apply Fin.ext
  have values := congrArg Fin.val same
  simp only [Fin.val_natAdd] at values
  omega

theorem body_injective : Function.Injective (mapConfiguration (n := 2) (Fin.natAdd a) :
    Configuration 2 m → Configuration 2 (a + m)) :=
  mapConfiguration_injective (Fin.natAdd a) address_injective

theorem prefix_ne_body (symbol : Fin a) (cell : Fin m) :
    Fin.castAdd m symbol ≠ Fin.natAdd a cell := by
  intro same
  have values := congrArg Fin.val same
  simp only [Fin.val_castAdd, Fin.val_natAdd] at values
  omega

/-- One actual source instruction enters the selected body address without changing storage. -/
theorem prefix_step (source : Program 2 m) (entries : Fin a → Fin m)
    (symbol : Fin a) (registers : Fin 2 → ℕ) (workspace : registers 1 = 0) :
    step (program source entries) (entryState symbol registers) =
      some (mapConfiguration (Fin.natAdd a) ⟨entries symbol, registers⟩) := by
  simp [step, entryState, workspace, mapConfiguration]

/-- Every relocated body preserves its complete partial execution. -/
theorem eval_body (source : Program 2 m) (entries : Fin a → Fin m)
    (state : Configuration 2 m) :
    eval (program source entries) (mapConfiguration (Fin.natAdd a) state) =
      mapConfiguration (Fin.natAdd a) <$> eval source state :=
  eval_map (Fin.natAdd a) source (program source entries)
    (fun cell => program_body source entries cell) state

/-- Static entry dispatch preserves complete results, termination, and divergence. -/
theorem eval_prefix (source : Program 2 m) (entries : Fin a → Fin m)
    (symbol : Fin a) (registers : Fin 2 → ℕ) (workspace : registers 1 = 0) :
    eval (program source entries) (entryState symbol registers) =
      mapConfiguration (Fin.natAdd a) <$> eval source ⟨entries symbol, registers⟩ := by
  have run : StateTransition.Reaches (step (program source entries)) (entryState symbol registers)
      (mapConfiguration (Fin.natAdd a) ⟨entries symbol, registers⟩) :=
    Relation.ReflTransGen.single (prefix_step source entries symbol registers workspace)
  exact (StateTransition.reaches_eval run).trans (eval_body source entries _)

theorem eval_prefix_dom (source : Program 2 m) (entries : Fin a → Fin m)
    (symbol : Fin a) (registers : Fin 2 → ℕ) (workspace : registers 1 = 0) :
    (eval (program source entries) (entryState symbol registers)).Dom ↔
      (eval source ⟨entries symbol, registers⟩).Dom := by
  rw [eval_prefix source entries symbol registers workspace]
  rfl

end Monodromy.Counter.EntryDispatch
