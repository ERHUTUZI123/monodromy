import «Monodromy-A-counter»
import Monodromy.Effectiveness

noncomputable section

namespace Monodromy.CoupledContinuation

/-- Integer labels are a proof interpretation, never an input to native path generation. -/
abbrev Labels := (ℤ × ℤ) × ℤ

def Labels.prepare (labels : Labels) : Memory := Monodromy.CoupledContinuation.prepare labels.1.1 labels.1.2 labels.2

/-- Proof-side arithmetic of one of the actual five loops or its reverse. -/
def Gate.evalInt (gate : Gate) (backward : Bool) (labels : Labels) : Labels :=
  let displacement : ℤ := if backward then -1 else 1
  match gate with
  | .left => ((labels.1.1 + displacement, labels.1.2), labels.2)
  | .right => ((labels.1.1, labels.1.2 + displacement), labels.2)
  | .zeroLeft => (labels.1, labels.2 + if labels.1.1 = 0 then displacement else 0)
  | .zeroRight => (labels.1, labels.2 + if labels.1.2 = 0 then displacement else 0)
  | .control => (labels.1, labels.2 + displacement)

def Word.evalInt : Word → Labels → Labels
  | [], labels => labels
  | (gate, backward) :: rest, labels => Word.evalInt rest (Gate.evalInt gate backward labels)

theorem Gate.primrec_evalInt (gate : Gate) (backward : Bool) : Primrec (Gate.evalInt gate backward) := by
  let displacement : ℤ := if backward then -1 else 1
  have first_coordinate : Primrec (fun labels : Labels => labels.1.1) := Primrec.fst.comp Primrec.fst
  have second_coordinate : Primrec (fun labels : Labels => labels.1.2) := Primrec.snd.comp Primrec.fst
  have control : Primrec (fun labels : Labels => labels.2) := Primrec.snd
  have left_test : PrimrecPred (fun labels : Labels => labels.1.1 = 0) :=
    Primrec.eq.comp first_coordinate (Primrec.const 0)
  have right_test : PrimrecPred (fun labels : Labels => labels.1.2 = 0) :=
    Primrec.eq.comp second_coordinate (Primrec.const 0)
  cases gate with
  | left =>
      exact ((IntegerPrimrec.add.comp first_coordinate (Primrec.const displacement)).pair second_coordinate).pair control
  | right =>
      exact (first_coordinate.pair (IntegerPrimrec.add.comp second_coordinate (Primrec.const displacement))).pair control
  | zeroLeft =>
      exact Primrec.fst.pair (IntegerPrimrec.add.comp control
        (Primrec.ite left_test (Primrec.const displacement) (Primrec.const 0)))
  | zeroRight =>
      exact Primrec.fst.pair (IntegerPrimrec.add.comp control
        (Primrec.ite right_test (Primrec.const displacement) (Primrec.const 0)))
  | control =>
      exact Primrec.fst.pair (IntegerPrimrec.add.comp control (Primrec.const displacement))

theorem Word.primrec_evalInt (word : Word) : Primrec (Word.evalInt word) := by
  induction word with
  | nil => exact Primrec.id
  | cons atom rest recursive =>
      rcases atom with ⟨gate, backward⟩
      exact recursive.comp (Gate.primrec_evalInt gate backward)

/-- All arithmetic cases are derived from native transport, including reverse conditional gates. -/
theorem Gate.execute_evalInt (gate : Gate) (backward : Bool) (labels : Labels) :
    execute (if backward then gate.driver.reverse else gate.driver) (Labels.prepare labels) =
      Labels.prepare (Gate.evalInt gate backward labels) := by
  rcases labels with ⟨⟨left, right⟩, control⟩
  cases gate with
  | left =>
      cases backward with
      | false => simpa [Gate.driver, Gate.evalInt, Labels.prepare] using execute_A_left left right control
      | true => simpa [Gate.driver, Gate.evalInt, Labels.prepare, sub_eq_add_neg] using execute_A_left_reverse left right control
  | right =>
      cases backward with
      | false => simpa [Gate.driver, Gate.evalInt, Labels.prepare] using execute_A_right left right control
      | true => simpa [Gate.driver, Gate.evalInt, Labels.prepare, sub_eq_add_neg] using execute_A_right_reverse left right control
  | zeroLeft =>
      cases backward with
      | false => simpa [Gate.driver, Gate.evalInt, Labels.prepare] using execute_B_left left right control
      | true =>
          have inverse := execute_driver_reverse B_left
            (prepare left right (control - if left = 0 then 1 else 0))
          rw [execute_B_left] at inverse
          simp only [sub_add_cancel] at inverse
          by_cases zero : left = 0 <;>
            simpa [Gate.driver, Gate.evalInt, Labels.prepare, zero, sub_eq_add_neg] using inverse
  | zeroRight =>
      cases backward with
      | false => simpa [Gate.driver, Gate.evalInt, Labels.prepare] using execute_B_right left right control
      | true =>
          have inverse := execute_driver_reverse B_right
            (prepare left right (control - if right = 0 then 1 else 0))
          rw [execute_B_right] at inverse
          simp only [sub_add_cancel] at inverse
          by_cases zero : right = 0 <;>
            simpa [Gate.driver, Gate.evalInt, Labels.prepare, zero, sub_eq_add_neg] using inverse
  | control =>
      cases backward with
      | false => simpa [Gate.driver, Gate.evalInt, Labels.prepare] using execute_control_prepare left right control
      | true => simpa [Gate.driver, Gate.evalInt, Labels.prepare, sub_eq_add_neg] using execute_control_reverse left right control

theorem Word.execute_evalInt (word : Word) (labels : Labels) :
    execute (Word.driver word) (Labels.prepare labels) = Labels.prepare (Word.evalInt word labels) := by
  induction word generalizing labels with
  | nil => exact execute_word_nil (Labels.prepare labels)
  | cons atom rest recursive =>
      rcases atom with ⟨gate, backward⟩
      rw [execute_word_cons, Gate.execute_evalInt, recursive]
      rfl

namespace Program

variable {degree : ℕ} [NeZero degree]

/-- Euclidean residues describe, but do not implement, finite-root routing. -/
def indexInt (degree : ℕ) [NeZero degree] (labels : Labels) : Fin degree :=
  ⟨(labels.2 % (degree : ℤ)).toNat, by
    apply (Int.toNat_lt_of_ne_zero (NeZero.ne degree)).mpr
    exact Int.emod_lt_of_pos _ (by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne degree))⟩

def nextInt (program : Program degree) (labels : Labels) : Labels :=
  Word.evalInt (program.table (indexInt degree labels)) labels

def haltInt (program : Program degree) (labels : Labels) : Bool :=
  program.stop (indexInt degree labels)

def stepInt (program : Program degree) (labels : Labels) : Option Labels :=
  if program.haltInt labels then none else some (program.nextInt labels)

def evalInt (program : Program degree) : Labels → Part Labels :=
  StateTransition.eval program.stepInt

theorem indexInt_cast (labels : Labels) :
    ((indexInt degree labels).val : ℤ) = labels.2 % (degree : ℤ) := by
  exact Int.toNat_of_nonneg (Int.emod_nonneg _ (by exact_mod_cast NeZero.ne degree))

theorem control_decomposition (labels : Labels) :
    (degree : ℤ) * (labels.2 / (degree : ℤ)) + (indexInt degree labels).val = labels.2 := by
  rw [indexInt_cast]
  exact Int.mul_ediv_add_emod _ _

theorem primrec_indexInt : Primrec (indexInt degree) := by
  apply Primrec.fin_val_iff.mp
  have degree_eq : degree - 1 + 1 = degree := by
    have positive := Nat.pos_of_ne_zero (NeZero.ne degree)
    omega
  exact ((IntegerPrimrec.remainder (degree - 1)).comp
    (Primrec.snd : Primrec (Prod.snd : Labels → ℤ))).of_eq
      (by intro labels; simp [degree_eq, indexInt])

theorem primrec_nextInt (program : Program degree) : Primrec program.nextInt :=
  (Primrec.fin_curry₁.mpr (fun index => Word.primrec_evalInt (program.table index))).comp
    primrec_indexInt Primrec.id

theorem primrec_haltInt (program : Program degree) : Primrec program.haltInt :=
  (Primrec.dom_finite program.stop).comp primrec_indexInt

theorem primrec_stepInt (program : Program degree) : Primrec program.stepInt := by
  have primitive := Primrec.cond (primrec_haltInt program) (Primrec.const none)
    (Primrec.option_some.comp (primrec_nextInt program))
  exact primitive.of_eq fun labels => by
    cases done : program.haltInt labels <;> simp [stepInt, done]

/-- Complete execution of a finite geometric word table is partial recursive. -/
theorem partrec_evalInt (program : Program degree) : Partrec program.evalInt :=
  Effectiveness.partrec_eval (primrec_stepInt program).to_comp

theorem advance_prepareInt (program : Program degree) (labels : Labels) :
    program.advance (Labels.prepare labels) = Labels.prepare (program.nextInt labels) := by
  have actual := program.advance_prepare labels.1.1 labels.1.2
    (labels.2 / (degree : ℤ)) (indexInt degree labels)
  rw [control_decomposition] at actual
  exact actual.trans (Word.execute_evalInt _ labels)

theorem haltSignal_prepareInt (program : Program degree) (labels : Labels) :
    program.haltSignal (Labels.prepare labels) = if program.haltInt labels then 1 else 0 := by
  have actual := program.haltSignal_prepare labels.1.1 labels.1.2
    (labels.2 / (degree : ℤ)) (indexInt degree labels)
  rw [control_decomposition] at actual
  exact actual

theorem step_prepareInt (program : Program degree) (labels : Labels) :
    program.step (Labels.prepare labels) = (program.stepInt labels).map Labels.prepare := by
  unfold step stepInt
  rw [haltSignal_prepareInt]
  cases program.haltInt labels <;> simp [advance_prepareInt]

/-- The partial-recursive interpretation preserves every result, halting, and divergence. -/
theorem eval_prepareInt (program : Program degree) (labels : Labels) :
    program.eval (Labels.prepare labels) = Labels.prepare <$> program.evalInt labels := by
  have refinement : StateTransition.Respects program.stepInt program.step
      (fun first second => Labels.prepare first = second) := by
    apply StateTransition.fun_respects.mpr
    intro source
    cases result : program.stepInt source with
    | none =>
        change program.step (Labels.prepare source) = none
        simp [step_prepareInt, result]
    | some successor =>
        apply Relation.TransGen.single
        simp [step_prepareInt, result]
  exact StateTransition.tr_eval' program.stepInt program.step Labels.prepare refinement labels

theorem eval_dom_prepareInt (program : Program degree) (labels : Labels) :
    (program.eval (Labels.prepare labels)).Dom ↔ (program.evalInt labels).Dom := by
  rw [eval_prepareInt]
  rfl

/-- Fixed effective interfaces preserve the ordinary partial-recursive upper bound. -/
theorem partrec_with_io (program : Program degree) {input : ℕ → Labels} {output : Labels → ℕ}
    (input_primitive : Primrec input) (output_primitive : Primrec output) :
    Partrec (fun value => (program.evalInt (input value)).map output) :=
  ((program.partrec_evalInt).comp input_primitive.to_comp).map
    (output_primitive.to_comp.comp Computable.snd).to₂

end Program

end Monodromy.CoupledContinuation
