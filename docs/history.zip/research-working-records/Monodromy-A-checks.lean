import Monodromy

#check Monodromy.Logarithm.zeroWeight
#check Monodromy.Logarithm.continuous_zeroWeight
#check Monodromy.Logarithm.zeroWeight_sheet
#check Monodromy.Logarithm.analyticAt_zeroWeight
#check Monodromy.Logarithm.zeroWeight_eq_kernel
#check Monodromy.Autonomy.response
#check Monodromy.Autonomy.continuous_response
#check Monodromy.Autonomy.analyticAt_response
#check Monodromy.Autonomy.flow
#check Monodromy.Autonomy.flow_hasDerivAt
#check Monodromy.Autonomy.response_sheet
#check Monodromy.Autonomy.flow_period
#check Monodromy.Autonomy.path
#check Monodromy.Autonomy.path_eq_turn
#check Monodromy.Autonomy.transport_path
#check Monodromy.Autonomy.operations_differ
#check Monodromy.Autonomy.write
#check Monodromy.Autonomy.next
#check Monodromy.Autonomy.state
#check Monodromy.Autonomy.direction
#check Monodromy.Autonomy.next_sheet
#check Monodromy.Autonomy.next_transport
#check Monodromy.Autonomy.next_inverse_sheet
#check Monodromy.Autonomy.next_zero
#check Monodromy.Autonomy.next_one
#check Monodromy.Autonomy.two_cycle
#check Monodromy.Autonomy.selection_reverses
#check Monodromy.Autonomy.nextHomeomorph
#check Monodromy.Autonomy.next_bijective
#check Monodromy.Autonomy.update
#check Monodromy.Autonomy.iterate_refinement
#check Monodromy.Autonomy.roundPaths
#check Monodromy.Autonomy.roundPaths_transport
#check Monodromy.Autonomy.runPaths
#check Monodromy.Autonomy.runPaths_transport
#check Monodromy.Autonomy.iterate_transport

#check Monodromy.Universality.every_finite_machine
#check Monodromy.Structure.continuation_characterization
#check Monodromy.Structure.descent_strictly_extends
#print axioms Monodromy.NestedContinuation.execute_prepare
#print axioms Monodromy.NestedContinuation.execute_trans
#print axioms Monodromy.NestedContinuation.execute_reverse
#print axioms Monodromy.Structure.continuation_characterization
