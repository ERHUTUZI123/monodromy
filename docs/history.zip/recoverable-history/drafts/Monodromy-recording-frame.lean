import «Monodromy-reversible-recording»

namespace Monodromy.Counter.Reversible.Recording

variable {n m : ℕ}

def frame (values : Fin n → ℕ) (history workspace : ℤ) : Fin (n + 2) → ℤ :=
  Fin.addCases (fun index => (values index : ℤ)) ![history, workspace]

def framed (control : Fin (size m)) (values : Fin n → ℕ) (history workspace : ℤ) :
    State (n + 2) (size m) := (control, frame values history workspace)

def encode (state : Counter.Configuration n m) (history : ℕ) : State (n + 2) (size m) :=
  framed (dispatch state.pc) state.counters history 0

@[simp] theorem frame_old (values : Fin n → ℕ) (history workspace : ℤ) (index : Fin n) :
    frame values history workspace (Fin.castAdd 2 index) = (values index : ℤ) := by
  simp [frame]

@[simp] theorem frame_tail (values : Fin n → ℕ) (history workspace : ℤ) (index : Fin 2) :
    frame values history workspace (historyRegister n index) = ![history, workspace] index := by
  simp [frame, historyRegister]

@[simp] theorem frame_history (values : Fin n → ℕ) (history workspace : ℤ) :
    frame values history workspace (historyRegister n 0) = history := by simp

@[simp] theorem frame_workspace (values : Fin n → ℕ) (history workspace : ℤ) :
    frame values history workspace (historyRegister n 1) = workspace := by simp

private theorem tail_ne_old (index : Fin 2) (old : Fin n) :
    historyRegister n index ≠ Fin.castAdd 2 old := by
  intro same
  have values := congrArg Fin.val same
  simp only [historyRegister, Fin.val_natAdd, Fin.val_castAdd] at values
  omega

theorem frame_extend (values : Fin n → ℕ) (history workspace : ℤ) :
    Function.extend (historyRegister n) ![history, workspace] (frame values 0 0) =
      frame values history workspace := by
  funext index
  induction index using Fin.addCases with
  | left old =>
      rw [Function.extend_apply' _ _ _ (by rintro ⟨tail, same⟩; exact tail_ne_old tail old same)]
      simp
  | right tail =>
      change Function.extend (historyRegister n) ![history, workspace] (frame values 0 0)
        (historyRegister n tail) = frame values history workspace (historyRegister n tail)
      rw [(historyRegister_injective n).extend_apply]
      exact (frame_tail values history workspace tail).symm

theorem framed_embed (control : Fin (size m)) (values : Fin n → ℕ) (history workspace : ℤ) :
    RegisterRelocation.embed (historyRegister n) (frame values 0 0)
      (control, ![history, workspace]) = framed control values history workspace := by
  simp only [RegisterRelocation.embed, framed, frame_extend]

theorem frame_update (values : Fin n → ℕ) (history workspace : ℤ) (index : Fin n) (value : ℕ) :
    Function.update (frame values history workspace) (Fin.castAdd 2 index) (value : ℤ) =
      frame (Function.update values index value) history workspace := by
  funext position
  induction position using Fin.addCases with
  | left old =>
      by_cases same : old = index
      · subst old; simp
      · simp [same]
  | right tail =>
      change Function.update (frame values history workspace) (Fin.castAdd 2 index) (value : ℤ)
        (historyRegister n tail) =
          frame (Function.update values index value) history workspace (historyRegister n tail)
      rw [Function.update_of_ne (tail_ne_old tail index)]
      simp only [frame_tail]

theorem shift_frame (values : Fin n → ℕ) (history workspace amount : ℤ) (index : Fin n)
    (value : ℕ) (updated : (values index : ℤ) + amount = value) :
    Action.apply (.shift (Fin.castAdd 2 index) amount) (frame values history workspace) =
      frame (Function.update values index value) history workspace := by
  simpa only [Action.apply, frame_old, updated] using frame_update values history workspace index value

theorem inc_frame (values : Fin n → ℕ) (history workspace : ℤ) (index : Fin n) :
    Action.apply (.shift (Fin.castAdd 2 index) 1) (frame values history workspace) =
      frame (Function.update values index (values index + 1)) history workspace :=
  shift_frame values history workspace 1 index _ (by simp)

theorem dec_frame (values : Fin n → ℕ) (history workspace : ℤ) (index : Fin n) (value : ℕ)
    (positive : values index = value + 1) :
    Action.apply (.shift (Fin.castAdd 2 index) (-1)) (frame values history workspace) =
      frame (Function.update values index value) history workspace :=
  shift_frame values history workspace (-1) index _ (by simp [positive])

/-- The actual copied radix graph writes its tag and restores its workspace. -/
theorem packing_reaches (program : Counter.Program n m) (valid : Deterministic (table program))
    (row : Fin m) (symbol : Fin (base m)) (values : Fin n → ℕ) (history : ℕ) :
    StateTransition.Reaches (step (table program))
      (framed (port row symbol) values history 0)
      (framed (dispatch row) values (base m * history + symbol.val : ℕ) 0) := by
  have run := Glue.reaches_embed_map_live
    (reverseTable (Radix.table (base m))) (table program)
    (historyRegister n) (historyRegister_injective n) (frame values 0 0)
    (copy row) (fun index => arcEquiv program (.inl (row, index)))
    (fun index => by simp only [table_arc, arcEdge, packing])
    (reverseTable_deterministic _ (Radix.targetCompatible (base m))) valid
    (Radix.reverse_pack (base m) history symbol)
  simpa only [Radix.point, RegisterRelocation.embed, Glue.mapState, framed, frame_extend,
    port, dispatch] using run

end Monodromy.Counter.Reversible.Recording
