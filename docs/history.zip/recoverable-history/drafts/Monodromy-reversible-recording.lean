import Monodromy.Counter

/-! Static reversible transition recording through copies of the fixed radix packer. -/
noncomputable section

namespace Monodromy.Counter.Reversible.Recording

variable {n m : ℕ}

def base (m : ℕ) : ℕ := m * 2 + 1

instance base_nonzero (m : ℕ) : NeZero (base m) := ⟨by simp [base]⟩

abbrev Node (m : ℕ) := (Fin m × Fin (Radix.size (base m))) ⊕ Fin m

def size (m : ℕ) : ℕ := m * Radix.size (base m) + m

def nodeEquiv (m : ℕ) : Node m ≃ Fin (size m) :=
  (Equiv.sumCongr finProdFinEquiv (Equiv.refl _)).trans finSumFinEquiv

def copy (row : Fin m) (position : Fin (Radix.size (base m))) : Fin (size m) :=
  nodeEquiv m (.inl (row, position))

def mid (row : Fin m) : Fin (size m) := nodeEquiv m (.inr row)

def dispatch (row : Fin m) : Fin (size m) := copy row (Radix.entry (base m))

def port (row : Fin m) (symbol : Fin (base m)) : Fin (size m) :=
  copy row (Radix.finish (base m) symbol)

/-- The nonzero digit retains the old address and decrement branch. -/
def digit (row : Fin m) (branch : Fin 2) : Fin (base m) :=
  ⟨(finProdFinEquiv (row, branch)).val + 1, by
    have bound := (finProdFinEquiv (row, branch)).isLt
    simp only [base]
    omega⟩

@[simp] theorem digit_eq_iff (row other : Fin m) (branch next : Fin 2) :
    digit row branch = digit other next ↔ row = other ∧ branch = next := by
  constructor
  · intro same
    have values := congrArg Fin.val same
    have tags : finProdFinEquiv (row, branch) = finProdFinEquiv (other, next) := by
      apply Fin.ext
      simp only [digit] at values
      omega
    exact Prod.mk.inj ((finProdFinEquiv).injective tags)
  · rintro ⟨rfl, rfl⟩
    rfl

/-- Precisely the active finite external arcs; halt rows contribute none. -/
def Active (program : Counter.Program n m) (pair : Fin m × Fin 3) : Prop :=
  match program pair.1 with
  | .inc _ _ => pair.2 = 0
  | .dec _ _ _ => True
  | .halt => False

instance active_decidable (program : Counter.Program n m) (pair : Fin m × Fin 3) :
    Decidable (Active program pair) := by
  unfold Active
  cases program pair.1 <;> infer_instance

abbrev Extra (program : Counter.Program n m) := {pair : Fin m × Fin 3 // Active program pair}

def historyRegister (n : ℕ) : Fin 2 → Fin (n + 2) := Fin.natAdd n

theorem historyRegister_injective (n : ℕ) : Function.Injective (historyRegister n) := by
  intro first second same
  apply Fin.ext
  have values := congrArg Fin.val same
  simp only [historyRegister, Fin.val_natAdd] at values
  omega

def packing (n m : ℕ) : Table (n + 2) (Radix.size (base m)) (Radix.edges (base m)) :=
  RegisterRelocation.mapTable (historyRegister n) (reverseTable (Radix.table (base m)))

theorem packing_deterministic (n m : ℕ) : Deterministic (packing n m) :=
  RegisterRelocation.deterministic _ (historyRegister_injective n) _
    (reverseTable_deterministic _ (Radix.targetCompatible (base m)))

theorem packing_targetCompatible (n m : ℕ) : TargetCompatible (packing n m) :=
  RegisterRelocation.targetCompatible _ (historyRegister_injective n) _
    (reverseTable_targetCompatible _ (Radix.deterministic (base m)))

theorem packing_no_outgoing_dispatch (index : Fin (Radix.edges (base m))) :
    (packing n m index).source ≠ Radix.entry (base m) :=
  Radix.no_incoming_entry (base m) index

theorem packing_no_incoming_port (symbol : Fin (base m))
    (index : Fin (Radix.edges (base m))) :
    (packing n m index).target ≠ Radix.finish (base m) symbol :=
  fun incoming => Radix.no_outgoing_finish (base m) symbol ⟨index, incoming⟩

def extraOrigin (program : Counter.Program n m) (arc : Extra program) : Node m :=
  match instruction : program arc.val.1 with
  | .inc _ _ => .inl (arc.val.1, Radix.entry (base m))
  | .dec _ _ _ => if arc.val.2 = 2 then .inr arc.val.1
      else .inl (arc.val.1, Radix.entry (base m))
  | .halt => False.elim (by simpa [Active, instruction] using arc.property)

def extraDestination (program : Counter.Program n m) (arc : Extra program) : Node m :=
  match instruction : program arc.val.1 with
  | .inc _ target => .inl (target, Radix.finish (base m) (digit arc.val.1 0))
  | .dec _ zero nonzero => ![
      Sum.inl (zero, Radix.finish (base m) (digit arc.val.1 0)),
      Sum.inr arc.val.1,
      Sum.inl (nonzero, Radix.finish (base m) (digit arc.val.1 1))] arc.val.2
  | .halt => False.elim (by simpa [Active, instruction] using arc.property)

def extraOperation (program : Counter.Program n m) (arc : Extra program) : Action (n + 2) :=
  match instruction : program arc.val.1 with
  | .inc register _ => .shift (Fin.castAdd 2 register) 1
  | .dec register _ _ => ![
      Action.test (Fin.castAdd 2 register) true,
      Action.test (Fin.castAdd 2 register) false,
      Action.shift (Fin.castAdd 2 register) (-1)] arc.val.2
  | .halt => False.elim (by simpa [Active, instruction] using arc.property)

def extraEdge (program : Counter.Program n m) (arc : Extra program) : Edge (n + 2) (size m) :=
  ⟨nodeEquiv m (extraOrigin program arc), nodeEquiv m (extraDestination program arc),
    extraOperation program arc⟩

abbrev Arc (program : Counter.Program n m) :=
  (Fin m × Fin (Radix.edges (base m))) ⊕ Extra program

def edges (program : Counter.Program n m) : ℕ :=
  m * Radix.edges (base m) + Fintype.card (Extra program)

def arcEquiv (program : Counter.Program n m) : Arc program ≃ Fin (edges program) :=
  (Equiv.sumCongr finProdFinEquiv (Fintype.equivFin (Extra program))).trans finSumFinEquiv

def arcEdge (program : Counter.Program n m) : Arc program → Edge (n + 2) (size m)
  | .inl (row, edge) => Glue.mapEdge (copy row) (packing n m edge)
  | .inr edge => extraEdge program edge

def table (program : Counter.Program n m) : Table (n + 2) (size m) (edges program) :=
  fun index => arcEdge program ((arcEquiv program).symm index)

@[simp] theorem table_arc (program : Counter.Program n m) (arc : Arc program) :
    table program (arcEquiv program arc) = arcEdge program arc := by
  simp [table]

/-- Every copy preserves its own finite radix address and original-row label. -/
@[simp] theorem copy_eq_iff (row other : Fin m)
    (first second : Fin (Radix.size (base m))) :
    copy row first = copy other second ↔ row = other ∧ first = second := by
  unfold copy
  rw [(nodeEquiv m).injective.eq_iff]
  simp

@[simp] theorem copy_ne_mid (row other : Fin m) (position : Fin (Radix.size (base m))) :
    copy row position ≠ mid other := by
  intro same
  have impossible : (Sum.inl (row, position) : Node m) = Sum.inr other :=
    (nodeEquiv m).injective same
  cases impossible

@[simp] theorem mid_eq_iff (row other : Fin m) : mid row = mid other ↔ row = other := by
  unfold mid
  rw [(nodeEquiv m).injective.eq_iff]
  simp

@[simp] theorem finish_eq_iff (first second : Fin (base m)) :
    Radix.finish (base m) first = Radix.finish (base m) second ↔ first = second := by
  unfold Radix.finish Radix.block
  rw [(Radix.nodeEquiv (base m)).injective.eq_iff]
  simp

end Monodromy.Counter.Reversible.Recording

namespace Monodromy.Counter.Reversible.Recording

variable {n m : ℕ}

theorem extraOrigin_inc (program : Counter.Program n m) (arc : Extra program)
    (register : Fin n) (target : Fin m) (instruction : program arc.val.1 = .inc register target) :
    extraOrigin program arc = Sum.inl (arc.val.1, Radix.entry (base m)) := by
  unfold extraOrigin
  split <;> simp_all

theorem extraOrigin_dec (program : Counter.Program n m) (arc : Extra program)
    (register : Fin n) (zero nonzero : Fin m)
    (instruction : program arc.val.1 = .dec register zero nonzero) :
    extraOrigin program arc = if arc.val.2 = 2 then Sum.inr arc.val.1
      else Sum.inl (arc.val.1, Radix.entry (base m)) := by
  unfold extraOrigin
  split <;> simp_all

theorem extraDestination_inc (program : Counter.Program n m) (arc : Extra program)
    (register : Fin n) (target : Fin m) (instruction : program arc.val.1 = .inc register target) :
    extraDestination program arc =
      Sum.inl (target, Radix.finish (base m) (digit arc.val.1 0)) := by
  unfold extraDestination
  split <;> simp_all

theorem extraDestination_dec (program : Counter.Program n m) (arc : Extra program)
    (register : Fin n) (zero nonzero : Fin m)
    (instruction : program arc.val.1 = .dec register zero nonzero) :
    extraDestination program arc = ![
      Sum.inl (zero, Radix.finish (base m) (digit arc.val.1 0)),
      Sum.inr arc.val.1,
      Sum.inl (nonzero, Radix.finish (base m) (digit arc.val.1 1))] arc.val.2 := by
  unfold extraDestination
  split <;> simp_all

theorem extraOperation_inc (program : Counter.Program n m) (arc : Extra program)
    (register : Fin n) (target : Fin m) (instruction : program arc.val.1 = .inc register target) :
    extraOperation program arc = .shift (Fin.castAdd 2 register) 1 := by
  unfold extraOperation
  split <;> simp_all

theorem extraOperation_dec (program : Counter.Program n m) (arc : Extra program)
    (register : Fin n) (zero nonzero : Fin m)
    (instruction : program arc.val.1 = .dec register zero nonzero) :
    extraOperation program arc = ![
      Action.test (Fin.castAdd 2 register) true,
      Action.test (Fin.castAdd 2 register) false,
      Action.shift (Fin.castAdd 2 register) (-1)] arc.val.2 := by
  unfold extraOperation
  split <;> simp_all

private theorem extraOrigin_row (program : Counter.Program n m) (arc : Extra program) :
    (extraOrigin program arc).elim Prod.fst id = arc.val.1 := by
  cases instruction : program arc.val.1 with
  | inc register target =>
      rw [extraOrigin_inc program arc register target instruction]
      rfl
  | dec register zero nonzero =>
      rw [extraOrigin_dec program arc register zero nonzero instruction]
      split_ifs <;> rfl
  | halt =>
      have active := arc.property
      unfold Active at active
      rw [instruction] at active
      exact active.elim

/-- The only external dispatch alternatives are complementary tests on the same old register. -/
theorem extra_deterministic (program : Counter.Program n m) (first second : Extra program)
    (different : first ≠ second) (same : extraOrigin program first = extraOrigin program second) :
    Action.Compatible (extraOperation program first) (extraOperation program second) := by
  have rows : first.val.1 = second.val.1 := by
    have owners := congrArg (fun node : Node m => node.elim Prod.fst id) same
    simpa only [extraOrigin_row] using owners
  rcases first with ⟨⟨row, branch⟩, first_active⟩
  rcases second with ⟨⟨other, next⟩, second_active⟩
  change row = other at rows
  subst other
  cases instruction : program row with
  | inc register target =>
      have first_zero : branch = 0 := by
        have active := first_active
        unfold Active at active
        rw [instruction] at active
        exact active
      have second_zero : next = 0 := by
        have active := second_active
        unfold Active at active
        rw [instruction] at active
        exact active
      subst branch
      subst next
      exact False.elim (different (Subtype.ext rfl))
  | dec register zero nonzero =>
      rw [extraOrigin_dec program ⟨(row, branch), first_active⟩ register zero nonzero instruction,
        extraOrigin_dec program ⟨(row, next), second_active⟩ register zero nonzero instruction] at same
      rw [extraOperation_dec program ⟨(row, branch), first_active⟩ register zero nonzero instruction,
        extraOperation_dec program ⟨(row, next), second_active⟩ register zero nonzero instruction]
      fin_cases branch <;> fin_cases next <;> simp_all [Action.Compatible]
  | halt =>
      have active := first_active
      unfold Active at active
      rw [instruction] at active
      exact active.elim

/-- A nonzero history digit makes every external destination distinct. -/
theorem extraDestination_injective (program : Counter.Program n m) :
    Function.Injective (extraDestination program) := by
  intro first second same
  rcases first with ⟨⟨row, branch⟩, first_active⟩
  rcases second with ⟨⟨other, next⟩, second_active⟩
  apply Subtype.ext
  cases first_instruction : program row <;> cases second_instruction : program other
  all_goals
    have first_valid := first_active
    have second_valid := second_active
    unfold Active at first_valid second_valid
    rw [first_instruction] at first_valid
    rw [second_instruction] at second_valid
  all_goals try contradiction
  all_goals first
    | rw [extraDestination_inc program ⟨(row, branch), first_active⟩ _ _ first_instruction] at same
    | rw [extraDestination_dec program ⟨(row, branch), first_active⟩ _ _ _ first_instruction] at same
  all_goals first
    | rw [extraDestination_inc program ⟨(other, next), second_active⟩ _ _ second_instruction] at same
    | rw [extraDestination_dec program ⟨(other, next), second_active⟩ _ _ _ second_instruction] at same
  all_goals fin_cases branch <;> fin_cases next <;> simp_all

private theorem extraOrigin_shape (program : Counter.Program n m) (arc : Extra program) :
    extraOrigin program arc = Sum.inl (arc.val.1, Radix.entry (base m)) ∨
      extraOrigin program arc = Sum.inr arc.val.1 := by
  cases instruction : program arc.val.1 with
  | inc register target => exact Or.inl (extraOrigin_inc program arc register target instruction)
  | dec register zero nonzero =>
      rw [extraOrigin_dec program arc register zero nonzero instruction]
      by_cases last : arc.val.2 = 2 <;> simp [last]
  | halt =>
      have active := arc.property
      unfold Active at active
      rw [instruction] at active
      exact active.elim

private theorem extraDestination_shape (program : Counter.Program n m) (arc : Extra program) :
    (∃ target symbol, extraDestination program arc =
      Sum.inl (target, Radix.finish (base m) symbol)) ∨
      extraDestination program arc = Sum.inr arc.val.1 := by
  rcases arc with ⟨⟨row, branch⟩, active⟩
  cases instruction : program row with
  | inc register target =>
      exact Or.inl ⟨target, digit row 0, extraDestination_inc program _ register target instruction⟩
  | dec register zero nonzero =>
      rw [extraDestination_dec program _ register zero nonzero instruction]
      fin_cases branch
      · exact Or.inl ⟨zero, digit row 0, rfl⟩
      · exact Or.inr rfl
      · exact Or.inl ⟨nonzero, digit row 1, rfl⟩
  | halt =>
      have impossible := active
      unfold Active at impossible
      rw [instruction] at impossible
      exact impossible.elim

private theorem packing_extra_source_ne (program : Counter.Program n m) (row : Fin m)
    (index : Fin (Radix.edges (base m))) (arc : Extra program) :
    copy row (packing n m index).source ≠ nodeEquiv m (extraOrigin program arc) := by
  intro same
  have raw : Sum.inl (row, (packing n m index).source) = extraOrigin program arc :=
    (nodeEquiv m).injective same
  rcases extraOrigin_shape program arc with dispatch_case | mid_case
  · rw [dispatch_case] at raw
    exact packing_no_outgoing_dispatch (n := n) index (Prod.mk.inj (Sum.inl.inj raw)).2
  · rw [mid_case] at raw
    cases raw

private theorem packing_extra_target_ne (program : Counter.Program n m) (row : Fin m)
    (index : Fin (Radix.edges (base m))) (arc : Extra program) :
    copy row (packing n m index).target ≠ nodeEquiv m (extraDestination program arc) := by
  intro same
  have raw : Sum.inl (row, (packing n m index).target) = extraDestination program arc :=
    (nodeEquiv m).injective same
  rcases extraDestination_shape program arc with ⟨target, symbol, port_case⟩ | mid_case
  · rw [port_case] at raw
    exact packing_no_incoming_port (n := n) symbol index (Prod.mk.inj (Sum.inl.inj raw)).2
  · rw [mid_case] at raw
    cases raw

/-- The compiled graph chooses every enabled edge through its own finite ports. -/
theorem deterministic (program : Counter.Program n m) : Deterministic (table program) := by
  intro first second different same
  obtain ⟨first, rfl⟩ := (arcEquiv program).surjective first
  obtain ⟨second, rfl⟩ := (arcEquiv program).surjective second
  have distinct : first ≠ second := fun identical => different (congrArg (arcEquiv program) identical)
  clear different
  simp only [table_arc] at same ⊢
  rcases first with ⟨row, index⟩ | first <;> rcases second with ⟨other, next⟩ | second
  all_goals simp only [arcEdge, Glue.mapEdge, extraEdge] at same ⊢
  · rcases (copy_eq_iff row other _ _).mp same with ⟨same_rows, same_source⟩
    subst other
    exact packing_deterministic n m index next
      (fun identical => distinct (congrArg Sum.inl (Prod.ext rfl identical))) same_source
  · exact False.elim (packing_extra_source_ne program row index second same)
  · exact False.elim (packing_extra_source_ne program other next first same.symm)
  · exact extra_deterministic program first second
      (fun identical => distinct (congrArg Sum.inr identical)) ((nodeEquiv m).injective same)

/-- A unique recoverable history tag separates every external predecessor. -/
theorem targetCompatible (program : Counter.Program n m) : TargetCompatible (table program) := by
  intro first second different same
  obtain ⟨first, rfl⟩ := (arcEquiv program).surjective first
  obtain ⟨second, rfl⟩ := (arcEquiv program).surjective second
  have distinct : first ≠ second := fun identical => different (congrArg (arcEquiv program) identical)
  clear different
  simp only [table_arc] at same ⊢
  rcases first with ⟨row, index⟩ | first <;> rcases second with ⟨other, next⟩ | second
  all_goals simp only [arcEdge, Glue.mapEdge, extraEdge] at same ⊢
  · rcases (copy_eq_iff row other _ _).mp same with ⟨same_rows, same_target⟩
    subst other
    exact packing_targetCompatible n m index next
      (fun identical => distinct (congrArg Sum.inl (Prod.ext rfl identical))) same_target
  · exact False.elim (packing_extra_target_ne program row index second same)
  · exact False.elim (packing_extra_target_ne program other next first same.symm)
  · exact False.elim (distinct (congrArg Sum.inr
      (extraDestination_injective program ((nodeEquiv m).injective same))))

end Monodromy.Counter.Reversible.Recording
