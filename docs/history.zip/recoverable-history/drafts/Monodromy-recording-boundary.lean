import «Monodromy-recording-frame»

namespace Monodromy.Counter.Reversible.Recording

variable {n m : ℕ}

def embed (recorded : Counter.Recorded.State n m) : State (n + 2) (size m) :=
  encode recorded.1 recorded.2

theorem embed_injective : Function.Injective (@embed n m) := by
  rintro ⟨⟨first_pc, first_values⟩, first_history⟩
    ⟨⟨second_pc, second_values⟩, second_history⟩ same
  change framed (dispatch first_pc) first_values first_history 0 =
    framed (dispatch second_pc) second_values second_history 0 at same
  apply Prod.ext
  · apply congrArg₂ Counter.Configuration.mk
    · have controls := congrArg (fun state : State (n + 2) (size m) => state.1) same
      exact ((copy_eq_iff first_pc second_pc _ _).mp controls).1
    · funext index
      have values := congrArg
        (fun state : State (n + 2) (size m) => state.2 (Fin.castAdd 2 index)) same
      exact Int.natCast_inj.mp (by simpa only [framed, frame_old] using values)
  · have histories := congrArg
      (fun state : State (n + 2) (size m) => state.2 (historyRegister n 0)) same
    exact Int.natCast_inj.mp (by simpa only [framed, frame_history] using histories)

private theorem halt_no_outgoing (program : Counter.Program n m) (row : Fin m)
    (halted : program row = .halt) (index : Fin (edges program)) :
    (table program index).source ≠ dispatch row := by
  obtain ⟨arc, rfl⟩ := (arcEquiv program).surjective index
  rw [table_arc]
  rcases arc with ⟨other, edge⟩ | arc
  · change copy other (packing n m edge).source ≠ copy row (Radix.entry (base m))
    exact fun same => packing_no_outgoing_dispatch edge ((copy_eq_iff other row _ _).mp same).2
  · intro same
    have raw : extraOrigin program arc = Sum.inl (row, Radix.entry (base m)) :=
      (nodeEquiv m).injective same
    rcases arc with ⟨⟨other, branch⟩, active⟩
    cases instruction : program other with
    | inc register target =>
        rw [extraOrigin_inc program ⟨(other, branch), active⟩ register target instruction] at raw
        have rows := (Prod.mk.inj (Sum.inl.inj raw)).1
        have impossible := instruction.symm.trans ((congrArg program rows).trans halted)
        cases impossible
    | dec register zero nonzero =>
        rw [extraOrigin_dec program ⟨(other, branch), active⟩ register zero nonzero instruction] at raw
        split at raw
        · cases raw
        · have rows := (Prod.mk.inj (Sum.inl.inj raw)).1
          have impossible := instruction.symm.trans ((congrArg program rows).trans halted)
          cases impossible
    | halt =>
        unfold Active at active
        rw [instruction] at active
        exact active.elim

theorem step_encode_none_iff (program : Counter.Program n m)
    (state : Counter.Configuration n m) (history : ℕ) :
    step (table program) (encode state history) = none ↔ Counter.step program state = none := by
  rw [step_none_iff]
  cases instruction : program state.pc with
  | halt =>
      constructor
      · intro _; exact Counter.step_halt program state instruction
      · intro _
        rintro ⟨index, enabled⟩
        exact halt_no_outgoing program state.pc instruction index enabled.1
  | inc register target =>
      simp only [Counter.step, instruction, reduceCtorEq, iff_false, not_not]
      let arc : Extra program := ⟨(state.pc, 0), by simp [Active, instruction]⟩
      refine ⟨arcEquiv program (.inr arc), ?_⟩
      rw [table_arc]
      change (extraEdge program arc).enabled (encode state history)
      simp only [extraEdge, Edge.enabled, encode, framed]
      rw [extraOrigin_inc program arc register target instruction,
        extraOperation_inc program arc register target instruction]
      exact ⟨rfl, trivial⟩
  | dec register zero nonzero =>
      have live : Counter.step program state ≠ none := by
        cases count : state.counters register <;> simp [Counter.step, instruction, count]
      simp only [live, iff_false, not_not]
      by_cases empty : state.counters register = 0
      · let arc : Extra program := ⟨(state.pc, 0), by simp [Active, instruction]⟩
        refine ⟨arcEquiv program (.inr arc), ?_⟩
        rw [table_arc]
        change (extraEdge program arc).enabled (encode state history)
        simp only [extraEdge, Edge.enabled, encode, framed]
        rw [extraOrigin_dec program arc register zero nonzero instruction,
          extraOperation_dec program arc register zero nonzero instruction]
        exact ⟨rfl, by simp [Action.enabled, arc, empty]⟩
      · let arc : Extra program := ⟨(state.pc, 1), by simp [Active, instruction]⟩
        refine ⟨arcEquiv program (.inr arc), ?_⟩
        rw [table_arc]
        change (extraEdge program arc).enabled (encode state history)
        simp only [extraEdge, Edge.enabled, encode, framed]
        rw [extraOrigin_dec program arc register zero nonzero instruction,
          extraOperation_dec program arc register zero nonzero instruction]
        exact ⟨rfl, by simp [Action.enabled, arc, empty]⟩

end Monodromy.Counter.Reversible.Recording
