import «Monodromy-recording-execution»

/-! First returns to original instruction dispatches in the actual recording graph. -/

namespace Monodromy.Counter.Reversible.Recording

variable {n m : ℕ}

/-- A finite-control observation, independent of every counter value. -/
def Boundary (state : State (n + 2) (size m)) : Prop :=
  ∃ row : Fin m, state.1 = dispatch row

def InternalStep (program : Counter.Program n m)
    (first last : State (n + 2) (size m)) : Prop :=
  step (table program) first = some last ∧ ¬ Boundary first

abbrev InternalReaches (program : Counter.Program n m) :=
  Relation.ReflTransGen (InternalStep program)

/-- A positive run whose intermediate source states avoid all old dispatches. -/
def FirstReturn (program : Counter.Program n m)
    (first last : State (n + 2) (size m)) : Prop :=
  Boundary first ∧ Boundary last ∧
    ∃ next, step (table program) first = some next ∧ InternalReaches program next last

theorem boundary_encode (state : Counter.Configuration n m) (history : ℕ) :
    Boundary (encode state history) := ⟨state.pc, rfl⟩

theorem not_boundary_copy (row : Fin m) (position : Fin (Radix.size (base m)))
    (interior : position ≠ Radix.entry (base m)) (values : Fin (n + 2) → ℤ) :
    ¬ Boundary (copy row position, values) := by
  rintro ⟨other, same⟩
  exact interior ((copy_eq_iff row other _ _).mp same).2

theorem not_boundary_mid (row : Fin m) (values : Fin n → ℕ) (history workspace : ℤ) :
    ¬ Boundary (framed (mid row) values history workspace) := by
  rintro ⟨other, same⟩
  exact copy_ne_mid other row (Radix.entry (base m)) same.symm

private theorem local_step_not_entry {first last : State 2 (Radix.size (base m))}
    (transition : step (reverseTable (Radix.table (base m))) first = some last) :
    first.1 ≠ Radix.entry (base m) := by
  intro at_entry
  obtain ⟨index, enabled, _⟩ := (step_iff _
    (reverseTable_deterministic _ (Radix.targetCompatible (base m)))).mp transition
  exact Radix.no_incoming_entry (base m) index (enabled.1.trans at_entry)

/-- The copied packer cannot visit a dispatch before its terminal return. -/
theorem packing_internal_reaches (program : Counter.Program n m)
    (row : Fin m) (symbol : Fin (base m)) (values : Fin n → ℕ) (history : ℕ) :
    InternalReaches program
      (framed (port row symbol) values history 0)
      (framed (dispatch row) values (base m * history + symbol.val : ℕ) 0) := by
  let source := reverseTable (Radix.table (base m))
  let route : State 2 (Radix.size (base m)) → State (n + 2) (size m) :=
    fun state => Glue.mapState (copy row)
      (RegisterRelocation.embed (historyRegister n) (frame values 0 0) state)
  have mapped : Relation.ReflTransGen (InternalStep program)
      (route (Radix.point (base m) (Radix.finish (base m) symbol) history 0))
      (route (Radix.point (base m) (Radix.entry (base m))
        (base m * history + symbol.val : ℕ) 0)) := by
    apply Relation.ReflTransGen.lift route
      (fun first last transition => ?_) _ _ (Radix.reverse_pack (base m) history symbol)
    have relocated : step (packing n m)
        (RegisterRelocation.embed (historyRegister n) (frame values 0 0) first) =
        some (RegisterRelocation.embed (historyRegister n) (frame values 0 0) last) := by
      change step (RegisterRelocation.mapTable (historyRegister n) source)
        (RegisterRelocation.embed (historyRegister n) (frame values 0 0) first) = _
      rw [RegisterRelocation.step_embed (historyRegister n) (historyRegister_injective n)
        (frame values 0 0) source
        (reverseTable_deterministic _ (Radix.targetCompatible (base m))), transition, Option.map_some]
    constructor
    · exact Glue.step_map_live (packing n m) (table program) (copy row)
        (fun index => arcEquiv program (.inl (row, index)))
        (fun index => by simp only [table_arc, arcEdge])
        (packing_deterministic n m) (deterministic program) relocated
    · exact not_boundary_copy row first.1 (local_step_not_entry transition)
        (RegisterRelocation.embed (historyRegister n) (frame values 0 0) first).2
  simpa only [route, Radix.point, RegisterRelocation.embed, Glue.mapState, framed,
    frame_extend, port, dispatch] using mapped

private theorem extra_step (program : Counter.Program n m) (arc : Extra program)
    (state : State (n + 2) (size m)) (enabled : (extraEdge program arc).enabled state) :
    step (table program) state = some ((extraEdge program arc).execute state) := by
  apply (step_iff _ (deterministic program)).mpr
  refine ⟨arcEquiv program (.inr arc), ?_, ?_⟩
  · simpa only [table_arc, arcEdge] using enabled
  · rw [table_arc]
    rfl

private theorem history_digit (row : Fin m) (branch : Fin 2) (history : ℕ) :
    base m * history + (digit row branch).val =
      Counter.Recorded.push (finProdFinEquiv (row, branch)) history := by
  simp only [base, digit, Counter.Recorded.push, Nat.add_assoc]

private theorem pack_firstReturn (program : Counter.Program n m)
    {initial : State (n + 2) (size m)} {row : Fin m} {symbol : Fin (base m)}
    {values : Fin n → ℕ} {history : ℕ} (marked : Boundary initial)
    (first_step : step (table program) initial =
      some (framed (port row symbol) values history 0)) :
    FirstReturn program initial
      (framed (dispatch row) values (base m * history + symbol.val : ℕ) 0) := by
  exact ⟨marked, ⟨row, rfl⟩, framed (port row symbol) values history 0, first_step,
    packing_internal_reaches program row symbol values history⟩

private theorem inc_firstReturn (program : Counter.Program n m) (before : Counter.Configuration n m)
    (history : ℕ) (register : Fin n) (target : Fin m)
    (instruction : program before.pc = .inc register target) :
    FirstReturn program (encode before history)
      (encode ⟨target, Function.update before.counters register (before.counters register + 1)⟩
        (base m * history + (digit before.pc 0).val)) := by
  let arc : Extra program := ⟨(before.pc, 0), by
    unfold Active
    rw [instruction]⟩
  have fields := extraEdge_inc program arc register target instruction
  have enabled : (extraEdge program arc).enabled (encode before history) := by
    rw [fields]
    exact ⟨rfl, trivial⟩
  have first_step := extra_step program arc (encode before history) enabled
  rw [fields] at first_step
  simp only [Edge.execute, encode, framed, inc_frame] at first_step
  exact pack_firstReturn program (boundary_encode before history) first_step

private theorem zero_firstReturn (program : Counter.Program n m) (before : Counter.Configuration n m)
    (history : ℕ) (register : Fin n) (zero nonzero : Fin m)
    (instruction : program before.pc = .dec register zero nonzero) (empty : before.counters register = 0) :
    FirstReturn program (encode before history)
      (encode ⟨zero, before.counters⟩ (base m * history + (digit before.pc 0).val)) := by
  let arc : Extra program := ⟨(before.pc, 0), by unfold Active; rw [instruction]; trivial⟩
  have fields : extraEdge program arc =
      ⟨dispatch before.pc, port zero (digit before.pc 0), .test (Fin.castAdd 2 register) true⟩ :=
    extraEdge_dec program arc register zero nonzero instruction
  have enabled : (extraEdge program arc).enabled (encode before history) := by
    rw [fields]
    constructor
    · rfl
    · change Action.enabled (.test (Fin.castAdd 2 register) true)
        (frame before.counters history 0)
      simp [Action.enabled, empty]
  have first_step := extra_step program arc (encode before history) enabled
  rw [fields] at first_step
  simp only [Edge.execute, Action.apply, encode, framed] at first_step
  exact pack_firstReturn program (boundary_encode before history) first_step

private theorem positive_firstReturn (program : Counter.Program n m)
    (before : Counter.Configuration n m) (history : ℕ) (register : Fin n) (zero nonzero : Fin m)
    (instruction : program before.pc = .dec register zero nonzero) (value : ℕ)
    (count : before.counters register = value + 1) :
    FirstReturn program (encode before history)
      (encode ⟨nonzero, Function.update before.counters register value⟩
        (base m * history + (digit before.pc 1).val)) := by
  let probe : Extra program := ⟨(before.pc, 1), by unfold Active; rw [instruction]; trivial⟩
  let write : Extra program := ⟨(before.pc, 2), by unfold Active; rw [instruction]; trivial⟩
  have probe_fields : extraEdge program probe =
      ⟨dispatch before.pc, mid before.pc, .test (Fin.castAdd 2 register) false⟩ :=
    extraEdge_dec program probe register zero nonzero instruction
  have write_fields : extraEdge program write =
      ⟨mid before.pc, port nonzero (digit before.pc 1), .shift (Fin.castAdd 2 register) (-1)⟩ :=
    extraEdge_dec program write register zero nonzero instruction
  have probe_enabled : (extraEdge program probe).enabled (encode before history) := by
    rw [probe_fields]
    constructor
    · rfl
    · change Action.enabled (.test (Fin.castAdd 2 register) false)
        (frame before.counters history 0)
      simp [Action.enabled, count]
      omega
  have first_step := extra_step program probe (encode before history) probe_enabled
  rw [probe_fields] at first_step
  simp only [Edge.execute, Action.apply, encode, framed] at first_step
  have write_enabled : (extraEdge program write).enabled
      (framed (mid before.pc) before.counters history 0) := by
    rw [write_fields]
    exact ⟨rfl, trivial⟩
  have second_step := extra_step program write (framed (mid before.pc) before.counters history 0)
    write_enabled
  rw [write_fields] at second_step
  simp only [Edge.execute, framed, dec_frame before.counters history 0 register value count] at second_step
  refine ⟨boundary_encode before history, ⟨nonzero, rfl⟩,
    framed (mid before.pc) before.counters history 0, first_step, ?_⟩
  exact Relation.ReflTransGen.head
    ⟨second_step, not_boundary_mid before.pc before.counters history 0⟩
    (packing_internal_reaches program nonzero (digit before.pc 1)
      (Function.update before.counters register value) history)

/-- Every original counter transition has an actual first return with its complete recoverable log. -/
theorem step_firstReturn (program : Counter.Program n m) {before after : Counter.Configuration n m}
    (transition : Counter.step program before = some after) (history : ℕ) :
    FirstReturn program (encode before history)
      (encode after (Counter.Recorded.push (Counter.Recorded.tag program before) history)) := by
  cases instruction : program before.pc with
  | halt => simp [Counter.step, instruction] at transition
  | inc register target =>
      have result := Option.some.inj ((Counter.step_inc program before instruction).symm.trans transition)
      subst after
      have run := inc_firstReturn program before history register target instruction
      rw [history_digit] at run
      simpa only [Counter.Recorded.tag, Counter.Recorded.branch, instruction] using run
  | dec register zero nonzero =>
      cases count : before.counters register with
      | zero =>
          have result := Option.some.inj
            ((Counter.step_dec_zero program before instruction count).symm.trans transition)
          subst after
          have run := zero_firstReturn program before history register zero nonzero instruction count
          rw [history_digit] at run
          simpa only [Counter.Recorded.tag, Counter.Recorded.branch, instruction, count, ite_true] using run
      | succ value =>
          have result := Option.some.inj
            ((Counter.step_dec_succ program before instruction count).symm.trans transition)
          subst after
          have run := positive_firstReturn program before history register zero nonzero instruction value count
          rw [history_digit] at run
          simpa [Counter.Recorded.tag, Counter.Recorded.branch, instruction, count] using run

end Monodromy.Counter.Reversible.Recording
