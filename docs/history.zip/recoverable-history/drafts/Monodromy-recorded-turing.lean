import Monodromy.FormalCompilation
import «Monodromy-recording-execution»

/-!
Turing execution with recoverable finite-radix history.
This first layer is a source specification. Its actual reversible counter
graph is supplied by `Counter.Reversible.Recording`.
-/

namespace Monodromy.Counter.Recorded

variable {n m : ℕ}

/-- Every ordinary source step has one recorded step from every prior history. -/
theorem respects_source (program : Counter.Program n m) :
    StateTransition.Respects (Counter.step program) (step program)
      (fun original logged => logged.1 = original) := by
  intro original logged related
  rcases logged with ⟨stored, history⟩
  change stored = original at related
  subst original
  cases transition : Counter.step program stored with
  | none =>
      change step program (stored, history) = none
      simp [step, transition]
  | some next =>
      refine ⟨(next, push (tag program stored) history), rfl, ?_⟩
      apply Relation.TransGen.single
      simp [step, transition]

end Monodromy.Counter.Recorded

namespace Monodromy.RecordedTuring

open Turing

noncomputable section

variable (a q : ℕ) [NeZero a] [NeZero q]

abbrev size (machine : TM0.Machine (Fin a) (Fin q)) : ℕ :=
  Counter.Compression.size (NativeTuring.source3 a q machine)

def counterEncode (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) : Counter.Configuration 2 (size a q machine) :=
  Counter.Compression.encode (NativeTuring.source3 a q machine)
    (Counter.TuringCompiler.encode a q state)

theorem counterEncode_injective (machine : TM0.Machine (Fin a) (Fin q)) :
    Function.Injective (counterEncode a q machine) :=
  (Counter.Compression.encode_injective (NativeTuring.source3 a q machine)).comp
    (Counter.TuringCompiler.encode_injective a q)

/-- The ordinary finite-counter compilation is used only as the irreversible source. -/
theorem counter_step_reaches (machine : TM0.Machine (Fin a) (Fin q))
    {first last : TM0.Cfg (Fin a) (Fin q)} (transition : TM0.step machine first = some last) :
    StateTransition.Reaches₁ (Counter.step (NativeTuring.source2 a q machine))
      (counterEncode a q machine first) (counterEncode a q machine last) := by
  have first_run := Counter.TuringCompiler.firstReturn_positive a q machine
    (Counter.TuringCompiler.step_firstReturn a q machine transition)
  obtain ⟨_, rfl, run⟩ := StateTransition.tr_reaches₁
    (Counter.Compression.respects (NativeTuring.source3 a q machine)) rfl first_run
  exact run

theorem counter_halt (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (halted : TM0.step machine state = none) :
    Counter.step (NativeTuring.source2 a q machine) (counterEncode a q machine state) = none := by
  have first := (Counter.TuringCompiler.halt_encode a q machine state).mpr halted
  exact (Counter.Compression.halt_encode (NativeTuring.source3 a q machine)
    (Counter.TuringCompiler.encode a q state)).mpr first

def transition (machine : TM0.Machine (Fin a) (Fin q)) :=
  Counter.Recorded.step (NativeTuring.source2 a q machine)

def encode (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) : Counter.Recorded.State 2 (size a q machine) :=
  (counterEncode a q machine state, history)

theorem encode_injective (machine : TM0.Machine (Fin a) (Fin q)) :
    Function.Injective (fun pair : TM0.Cfg (Fin a) (Fin q) × ℕ =>
      encode a q machine pair.1 pair.2) := by
  intro first second same
  exact Prod.ext (counterEncode_injective a q machine (congrArg Prod.fst same))
    (congrArg (fun logged : Counter.Recorded.State 2 (size a q machine) => logged.2) same)

/-- The recorded transition has a unique defined predecessor. -/
theorem transition_injective (machine : TM0.Machine (Fin a) (Fin q))
    {first second last : Counter.Recorded.State 2 (size a q machine)}
    (left : transition a q machine first = some last)
    (right : transition a q machine second = some last) : first = second :=
  Counter.Recorded.step_defined_injective (NativeTuring.source2 a q machine) left right

/-- A complete source step retains its full configuration and a recoverable updated history. -/
theorem step_reaches (machine : TM0.Machine (Fin a) (Fin q))
    {first last : TM0.Cfg (Fin a) (Fin q)} (transition : TM0.step machine first = some last)
    (history : ℕ) :
    ∃ finalHistory, StateTransition.Reaches₁ (RecordedTuring.transition a q machine)
      (encode a q machine first history) (encode a q machine last finalHistory) := by
  have original_run := counter_step_reaches a q machine transition
  obtain ⟨⟨final, finalHistory⟩, related, run⟩ := StateTransition.tr_reaches₁
    (Counter.Recorded.respects_source (NativeTuring.source2 a q machine))
    (a₂ := encode a q machine first history) rfl original_run
  change final = counterEncode a q machine last at related
  subst final
  exact ⟨finalHistory, run⟩

theorem step_halt (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) (halted : TM0.step machine state = none) :
    transition a q machine (encode a q machine state history) = none := by
  unfold transition Counter.Recorded.step
  dsimp only [encode]
  rw [counter_halt a q machine state halted]
  rfl

def Related (machine : TM0.Machine (Fin a) (Fin q))
    (original : TM0.Cfg (Fin a) (Fin q)) (logged : Counter.Recorded.State 2 (size a q machine)) : Prop :=
  ∃ history, encode a q machine original history = logged

theorem respects (machine : TM0.Machine (Fin a) (Fin q)) :
    StateTransition.Respects (TM0.step machine) (transition a q machine) (Related a q machine) := by
  intro original logged related
  obtain ⟨history, rfl⟩ := related
  cases source_step : TM0.step machine original with
  | none => exact step_halt a q machine original history source_step
  | some next =>
      obtain ⟨finalHistory, run⟩ := step_reaches a q machine source_step history
      exact ⟨encode a q machine next finalHistory, ⟨finalHistory, rfl⟩, run⟩

theorem halting_iff (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    (StateTransition.eval (transition a q machine) (encode a q machine state history)).Dom ↔
      (StateTransition.eval (TM0.step machine) state).Dom :=
  StateTransition.tr_eval_dom (respects a q machine) ⟨history, rfl⟩

theorem divergence_iff (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    ¬ (StateTransition.eval (transition a q machine) (encode a q machine state history)).Dom ↔
      ¬ (StateTransition.eval (TM0.step machine) state).Dom :=
  not_congr (halting_iff a q machine state history)

/-- Terminal configurations are preserved exactly; their history remains part of the result. -/
theorem result_iff (machine : TM0.Machine (Fin a) (Fin q))
    (first last : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    (∃ finalHistory, encode a q machine last finalHistory ∈
      StateTransition.eval (transition a q machine) (encode a q machine first history)) ↔
      last ∈ StateTransition.eval (TM0.step machine) first := by
  constructor
  · rintro ⟨finalHistory, finished⟩
    obtain ⟨source, ⟨sourceHistory, related⟩, source_finished⟩ :=
      StateTransition.tr_eval_rev (respects a q machine) ⟨history, rfl⟩ finished
    have same := counterEncode_injective a q machine (congrArg Prod.fst related)
    simpa only [same] using source_finished
  · intro source_finished
    obtain ⟨final, ⟨finalHistory, rfl⟩, finished⟩ :=
      StateTransition.tr_eval (respects a q machine) ⟨history, rfl⟩ source_finished
    exact ⟨finalHistory, finished⟩

end

end Monodromy.RecordedTuring

namespace Monodromy.ReversibleTuring

open Turing

noncomputable section

variable (a q : ℕ) [NeZero a] [NeZero q]

/-- A fixed finite reversible graph realizes the source; its four registers are an intermediate code. -/
def table (machine : TM0.Machine (Fin a) (Fin q)) :
    Counter.Reversible.Table 4
      (Counter.Reversible.Recording.size (RecordedTuring.size a q machine))
      (Counter.Reversible.Recording.edges (NativeTuring.source2 a q machine)) :=
  Counter.Reversible.Recording.table (NativeTuring.source2 a q machine)

def encode (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    Counter.Reversible.State 4
      (Counter.Reversible.Recording.size (RecordedTuring.size a q machine)) :=
  Counter.Reversible.Recording.encode (RecordedTuring.counterEncode a q machine state) history

/-- At every simulated boundary the history is retained and its working register is zero. -/
theorem boundary_storage (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    ((encode a q machine state history).2 (Counter.Reversible.Recording.historyRegister 2 0),
      (encode a q machine state history).2 (Counter.Reversible.Recording.historyRegister 2 1)) =
        ((history : ℤ), 0) := by
  simp only [encode, Counter.Reversible.Recording.encode, Counter.Reversible.Recording.framed,
    Counter.Reversible.Recording.frame_history, Counter.Reversible.Recording.frame_workspace]

theorem encode_injective (machine : TM0.Machine (Fin a) (Fin q)) :
    Function.Injective (fun pair : TM0.Cfg (Fin a) (Fin q) × ℕ =>
      encode a q machine pair.1 pair.2) := by
  intro first second same
  have logged : RecordedTuring.encode a q machine first.1 first.2 =
      RecordedTuring.encode a q machine second.1 second.2 := by
    apply Counter.Reversible.Recording.embed_injective
    exact same
  exact RecordedTuring.encode_injective a q machine logged

/-- Every defined graph step has a unique predecessor, including states outside the encoded domain. -/
theorem defined_step_injective (machine : TM0.Machine (Fin a) (Fin q))
    {first second last : Counter.Reversible.State 4
      (Counter.Reversible.Recording.size (RecordedTuring.size a q machine))}
    (left : Counter.Reversible.step (table a q machine) first = some last)
    (right : Counter.Reversible.step (table a q machine) second = some last) : first = second :=
  Counter.Reversible.step_some_injective (table a q machine)
    (Counter.Reversible.Recording.deterministic (NativeTuring.source2 a q machine))
    (Counter.Reversible.Recording.targetCompatible (NativeTuring.source2 a q machine)) left right

/-- Each live Turing step executes the actual finite graph and leaves a recoverable larger history. -/
theorem step_reaches (machine : TM0.Machine (Fin a) (Fin q))
    {first last : TM0.Cfg (Fin a) (Fin q)} (transition : TM0.step machine first = some last)
    (history : ℕ) :
    ∃ finalHistory, history < finalHistory ∧
      StateTransition.Reaches₁ (Counter.Reversible.step (table a q machine))
        (encode a q machine first history) (encode a q machine last finalHistory) := by
  obtain ⟨finalHistory, logged_run⟩ := RecordedTuring.step_reaches a q machine transition history
  obtain ⟨_, rfl, graph_run⟩ := StateTransition.tr_reaches₁
    (Counter.Reversible.Recording.recorded_respects (NativeTuring.source2 a q machine))
    rfl logged_run
  refine ⟨finalHistory, ?_, graph_run⟩
  exact Counter.Recorded.history_lt_of_reaches (NativeTuring.source2 a q machine) logged_run

theorem step_halt (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) (halted : TM0.step machine state = none) :
    Counter.Reversible.step (table a q machine) (encode a q machine state history) = none :=
  (Counter.Reversible.Recording.step_encode_none_iff (NativeTuring.source2 a q machine)
    (RecordedTuring.counterEncode a q machine state) history).mpr
      (RecordedTuring.counter_halt a q machine state halted)

def Related (machine : TM0.Machine (Fin a) (Fin q))
    (original : TM0.Cfg (Fin a) (Fin q))
    (compiled : Counter.Reversible.State 4
      (Counter.Reversible.Recording.size (RecordedTuring.size a q machine))) : Prop :=
  ∃ history, encode a q machine original history = compiled

theorem respects (machine : TM0.Machine (Fin a) (Fin q)) :
    StateTransition.Respects (TM0.step machine) (Counter.Reversible.step (table a q machine))
      (Related a q machine) := by
  intro original compiled related
  obtain ⟨history, rfl⟩ := related
  cases transition : TM0.step machine original with
  | none => exact step_halt a q machine original history transition
  | some next =>
      obtain ⟨finalHistory, _, run⟩ := step_reaches a q machine transition history
      exact ⟨encode a q machine next finalHistory, ⟨finalHistory, rfl⟩, run⟩

theorem halting_iff (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    (Counter.Reversible.eval (table a q machine) (encode a q machine state history)).Dom ↔
      (StateTransition.eval (TM0.step machine) state).Dom :=
  StateTransition.tr_eval_dom (respects a q machine) ⟨history, rfl⟩

theorem divergence_iff (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    ¬ (Counter.Reversible.eval (table a q machine) (encode a q machine state history)).Dom ↔
      ¬ (StateTransition.eval (TM0.step machine) state).Dom :=
  not_congr (halting_iff a q machine state history)

/-- The entire final Turing configuration is retained, while the terminal history remains observable. -/
theorem result_iff (machine : TM0.Machine (Fin a) (Fin q))
    (first last : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    (∃ finalHistory, encode a q machine last finalHistory ∈
      Counter.Reversible.eval (table a q machine) (encode a q machine first history)) ↔
      last ∈ StateTransition.eval (TM0.step machine) first := by
  constructor
  · rintro ⟨finalHistory, finished⟩
    obtain ⟨source, ⟨sourceHistory, related⟩, source_finished⟩ :=
      StateTransition.tr_eval_rev (respects a q machine) ⟨history, rfl⟩ finished
    have same : (source, sourceHistory) = (last, finalHistory) :=
      @encode_injective a q _ _ machine (source, sourceHistory) (last, finalHistory) related
    have configurations : source = last := congrArg Prod.fst same
    simpa only [configurations] using source_finished
  · intro source_finished
    obtain ⟨final, ⟨finalHistory, rfl⟩, finished⟩ :=
      StateTransition.tr_eval (respects a q machine) ⟨history, rfl⟩ source_finished
    exact ⟨finalHistory, finished⟩

/-- Reverse execution is generated by the reversed finite graph rather than by a supplied trace. -/
theorem step_retraces (machine : TM0.Machine (Fin a) (Fin q))
    {first last : TM0.Cfg (Fin a) (Fin q)} (transition : TM0.step machine first = some last)
    (history : ℕ) :
    ∃ finalHistory, history < finalHistory ∧
      StateTransition.Reaches
        (Counter.Reversible.step (Counter.Reversible.reverseTable (table a q machine)))
        (encode a q machine last finalHistory) (encode a q machine first history) := by
  obtain ⟨finalHistory, grew, run⟩ := step_reaches a q machine transition history
  refine ⟨finalHistory, grew, ?_⟩
  exact Counter.Reversible.reaches_reverse (table a q machine)
    (Counter.Reversible.Recording.deterministic (NativeTuring.source2 a q machine))
    (Counter.Reversible.Recording.targetCompatible (NativeTuring.source2 a q machine)) run.to_reflTransGen

end

end Monodromy.ReversibleTuring
