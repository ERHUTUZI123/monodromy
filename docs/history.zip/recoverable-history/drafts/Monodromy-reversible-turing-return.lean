import «Monodromy-recorded-turing»
import «Monodromy-recording-marked»

/-!
Exact first returns of the reversible source simulation.
The boundary and its evaluator use only the fixed graph and finite control marks.
-/

noncomputable section

namespace Monodromy.ReversibleTuring

open Turing

variable (a q : ℕ) [NeZero a] [NeZero q]

/-- The compiled machine's finite dispatch marks are lifted to recording ports. -/
def Boundary (machine : TM0.Machine (Fin a) (Fin q))
    (state : Counter.Reversible.State 4
      (Counter.Reversible.Recording.size (RecordedTuring.size a q machine))) : Prop :=
  Counter.Reversible.Recording.Marked (NativeTuring.counterMark a q machine) state

instance boundary_decidable (machine : TM0.Machine (Fin a) (Fin q))
    (state : Counter.Reversible.State 4
      (Counter.Reversible.Recording.size (RecordedTuring.size a q machine))) :
    Decidable (Boundary a q machine state) := by
  unfold Boundary
  infer_instance

private theorem source_marked (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) :
    NativeTuring.counterMark a q machine (RecordedTuring.counterEncode a q machine state).pc = true := by
  unfold RecordedTuring.counterEncode NativeTuring.counterMark
  exact @decide_eq_true _ (by unfold NativeTuring.CounterMarked; infer_instance)
    ((NativeTuring.counterMarked_encode3_iff a q machine
    (Counter.TuringCompiler.encode a q state)).mpr
      (Counter.TuringCompiler.encode_boundary a q state))

theorem boundary_encode (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    Boundary a q machine (encode a q machine state history) :=
  (Counter.Reversible.Recording.marked_encode_iff (NativeTuring.counterMark a q machine)
    (RecordedTuring.counterEncode a q machine state) history).mpr (source_marked a q machine state)

/-- A live Turing step is the first positive return to its finite marked dispatches. -/
theorem step_firstReturn (machine : TM0.Machine (Fin a) (Fin q))
    {first last : TM0.Cfg (Fin a) (Fin q)} (transition : TM0.step machine first = some last)
    (history : ℕ) :
    ∃ finalHistory, history < finalHistory ∧
      Counter.Reversible.Recording.MarkedFirstReturn (NativeTuring.source2 a q machine)
        (NativeTuring.counterMark a q machine)
        (encode a q machine first history) (encode a q machine last finalHistory) := by
  obtain ⟨middle, initial, rest⟩ := NativeTuring.counter_firstReturn a q machine transition
  have internal : Relation.ReflTransGen
      (fun current next : Counter.Configuration 2 (RecordedTuring.size a q machine) =>
        Counter.step (NativeTuring.source2 a q machine) current = some next ∧
          NativeTuring.counterMark a q machine current.pc = false)
      middle (RecordedTuring.counterEncode a q machine last) := by
    refine Relation.ReflTransGen.mono (r := NativeTuring.CounterInternalStep a q machine)
      (fun current next edge => ?_) _ _ rest
    exact ⟨edge.1, by simpa only
      [NativeTuring.counterMark, decide_eq_false_iff_not] using edge.2⟩
  exact Counter.Reversible.Recording.marked_firstReturn (NativeTuring.source2 a q machine)
    (NativeTuring.counterMark a q machine) initial internal
    (source_marked a q machine first) (source_marked a q machine last) history

/-- The same graph is stopped at the chosen finite dispatch marks. -/
def boundaryTransition (machine : TM0.Machine (Fin a) (Fin q))
    (state : Counter.Reversible.State 4
      (Counter.Reversible.Recording.size (RecordedTuring.size a q machine))) :=
  if Boundary a q machine state then none else Counter.Reversible.step (table a q machine) state

private theorem boundaryTransition_stops (machine : TM0.Machine (Fin a) (Fin q))
    {state : Counter.Reversible.State 4
      (Counter.Reversible.Recording.size (RecordedTuring.size a q machine))}
    (marked : Boundary a q machine state) : boundaryTransition a q machine state = none := by
  simp only [boundaryTransition, ite_eq_left marked]

private theorem internal_marked_reaches (machine : TM0.Machine (Fin a) (Fin q))
    {first last : Counter.Reversible.State 4
      (Counter.Reversible.Recording.size (RecordedTuring.size a q machine))}
    (run : Counter.Reversible.Recording.InternalMarkedReaches
      (NativeTuring.source2 a q machine) (NativeTuring.counterMark a q machine) first last) :
    StateTransition.Reaches (boundaryTransition a q machine) first last := by
  induction run with
  | refl => exact Relation.ReflTransGen.refl
  | @tail first last _ edge previous =>
      apply previous.tail
      change (if Boundary a q machine first then none
        else Counter.Reversible.step (table a q machine) first) = some last
      have unmarked : ¬ Boundary a q machine first := edge.2
      rw [ite_eq_right unmarked]
      exact edge.1

/-- Execute the fixed graph once, then stop it at a finite control mark or a graph dead end. -/
def macroStep (machine : TM0.Machine (Fin a) (Fin q))
    (state : Counter.Reversible.State 4
      (Counter.Reversible.Recording.size (RecordedTuring.size a q machine))) :
    Part (Option (Counter.Reversible.State 4
      (Counter.Reversible.Recording.size (RecordedTuring.size a q machine)))) :=
  match Counter.Reversible.step (table a q machine) state with
  | none => Part.some none
  | some next => (StateTransition.eval (boundaryTransition a q machine) next).map some

theorem macroStep_halt (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) (halted : TM0.step machine state = none) :
    macroStep a q machine (encode a q machine state history) = Part.some none := by
  rw [macroStep, step_halt a q machine state history halted]

/-- The causal marked-return evaluator executes exactly the source step, retaining its new history. -/
theorem macroStep_live (machine : TM0.Machine (Fin a) (Fin q))
    {first last : TM0.Cfg (Fin a) (Fin q)} (transition : TM0.step machine first = some last)
    (history : ℕ) :
    ∃ finalHistory, history < finalHistory ∧
      macroStep a q machine (encode a q machine first history) =
        Part.some (some (encode a q machine last finalHistory)) := by
  obtain ⟨finalHistory, grew, _, marked, next, initial, rest⟩ :=
    step_firstReturn a q machine transition history
  have completed : StateTransition.eval (boundaryTransition a q machine) next =
      Part.some (encode a q machine last finalHistory) := by
    apply Part.eq_some_iff.mpr
    exact StateTransition.mem_eval.mpr
      ⟨internal_marked_reaches a q machine rest, boundaryTransition_stops a q machine marked⟩
  refine ⟨finalHistory, grew, ?_⟩
  change Counter.Reversible.step (table a q machine) (encode a q machine first history) =
    some next at initial
  simp only [macroStep, initial, completed, Part.map_some]

/-- The optional source result and full recorded configuration agree under the defined graph macro. -/
theorem macroStep_encode (machine : TM0.Machine (Fin a) (Fin q))
    (state : TM0.Cfg (Fin a) (Fin q)) (history : ℕ) :
    ∃ finalHistory,
      macroStep a q machine (encode a q machine state history) =
        Part.some ((TM0.step machine state).map (fun next => encode a q machine next finalHistory)) ∧
      (TM0.step machine state ≠ none → history < finalHistory) := by
  cases transition : TM0.step machine state with
  | none =>
      refine ⟨history, ?_, ?_⟩
      · simpa only [transition, Option.map_none] using macroStep_halt a q machine state history transition
      · simp
  | some next =>
      obtain ⟨finalHistory, grew, result⟩ := macroStep_live a q machine transition history
      exact ⟨finalHistory, result, fun _ => grew⟩

end Monodromy.ReversibleTuring
