import «Monodromy-recording-boundary»

/-! Every source instruction is executed by the statically constructed recording graph. -/

namespace Monodromy.Counter.Reversible.Recording

variable {n m : ℕ}

theorem extraEdge_inc (program : Counter.Program n m) (arc : Extra program)
    (register : Fin n) (target : Fin m) (instruction : program arc.val.1 = .inc register target) :
    extraEdge program arc =
      ⟨dispatch arc.val.1, port target (digit arc.val.1 0), .shift (Fin.castAdd 2 register) 1⟩ := by
  unfold extraEdge
  rw [extraOrigin_inc program arc register target instruction,
    extraDestination_inc program arc register target instruction,
    extraOperation_inc program arc register target instruction]
  rfl

theorem extraEdge_dec (program : Counter.Program n m) (arc : Extra program)
    (register : Fin n) (zero nonzero : Fin m)
    (instruction : program arc.val.1 = .dec register zero nonzero) :
    extraEdge program arc = ![
      ⟨dispatch arc.val.1, port zero (digit arc.val.1 0), .test (Fin.castAdd 2 register) true⟩,
      ⟨dispatch arc.val.1, mid arc.val.1, .test (Fin.castAdd 2 register) false⟩,
      ⟨mid arc.val.1, port nonzero (digit arc.val.1 1), .shift (Fin.castAdd 2 register) (-1)⟩]
      arc.val.2 := by
  unfold extraEdge
  rw [extraOrigin_dec program arc register zero nonzero instruction,
    extraDestination_dec program arc register zero nonzero instruction,
    extraOperation_dec program arc register zero nonzero instruction]
  rcases arc with ⟨⟨row, branch⟩, active⟩
  fin_cases branch <;> rfl

private theorem extra_step (program : Counter.Program n m) (arc : Extra program)
    (state : State (n + 2) (size m)) (enabled : (extraEdge program arc).enabled state) :
    step (table program) state = some ((extraEdge program arc).execute state) := by
  apply (step_iff _ (deterministic program)).mpr
  refine ⟨arcEquiv program (.inr arc), ?_, ?_⟩
  · simpa only [table_arc, arcEdge] using enabled
  · rw [table_arc]
    rfl

private theorem history_digit (row : Fin m) (branch : Fin 2) (history : ℕ) :
    base m * history + (digit row branch).val =
      Counter.Recorded.push (finProdFinEquiv (row, branch)) history := by
  simp only [base, digit, Counter.Recorded.push, Nat.add_assoc]

private theorem inc_reaches (program : Counter.Program n m) (before : Counter.Configuration n m)
    (history : ℕ) (register : Fin n) (target : Fin m)
    (instruction : program before.pc = .inc register target) :
    StateTransition.Reaches₁ (step (table program)) (encode before history)
      (encode ⟨target, Function.update before.counters register (before.counters register + 1)⟩
        (base m * history + (digit before.pc 0).val)) := by
  let arc : Extra program := ⟨(before.pc, 0), by
    unfold Active
    rw [instruction]⟩
  have fields := extraEdge_inc program arc register target instruction
  have enabled : (extraEdge program arc).enabled (encode before history) := by
    rw [fields]
    exact ⟨rfl, trivial⟩
  have first_step := extra_step program arc (encode before history) enabled
  rw [fields] at first_step
  simp only [Edge.execute, encode, framed, inc_frame] at first_step
  exact Relation.TransGen.head'
    (r := fun current next => next ∈ step (table program) current) first_step
    (packing_reaches program (deterministic program) target (digit before.pc 0)
      (Function.update before.counters register (before.counters register + 1)) history)

private theorem zero_reaches (program : Counter.Program n m) (before : Counter.Configuration n m)
    (history : ℕ) (register : Fin n) (zero nonzero : Fin m)
    (instruction : program before.pc = .dec register zero nonzero) (empty : before.counters register = 0) :
    StateTransition.Reaches₁ (step (table program)) (encode before history)
      (encode ⟨zero, before.counters⟩ (base m * history + (digit before.pc 0).val)) := by
  let arc : Extra program := ⟨(before.pc, 0), by unfold Active; rw [instruction]; trivial⟩
  have fields : extraEdge program arc =
      ⟨dispatch before.pc, port zero (digit before.pc 0), .test (Fin.castAdd 2 register) true⟩ :=
    extraEdge_dec program arc register zero nonzero instruction
  have enabled : (extraEdge program arc).enabled (encode before history) := by
    rw [fields]
    constructor
    · rfl
    · change Action.enabled (.test (Fin.castAdd 2 register) true)
        (frame before.counters history 0)
      simp [Action.enabled, empty]
  have first_step := extra_step program arc (encode before history) enabled
  rw [fields] at first_step
  simp only [Edge.execute, Action.apply, encode, framed] at first_step
  exact Relation.TransGen.head'
    (r := fun current next => next ∈ step (table program) current) first_step
    (packing_reaches program (deterministic program) zero (digit before.pc 0) before.counters history)

private theorem positive_reaches (program : Counter.Program n m)
    (before : Counter.Configuration n m) (history : ℕ) (register : Fin n) (zero nonzero : Fin m)
    (instruction : program before.pc = .dec register zero nonzero) (value : ℕ)
    (count : before.counters register = value + 1) :
    StateTransition.Reaches₁ (step (table program)) (encode before history)
      (encode ⟨nonzero, Function.update before.counters register value⟩
        (base m * history + (digit before.pc 1).val)) := by
  let probe : Extra program := ⟨(before.pc, 1), by unfold Active; rw [instruction]; trivial⟩
  let write : Extra program := ⟨(before.pc, 2), by unfold Active; rw [instruction]; trivial⟩
  have probe_fields : extraEdge program probe =
      ⟨dispatch before.pc, mid before.pc, .test (Fin.castAdd 2 register) false⟩ :=
    extraEdge_dec program probe register zero nonzero instruction
  have write_fields : extraEdge program write =
      ⟨mid before.pc, port nonzero (digit before.pc 1), .shift (Fin.castAdd 2 register) (-1)⟩ :=
    extraEdge_dec program write register zero nonzero instruction
  have probe_enabled : (extraEdge program probe).enabled (encode before history) := by
    rw [probe_fields]
    constructor
    · rfl
    · change Action.enabled (.test (Fin.castAdd 2 register) false)
        (frame before.counters history 0)
      simp [Action.enabled, count]
      omega
  have first_step := extra_step program probe (encode before history) probe_enabled
  rw [probe_fields] at first_step
  simp only [Edge.execute, Action.apply, encode, framed] at first_step
  have write_enabled : (extraEdge program write).enabled
      (framed (mid before.pc) before.counters history 0) := by
    rw [write_fields]
    exact ⟨rfl, trivial⟩
  have second_step := extra_step program write (framed (mid before.pc) before.counters history 0)
    write_enabled
  rw [write_fields] at second_step
  simp only [Edge.execute, framed, dec_frame before.counters history 0 register value count] at second_step
  apply Relation.TransGen.head'
    (r := fun current next => next ∈ step (table program) current) first_step
  exact Relation.ReflTransGen.head second_step
    (packing_reaches program (deterministic program) nonzero (digit before.pc 1)
      (Function.update before.counters register value) history)

/-- Every original counter transition is a positive actual graph execution with its recoverable log. -/
theorem step_reaches (program : Counter.Program n m) {before after : Counter.Configuration n m}
    (transition : Counter.step program before = some after) (history : ℕ) :
    StateTransition.Reaches₁ (step (table program)) (encode before history)
      (encode after (Counter.Recorded.push (Counter.Recorded.tag program before) history)) := by
  cases instruction : program before.pc with
  | halt => simp [Counter.step, instruction] at transition
  | inc register target =>
      have result := Option.some.inj ((Counter.step_inc program before instruction).symm.trans transition)
      subst after
      have run := inc_reaches program before history register target instruction
      rw [history_digit] at run
      simpa only [Counter.Recorded.tag, Counter.Recorded.branch, instruction] using run
  | dec register zero nonzero =>
      cases count : before.counters register with
      | zero =>
          have result := Option.some.inj
            ((Counter.step_dec_zero program before instruction count).symm.trans transition)
          subst after
          have run := zero_reaches program before history register zero nonzero instruction count
          rw [history_digit] at run
          simpa only [Counter.Recorded.tag, Counter.Recorded.branch, instruction, count, ite_true] using run
      | succ value =>
          have result := Option.some.inj
            ((Counter.step_dec_succ program before instruction count).symm.trans transition)
          subst after
          have run := positive_reaches program before history register zero nonzero instruction value count
          rw [history_digit] at run
          simpa [Counter.Recorded.tag, Counter.Recorded.branch, instruction, count] using run

/-- The complete recorded transition system refines to this actual static graph. -/
theorem recorded_respects (program : Counter.Program n m) :
    StateTransition.Respects (Counter.Recorded.step program) (step (table program))
      (fun original compiled => embed original = compiled) := by
  apply StateTransition.fun_respects.mpr
  rintro ⟨before, history⟩
  cases transition : Counter.step program before with
  | none =>
      simp only [Counter.Recorded.step, transition, Option.map_none, StateTransition.FRespects, embed]
      exact (step_encode_none_iff program before history).mpr transition
  | some after =>
      simp only [Counter.Recorded.step, transition, Option.map_some, StateTransition.FRespects, embed]
      exact step_reaches program transition history

/-- Full terminal configurations and undefinedness agree, with the complete history retained. -/
theorem eval_embed (program : Counter.Program n m) (state : Counter.Recorded.State n m) :
    eval (table program) (embed state) =
      embed <$> StateTransition.eval (Counter.Recorded.step program) state :=
  StateTransition.tr_eval' (Counter.Recorded.step program) (step (table program)) embed
    (recorded_respects program) state

/-- The same finite graph in reverse restores the entire source configuration and its prior history. -/
theorem step_reaches_reverse (program : Counter.Program n m)
    {before after : Counter.Configuration n m}
    (transition : Counter.step program before = some after) (history : ℕ) :
    StateTransition.Reaches (step (reverseTable (table program)))
      (encode after (Counter.Recorded.push (Counter.Recorded.tag program before) history))
      (encode before history) :=
  reaches_reverse (table program) (deterministic program) (targetCompatible program)
    (step_reaches program transition history).to_reflTransGen

end Monodromy.Counter.Reversible.Recording
