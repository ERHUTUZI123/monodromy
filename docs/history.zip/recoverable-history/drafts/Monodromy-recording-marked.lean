import «Monodromy-recording-return»

namespace Monodromy.Counter.Reversible.Recording

variable {n m : ℕ}

def Marked (mark : Fin m → Bool) (state : State (n + 2) (size m)) : Prop :=
  ∃ row, state.1 = dispatch row ∧ mark row = true

instance (mark : Fin m → Bool) (state : State (n + 2) (size m)) : Decidable (Marked mark state) :=
  inferInstanceAs (Decidable (∃ row, state.1 = dispatch row ∧ mark row = true))

theorem marked_boundary {mark : Fin m → Bool} {state : State (n + 2) (size m)}
    (marked : Marked mark state) : Boundary state := by
  obtain ⟨row, same, _⟩ := marked
  exact ⟨row, same⟩

theorem marked_encode_iff (mark : Fin m → Bool)
    (state : Counter.Configuration n m) (history : ℕ) :
    Marked mark (encode state history) ↔ mark state.pc = true := by
  constructor
  · rintro ⟨row, same, marked⟩
    have rows := ((copy_eq_iff state.pc row _ _).mp same).1
    exact rows.symm ▸ marked
  · intro marked
    exact ⟨state.pc, rfl, marked⟩

def InternalMarkedStep (program : Counter.Program n m) (mark : Fin m → Bool)
    (first last : State (n + 2) (size m)) : Prop :=
  step (table program) first = some last ∧ ¬ Marked mark first

abbrev InternalMarkedReaches (program : Counter.Program n m) (mark : Fin m → Bool) :=
  Relation.ReflTransGen (InternalMarkedStep program mark)

def MarkedFirstReturn (program : Counter.Program n m) (mark : Fin m → Bool)
    (first last : State (n + 2) (size m)) : Prop :=
  Marked mark first ∧ Marked mark last ∧
    ∃ after, step (table program) first = some after ∧ InternalMarkedReaches program mark after last

private theorem internal_to_marked (program : Counter.Program n m) (mark : Fin m → Bool)
    {first last : State (n + 2) (size m)} (run : InternalReaches program first last) :
    InternalMarkedReaches program mark first last := by
  induction run with
  | refl => exact Relation.ReflTransGen.refl
  | tail _ edge previous =>
      exact previous.tail ⟨edge.1, fun marked => edge.2 (marked_boundary marked)⟩

/-- An unmarked source instruction has no marked geometric return in its execution. -/
theorem counter_internal_step (program : Counter.Program n m) (mark : Fin m → Bool)
    {first last : Counter.Configuration n m} (transition : Counter.step program first = some last)
    (unmarked : mark first.pc = false) (history : ℕ) :
    InternalMarkedReaches program mark (encode first history)
      (encode last (Counter.Recorded.push (Counter.Recorded.tag program first) history)) := by
  obtain ⟨_, _, next, initial, rest⟩ := step_firstReturn program transition history
  apply Relation.ReflTransGen.head (b := next) ?_ (internal_to_marked program mark rest)
  refine ⟨initial, ?_⟩
  rw [marked_encode_iff, unmarked]
  decide

/-- A finite unmarked source run retains its full final configuration and its actual history. -/
theorem counter_internal_reaches (program : Counter.Program n m) (mark : Fin m → Bool)
    {first last : Counter.Configuration n m}
    (run : Relation.ReflTransGen (fun current next : Counter.Configuration n m =>
      Counter.step program current = some next ∧ mark current.pc = false) first last)
    (history : ℕ) :
    ∃ finalHistory, history ≤ finalHistory ∧
      InternalMarkedReaches program mark (encode first history) (encode last finalHistory) := by
  induction run generalizing history with
  | refl => exact ⟨history, le_refl history, Relation.ReflTransGen.refl⟩
  | @tail middle last _ edge previous =>
      obtain ⟨logged, not_smaller, traversed⟩ := previous history
      have growth := Counter.Recorded.history_lt program
        (first := (middle, logged))
        (last := (last, Counter.Recorded.push (Counter.Recorded.tag program middle) logged))
        (by simp only [Counter.Recorded.step, edge.1, Option.map_some])
      exact ⟨Counter.Recorded.push (Counter.Recorded.tag program middle) logged,
        not_smaller.trans (le_of_lt growth),
        traversed.trans (counter_internal_step program mark edge.1 edge.2 logged)⟩

/-- A source first return lifts to the first positive return to the fixed marked ports. -/
theorem marked_firstReturn (program : Counter.Program n m) (mark : Fin m → Bool)
    {first middle last : Counter.Configuration n m}
    (initial : Counter.step program first = some middle)
    (rest : Relation.ReflTransGen (fun current next : Counter.Configuration n m =>
      Counter.step program current = some next ∧ mark current.pc = false) middle last)
    (first_marked : mark first.pc = true) (last_marked : mark last.pc = true) (history : ℕ) :
    ∃ finalHistory, history < finalHistory ∧
      MarkedFirstReturn program mark (encode first history) (encode last finalHistory) := by
  obtain ⟨_, _, next, head, inside⟩ := step_firstReturn program initial history
  obtain ⟨logged, not_smaller, following⟩ := counter_internal_reaches program mark rest
    (Counter.Recorded.push (Counter.Recorded.tag program first) history)
  have growth := Counter.Recorded.history_lt program
    (first := (first, history))
    (last := (middle, Counter.Recorded.push (Counter.Recorded.tag program first) history))
    (by simp only [Counter.Recorded.step, initial, Option.map_some])
  exact ⟨logged, growth.trans_le not_smaller, (marked_encode_iff mark first history).mpr first_marked,
    (marked_encode_iff mark last logged).mpr last_marked, next, head,
    (internal_to_marked program mark inside).trans following⟩

end Monodromy.Counter.Reversible.Recording
