import Monodromy.Continuation

/-! Finite reversible conditional control, using only the existing geometric words. -/
noncomputable section

namespace Monodromy.ReversibleControl

open CoupledContinuation

/-- A static signed word in the one existing zero-conditional loop. -/
def zeroWord : ℤ → Word
  | .ofNat count => List.replicate count (.zeroLeft, false)
  | .negSucc count => List.replicate (count + 1) (.zeroLeft, true)

private theorem execute_B_reverse (left right control : ℤ) :
    execute B_left.reverse (prepare left right control) =
      prepare left right (control - if left = 0 then 1 else 0) := by
  have inverse := execute_driver_reverse B_left
    (prepare left right (control - if left = 0 then 1 else 0))
  rw [execute_B_left] at inverse
  simpa only [sub_add_cancel] using inverse

private theorem repeat_forward (count : ℕ) (left right control : ℤ) :
    execute (Word.driver (List.replicate count (.zeroLeft, false))) (prepare left right control) =
      prepare left right (control + if left = 0 then (count : ℤ) else 0) := by
  induction count generalizing control with
  | zero => simp only [List.replicate_zero, execute_word_nil, Nat.cast_zero, ite_self, add_zero]
  | succ count induction_hypothesis =>
      rw [List.replicate_succ, execute_word_cons]
      change execute (Word.driver (List.replicate count (.zeroLeft, false)))
        (execute B_left (prepare left right control)) = _
      rw [execute_B_left, induction_hypothesis]
      congr 1
      split_ifs <;> push_cast <;> omega

private theorem repeat_backward (count : ℕ) (left right control : ℤ) :
    execute (Word.driver (List.replicate count (.zeroLeft, true))) (prepare left right control) =
      prepare left right (control - if left = 0 then (count : ℤ) else 0) := by
  induction count generalizing control with
  | zero => simp only [List.replicate_zero, execute_word_nil, Nat.cast_zero, ite_self, sub_zero]
  | succ count induction_hypothesis =>
      rw [List.replicate_succ, execute_word_cons]
      change execute (Word.driver (List.replicate count (.zeroLeft, true)))
        (execute B_left.reverse (prepare left right control)) = _
      rw [execute_B_reverse, induction_hypothesis]
      congr 1
      split_ifs <;> push_cast <;> omega

/-- The integer formula is proved from actual forward and reverse lifted loops. -/
theorem execute_zeroWord (amount left right control : ℤ) :
    execute (Word.driver (zeroWord amount)) (prepare left right control) =
      prepare left right (control + if left = 0 then amount else 0) := by
  cases amount with
  | ofNat count => exact repeat_forward count left right control
  | negSucc count =>
      rw [zeroWord, repeat_backward]
      congr 1
      split_ifs <;> omega

variable {degree : ℕ} [NeZero degree]

/-- A finite permutation is compiled into finite words, not a new geometric operation. -/
def table (permutation : Equiv.Perm (Fin degree)) (index : Fin degree) : Word :=
  zeroWord ((permutation index).val - (index.val : ℤ))

/-- The native interpreter and its actual finite-root routing are used unchanged. -/
def program (permutation : Equiv.Perm (Fin degree)) : Program degree :=
  ⟨table permutation, fun _ => false⟩

/-- Each return is an ordinary nonhalting native Word-table step. -/
theorem step_eq_some (permutation : Equiv.Perm (Fin degree)) (state : Memory) :
    (program permutation).step state = some ((program permutation).advance state) := by
  simp [Program.step, Program.haltSignal, program, Choice.dispatch]

/-- The statically compiled primitive count is the absolute PC displacement. -/
theorem word_length (amount : ℤ) : (zeroWord amount).length = amount.natAbs := by
  cases amount <;> simp [zeroWord]

/-- A zero memory permutes the PC residue and retains its whole integer quotient. -/
theorem advance_prepare (permutation : Equiv.Perm (Fin degree))
    (left right quotient : ℤ) (index : Fin degree) :
    (program permutation).advance (prepare left right ((degree : ℤ) * quotient + index.val)) =
      if left = 0 then
        prepare left right ((degree : ℤ) * quotient + (permutation index).val)
      else prepare left right ((degree : ℤ) * quotient + index.val) := by
  rw [Program.advance_prepare]
  change execute (Word.driver (zeroWord ((permutation index).val - (index.val : ℤ))))
    (prepare left right ((degree : ℤ) * quotient + index.val)) = _
  rw [execute_zeroWord]
  by_cases zero : left = 0
  · rw [ite_eq_left zero, ite_eq_left zero]
    congr 1
    omega
  · simp only [ite_eq_right zero, add_zero]

/-- The inverse is another finite word table, selected using the returned control root. -/
theorem inverse_prepare (permutation : Equiv.Perm (Fin degree))
    (left right quotient : ℤ) (index : Fin degree) :
    (program permutation.symm).advance
      ((program permutation).advance (prepare left right ((degree : ℤ) * quotient + index.val))) =
        prepare left right ((degree : ℤ) * quotient + index.val) := by
  rw [advance_prepare]
  by_cases zero : left = 0
  · rw [ite_eq_left zero, advance_prepare, ite_eq_left zero, permutation.symm_apply_apply]
  · rw [ite_eq_right zero, advance_prepare, ite_eq_right zero]

private theorem prepared_residue_induction {property : Memory → Prop}
    (holds : ∀ left right quotient (index : Fin degree),
      property (prepare left right ((degree : ℤ) * quotient + index.val))) (state : Memory) :
    property state := by
  obtain ⟨⟨⟨left, right⟩, control⟩, rfl⟩ := prepare_surjective state
  let index : Fin degree := ⟨(control % (degree : ℤ)).toNat, by
    apply (Int.toNat_lt_of_ne_zero (NeZero.ne degree)).mpr
    exact Int.emod_lt_of_pos _ (by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne degree))⟩
  have remainder : (index.val : ℤ) = control % (degree : ℤ) :=
    Int.toNat_of_nonneg (Int.emod_nonneg _ (by exact_mod_cast NeZero.ne degree))
  have decomposition : (degree : ℤ) * (control / (degree : ℤ)) + index.val = control := by
    rw [remainder]
    exact Int.mul_ediv_add_emod _ _
  have result := holds left right (control / (degree : ℤ)) index
  rwa [decomposition] at result

/-- The inverse reconstructs the entire raw geometric state, with no retained trace. -/
theorem inverse (permutation : Equiv.Perm (Fin degree)) (state : Memory) :
    (program permutation.symm).advance ((program permutation).advance state) = state :=
  prepared_residue_induction (degree := degree)
    (property := fun point =>
      (program permutation.symm).advance ((program permutation).advance point) = point)
    (inverse_prepare permutation) state

/-- Control permutations compose through the same actual conditional path execution. -/
theorem compose_prepare (first second : Equiv.Perm (Fin degree))
    (left right quotient : ℤ) (index : Fin degree) :
    (program second).advance
      ((program first).advance (prepare left right ((degree : ℤ) * quotient + index.val))) =
    (program (first.trans second)).advance
      (prepare left right ((degree : ℤ) * quotient + index.val)) := by
  rw [advance_prepare]
  by_cases zero : left = 0
  · rw [ite_eq_left zero, advance_prepare, ite_eq_left zero, advance_prepare, ite_eq_left zero]
    rfl
  · rw [ite_eq_right zero, advance_prepare, ite_eq_right zero, advance_prepare, ite_eq_right zero]

theorem compose (first second : Equiv.Perm (Fin degree)) (state : Memory) :
    (program second).advance ((program first).advance state) =
      (program (first.trans second)).advance state :=
  prepared_residue_induction (degree := degree)
    (property := fun point => (program second).advance ((program first).advance point) =
      (program (first.trans second)).advance point)
    (compose_prepare first second) state

/-- The identity permutation compiles to an identity native return. -/
theorem identity (state : Memory) :
    (program (Equiv.refl (Fin degree))).advance state = state := by
  apply prepared_residue_induction (degree := degree)
    (property := fun point => (program (Equiv.refl (Fin degree))).advance point = point)
    (state := state)
  intro left right quotient index
  rw [advance_prepare]
  split_ifs <;> rfl

def executionEquiv (permutation : Equiv.Perm (Fin degree)) : Memory ≃ Memory where
  toFun := (program permutation).advance
  invFun := (program permutation.symm).advance
  left_inv := inverse permutation
  right_inv := by
    intro state
    simpa only [Equiv.symm_symm] using inverse permutation.symm state

/-- The two-PC controlled exchange is a single nonhalting native finite word table. -/
def swap : Program 2 := program (Equiv.swap (0 : Fin 2) 1)

theorem swap_involutive : Function.Involutive swap.advance := by
  intro state
  have symmetry : (Equiv.swap (0 : Fin 2) 1).symm = Equiv.swap (0 : Fin 2) 1 := Equiv.symm_swap _ _
  simpa only [swap, symmetry] using inverse (Equiv.swap (0 : Fin 2) 1) state

end Monodromy.ReversibleControl
