import Monodromy.Continuation
import Mathlib.Tactic.Ring
import Mathlib.Data.Fintype.Card

noncomputable section

namespace Monodromy.CoupledContinuation

open unitInterval

/-- The upper deck action is already executable by an existing control path word. -/
def controlDeck (amount : ℤ) : Memory → Memory :=
  execute (Word.driver (Word.control amount))

theorem controlDeck_prepare (amount left right control : ℤ) :
    controlDeck amount (prepare left right control) = prepare left right (control + amount) :=
  execute_control_word amount left right control

/-- Control transport changes only the upper root by its exponential period. -/
theorem controlDeck_values (amount : ℤ) (state : Memory) :
    (controlDeck amount state).val = (state.val.1, state.val.2 + NestedContinuation.period amount) := by
  obtain ⟨⟨⟨left, right⟩, control⟩, rfl⟩ := prepare_surjective state
  rw [controlDeck_prepare]
  apply Prod.ext
  · rfl
  · change upperRoot left right (control + amount) =
      upperRoot left right control + NestedContinuation.period amount
    simp [upperRoot, NestedContinuation.period]
    ring

private theorem projection_period_shift (amount : ℤ) (point : Point) :
    projection (point.1, point.2 + NestedContinuation.period amount) = projection point := by
  apply Prod.ext
  · rfl
  · apply Subtype.ext
    change Complex.exp (point.2 + NestedContinuation.period amount) /
      (point.1.1.val * point.1.2.val) = Complex.exp point.2 / (point.1.1.val * point.1.2.val)
    rw [Complex.exp_add, NestedContinuation.exp_period, mul_one]

/-- Lift uniqueness makes every fixed driver equivariant under the upper deck action. -/
theorem execute_controlDeck (driver : Driver) (amount : ℤ) (state : Memory) :
    execute driver (controlDeck amount state) = controlDeck amount (execute driver state) := by
  let shifted : C(I, Point) :=
    ⟨fun time => ((trajectory driver state time).1,
      (trajectory driver state time).2 + NestedContinuation.period amount),
      (trajectory driver state).continuous.fst.prodMk
        ((trajectory driver state).continuous.snd.add continuous_const)⟩
  have projects : ∀ time, projection (shifted time) = driver.path time := by
    intro time
    exact (projection_period_shift amount (trajectory driver state time)).trans
      (trajectory_projects driver state time)
  have starts : trajectory driver (controlDeck amount state) 0 = shifted 0 := by
    change trajectory driver (controlDeck amount state) 0 =
      ((trajectory driver state 0).1, (trajectory driver state 0).2 + NestedContinuation.period amount)
    rw [trajectory_start, trajectory_start, controlDeck_values]
  have same : trajectory driver (controlDeck amount state) = shifted :=
    coupled_curve_unique _ _
      (fun time => (trajectory_projects driver (controlDeck amount state) time).trans (projects time).symm)
      starts
  apply Subtype.ext
  rw [controlDeck_values]
  exact congrArg (fun curve : C(I, Point) => curve 1) same

/-- A deck shift multiplies every return observation by the same finite-cover phase. -/
theorem controlRoot_controlDeck (degree : ℕ) (amount : ℤ) (state : Memory) :
    controlRoot degree (controlDeck amount state) =
      Complex.exp (NestedContinuation.period amount / (degree : ℂ)) * controlRoot degree state := by
  unfold controlRoot
  rw [controlDeck_values]
  rw [← Complex.exp_add]
  congr 1
  ring

section FiniteRouting

variable (degree : ℕ) [NeZero degree]

private theorem root_prepare (index : Fin degree) (left right : ℤ) :
    controlRoot degree (prepare left right index.val) = (Radix.omega degree index : ℂ) := by
  rw [controlRoot_prepare]
  have root := congrArg (fun value : Circle => (value : ℂ)) (Radix.readRoot_digit degree 0 index)
  simpa only [mul_zero, zero_add] using root

/-- Every selected path has a fixed target observation on its own source cell. -/
def SendsRootCells (table : Fin degree → Driver) (next : Fin degree → Fin degree) : Prop :=
  ∀ index state, controlRoot degree state = (Radix.omega degree index : ℂ) →
    controlRoot degree (execute (table index) state) = (Radix.omega degree (next index) : ℂ)

/-- Exact cell matching includes the preimage condition needed to reverse a routed path. -/
def MatchesRootCells (table : Fin degree → Driver) (next : Fin degree → Fin degree) : Prop :=
  ∀ index state,
    controlRoot degree (execute (table index) state) = (Radix.omega degree (next index) : ℂ) ↔
      controlRoot degree state = (Radix.omega degree index : ℂ)

/-- For these actual lifts, one-sided cell transport is exact by deck equivariance. -/
theorem matchesRootCells_of_sends (table : Fin degree → Driver) (next : Fin degree → Fin degree)
    (sends : SendsRootCells degree table next) : MatchesRootCells degree table next := by
  intro index state
  constructor
  · intro target
    obtain ⟨⟨⟨left, right⟩, control⟩, rfl⟩ := prepare_surjective state
    change controlRoot degree (execute (table index) (prepare left right control)) =
      (Radix.omega degree (next index) : ℂ) at target
    change controlRoot degree (prepare left right control) = (Radix.omega degree index : ℂ)
    let initial := prepare left right (index.val : ℤ)
    let amount : ℤ := control - index.val
    have initial_root : controlRoot degree initial = (Radix.omega degree index : ℂ) :=
      root_prepare degree index left right
    have initial_target := sends index initial initial_root
    have shifted : controlDeck amount initial = prepare left right control := by
      rw [controlDeck_prepare]
      congr 1
      dsimp [amount]
      omega
    have output_phase :
        controlRoot degree (execute (table index) (prepare left right control)) =
          Complex.exp (NestedContinuation.period amount / (degree : ℂ)) *
            controlRoot degree (execute (table index) initial) := by
      rw [← shifted, execute_controlDeck, controlRoot_controlDeck]
    have balance := output_phase.symm.trans target
    rw [initial_target] at balance
    have phase_one : Complex.exp (NestedContinuation.period amount / (degree : ℂ)) = 1 := by
      apply mul_right_cancel₀ (Radix.omega degree (next index)).coe_ne_zero
      simpa only [one_mul] using balance
    rw [← shifted, controlRoot_controlDeck, phase_one, one_mul]
    exact initial_root
  · exact sends index state

/-- Inversion uses the same paths in reverse, indexed by the inverse finite permutation. -/
def reindexedReverse (table : Fin degree → Driver) (permutation : Equiv.Perm (Fin degree)) :
    Fin degree → Driver := fun index => (table (permutation.symm index)).reverse

theorem permuted_routed_left_inverse (table : Fin degree → Driver)
    (permutation : Equiv.Perm (Fin degree))
    (cells : MatchesRootCells degree table permutation) :
    Function.LeftInverse (executeRouted degree (reindexedReverse degree table permutation))
      (executeRouted degree table) := by
  intro state
  obtain ⟨index, observed⟩ := controlRoot_is_root degree state
  have moved := (cells index state).mpr observed
  rw [executeRouted_eq degree table state index observed]
  rw [executeRouted_eq degree (reindexedReverse degree table permutation)
    (execute (table index) state) (permutation index) moved]
  simpa only [reindexedReverse, permutation.symm_apply_apply] using execute_driver_reverse (table index) state

theorem permuted_routed_right_inverse (table : Fin degree → Driver)
    (permutation : Equiv.Perm (Fin degree))
    (cells : MatchesRootCells degree table permutation) :
    Function.RightInverse (executeRouted degree (reindexedReverse degree table permutation))
      (executeRouted degree table) := by
  intro state
  obtain ⟨index, observed⟩ := controlRoot_is_root degree state
  have reversed : controlRoot degree (execute (table (permutation.symm index)).reverse state) =
      (Radix.omega degree (permutation.symm index) : ℂ) := by
    apply (cells (permutation.symm index) _).mp
    rw [execute_after_driver_reverse, permutation.apply_symm_apply]
    exact observed
  rw [executeRouted_eq degree (reindexedReverse degree table permutation) state index observed]
  change executeRouted degree table (execute (table (permutation.symm index)).reverse state) = state
  rw [executeRouted_eq degree table _ (permutation.symm index) reversed]
  exact execute_after_driver_reverse (table (permutation.symm index)) state

/-- A root-permuting table is globally reversible by the existing routed execution kernel. -/
def permutedRoutedEquiv (table : Fin degree → Driver) (permutation : Equiv.Perm (Fin degree))
    (sends : SendsRootCells degree table permutation) : Memory ≃ Memory where
  toFun := executeRouted degree table
  invFun := executeRouted degree (reindexedReverse degree table permutation)
  left_inv := permuted_routed_left_inverse degree table permutation
    (matchesRootCells_of_sends degree table permutation sends)
  right_inv := permuted_routed_right_inverse degree table permutation
    (matchesRootCells_of_sends degree table permutation sends)

theorem permutedRoutedEquiv_apply (table : Fin degree → Driver) (permutation : Equiv.Perm (Fin degree))
    (sends : SendsRootCells degree table permutation) (state : Memory) :
    permutedRoutedEquiv degree table permutation sends state = executeRouted degree table state := rfl

theorem permutedRoutedEquiv_inverse (table : Fin degree → Driver) (permutation : Equiv.Perm (Fin degree))
    (sends : SendsRootCells degree table permutation) (state : Memory) :
    (permutedRoutedEquiv degree table permutation sends).symm state =
      executeRouted degree (reindexedReverse degree table permutation) state := rfl

/-- Root-preserving routing is exactly the identity-permutation instance. -/
theorem permutedRoutedEquiv_refl (table : Fin degree → Driver)
    (preserves : ∀ index state, controlRoot degree (execute (table index) state) = controlRoot degree state) :
    permutedRoutedEquiv degree table (Equiv.refl _)
      (fun index state observed => (preserves index state).trans observed) = routedEquiv degree table preserves := by
  apply Equiv.ext
  intro state
  rfl

/-- A closed finite observation evolves by its specified transition on roots. -/
theorem routed_root (table : Fin degree → Driver) (next : Fin degree → Fin degree)
    (sends : SendsRootCells degree table next) (state : Memory) (index : Fin degree)
    (observed : controlRoot degree state = (Radix.omega degree index : ℂ)) :
    controlRoot degree (executeRouted degree table state) = (Radix.omega degree (next index) : ℂ) := by
  rw [executeRouted_eq degree table state index observed]
  exact sends index state observed

theorem finite_surjective_of_routed_surjective (table : Fin degree → Driver)
    (next : Fin degree → Fin degree) (sends : SendsRootCells degree table next)
    (onto : Function.Surjective (executeRouted degree table)) : Function.Surjective next := by
  intro target
  obtain ⟨state, reaches⟩ := onto (prepare 0 0 target.val)
  obtain ⟨index, observed⟩ := controlRoot_is_root degree state
  have roots := routed_root degree table next sends state index observed
  rw [reaches, root_prepare] at roots
  exact ⟨index, Radix.omega_injective degree (Subtype.ext roots.symm)⟩

/-- Within root-closed routing, global reversibility is exactly finite-root permutation. -/
theorem routed_bijective_iff (table : Fin degree → Driver) (next : Fin degree → Fin degree)
    (sends : SendsRootCells degree table next) :
    Function.Bijective (executeRouted degree table) ↔ Function.Bijective next := by
  constructor
  · intro reversible
    exact Finite.surjective_iff_bijective.mp
      (finite_surjective_of_routed_surjective degree table next sends reversible.surjective)
  · intro finite_reversible
    exact (permutedRoutedEquiv degree table (Equiv.ofBijective next finite_reversible) sends).bijective

end FiniteRouting

end Monodromy.CoupledContinuation

#print axioms Monodromy.CoupledContinuation.execute_controlDeck
#print axioms Monodromy.CoupledContinuation.matchesRootCells_of_sends
#print axioms Monodromy.CoupledContinuation.routed_bijective_iff
