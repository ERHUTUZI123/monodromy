module

public import «Monodromy-analytic-scalars»
public import Monodromy.Effectiveness

@[expose] public section

noncomputable section

namespace Monodromy.AnalyticComparison

open CoupledContinuation

abbrev State := (ℝ × ℝ) × ℝ

def embed (labels : Labels) : State :=
  (((labels.1.1 : ℝ), (labels.1.2 : ℝ)), (labels.2 : ℝ))

theorem embed_injective : Function.Injective embed := by
  rintro ⟨⟨x, y⟩, z⟩ ⟨⟨x', y'⟩, z'⟩ same
  have hx : (x : ℝ) = x' := congrArg (fun s : State => s.1.1) same
  have hy : (y : ℝ) = y' := congrArg (fun s : State => s.1.2) same
  have hz : (z : ℝ) = z' := congrArg (fun s : State => s.2) same
  have : x = x' := by exact_mod_cast hx
  have : y = y' := by exact_mod_cast hy
  have : z = z' := by exact_mod_cast hz
  aesop

/-- These analytic shears evaluate formulas directly, with no path-lifting operation. -/
def gate (operation : Gate) (backward : Bool) (state : State) : State :=
  let displacement : ℝ := if backward then -1 else 1
  match operation with
  | .left => ((state.1.1 + displacement, state.1.2), state.2)
  | .right => ((state.1.1, state.1.2 + displacement), state.2)
  | .zeroLeft => (state.1, state.2 + displacement * zero state.1.1)
  | .zeroRight => (state.1, state.2 + displacement * zero state.1.2)
  | .control => (state.1, state.2 + displacement)

theorem analyticAt_gate (operation : Gate) (backward : Bool) (state : State) :
    AnalyticAt ℝ (gate operation backward) state := by
  have first : AnalyticAt ℝ (fun s : State => s.1.1) state :=
    analyticAt_fst.comp analyticAt_fst
  have second : AnalyticAt ℝ (fun s : State => s.1.2) state :=
    analyticAt_snd.comp analyticAt_fst
  have control : AnalyticAt ℝ (fun s : State => s.2) state := analyticAt_snd
  cases operation with
  | left => exact ((first.add analyticAt_const).prod second).prod control
  | right => exact (first.prod (second.add analyticAt_const)).prod control
  | zeroLeft =>
      exact analyticAt_fst.prod (control.add
        (analyticAt_const.mul ((analyticAt_zero _).comp first)))
  | zeroRight =>
      exact analyticAt_fst.prod (control.add
        (analyticAt_const.mul ((analyticAt_zero _).comp second)))
  | control => exact analyticAt_fst.prod (control.add analyticAt_const)

theorem gate_embed (operation : Gate) (backward : Bool) (labels : Labels) :
    gate operation backward (embed labels) = embed (operation.evalInt backward labels) := by
  rcases labels with ⟨⟨left, right⟩, control⟩
  cases operation <;> cases backward <;>
    simp [gate, Gate.evalInt, embed, zero_int]

def word : Word → State → State
  | [], state => state
  | (operation, backward) :: rest, state => word rest (gate operation backward state)

theorem gate_reverse (operation : Gate) (backward : Bool) (state : State) :
    gate operation (!backward) (gate operation backward state) = state := by
  rcases state with ⟨⟨left, right⟩, control⟩
  cases operation <;> cases backward <;> simp [gate]

theorem word_append (first second : Word) (state : State) :
    word (first ++ second) state = word second (word first state) := by
  induction first generalizing state with
  | nil => rfl
  | cons atom rest recursive => simpa only [List.cons_append, word] using recursive _

/-- The same formal reverse word inverts every analytic primitive on the whole real space. -/
theorem word_inverse (operations : Word) (state : State) :
    word operations.inverse (word operations state) = state := by
  induction operations generalizing state with
  | nil => rfl
  | cons atom rest recursive =>
      rcases atom with ⟨operation, backward⟩
      rw [Word.inverse, word_append, word, recursive]
      simpa only [Word.atom, word] using gate_reverse operation backward state

theorem analyticAt_word (operations : Word) (state : State) :
    AnalyticAt ℝ (word operations) state := by
  induction operations generalizing state with
  | nil => exact analyticAt_id
  | cons atom rest recursive =>
      exact (recursive _).comp (analyticAt_gate atom.1 atom.2 state)

theorem word_embed (operations : Word) (labels : Labels) :
    word operations (embed labels) = embed (operations.evalInt labels) := by
  induction operations generalizing labels with
  | nil => rfl
  | cons atom rest recursive =>
      simp only [word, Word.evalInt, gate_embed, recursive]

variable {degree : ℕ} [NeZero degree]

/-- A finite analytic successor over three real coordinates. -/
def next (program : Program degree) (state : State) : State :=
  ∑ index, weight degree index state.2 • word (program.table index) state

def halt (program : Program degree) (state : State) : ℝ :=
  ∑ index, weight degree index state.2 * if program.stop index then 1 else 0

theorem analyticAt_next (program : Program degree) (state : State) :
    AnalyticAt ℝ (next program) state := by
  exact Finset.analyticAt_fun_sum Finset.univ (fun index _ =>
    (((analyticAt_weight degree index _).comp analyticAt_snd).smul
      (analyticAt_word (program.table index) state)))

theorem analyticAt_halt (program : Program degree) (state : State) :
    AnalyticAt ℝ (halt program) state := by
  exact Finset.analyticAt_fun_sum Finset.univ (fun index _ =>
    (((analyticAt_weight degree index _).comp analyticAt_snd).mul analyticAt_const))

theorem weight_label (marked : Fin degree) (labels : Labels) :
    weight degree marked (labels.2 : ℝ) =
      if marked = Program.indexInt degree labels then 1 else 0 := by
  have result := weight_int_digit degree (labels.2 / (degree : ℤ)) marked
    (Program.indexInt degree labels)
  rw [Program.control_decomposition] at result
  exact result

theorem next_embed (program : Program degree) (labels : Labels) :
    next program (embed labels) = embed (program.nextInt labels) := by
  classical
  simp only [next, embed, weight_label]
  rw [Finset.sum_eq_single (Program.indexInt degree labels)]
  · simp only [ite_true, one_smul]
    exact word_embed _ labels
  · intro index _ different
    simp [different]
  · simp

theorem halt_embed (program : Program degree) (labels : Labels) :
    halt program (embed labels) = if program.haltInt labels then 1 else 0 := by
  classical
  simp only [halt, embed, weight_label]
  rw [Finset.sum_eq_single (Program.indexInt degree labels)]
  · simp [Program.haltInt]
    rfl
  · intro index _ different
    simp [different]
  · simp

def step (program : Program degree) (state : State) : Option State :=
  if halt program state = 1 then none else some (next program state)

def eval (program : Program degree) : State → Part State :=
  StateTransition.eval (step program)

theorem step_embed (program : Program degree) (labels : Labels) :
    step program (embed labels) = (program.stepInt labels).map embed := by
  unfold step Program.stepInt
  rw [halt_embed]
  cases program.haltInt labels <;> simp [next_embed]

/-- Direct analytic execution agrees on complete results and divergence, not only on one step. -/
theorem eval_embed (program : Program degree) (labels : Labels) :
    eval program (embed labels) = embed <$> program.evalInt labels := by
  have refinement : StateTransition.Respects program.stepInt (step program)
      (fun first second => embed first = second) := by
    apply StateTransition.fun_respects.mpr
    intro source
    cases result : program.stepInt source with
    | none =>
        change step program (embed source) = none
        simp [step_embed, result]
    | some successor =>
        apply Relation.TransGen.single
        simp [step_embed, result]
  exact StateTransition.tr_eval' program.stepInt (step program) embed refinement labels

theorem result_iff (program : Program degree) (initial final : Labels) :
    embed final ∈ eval program (embed initial) ↔
      Labels.prepare final ∈ program.eval (Labels.prepare initial) := by
  rw [eval_embed, Program.eval_prepareInt]
  simp only [Part.map_eq_map, Part.mem_map_iff]
  constructor
  · rintro ⟨found, reaches, same⟩
    exact ⟨found, reaches, congrArg Labels.prepare (embed_injective same)⟩
  · rintro ⟨found, reaches, same⟩
    have injective : Function.Injective Labels.prepare := by
      rintro ⟨⟨x, y⟩, z⟩ ⟨⟨x', y'⟩, z'⟩ same
      simpa [Labels.prepare] using prepare_injective same
    exact ⟨found, reaches, congrArg embed (injective same)⟩

theorem halting_iff (program : Program degree) (labels : Labels) :
    (eval program (embed labels)).Dom ↔ (program.eval (Labels.prepare labels)).Dom := by
  rw [eval_embed, Program.eval_prepareInt]
  rfl

end Monodromy.AnalyticComparison
