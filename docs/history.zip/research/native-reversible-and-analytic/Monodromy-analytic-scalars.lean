module

public import Monodromy.Continuation
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Sinc
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Deriv
public import Mathlib.Analysis.Analytic.IsolatedZeros

@[expose] public section

open scoped Topology

noncomputable section

/-- The removable value at zero preserves real analyticity. -/
theorem Real.analyticAt_sinc (x : ℝ) : AnalyticAt ℝ Real.sinc x := by
  rw [Real.sinc_eq_dslope]
  by_cases same : x = 0
  · subst x
    obtain ⟨series, analytic⟩ := (Real.analyticAt_sin : AnalyticAt ℝ Real.sin 0)
    exact ⟨series.fslope, analytic.has_fpower_series_dslope_fslope⟩
  · have analytic : AnalyticAt ℝ (fun y : ℝ => (Real.sin y - Real.sin 0) / (y - 0)) x :=
      (Real.analyticAt_sin.sub analyticAt_const).div
        (analyticAt_id.sub analyticAt_const) (sub_ne_zero.mpr same)
    apply analytic.congr
    filter_upwards [isOpen_ne.mem_nhds same] with y other
    simp only [dslope_of_ne Real.sin other, slope_def_field]

namespace Monodromy.AnalyticComparison

/-- An analytic exact zero indicator on the integer lattice. -/
def zero (x : ℝ) : ℝ := Real.sinc (Real.pi * x)

theorem analyticAt_zero (x : ℝ) : AnalyticAt ℝ zero x :=
  (Real.analyticAt_sinc _).comp (analyticAt_const.mul analyticAt_id)

theorem zero_int (n : ℤ) : zero (n : ℝ) = if n = 0 then 1 else 0 := by
  by_cases same : n = 0
  · subst n
    simp [zero]
  · have nonzero : Real.pi * (n : ℝ) ≠ 0 :=
      mul_ne_zero Real.pi_ne_zero (by exact_mod_cast same)
    rw [zero, Real.sinc_of_ne_zero nonzero, mul_comm Real.pi (n : ℝ),
      Real.sin_int_mul_pi, zero_div, ite_eq_right same]

/-- A real analytic cardinal selector for the finite control residue. -/
def weight (degree : ℕ) [NeZero degree] (marked : Fin degree) (x : ℝ) : ℝ :=
  (Choice.kernel (fun z : ℂ => z ^ degree) (Radix.omega degree marked : ℂ)
    (Radix.readRoot degree ((2 * Real.pi) * x) : ℂ)).re

theorem analyticAt_weight (degree : ℕ) [NeZero degree] (marked : Fin degree) (x : ℝ) :
    AnalyticAt ℝ (weight degree marked) x := by
  have root : AnalyticAt ℂ (fun z : ℂ =>
      Complex.exp (((2 * Real.pi : ℝ) : ℂ) * z / (degree : ℂ) * Complex.I)) (x : ℂ) :=
    analyticAt_cexp.comp
      (((analyticAt_const.mul analyticAt_id).div_const).mul analyticAt_const)
  have analytic : AnalyticAt ℂ (fun z : ℂ =>
      Choice.kernel (fun w : ℂ => w ^ degree) (Radix.omega degree marked : ℂ)
        (Complex.exp (((2 * Real.pi : ℝ) : ℂ) * z / (degree : ℂ) * Complex.I))) (x : ℂ) :=
    (Choice.analyticAt_kernel (fun _ => analyticAt_id.pow degree)
      (Radix.omega degree marked : ℂ) _).comp root
  change AnalyticAt ℝ (fun y : ℝ =>
    (Choice.kernel (fun z : ℂ => z ^ degree) (Radix.omega degree marked : ℂ)
      (Radix.readRoot degree ((2 * Real.pi) * y) : ℂ)).re) x
  simpa only [Radix.readRoot, Circle.coe_exp, Complex.ofReal_div,
    Complex.ofReal_mul, Complex.ofReal_natCast] using analytic.re_ofReal

theorem weight_int_digit (degree : ℕ) [NeZero degree]
    (quotient : ℤ) (marked digit : Fin degree) :
    weight degree marked (((degree : ℤ) * quotient + digit.val : ℤ) : ℝ) =
      if marked = digit then 1 else 0 := by
  unfold weight
  rw [Radix.readRoot_digit, Radix.kernel_root]
  split_ifs <;> simp

theorem weight_digit (degree : ℕ) [NeZero degree] (marked : Fin degree)
    (quotient : ℤ) (digit : Fin degree) :
    weight degree marked ((degree : ℝ) * (quotient : ℝ) + (digit.val : ℝ)) =
      if marked = digit then 1 else 0 := by
  simpa only [Int.cast_add, Int.cast_mul, Int.cast_natCast] using
    weight_int_digit degree quotient marked digit

theorem weight_int (degree : ℕ) [NeZero degree] (marked : Fin degree) (n : ℤ) :
    weight degree marked (n : ℝ) =
      if n % (degree : ℤ) = (marked.val : ℤ) then 1 else 0 := by
  have positive : 0 < (degree : ℤ) := by
    exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne degree)
  let digit : Fin degree := ⟨(n % (degree : ℤ)).toNat, by
    have lower := Int.emod_nonneg n positive.ne'
    have upper := Int.emod_lt_of_pos n positive
    omega⟩
  have digit_value : (digit.val : ℤ) = n % (degree : ℤ) :=
    Int.toNat_of_nonneg (Int.emod_nonneg n positive.ne')
  have decomposition : (degree : ℤ) * (n / (degree : ℤ)) + digit.val = n := by
    rw [digit_value]
    exact Int.mul_ediv_add_emod n (degree : ℤ)
  have observed := weight_int_digit degree (n / (degree : ℤ)) marked digit
  rw [decomposition] at observed
  have same : marked = digit ↔ n % (degree : ℤ) = (marked.val : ℤ) := by
    constructor
    · rintro rfl
      exact digit_value.symm
    · intro equality
      apply Fin.ext
      exact_mod_cast equality.symm.trans digit_value.symm
  simpa only [same] using observed

end Monodromy.AnalyticComparison
