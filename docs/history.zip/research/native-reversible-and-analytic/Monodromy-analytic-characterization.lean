module

public import «Monodromy-analytic-model»
public import Monodromy.Structure

@[expose] public section

namespace Monodromy.Structure

open CoupledContinuation NativeInterface

/-- The direct analytic comparator has exactly the native program's fixed numeric graph. -/
theorem analytic_computes_iff {degree : ℕ} [NeZero degree]
    (program : Program degree) (function : ℕ → Part ℕ) :
    (∀ input value, value ∈ function input ↔ ∃ labels : Labels,
      AnalyticComparison.embed labels ∈ AnalyticComparison.eval program
        (AnalyticComparison.embed (inputLabels input)) ∧ outputLabels labels = value) ↔
      Computes program function := by
  simp_rw [AnalyticComparison.result_iff]
  rfl

/-- The same finite programs have globally real analytic successors in three real coordinates. -/
theorem analytic_realization {function : ℕ → Part ℕ} (effective : Partrec function) :
    ∃ degree : ℕ, ∃ program : Program (degree + 1),
      (∀ state, AnalyticAt ℝ (AnalyticComparison.next program) state) ∧
      (∀ state, AnalyticAt ℝ (AnalyticComparison.halt program) state) ∧
      ∀ input value, value ∈ function input ↔ ∃ labels : Labels,
        AnalyticComparison.embed labels ∈ AnalyticComparison.eval program
          (AnalyticComparison.embed (inputLabels input)) ∧ outputLabels labels = value := by
  obtain ⟨degree, program, correct⟩ := realizable_of_partrec effective
  exact ⟨degree, program, AnalyticComparison.analyticAt_next program,
    AnalyticComparison.analyticAt_halt program, (analytic_computes_iff program function).mpr correct⟩

end Monodromy.Structure
