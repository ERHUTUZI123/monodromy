import Monodromy.Counter

/-! The actual reversible recording family uses only unit shifts and zero tests. -/

namespace Monodromy.Counter.Reversible.Action

variable {n : ℕ}

/-- The elementary source family required by reversible counter compression. -/
def UnitShift : Action n → Prop
  | .shift _ amount => amount = 1 ∨ amount = -1
  | .test _ _ => True

@[simp] theorem unitShift_reverse (action : Action n) :
    UnitShift (reverseAction action) ↔ UnitShift action := by
  cases action with
  | test => rfl
  | shift register amount =>
      change (-amount = 1 ∨ -amount = -1) ↔ amount = 1 ∨ amount = -1
      omega

end Monodromy.Counter.Reversible.Action

namespace Monodromy.Counter.Reversible.RegisterRelocation

variable {n m : ℕ}

@[simp] theorem unitShift_mapAction (register : Fin n → Fin m) (action : Action n) :
    Action.UnitShift (mapAction register action) ↔ Action.UnitShift action := by
  cases action <;> rfl

end Monodromy.Counter.Reversible.RegisterRelocation

namespace Monodromy.Counter.Reversible.Radix

variable (p : ℕ) [NeZero p]

theorem unitShift (index : Fin (edges p)) : Action.UnitShift (table p index).action := by
  obtain ⟨arc, rfl⟩ := (arcEquiv p).surjective index
  rw [table_arc]
  change Action.UnitShift (operation p arc)
  rcases arc with position | ⟨remainder, phase⟩
  · fin_cases position <;> simp [operation, Action.UnitShift]
  · fin_cases phase <;> simp [operation, Action.UnitShift]

end Monodromy.Counter.Reversible.Radix

namespace Monodromy.Counter.Reversible.Recording

variable {n m : ℕ}

private theorem extra_unitShift (program : Counter.Program n m) (arc : Extra program) :
    Action.UnitShift (extraOperation program arc) := by
  cases instruction : program arc.val.1 with
  | inc register target =>
      rw [extraOperation_inc program arc register target instruction]
      exact Or.inl rfl
  | dec register zero nonzero =>
      rw [extraOperation_dec program arc register zero nonzero instruction]
      rcases arc with ⟨⟨row, branch⟩, active⟩
      fin_cases branch <;> simp [Action.UnitShift]
  | halt =>
      have active := arc.property
      unfold Active at active
      rw [instruction] at active
      exact active.elim

/-- Every shift of the statically compiled recording graph is exactly one unit. -/
theorem unitShift (program : Counter.Program n m) (index : Fin (edges program)) :
    Action.UnitShift (table program index).action := by
  obtain ⟨arc, rfl⟩ := (arcEquiv program).surjective index
  rw [table_arc]
  rcases arc with ⟨row, edge⟩ | arc
  · change Action.UnitShift
      (RegisterRelocation.mapAction (historyRegister n)
        (reverseAction (Radix.table (base m) edge).action))
    rw [RegisterRelocation.unitShift_mapAction, Action.unitShift_reverse]
    exact Radix.unitShift (base m) edge
  · exact extra_unitShift program arc

end Monodromy.Counter.Reversible.Recording
