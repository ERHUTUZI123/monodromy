import «Monodromy-prime-basis»

namespace Monodromy.PrimeCode

example (registers : Fin 3 → ℕ) : 0 < encode registers := by
  simpa only [three_encode] using three.encode_positive registers

example (registers : Fin 3 → ℕ) (index : Fin 3) :
    (encode registers).factorization (prime index) = registers index := by
  simpa only [three_encode, three_prime] using three.factorization_encode registers index

example : Function.LeftInverse decode encode := by
  intro registers
  simpa only [three_encode, three_decode] using three.decode_encode registers

example : Function.Injective encode := by
  intro first second same
  apply three.encode_injective
  simpa only [three_encode] using same

example : encode (fun _ => 0) = 1 := by
  simpa only [three_encode] using three.encode_zero

example (registers : Fin 3 → ℕ) (index : Fin 3) :
    encode (Function.update registers index (registers index + 1)) = prime index * encode registers := by
  simpa only [three_encode, three_prime] using three.encode_increment registers index

example (registers : Fin 3 → ℕ) (index : Fin 3) :
    prime index ∣ encode registers ↔ registers index ≠ 0 := by
  simpa only [three_encode, three_prime] using three.prime_dvd_encode_iff registers index

example (registers : Fin 3 → ℕ) (index : Fin 3) :
    registers index = 0 ↔ ¬ prime index ∣ encode registers := by
  simpa only [three_encode, three_prime] using three.register_zero_iff registers index

example (registers : Fin 3 → ℕ) (index : Fin 3) :
    encode registers % prime index = 0 ↔ registers index ≠ 0 := by
  simpa only [three_encode, three_prime] using three.remainder_zero_iff registers index

example (registers : Fin 3 → ℕ) (index : Fin 3) (nonzero : registers index ≠ 0) :
    encode (Function.update registers index (registers index - 1)) = encode registers / prime index := by
  simpa only [three_encode, three_prime] using three.encode_decrement registers index nonzero

#print axioms Basis.factorization_encode
#print axioms Basis.encode_injective
#print axioms Basis.encode_increment
#print axioms Basis.encode_decrement

end Monodromy.PrimeCode
