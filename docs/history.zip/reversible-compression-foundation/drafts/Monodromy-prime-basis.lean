import Monodromy.Counter

namespace Monodromy.PrimeCode

/-- A finite family of distinct primes represents independent natural registers. -/
structure Basis (n : ℕ) where
  prime : Fin n → ℕ
  isPrime : ∀ index, (prime index).Prime
  distinct : Function.Injective prime

namespace Basis

variable {n : ℕ} (basis : Basis n)

def encode (registers : Fin n → ℕ) : ℕ := ∏ index, basis.prime index ^ registers index

def decode (code : ℕ) : Fin n → ℕ := fun index => code.factorization (basis.prime index)

theorem encode_positive (registers : Fin n → ℕ) : 0 < basis.encode registers := by
  apply Finset.prod_pos
  intro index _
  exact pow_pos (basis.isPrime index).pos _

/-- Prime valuations recover every register, uniformly in the finite dimension. -/
theorem factorization_encode (registers : Fin n → ℕ) (index : Fin n) :
    (basis.encode registers).factorization (basis.prime index) = registers index := by
  unfold encode
  rw [Nat.factorization_prod_apply (fun other _ => pow_ne_zero _ (basis.isPrime other).ne_zero)]
  rw [Finset.sum_eq_single index]
  · exact Nat.factorization_pow_self (basis.isPrime index)
  · intro other _ different
    rw [(basis.isPrime other).factorization_pow]
    exact Finsupp.single_eq_of_ne' (basis.distinct.ne different)
  · simp

theorem decode_encode : Function.LeftInverse basis.decode basis.encode := by
  intro registers
  funext index
  exact basis.factorization_encode registers index

theorem encode_injective : Function.Injective basis.encode := basis.decode_encode.injective

@[simp] theorem encode_zero : basis.encode (fun _ => 0) = 1 := by simp [encode]

theorem encode_increment (registers : Fin n → ℕ) (index : Fin n) :
    basis.encode (Function.update registers index (registers index + 1)) =
      basis.prime index * basis.encode registers := by
  unfold encode
  rw [Fintype.prod_eq_mul_prod_compl index, Fintype.prod_eq_mul_prod_compl index]
  rw [Function.update_self, pow_succ]
  have unchanged :
      (∏ other ∈ ({index}ᶜ : Finset (Fin n)), basis.prime other ^
        Function.update registers index (registers index + 1) other) =
      ∏ other ∈ ({index}ᶜ : Finset (Fin n)), basis.prime other ^ registers other := by
    apply Finset.prod_congr rfl
    intro other present
    have different : other ≠ index := by simpa using present
    rw [Function.update_of_ne different]
  rw [unchanged]
  ac_rfl

theorem prime_dvd_encode_iff (registers : Fin n → ℕ) (index : Fin n) :
    basis.prime index ∣ basis.encode registers ↔ registers index ≠ 0 := by
  rw [(basis.isPrime index).dvd_iff_one_le_factorization (basis.encode_positive registers).ne',
    basis.factorization_encode]
  omega

theorem register_zero_iff (registers : Fin n → ℕ) (index : Fin n) :
    registers index = 0 ↔ ¬ basis.prime index ∣ basis.encode registers := by
  rw [basis.prime_dvd_encode_iff]
  omega

theorem remainder_zero_iff (registers : Fin n → ℕ) (index : Fin n) :
    basis.encode registers % basis.prime index = 0 ↔ registers index ≠ 0 := by
  rw [← Nat.dvd_iff_mod_eq_zero, basis.prime_dvd_encode_iff]

theorem encode_decrement (registers : Fin n → ℕ) (index : Fin n)
    (nonzero : registers index ≠ 0) :
    basis.encode (Function.update registers index (registers index - 1)) =
      basis.encode registers / basis.prime index := by
  let previous := Function.update registers index (registers index - 1)
  have restores : Function.update previous index (previous index + 1) = registers := by
    funext other
    by_cases same : other = index
    · subst other
      simp only [previous, Function.update_self]
      omega
    · simp [previous, same]
  have restores_code := basis.encode_increment previous index
  rw [restores] at restores_code
  change basis.encode previous = basis.encode registers / basis.prime index
  rw [restores_code, Nat.mul_div_cancel_left _ (basis.isPrime index).pos]

end Basis

/-- The existing three-register code is the specialization with primes 2, 3 and 5. -/
def three : Basis 3 where
  prime := prime
  isPrime := prime_prime
  distinct := by
    intro first second same
    fin_cases first <;> fin_cases second <;> simp_all [prime]

@[simp] theorem three_prime (index : Fin 3) : three.prime index = prime index := rfl

@[simp] theorem three_decode (code : ℕ) : three.decode code = decode code := rfl

theorem three_encode (registers : Fin 3 → ℕ) : three.encode registers = encode registers := by
  change (∏ index : Fin 3, prime index ^ registers index) =
    2 ^ registers 0 * 3 ^ registers 1 * 5 ^ registers 2
  simp [Fin.prod_univ_succ, prime, mul_assoc]

end Monodromy.PrimeCode
