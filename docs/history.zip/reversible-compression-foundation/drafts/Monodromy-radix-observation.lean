import Monodromy.Counter

/-!
A read-only radix observation. Forward radix exits are identified with the
finish-labelled entry ports of reversed copies; a finite permutation chooses each copy.
There are two counters and precisely two families of existing radix edges.
-/

noncomputable section

namespace Monodromy.Counter.Reversible.RadixObservation

open Glue

variable (p m : ℕ)

def IsFinish (position : Fin (Radix.size p)) : Prop :=
  ∃ remainder : Fin p, position = Radix.finish p remainder

instance (position : Fin (Radix.size p)) : Decidable (IsFinish p position) :=
  inferInstanceAs (Decidable (∃ remainder : Fin p, position = Radix.finish p remainder))

abbrev Interior := {position : Fin (Radix.size p) // ¬ IsFinish p position}

/-- Forward exit ports are represented by their identified reverse ports. -/
abbrev Node := (Fin m × Interior p) ⊕ (Fin m × Fin (Radix.size p))

def size : ℕ := Fintype.card (Node p m)

def nodeEquiv : Node p m ≃ Fin (size p m) := Fintype.equivFin _

private def position : Node p m → Fin (Radix.size p)
  | .inl pair => pair.2.1
  | .inr pair => pair.2

private def leftNode (permutation : Fin p → Equiv.Perm (Fin m))
    (row : Fin m) (index : Fin (Radix.size p)) : Node p m :=
  if finished : IsFinish p index then
    .inr (permutation (Fin.find (fun remainder => index = Radix.finish p remainder) finished) row,
      index)
  else .inl (row, ⟨index, finished⟩)

private def rightNode (row : Fin m) (index : Fin (Radix.size p)) : Node p m :=
  .inr (row, index)

private theorem position_left (permutation : Fin p → Equiv.Perm (Fin m))
    (row : Fin m) (index : Fin (Radix.size p)) :
    position p m (leftNode p m permutation row index) = index := by
  unfold leftNode
  split_ifs <;> rfl

private theorem position_right (row : Fin m) (index : Fin (Radix.size p)) :
    position p m (rightNode p m row index) = index := rfl

private theorem finish_injective : Function.Injective (Radix.finish p) := by
  intro first second same
  change Radix.nodeEquiv p (.inr (first, 7)) = Radix.nodeEquiv p (.inr (second, 7)) at same
  have nodes := (Radix.nodeEquiv p).injective same
  simpa only [Sum.inr.injEq, Prod.mk.injEq, and_true] using nodes

private theorem leftNode_injective (permutation : Fin p → Equiv.Perm (Fin m)) :
    Function.Injective (fun pair : Fin m × Fin (Radix.size p) =>
      leftNode p m permutation pair.1 pair.2) := by
  rintro ⟨first, initial⟩ ⟨second, final⟩ same
  change leftNode p m permutation first initial = leftNode p m permutation second final at same
  have positions := congrArg (position p m) same
  simp only [position_left] at positions
  subst final
  apply Prod.ext
  · unfold leftNode at same
    split_ifs at same with finished
    · exact (permutation _).injective (congrArg Prod.fst (Sum.inr.inj same))
    · have pairs : (first, (⟨initial, finished⟩ : Interior p)) =
          (second, (⟨initial, finished⟩ : Interior p)) := Sum.inl.inj same
      exact congrArg (fun pair : Fin m × Interior p => pair.1) pairs
  · rfl

private theorem rightNode_injective :
    Function.Injective (fun pair : Fin m × Fin (Radix.size p) =>
      rightNode p m pair.1 pair.2) := Sum.inr_injective

private theorem left_right_ne (permutation : Fin p → Equiv.Perm (Fin m))
    (first second : Fin m) (initial final : Fin (Radix.size p))
    (unfinished : ¬ IsFinish p initial) :
    leftNode p m permutation first initial ≠ rightNode p m second final := by
  unfold leftNode rightNode
  rw [dite_eq_right unfinished]
  intro same
  cases same

private theorem left_right_ne' (permutation : Fin p → Equiv.Perm (Fin m))
    (first second : Fin m) (initial final : Fin (Radix.size p))
    (unfinished : ¬ IsFinish p final) :
    leftNode p m permutation first initial ≠ rightNode p m second final := by
  intro same
  have positions := congrArg (position p m) same
  simp only [position_left, position_right] at positions
  subst final
  exact left_right_ne p m permutation first second initial initial unfinished same

def front (permutation : Fin p → Equiv.Perm (Fin m))
    (row : Fin m) (position : Fin (Radix.size p)) : Fin (size p m) :=
  nodeEquiv p m (leftNode p m permutation row position)

def back (row : Fin m) (position : Fin (Radix.size p)) : Fin (size p m) :=
  nodeEquiv p m (rightNode p m row position)

theorem front_injective (permutation : Fin p → Equiv.Perm (Fin m)) :
    Function.Injective (fun pair : Fin m × Fin (Radix.size p) =>
      front p m permutation pair.1 pair.2) :=
  (nodeEquiv p m).injective.comp (leftNode_injective p m permutation)

theorem back_injective :
    Function.Injective (fun pair : Fin m × Fin (Radix.size p) =>
      back p m pair.1 pair.2) :=
  (nodeEquiv p m).injective.comp (rightNode_injective p m)

theorem front_ne_back (permutation : Fin p → Equiv.Perm (Fin m))
    (first second : Fin m) (initial final : Fin (Radix.size p))
    (unfinished : ¬ IsFinish p initial) :
    front p m permutation first initial ≠ back p m second final :=
  fun same => left_right_ne p m permutation first second initial final unfinished
    ((nodeEquiv p m).injective same)

theorem front_ne_back' (permutation : Fin p → Equiv.Perm (Fin m))
    (first second : Fin m) (initial final : Fin (Radix.size p))
    (unfinished : ¬ IsFinish p final) :
    front p m permutation first initial ≠ back p m second final :=
  fun same => left_right_ne' p m permutation first second initial final unfinished
    ((nodeEquiv p m).injective same)

/-- This equality is the port identification; it adds no executable transition. -/
theorem front_finish (permutation : Fin p → Equiv.Perm (Fin m))
    (row : Fin m) (remainder : Fin p) :
    front p m permutation row (Radix.finish p remainder) =
      back p m (permutation remainder row) (Radix.finish p remainder) := by
  have finished : IsFinish p (Radix.finish p remainder) := ⟨remainder, rfl⟩
  have selected : Fin.find (fun other => Radix.finish p remainder = Radix.finish p other) finished =
      remainder := by
    apply finish_injective p
    exact (Fin.find_spec finished).symm
  simp only [front, back, leftNode, dite_eq_left finished, selected, rightNode]

private theorem entry_unfinished : ¬ IsFinish p (Radix.entry p) := by
  rintro ⟨remainder, same⟩
  change Radix.nodeEquiv p (.inl 0) = Radix.nodeEquiv p (.inr (remainder, 7)) at same
  cases (Radix.nodeEquiv p).injective same

variable [NeZero p]

private theorem source_unfinished (index : Fin (Radix.edges p)) :
    ¬ IsFinish p (Radix.table p index).source := by
  rintro ⟨remainder, same⟩
  exact Radix.no_outgoing_finish p remainder ⟨index, same⟩

abbrev Arc := (Fin m × Fin (Radix.edges p)) ⊕ (Fin m × Fin (Radix.edges p))

def edges : ℕ := m * Radix.edges p + m * Radix.edges p

omit [NeZero p] in
instance [NeZero m] : NeZero (size p m) := by
  change NeZero (Fintype.card (Node p m))
  exact ⟨Nat.ne_of_gt (Fintype.card_pos_iff.mpr ⟨Sum.inr ((0 : Fin m), Radix.entry p)⟩)⟩

def arcEquiv : Arc p m ≃ Fin (edges p m) :=
  (Equiv.sumCongr finProdFinEquiv finProdFinEquiv).trans finSumFinEquiv

def arcEdge (permutation : Fin p → Equiv.Perm (Fin m)) : Arc p m → Edge 2 (size p m)
  | .inl (row, index) => mapEdge (front p m permutation row) (Radix.table p index)
  | .inr (row, index) => mapEdge (back p m row) (reverseTable (Radix.table p) index)

def table (permutation : Fin p → Equiv.Perm (Fin m)) : Table 2 (size p m) (edges p m) :=
  fun index => arcEdge p m permutation ((arcEquiv p m).symm index)

@[simp] theorem table_arc (permutation : Fin p → Equiv.Perm (Fin m)) (arc : Arc p m) :
    table p m permutation (arcEquiv p m arc) = arcEdge p m permutation arc := by
  simp only [table, Equiv.symm_apply_apply]

theorem deterministic (permutation : Fin p → Equiv.Perm (Fin m)) :
    Deterministic (table p m permutation) := by
  intro first second different same
  obtain ⟨first, rfl⟩ := (arcEquiv p m).surjective first
  obtain ⟨second, rfl⟩ := (arcEquiv p m).surjective second
  have distinct : first ≠ second := fun equal => different (congrArg (arcEquiv p m) equal)
  simp only [table_arc] at same ⊢
  rcases first with ⟨row, first⟩ | ⟨row, first⟩ <;>
    rcases second with ⟨other, second⟩ | ⟨other, second⟩
  · change Action.Compatible (Radix.table p first).action (Radix.table p second).action
    have ports : (row, (Radix.table p first).source) = (other, (Radix.table p second).source) :=
      front_injective p m permutation same
    have rows : row = other := congrArg Prod.fst ports
    have positions := congrArg Prod.snd ports
    subst other
    exact Radix.deterministic p first second
      (fun equal => distinct (by subst second; rfl)) positions
  · exact False.elim (front_ne_back p m permutation row other _ _
      (source_unfinished p first) same)
  · exact False.elim (front_ne_back p m permutation other row _ _
      (source_unfinished p second) same.symm)
  · change Action.Compatible (reverseTable (Radix.table p) first).action
      (reverseTable (Radix.table p) second).action
    have ports : (row, (reverseTable (Radix.table p) first).source) =
        (other, (reverseTable (Radix.table p) second).source) := back_injective p m same
    have rows : row = other := congrArg Prod.fst ports
    have positions := congrArg Prod.snd ports
    subst other
    exact reverseTable_deterministic _ (Radix.targetCompatible p) first second
      (fun equal => distinct (by subst second; rfl)) positions

theorem targetCompatible (permutation : Fin p → Equiv.Perm (Fin m)) :
    TargetCompatible (table p m permutation) := by
  intro first second different same
  obtain ⟨first, rfl⟩ := (arcEquiv p m).surjective first
  obtain ⟨second, rfl⟩ := (arcEquiv p m).surjective second
  have distinct : first ≠ second := fun equal => different (congrArg (arcEquiv p m) equal)
  simp only [table_arc] at same ⊢
  rcases first with ⟨row, first⟩ | ⟨row, first⟩ <;>
    rcases second with ⟨other, second⟩ | ⟨other, second⟩
  · change Action.Compatible (Radix.table p first).action (Radix.table p second).action
    have ports : (row, (Radix.table p first).target) = (other, (Radix.table p second).target) :=
      front_injective p m permutation same
    have rows : row = other := congrArg Prod.fst ports
    have positions := congrArg Prod.snd ports
    subst other
    exact Radix.targetCompatible p first second
      (fun equal => distinct (by subst second; rfl)) positions
  · exact False.elim (front_ne_back' p m permutation row other _ _
      (source_unfinished p second) same)
  · exact False.elim (front_ne_back' p m permutation other row _ _
      (source_unfinished p first) same.symm)
  · change Action.Compatible (reverseTable (Radix.table p) first).action
      (reverseTable (Radix.table p) second).action
    have ports : (row, (reverseTable (Radix.table p) first).target) =
        (other, (reverseTable (Radix.table p) second).target) := back_injective p m same
    have rows : row = other := congrArg Prod.fst ports
    have positions := congrArg Prod.snd ports
    subst other
    exact reverseTable_targetCompatible _ (Radix.deterministic p) first second
      (fun equal => distinct (by subst second; rfl)) positions

def inputPort (permutation : Fin p → Equiv.Perm (Fin m)) (row : Fin m) : Fin (size p m) :=
  front p m permutation row (Radix.entry p)

def outputPort (row : Fin m) : Fin (size p m) := back p m row (Radix.entry p)

def point (control : Fin (size p m)) (left right : ℤ) : State 2 (size p m) :=
  (control, ![left, right])

/-- The exit ports need no extra stopping rule. -/
theorem no_outgoing_output (permutation : Fin p → Equiv.Perm (Fin m)) (row : Fin m) :
    ¬ ∃ index, (table p m permutation index).source = outputPort p m row := by
  rintro ⟨index, same⟩
  obtain ⟨arc, rfl⟩ := (arcEquiv p m).surjective index
  simp only [table_arc] at same
  rcases arc with ⟨other, index⟩ | ⟨other, index⟩
  · exact front_ne_back p m permutation other row _ _ (source_unfinished p index) same
  · have ports : (other, (Radix.table p index).target) = (row, Radix.entry p) :=
      back_injective p m same
    exact Radix.no_incoming_entry p index (congrArg Prod.snd ports)

/-- The input ports have no incoming edge and can be identified with preceding exits. -/
theorem no_incoming_input (permutation : Fin p → Equiv.Perm (Fin m)) (row : Fin m)
    (index : Fin (edges p m)) :
    (table p m permutation index).target ≠ inputPort p m permutation row := by
  intro same
  obtain ⟨arc, rfl⟩ := (arcEquiv p m).surjective index
  simp only [table_arc] at same
  rcases arc with ⟨other, index⟩ | ⟨other, index⟩
  · have ports : (other, (Radix.table p index).target) = (row, Radix.entry p) :=
      front_injective p m permutation same
    exact Radix.no_incoming_entry p index (congrArg Prod.snd ports)
  · exact front_ne_back p m permutation row other _ _ (entry_unfinished p) same.symm

/-- Actual radix transport reads a remainder, routes finite control, and restores both values. -/
theorem reaches_result (permutation : Fin p → Equiv.Perm (Fin m)) (row : Fin m) (value : ℕ) :
    StateTransition.Reaches (step (table p m permutation))
      (point p m (inputPort p m permutation row) value 0)
      (point p m (outputPort p m (permutation (Counter.DivMod.residue p value) row)) value 0) := by
  have forward := Glue.reaches_map_live (Radix.table p) (table p m permutation)
    (front p m permutation row) (fun index => arcEquiv p m (.inl (row, index)))
    (fun index => by simp only [table_arc, arcEdge])
    (Radix.deterministic p) (deterministic p m permutation) (Radix.reaches_result p value)
  have backward := Glue.reaches_map_live (reverseTable (Radix.table p)) (table p m permutation)
    (back p m (permutation (Counter.DivMod.residue p value) row))
    (fun index => arcEquiv p m (.inr (permutation (Counter.DivMod.residue p value) row, index)))
    (fun index => by simp only [table_arc, arcEdge])
    (reverseTable_deterministic _ (Radix.targetCompatible p)) (deterministic p m permutation)
    (Radix.reverse_pack p (value / p) (Counter.DivMod.residue p value))
  change StateTransition.Reaches (step (table p m permutation))
    (point p m (inputPort p m permutation row) value 0)
    (point p m (front p m permutation row (Radix.finish p (Counter.DivMod.residue p value)))
      (value / p : ℕ) 0) at forward
  rw [front_finish] at forward
  change StateTransition.Reaches (step (table p m permutation))
    (point p m (back p m (permutation (Counter.DivMod.residue p value) row)
      (Radix.finish p (Counter.DivMod.residue p value))) (value / p : ℕ) 0)
    (point p m (outputPort p m (permutation (Counter.DivMod.residue p value) row))
      (p * (value / p) + (Counter.DivMod.residue p value).val : ℕ) 0) at backward
  have restore : p * (value / p) + (Counter.DivMod.residue p value).val = value := by
    simpa only [Counter.DivMod.residue, Nat.add_comm] using Nat.mod_add_div value p
  rw [restore] at backward
  exact forward.trans backward

theorem halt_output (permutation : Fin p → Equiv.Perm (Fin m)) (row : Fin m)
    (values : Fin 2 → ℤ) : step (table p m permutation) (outputPort p m row, values) = none := by
  rw [step_none_iff]
  rintro ⟨index, enabled⟩
  exact no_outgoing_output p m permutation row ⟨index, enabled.1⟩

/-- Complete execution is read-only on the two physical counters. -/
theorem eval_result (permutation : Fin p → Equiv.Perm (Fin m)) (row : Fin m) (value : ℕ) :
    eval (table p m permutation) (point p m (inputPort p m permutation row) value 0) =
      Part.some (point p m
        (outputPort p m (permutation (Counter.DivMod.residue p value) row)) value 0) := by
  apply Part.eq_some_iff.mpr
  exact StateTransition.mem_eval.mpr
    ⟨reaches_result p m permutation row value, halt_output p m permutation _ _⟩

/-- The same fixed three-root compiler executes the observation and returns both memory values. -/
theorem native_eval [NeZero m] (permutation : Fin p → Equiv.Perm (Fin m))
    (row : Fin m) (value : ℕ) :
    (ReversibleCompilation.haltingProgram (table p m permutation)
      (deterministic p m permutation) (targetCompatible p m permutation)).eval
      (ReversibleCompilation.iota (e := edges p m)
        (point p m (inputPort p m permutation row) value 0)) =
      Part.some (ReversibleCompilation.iota (e := edges p m)
        (point p m (outputPort p m (permutation (Counter.DivMod.residue p value) row)) value 0)) := by
  apply ReversibleCompilation.eval_of_reaches
  · exact reaches_result p m permutation row value
  · exact no_outgoing_output p m permutation _

end Monodromy.Counter.Reversible.RadixObservation
