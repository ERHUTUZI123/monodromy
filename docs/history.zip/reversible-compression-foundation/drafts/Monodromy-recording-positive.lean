import Monodromy.Counter

/-! Nonnegative intermediate counter states of the actual reversible recording graph. -/

namespace Monodromy.Counter.Reversible.Radix

variable (p : ℕ) [NeZero p]

/-- The existing finite-port invariant is stable under the actual reversed graph. -/
theorem valid_reverse_step {first last : State 2 (size p)}
    (valid : Valid p first) (transition : step (reverseTable (table p)) first = some last) :
    Valid p last := by
  obtain ⟨index, enabled, rfl⟩ :=
    (step_iff _ (reverseTable_deterministic _ (targetCompatible p))).mp transition
  obtain ⟨arc, rfl⟩ := (arcEquiv p).surjective index
  rcases first with ⟨position, values⟩
  have position_eq : nodeEquiv p (destination p arc) = position := by
    simpa only [reverseTable, reverseEdge, table_arc, Edge.enabled] using enabled.1
  subst position
  have action_enabled : (reverseAction (operation p arc)).enabled values := by
    simpa only [reverseTable, reverseEdge, table_arc] using enabled.2
  clear enabled
  rcases arc with index | ⟨remainder, index⟩ <;> fin_cases index <;>
    simp_all [Valid, admissible, reverseTable, reverseEdge, table_arc, Edge.execute,
      reverseAction, Action.apply, Action.enabled, origin, destination, operation]
  all_goals try omega

end Monodromy.Counter.Reversible.Radix

namespace Monodromy.Counter.Reversible.Recording

variable {n m : ℕ}

def OldNonnegative (values : Fin (n + 2) → ℤ) : Prop :=
  ∀ index : Fin n, 0 ≤ values (Fin.castAdd 2 index)

/-- Copy ports use the existing radix invariant; the decrement middle retains its positive input. -/
def admissible (program : Counter.Program n m) : Node m → (Fin (n + 2) → ℤ) → Prop
  | .inl (_, position), values =>
      Radix.Valid (base m) (position, values ∘ historyRegister n)
  | .inr row, values =>
      0 ≤ values (historyRegister n 0) ∧ values (historyRegister n 1) = 0 ∧
      match program row with
      | .dec register _ _ => 0 < values (Fin.castAdd 2 register)
      | _ => False

def Valid (program : Counter.Program n m) (state : State (n + 2) (size m)) : Prop :=
  OldNonnegative state.2 ∧ admissible program ((nodeEquiv m).symm state.1) state.2

@[simp] theorem valid_copy_iff (program : Counter.Program n m) (row : Fin m)
    (position : Fin (Radix.size (base m))) (values : Fin (n + 2) → ℤ) :
    Valid program (copy row position, values) ↔
      OldNonnegative values ∧ Radix.Valid (base m) (position, values ∘ historyRegister n) := by
  simp only [Valid, copy, Equiv.symm_apply_apply, admissible]

@[simp] theorem valid_mid_iff (program : Counter.Program n m) (row : Fin m)
    (values : Fin (n + 2) → ℤ) :
    Valid program (mid row, values) ↔
      OldNonnegative values ∧ 0 ≤ values (historyRegister n 0) ∧
        values (historyRegister n 1) = 0 ∧
        match program row with
        | .dec register _ _ => 0 < values (Fin.castAdd 2 register)
        | _ => False := by
  simp only [Valid, mid, Equiv.symm_apply_apply, admissible]

@[simp] theorem valid_dispatch_iff (program : Counter.Program n m) (row : Fin m)
    (values : Fin (n + 2) → ℤ) :
    Valid program (dispatch row, values) ↔
      OldNonnegative values ∧ 0 ≤ values (historyRegister n 0) ∧
        values (historyRegister n 1) = 0 := by
  change Valid program (copy row (Radix.entry (base m)), values) ↔ _
  rw [valid_copy_iff]
  simp only [Radix.Valid, Radix.entry, Radix.global, Equiv.symm_apply_apply,
    Radix.admissible, Function.comp_apply, Matrix.cons_val_zero]
  constructor
  · rintro ⟨old, history, _, empty⟩
    exact ⟨old, history, empty⟩
  · rintro ⟨old, history, empty⟩
    exact ⟨old, history, by omega, empty⟩

@[simp] theorem valid_port_iff (program : Counter.Program n m) (row : Fin m)
    (symbol : Fin (base m)) (values : Fin (n + 2) → ℤ) :
    Valid program (port row symbol, values) ↔
      OldNonnegative values ∧ 0 ≤ values (historyRegister n 0) ∧
        0 ≤ values (historyRegister n 1) := by
  change Valid program (copy row (Radix.finish (base m) symbol), values) ↔ _
  rw [valid_copy_iff]
  simp [Radix.Valid, Radix.finish, Radix.block, Radix.admissible]

theorem valid_encode (program : Counter.Program n m) (state : Counter.Configuration n m)
    (history : ℕ) : Valid program (encode state history) := by
  change Valid program (dispatch state.pc, frame state.counters history 0)
  rw [valid_dispatch_iff]
  refine ⟨?_, ?_, ?_⟩
  · intro index
    simpa only [frame_old] using Int.natCast_nonneg (state.counters index)
  · simpa only [frame_history] using Int.natCast_nonneg history
  · exact frame_workspace _ _ _

/-- The invariant certifies every physical source counter, including history and workspace. -/
theorem valid_nonnegative (program : Counter.Program n m) (state : State (n + 2) (size m))
    (valid : Valid program state) (index : Fin (n + 2)) : 0 ≤ state.2 index := by
  induction index using Fin.addCases with
  | left old => exact valid.1 old
  | right tail =>
      change 0 ≤ state.2 (historyRegister n tail)
      rcases state with ⟨position, values⟩
      obtain ⟨node, rfl⟩ := (nodeEquiv m).surjective position
      rcases node with ⟨row, position⟩ | row
      · have tail_valid := ((valid_copy_iff program row position values).mp valid).2
        fin_cases tail
        · exact tail_valid.1
        · exact tail_valid.2.1
      · have tail_valid := (valid_mid_iff program row values).mp valid
        fin_cases tail
        · exact tail_valid.2.1
        · change 0 ≤ values (historyRegister n 1)
          rw [tail_valid.2.2.1]

end Monodromy.Counter.Reversible.Recording

namespace Monodromy.Counter.Reversible.Recording

variable {n m : ℕ}

private theorem tail_ne_old (tail : Fin 2) (old : Fin n) :
    historyRegister n tail ≠ Fin.castAdd 2 old := by
  intro same
  have values := congrArg Fin.val same
  simp only [historyRegister, Fin.val_natAdd, Fin.val_castAdd] at values
  omega

private theorem old_nonnegative_mapped (action : Action 2) (values : Fin (n + 2) → ℤ)
    (old : OldNonnegative values) :
    OldNonnegative ((RegisterRelocation.mapAction (historyRegister n) action).apply values) := by
  intro index
  rw [RegisterRelocation.apply_outside (historyRegister n) action values (Fin.castAdd 2 index)
    (fun tail => tail_ne_old tail index)]
  exact old index

private theorem old_nonnegative_shift (register : Fin n) (amount : ℤ)
    (values : Fin (n + 2) → ℤ) (old : OldNonnegative values)
    (safe : 0 ≤ values (Fin.castAdd 2 register) + amount) :
    OldNonnegative (Action.apply (.shift (Fin.castAdd 2 register) amount) values) := by
  intro index
  by_cases selected : index = register
  · subst index
    simpa only [Action.apply, Function.update_self] using safe
  · simpa [Action.apply, selected] using old index

private theorem shift_old_tail (register : Fin n) (amount : ℤ)
    (values : Fin (n + 2) → ℤ) (tail : Fin 2) :
    Action.apply (.shift (Fin.castAdd 2 register) amount) values (historyRegister n tail) =
      values (historyRegister n tail) :=
  Function.update_of_ne (tail_ne_old tail register) _ _

private theorem valid_port_shift (program : Counter.Program n m) (row : Fin m)
    (symbol : Fin (base m)) (values : Fin (n + 2) → ℤ) (register : Fin n) (amount : ℤ)
    (old : OldNonnegative values) (safe : 0 ≤ values (Fin.castAdd 2 register) + amount)
    (history : 0 ≤ values (historyRegister n 0)) (workspace : 0 ≤ values (historyRegister n 1)) :
    Valid program (port row symbol, Action.apply (.shift (Fin.castAdd 2 register) amount) values) := by
  rw [valid_port_iff]
  exact ⟨old_nonnegative_shift register amount values old safe,
    by rw [shift_old_tail]; exact history,
    by rw [shift_old_tail]; exact workspace⟩

private theorem packing_valid_edge (program : Counter.Program n m) (row : Fin m)
    (index : Fin (Radix.edges (base m))) (values : Fin (n + 2) → ℤ)
    (valid : Valid program (copy row (packing n m index).source, values))
    (enabled : (packing n m index).action.enabled values) :
    Valid program (copy row (packing n m index).target, (packing n m index).action.apply values) := by
  rcases (valid_copy_iff program row _ values).mp valid with ⟨old, radix_valid⟩
  let original := reverseTable (Radix.table (base m)) index
  have guard : original.action.enabled (values ∘ historyRegister n) :=
    (RegisterRelocation.enabled_project (historyRegister n) original.action values).mp enabled
  have transition : step (reverseTable (Radix.table (base m)))
      (original.source, values ∘ historyRegister n) =
      some (original.target, original.action.apply (values ∘ historyRegister n)) := by
    apply (step_iff _ (reverseTable_deterministic _ (Radix.targetCompatible (base m)))).mpr
    exact ⟨index, ⟨rfl, guard⟩, rfl⟩
  have result := Radix.valid_reverse_step (base m) radix_valid transition
  rw [valid_copy_iff]
  refine ⟨old_nonnegative_mapped original.action values old, ?_⟩
  change Radix.Valid (base m)
    (original.target, (RegisterRelocation.mapAction (historyRegister n) original.action).apply values ∘
      historyRegister n)
  rw [RegisterRelocation.apply_project (historyRegister n) (historyRegister_injective n)]
  exact result

private theorem extra_valid_edge (program : Counter.Program n m) (arc : Extra program)
    (values : Fin (n + 2) → ℤ) (valid : Valid program ((extraEdge program arc).source, values))
    (enabled : (extraEdge program arc).action.enabled values) :
    Valid program ((extraEdge program arc).target, (extraEdge program arc).action.apply values) := by
  cases instruction : program arc.val.1 with
  | inc register target =>
      rw [extraEdge_inc program arc register target instruction] at valid enabled ⊢
      rcases (valid_dispatch_iff program arc.val.1 values).mp valid with ⟨old, history, empty⟩
      apply valid_port_shift program target (digit arc.val.1 0) values register 1 old
      · have nonnegative := old register
        omega
      · exact history
      · omega
  | dec register zero nonzero =>
      rw [extraEdge_dec program arc register zero nonzero instruction] at valid enabled ⊢
      rcases arc with ⟨⟨row, branch⟩, active⟩
      fin_cases branch
      · rcases (valid_dispatch_iff program row values).mp valid with ⟨old, history, empty⟩
        change Valid program (port zero (digit row 0), values)
        rw [valid_port_iff]
        exact ⟨old, history, by omega⟩
      · rcases (valid_dispatch_iff program row values).mp valid with ⟨old, history, empty⟩
        change Valid program (mid row, values)
        rw [valid_mid_iff, instruction]
        refine ⟨old, history, empty, ?_⟩
        change Action.enabled (.test (Fin.castAdd 2 register) false) values at enabled
        have not_zero : values (Fin.castAdd 2 register) ≠ 0 := by
          simpa only [Action.enabled, Bool.false_eq_true, iff_false] using enabled
        have nonnegative := old register
        omega
      · rcases (valid_mid_iff program row values).mp valid with ⟨old, history, empty, selected⟩
        have positive : 0 < values (Fin.castAdd 2 register) := by
          simpa only [instruction] using selected
        apply valid_port_shift program nonzero (digit row 1) values register (-1) old
        · omega
        · exact history
        · omega
  | halt =>
      have active := arc.property
      unfold Active at active
      rw [instruction] at active
      exact active.elim

/-- All actual recording transitions preserve the natural counter domain at intermediate ports. -/
theorem valid_step (program : Counter.Program n m) {first last : State (n + 2) (size m)}
    (valid : Valid program first) (transition : step (table program) first = some last) :
    Valid program last := by
  obtain ⟨index, enabled, rfl⟩ := (step_iff _ (deterministic program)).mp transition
  obtain ⟨arc, rfl⟩ := (arcEquiv program).surjective index
  rcases first with ⟨position, values⟩
  have position_eq : (arcEdge program arc).source = position := by
    simpa only [table_arc] using enabled.1
  subst position
  have action_enabled : (arcEdge program arc).action.enabled values := by
    simpa only [table_arc] using enabled.2
  clear enabled
  simp only [table_arc, Edge.execute]
  rcases arc with ⟨row, index⟩ | arc
  · exact packing_valid_edge program row index values valid action_enabled
  · exact extra_valid_edge program arc values valid action_enabled

theorem stable (program : Counter.Program n m) : Stable (table program) (Valid program) :=
  fun {_ _} valid transition => valid_step program valid transition

theorem valid_reaches (program : Counter.Program n m) {first last : State (n + 2) (size m)}
    (valid : Valid program first) (run : StateTransition.Reaches (step (table program)) first last) :
    Valid program last := by
  induction run with
  | refl => exact valid
  | tail _ transition previous => exact valid_step program previous transition

/-- Every intermediate state of every encoded recording run has only nonnegative counters. -/
theorem encode_reaches_nonnegative (program : Counter.Program n m)
    (initial : Counter.Configuration n m) (history : ℕ) {state : State (n + 2) (size m)}
    (run : StateTransition.Reaches (step (table program)) (encode initial history) state)
    (index : Fin (n + 2)) : 0 ≤ state.2 index :=
  valid_nonnegative program state (valid_reaches program (valid_encode program initial history) run) index

end Monodromy.Counter.Reversible.Recording
